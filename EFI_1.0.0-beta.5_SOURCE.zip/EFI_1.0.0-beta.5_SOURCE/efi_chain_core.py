#!/usr/bin/env python3
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import secrets
import time
from dataclasses import dataclass
from typing import Any

from argon2.low_level import Type, hash_secret_raw
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

VERSION = "Entropic Fusion Integrated EFI 0.2.0-alpha"
WARNING = (
    "Research prototype only. Entropic Chain measurements describe tested sequential work only. "
    "They are not extra security bits, a lower bound, or a hardness proof."
)
FAMILIES = (
    "subset_sum",
    "xor_relation",
    "modular_sum",
    "ternary_vector",
    "permutation_assignment",
)
WITNESS_DOMAIN = b"ENTROPIC-FUSION/EFI-0.2/WITNESS/v1"
NODE_CONTEXT_DOMAIN = "ENTROPIC-FUSION/EFI-0.2/NODE-CONTEXT/v1"
GATE_DOMAIN = b"ENTROPIC-FUSION/EFI-0.2/GATE/v1"
TRANSITION_DOMAIN = b"ENTROPIC-FUSION/EFI-0.2/TRANSITION/v1"
FINAL_DOMAIN = b"ENTROPIC-FUSION/EFI-0.2/FINAL/v1"


def canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def b64e(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def b64d(text: str) -> bytes:
    return base64.b64decode(text.encode("ascii"), validate=True)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def xor_values(values) -> int:
    value = 0
    for item in values:
        value ^= int(item)
    return value


@dataclass(frozen=True)
class Profile:
    memory_kib: int = 32768
    time_cost: int = 1
    argon2_parallelism: int = 1

    subset_items: int = 36
    subset_weight_bits: int = 64
    subset_selected: int = 18

    relation_half_items: int = 32
    relation_pick_each_half: int = 6
    xor_bits: int = 64
    modular_prime: int = 2305843009213693951

    vector_items: int = 24
    vector_dimension: int = 4
    vector_coordinate_bits: int = 30

    permutation_size: int = 12
    permutation_cost_bits: int = 52


def chain_schedule(cycles: int, families=FAMILIES) -> list[str]:
    if cycles < 1:
        raise ValueError("cycles must be at least 1")
    chosen = tuple(families)
    if not chosen:
        raise ValueError("at least one family is required")
    unknown = [name for name in chosen if name not in FAMILIES]
    if unknown:
        raise ValueError(f"unsupported family names: {unknown}")
    return list(chosen) * cycles


def permutation_count(n: int, k: int) -> int:
    return math.factorial(n) // math.factorial(n - k)


def public_profile(profile: Profile, schedule: list[str]) -> dict:
    relation_count = math.comb(profile.relation_half_items, profile.relation_pick_each_half)
    half = profile.permutation_size // 2
    return {
        "total_stages": len(schedule),
        "family_counts": {name: schedule.count(name) for name in sorted(set(schedule))},
        "memory_kib_per_witness_check": profile.memory_kib,
        "subset_sum": {
            "items": profile.subset_items,
            "selected": profile.subset_selected,
            "weight_bits": profile.subset_weight_bits,
            "raw_subset_space": 1 << profile.subset_items,
            "reference_half_sum_enumerations": 2 * (1 << (profile.subset_items // 2)),
        },
        "xor_relation": {
            "left_items": profile.relation_half_items,
            "right_items": profile.relation_half_items,
            "pick_left": profile.relation_pick_each_half,
            "pick_right": profile.relation_pick_each_half,
            "bits": profile.xor_bits,
            "raw_balanced_choice_space": relation_count * relation_count,
            "reference_combination_enumerations": 2 * relation_count,
        },
        "modular_sum": {
            "left_items": profile.relation_half_items,
            "right_items": profile.relation_half_items,
            "pick_left": profile.relation_pick_each_half,
            "pick_right": profile.relation_pick_each_half,
            "prime": profile.modular_prime,
            "raw_balanced_choice_space": relation_count * relation_count,
            "reference_combination_enumerations": 2 * relation_count,
        },
        "ternary_vector": {
            "items": profile.vector_items,
            "dimension": profile.vector_dimension,
            "coefficients": [-1, 0, 1],
            "raw_coefficient_space": 3 ** profile.vector_items,
            "reference_half_state_enumerations": 2 * (3 ** (profile.vector_items // 2)),
        },
        "permutation_assignment": {
            "size": profile.permutation_size,
            "raw_assignment_space": math.factorial(profile.permutation_size),
            "reference_half_assignment_enumerations": 2 * permutation_count(profile.permutation_size, half),
        },
    }


def _prf(chain_secret: bytes, chain_id: bytes, index: int, family: str, label: bytes, counter: int = 0) -> bytes:
    if len(chain_secret) != 32:
        raise ValueError("chain secret must be 256 bits")
    msg = (
        WITNESS_DOMAIN + b"\x00" + chain_id + index.to_bytes(4, "big") + b"\x00" +
        family.encode("ascii") + b"\x00" + label + counter.to_bytes(4, "big")
    )
    return hmac.new(chain_secret, msg, hashlib.sha256).digest()


def _ranked_indices(chain_secret: bytes, chain_id: bytes, index: int, family: str, label: bytes, n: int, take: int) -> tuple[int, ...]:
    scored = [(_prf(chain_secret, chain_id, index, family, label + i.to_bytes(2, "big")), i) for i in range(n)]
    scored.sort(key=lambda item: item[0])
    return tuple(sorted(i for _, i in scored[:take]))


def subset_witness_bytes(mask: int, n: int) -> bytes:
    return canonical({"family": "subset_sum", "mask_hex": f"{int(mask):x}", "items": n})


def relation_witness_bytes(family: str, left_indices, right_indices, n: int) -> bytes:
    return canonical({
        "family": family,
        "left": list(map(int, left_indices)),
        "right": list(map(int, right_indices)),
        "half_items": n,
    })


def vector_witness_bytes(coefficients) -> bytes:
    return canonical({"family": "ternary_vector", "coefficients": list(map(int, coefficients))})


def permutation_witness_bytes(columns) -> bytes:
    return canonical({"family": "permutation_assignment", "columns": list(map(int, columns))})


def derive_witness(chain_secret: bytes, chain_id: bytes, index: int, family: str, profile: Profile) -> bytes:
    if family == "subset_sum":
        selected = _ranked_indices(
            chain_secret, chain_id, index, family, b"subset", profile.subset_items, profile.subset_selected
        )
        mask = sum(1 << i for i in selected)
        return subset_witness_bytes(mask, profile.subset_items)
    if family in {"xor_relation", "modular_sum"}:
        left = _ranked_indices(
            chain_secret, chain_id, index, family, b"left", profile.relation_half_items, profile.relation_pick_each_half
        )
        right = _ranked_indices(
            chain_secret, chain_id, index, family, b"right", profile.relation_half_items, profile.relation_pick_each_half
        )
        return relation_witness_bytes(family, left, right, profile.relation_half_items)
    if family == "ternary_vector":
        coefficients = []
        for item in range(profile.vector_items):
            byte = _prf(chain_secret, chain_id, index, family, b"coefficient", item)[0]
            coefficients.append((-1, 0, 1)[byte % 3])
        if all(value == 0 for value in coefficients):
            replacement = int.from_bytes(_prf(chain_secret, chain_id, index, family, b"nonzero")[:4], "big") % profile.vector_items
            coefficients[replacement] = 1
        return vector_witness_bytes(coefficients)
    if family == "permutation_assignment":
        scored = [
            (_prf(chain_secret, chain_id, index, family, b"permutation" + row.to_bytes(2, "big")), row)
            for row in range(profile.permutation_size)
        ]
        scored.sort(key=lambda item: item[0])
        permutation = [row for _, row in scored]
        return permutation_witness_bytes(permutation)
    raise ValueError(f"unsupported family: {family}")


def _decode_witness(witness: bytes) -> dict:
    return json.loads(witness.decode("utf-8"))


def _make_problem(index: int, family: str, witness: bytes, profile: Profile) -> dict:
    decoded = _decode_witness(witness)
    rr = secrets.SystemRandom()
    if family == "subset_sum":
        weights = [secrets.randbits(profile.subset_weight_bits) | 1 for _ in range(profile.subset_items)]
        mask = int(decoded["mask_hex"], 16)
        selected = [i for i in range(profile.subset_items) if (mask >> i) & 1]
        return {
            "weights": weights,
            "target": sum(weights[i] for i in selected),
            "selected_count": profile.subset_selected,
        }
    if family == "xor_relation":
        n = profile.relation_half_items
        left = [secrets.randbits(profile.xor_bits) for _ in range(n)]
        right = [secrets.randbits(profile.xor_bits) for _ in range(n)]
        li = tuple(map(int, decoded["left"]))
        ri = tuple(map(int, decoded["right"]))
        target = xor_values(left[i] for i in li) ^ xor_values(right[i] for i in ri)
        width = (profile.xor_bits + 3) // 4
        return {
            "left_columns_hex": [f"{value:0{width}x}" for value in left],
            "right_columns_hex": [f"{value:0{width}x}" for value in right],
            "target_hex": f"{target:0{width}x}",
            "pick_left": profile.relation_pick_each_half,
            "pick_right": profile.relation_pick_each_half,
            "bits": profile.xor_bits,
        }
    if family == "modular_sum":
        n = profile.relation_half_items
        prime = profile.modular_prime
        left = [secrets.randbelow(prime) for _ in range(n)]
        right = [secrets.randbelow(prime) for _ in range(n)]
        li = tuple(map(int, decoded["left"]))
        ri = tuple(map(int, decoded["right"]))
        target = (sum(left[i] for i in li) + sum(right[i] for i in ri)) % prime
        width = (prime.bit_length() + 3) // 4
        return {
            "left_columns_hex": [f"{value:0{width}x}" for value in left],
            "right_columns_hex": [f"{value:0{width}x}" for value in right],
            "target_hex": f"{target:0{width}x}",
            "pick_left": profile.relation_pick_each_half,
            "pick_right": profile.relation_pick_each_half,
            "prime": prime,
        }
    if family == "ternary_vector":
        bound = 1 << (profile.vector_coordinate_bits - 1)
        vectors = [
            [rr.randrange(-bound, bound) for _ in range(profile.vector_dimension)]
            for _ in range(profile.vector_items)
        ]
        coefficients = list(map(int, decoded["coefficients"]))
        target = [
            sum(coefficients[i] * vectors[i][dimension] for i in range(profile.vector_items))
            for dimension in range(profile.vector_dimension)
        ]
        return {
            "vectors": vectors,
            "target": target,
            "coefficients": [-1, 0, 1],
            "dimension": profile.vector_dimension,
        }
    if family == "permutation_assignment":
        n = profile.permutation_size
        costs = [[secrets.randbits(profile.permutation_cost_bits) for _ in range(n)] for _ in range(n)]
        permutation = list(map(int, decoded["columns"]))
        return {
            "size": n,
            "cost_bits": profile.permutation_cost_bits,
            "costs": costs,
            "target": sum(costs[row][permutation[row]] for row in range(n)),
        }
    raise ValueError(f"unsupported family: {family}")


def node_context(chain_id: bytes, index: int, family: str, problem: dict, profile: Profile) -> bytes:
    return hashlib.sha256(canonical({
        "domain": NODE_CONTEXT_DOMAIN,
        "chain_id": chain_id.hex(),
        "index": index,
        "family": family,
        "problem_sha256": sha256_hex(canonical(problem)),
        "memory_kib": profile.memory_kib,
        "time_cost": profile.time_cost,
        "parallelism": profile.argon2_parallelism,
    })).digest()


def memory_gate(witness: bytes, salt: bytes, context: bytes, profile: Profile) -> bytes:
    return hash_secret_raw(
        secret=GATE_DOMAIN + b"\x00" + witness + context,
        salt=salt,
        time_cost=profile.time_cost,
        memory_cost=profile.memory_kib,
        parallelism=profile.argon2_parallelism,
        hash_len=32,
        type=Type.ID,
    )


def transition_key(gate: bytes, context: bytes) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=TRANSITION_DOMAIN + b"\x00" + context,
    ).derive(gate)


def build_chain(chain_secret: bytes, profile: Profile, schedule: list[str]) -> tuple[dict, bytes, dict]:
    if len(chain_secret) != 32:
        raise ValueError("chain secret must be 256 bits")
    chain_id = secrets.token_bytes(16)
    started = time.perf_counter()
    nodes = []
    witnesses = []
    for index, family in enumerate(schedule, 1):
        witness = derive_witness(chain_secret, chain_id, index, family, profile)
        problem = _make_problem(index, family, witness, profile)
        node = {
            "node_version": 1,
            "index": index,
            "type": family,
            "problem": problem,
            "salt_b64": b64e(secrets.token_bytes(16)),
        }
        nodes.append(node)
        witnesses.append(witness)

    terminal = secrets.token_bytes(32)
    transitions = {}
    gate_seconds = 0.0
    for index, node in enumerate(nodes, 1):
        context = node_context(chain_id, index, node["type"], node["problem"], profile)
        gate_started = time.perf_counter()
        gate = memory_gate(witnesses[index - 1], b64d(node["salt_b64"]), context, profile)
        gate_seconds += time.perf_counter() - gate_started
        key = transition_key(gate, context)
        nonce = secrets.token_bytes(12)
        if index < len(nodes):
            plaintext = canonical({"kind": "node", "node": nodes[index]})
        else:
            plaintext = canonical({"kind": "terminal", "terminal_b64": b64e(terminal)})
        ciphertext = AESGCM(key).encrypt(nonce, plaintext, context)
        transitions[str(index)] = {"nonce_b64": b64e(nonce), "ciphertext_b64": b64e(ciphertext)}

    capsule = {
        "version": VERSION,
        "warning": WARNING,
        "layout": "sequential encrypted transition envelopes",
        "chain_id_hex": chain_id.hex(),
        "profile": public_profile(profile, schedule),
        "chain_schedule": list(schedule),
        "first_node": nodes[0],
        "transitions": transitions,
    }
    return capsule, terminal, {
        "stages": len(schedule),
        "build_seconds": time.perf_counter() - started,
        "gate_seconds": gate_seconds,
        "terminal_sha256": sha256_hex(terminal),
    }


def open_next(capsule: dict, node: dict, witness: bytes, profile: Profile) -> bytes:
    chain_id = bytes.fromhex(capsule["chain_id_hex"])
    index = int(node["index"])
    context = node_context(chain_id, index, node["type"], node["problem"], profile)
    gate = memory_gate(witness, b64d(node["salt_b64"]), context, profile)
    key = transition_key(gate, context)
    envelope = capsule["transitions"][str(index)]
    return AESGCM(key).decrypt(b64d(envelope["nonce_b64"]), b64d(envelope["ciphertext_b64"]), context)


def try_candidate(capsule: dict, node: dict, witness: bytes, profile: Profile) -> bytes | None:
    try:
        return open_next(capsule, node, witness, profile)
    except InvalidTag:
        return None


def legitimate_traverse(capsule: dict, chain_secret: bytes, profile: Profile) -> tuple[bytes, dict]:
    chain_id = bytes.fromhex(capsule["chain_id_hex"])
    schedule = list(capsule["chain_schedule"])
    node = capsule["first_node"]
    stage_seconds = []
    started = time.perf_counter()
    terminal = None
    for index, family in enumerate(schedule, 1):
        stage_started = time.perf_counter()
        witness = derive_witness(chain_secret, chain_id, index, family, profile)
        plaintext = open_next(capsule, node, witness, profile)
        stage_seconds.append(time.perf_counter() - stage_started)
        decoded = json.loads(plaintext.decode("utf-8"))
        if index < len(schedule):
            node = decoded["node"]
        else:
            terminal = b64d(decoded["terminal_b64"])
    if terminal is None:
        raise RuntimeError("terminal token was not produced")
    return terminal, {
        "stages": len(schedule),
        "seconds": time.perf_counter() - started,
        "per_stage_seconds": stage_seconds,
        "terminal_sha256": sha256_hex(terminal),
    }


def final_key(chain_secret: bytes, terminal: bytes, context: bytes) -> bytes:
    if len(chain_secret) != 32 or len(terminal) != 32:
        raise ValueError("final key inputs must each be 256 bits")
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=hashlib.sha256(context).digest(),
        info=FINAL_DOMAIN + b"\x00" + context,
    ).derive(chain_secret + terminal)
