#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import os
import queue
import re
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import entropic_fusion_integrated_efi_0_5_0 as backend
import efi_private_envelope as privacy
import efi_deniable_container as deniable
from efi_help_content import HELP_SECTIONS, HELP_BY_KEY

VERSION = "Entropic Fusion Integrated EFI 1.0.0-beta.5"
ITERATION = "EFI_ITER_021"
BACKEND_VERSION = backend.VERSION
WINDOW_TITLE = "Entropic Fusion Integrated"
WINFSP_EXPECTED_VERSION = "2.1.25156"
WINFSP_EXPECTED_SHA256 = "073a70e00f77423e34bed98b86e600def93393ba5822204fac57a29324db9f7a"
WINFSP_SOURCE_URL = "https://github.com/winfsp/winfsp/releases/download/v2.1/winfsp-2.1.25156.msi"

# Visual lineage comes from the Beta 1.1.1 desktop shell.
BG = "#F4F7FB"
PANEL = "#FFFFFF"
NAVY = "#101828"
INK = "#172033"
MUTED = "#667085"
ACCENT = "#1877F2"
ACCENT_DARK = "#125DC0"
SUCCESS = "#15803D"
WARN = "#A16207"
DANGER = "#B42318"
BORDER = "#D8E0EA"


def resource_root() -> Path:
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        return Path(meipass)
    return Path(__file__).resolve().parent


def et013_dir() -> Path:
    return resource_root() / "et013_frozen"


def beta111_dir() -> Path:
    return et013_dir() / "beta1_1_1_rebuild_kit"


def bundled_winfsp_msi() -> Path:
    return resource_root() / "third_party" / "winfsp-2.1.25156.msi"


def _winfsp_locations() -> list[Path]:
    if os.name != "nt":
        return []
    return [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "WinFsp",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "WinFsp",
    ]


def winfsp_present() -> bool:
    return any(p.exists() for p in _winfsp_locations()) if os.name == "nt" else False


def _safe_error(exc: BaseException) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    text = re.sub(r"-----BEGIN [^-]+-----.*?-----END [^-]+-----", "[key material omitted]", text, flags=re.S)
    text = re.sub(r"(?i)(password\s*[=:]\s*)\S+", r"\1[omitted]", text)
    return text[:1200] + ("…" if len(text) > 1200 else "")


def _human_bytes(value: int) -> str:
    n = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{value} B"


def _human_seconds(value: float) -> str:
    if value < 1:
        return f"{value * 1000:.0f} ms"
    if value < 60:
        return f"{value:.2f} s"
    m, s = divmod(value, 60)
    if m < 60:
        return f"{int(m)}m {s:.0f}s"
    h, m = divmod(m, 60)
    return f"{int(h)}h {int(m)}m"


def _unique_output(path: Path) -> Path:
    if not path.exists():
        return path
    for i in range(1, 10000):
        candidate = path.with_name(f"{path.stem}.decrypted-{i}{path.suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError("could not choose a non-conflicting output filename")


def inspect_capsule(path: Path) -> dict:
    path = Path(path)
    if deniable.is_deniable_container(path):
        return deniable.public_inspect(path)
    return privacy.public_inspect(path)


def headless_deniable_probe() -> dict:
    etd = et013_dir()
    if not etd.is_dir():
        raise FileNotFoundError(f"frozen ET 0.13 dependency not found: {etd}")
    return deniable.deniable_regression_probe(etd)


def runtime_probe(check_crypto: bool = False) -> dict:
    etd = et013_dir()
    out = {
        "version": VERSION,
        "iteration": ITERATION,
        "backend_version": BACKEND_VERSION,
        "root_engine_expected": backend.ROOT_ENGINE_VERSION,
        "et013_dir": str(etd),
        "et013_source_present": (etd / "entropic_tetration_et_0_13_0.py").is_file(),
        "beta111_source_present": (beta111_dir() / "entropic_bound_fusion_v0_11B_23_1.py").is_file(),
        "beta111_desktop_source_present": (beta111_dir() / "entropic_fusion_desktop_beta1_1_1.py").is_file(),
        "vault_host_present": ((Path(sys.executable).resolve().parent / "EntropicFusionHost.exe").is_file() if getattr(sys, "frozen", False) else (beta111_dir() / "entropic_mount_host_aclpipe_beta1_1_1.py").is_file()),
        "windows": os.name == "nt",
        "winfsp_present": winfsp_present(),
        "bundled_winfsp_msi_present": bundled_winfsp_msi().is_file(),
        "winfsp_expected_version": WINFSP_EXPECTED_VERSION,
        "winfsp_expected_msi_sha256": WINFSP_EXPECTED_SHA256,
        "crypto_checked": False,
    }
    if check_crypto:
        try:
            engine = backend.load_root_engine(etd)
            mlkem = backend.load_mlkem(etd)
            openssl = mlkem.check_available()
            out.update({
                "crypto_checked": True,
                "root_engine_loaded": getattr(engine, "VERSION", None) == backend.ROOT_ENGINE_VERSION,
                "mlkem_available": True,
                "openssl": openssl,
            })
        except Exception as exc:
            out.update({
                "crypto_checked": True,
                "root_engine_loaded": False,
                "mlkem_available": False,
                "crypto_error": _safe_error(exc),
            })
    return out


def ui_feature_probe() -> dict:
    return {
        "version": VERSION,
        "iteration": ITERATION,
        "tabs": ["Home", "Vault", "Identity", "Encrypt", "Decrypt", "Deniable", "Entropic Engine", "Inspect", "Self-Test", "Activity", "Help"],
        "features": {
            "beta111_visual_lineage": True,
            "beta111_full_vault_manager_launcher": True,
            "tetration_switch": True,
            "pentation_switch": True,
            "standard_switch": True,
            "live_hyperoperation_plan": True,
            "engine_demo": True,
            "benchmark": True,
            "cancel": True,
            "progress_bar": True,
            "efi_identity": True,
            "efi_encrypt": True,
            "efi_decrypt": True,
            "capsule_inspect": True,
            "adaptive_window_geometry": True,
            "bundled_winfsp_repair_button": True,
            "offline_installer_policy": True,
            "metadata_private_outer_envelope": True,
            "opaque_capsule_filename": True,
            "legacy_capsule_decrypt_compatibility": True,
            "searchable_professional_help": True,
            "large_file_streaming": True,
            "graduated_padding_buckets": True,
            "encrypted_zero_padding": True,
            "stream_cancel_and_progress": True,
            "deniable_dual_profile": True,
            "duress_credential": True,
            "fixed_opaque_reserve": True,
            "dual_mlkem_fusion_wording": True,
            "hndl_guidance": True,
            "help_word_count_hidden": True,
            "scrollable_long_form_tabs": True,
            "visible_resize_grip": True,
            "responsive_deniable_layout": True,
        },
    }


def headless_roundtrip_probe() -> dict:
    etd = et013_dir()
    if not etd.is_dir():
        raise FileNotFoundError(f"frozen ET 0.13 dependency not found: {etd}")
    started = time.perf_counter()
    r = privacy.privacy_regression_probe(etd)
    if r.get("status") != "PASS":
        raise AssertionError("metadata-privacy regression failed: " + repr(r))
    r = dict(r)
    r.update({
        "version": VERSION,
        "status": "PASS",
        "stages": 5,
        "metadata_privacy": "PROTECTED",
        "seconds": time.perf_counter() - started,
    })
    return r


def _adaptive_geometry(root) -> None:
    root.update_idletasks()
    width, height, left, top = 1180, 760, 60, 40
    if os.name == "nt":
        try:
            from ctypes import wintypes
            class RECT(ctypes.Structure):
                _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]
            class MONITORINFO(ctypes.Structure):
                _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", RECT), ("rcWork", RECT), ("dwFlags", wintypes.DWORD)]
            user32 = ctypes.windll.user32
            mon = user32.MonitorFromWindow(root.winfo_id(), 2)
            mi = MONITORINFO(); mi.cbSize = ctypes.sizeof(MONITORINFO)
            if user32.GetMonitorInfoW(mon, ctypes.byref(mi)):
                ww = mi.rcWork.right - mi.rcWork.left
                wh = mi.rcWork.bottom - mi.rcWork.top
                width = min(1180, max(800, int(ww * 0.90)))
                height = min(780, max(560, int(wh * 0.88)))
                width = min(width, max(640, ww - 20)); height = min(height, max(480, wh - 20))
                left = mi.rcWork.left + max(8, (ww - width) // 2)
                top = mi.rcWork.top + max(8, (wh - height) // 2)
        except Exception:
            pass
    root.geometry(f"{width}x{height}+{left}+{top}")
    root.minsize(760, 520)


def _launch_vault_manager_child() -> None:
    if getattr(sys, "frozen", False):
        subprocess.Popen([sys.executable, "--vault-manager"], close_fds=True)
    else:
        subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "--vault-manager"], close_fds=True)


def _vault_manager_main() -> int:
    kit = beta111_dir()
    if not kit.is_dir():
        raise FileNotFoundError("Beta 1.1.1 vault manager is not bundled")
    sys.path.insert(0, str(kit))
    from entropic_fusion_desktop_beta1_1_1 import DesktopApp
    DesktopApp().mainloop()
    return 0


def _install_bundled_winfsp() -> None:
    if os.name != "nt":
        raise RuntimeError("WinFsp installation is only available on Windows")
    msi = bundled_winfsp_msi()
    if not msi.is_file():
        raise FileNotFoundError("The bundled WinFsp installer is not present in this build")
    got = hashlib.sha256(msi.read_bytes()).hexdigest()
    if got != WINFSP_EXPECTED_SHA256:
        raise RuntimeError("Bundled WinFsp MSI hash mismatch")
    params = f'/i "{msi}" /passive /norestart'
    rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", "msiexec.exe", params, None, 1)
    if rc <= 32:
        raise RuntimeError("Windows did not start the WinFsp installer")


def launch_gui() -> int:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk(); root.withdraw()
    root.title(f"{WINDOW_TITLE} - EFI 1.0.0-beta.5")
    root.configure(bg=BG)
    root.resizable(True, True)
    _adaptive_geometry(root)

    style = ttk.Style(root)
    try: style.theme_use("clam")
    except Exception: pass
    style.configure(".", font=("Segoe UI", 10))
    style.configure("App.TFrame", background=BG)
    style.configure("Panel.TFrame", background=PANEL)
    style.configure("Header.TFrame", background=NAVY)
    style.configure("Header.TLabel", background=NAVY, foreground="white")
    style.configure("Title.TLabel", background=NAVY, foreground="white", font=("Segoe UI Semibold", 22))
    style.configure("SubTitle.TLabel", background=NAVY, foreground="#D8E4F4", font=("Segoe UI", 10))
    style.configure("Hero.TLabel", background=PANEL, foreground=INK, font=("Segoe UI Semibold", 24))
    style.configure("HeroSub.TLabel", background=PANEL, foreground=MUTED, font=("Segoe UI", 11))
    style.configure("CardTitle.TLabel", background=PANEL, foreground=INK, font=("Segoe UI Semibold", 13))
    style.configure("Body.TLabel", background=PANEL, foreground=MUTED)
    style.configure("Muted.TLabel", background=BG, foreground=MUTED)
    style.configure("Danger.TLabel", background=BG, foreground=DANGER, font=("Segoe UI Semibold", 10))
    style.configure("Metric.TLabel", background=PANEL, foreground=INK, font=("Segoe UI Semibold", 16))
    style.configure("MetricSub.TLabel", background=PANEL, foreground=MUTED, font=("Segoe UI", 9))
    style.configure("Primary.TButton", padding=(16, 10), font=("Segoe UI Semibold", 10))
    style.map("Primary.TButton", background=[("active", ACCENT_DARK), ("!disabled", ACCENT)], foreground=[("!disabled", "white")])
    style.configure("Soft.TButton", padding=(13, 9))
    style.configure("Pretty.TNotebook", background=BG, borderwidth=0)
    style.configure("Pretty.TNotebook.Tab", padding=(14, 10), font=("Segoe UI Semibold", 9), borderwidth=0)
    style.map("Pretty.TNotebook.Tab", background=[("selected", ACCENT), ("active", "#DDEBFF"), ("!selected", BG)], foreground=[("selected", "white"), ("active", ACCENT_DARK), ("!selected", MUTED)])

    work_q: queue.Queue = queue.Queue()
    cancel_event = threading.Event()
    busy = {"value": False, "started": 0.0, "label": ""}
    last_output = {"path": ""}
    last_details = {"value": {}}
    activity_lines: list[str] = []
    action_buttons: list = []

    shell = ttk.Frame(root, style="App.TFrame"); shell.pack(fill="both", expand=True)
    header = ttk.Frame(shell, style="Header.TFrame", padding=(24, 17)); header.pack(fill="x")
    left = ttk.Frame(header, style="Header.TFrame"); left.pack(side="left", fill="x", expand=True)
    ttk.Label(left, text="Entropic Fusion Integrated", style="Title.TLabel").pack(anchor="w")
    ttk.Label(left, text="Entropic Fusion = Entropic Notation + ML-KEM-768 + ML-KEM-1024  |  ET  |  EC100  |  Deniable  |  Vault", style="SubTitle.TLabel").pack(anchor="w", pady=(3, 0))
    header_status = tk.StringVar(value="System ready")
    ttk.Label(header, textvariable=header_status, style="Header.TLabel").pack(side="right")

    body = ttk.Frame(shell, style="App.TFrame", padding=(18, 12, 18, 8)); body.pack(fill="both", expand=True)
    nb = ttk.Notebook(body, style="Pretty.TNotebook"); nb.pack(fill="both", expand=True)

    # Long-form pages are scrollable so controls can never be hidden below the
    # visible client area on laptops, scaled displays or mixed-DPI monitors.
    scrollable_names = {"Home", "Vault", "Identity", "Encrypt", "Decrypt", "Deniable", "Entropic Engine", "Inspect"}
    tabs = {}
    tab_views = {}
    scroll_canvases = {}

    def _make_scrollable_tab(name: str):
        outer = ttk.Frame(nb, style="App.TFrame")
        canvas = tk.Canvas(outer, background=BG, highlightthickness=0, borderwidth=0)
        vbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vbar.set)
        vbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        inner = ttk.Frame(canvas, style="App.TFrame", padding=16)
        window_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda _e, c=canvas: c.configure(scrollregion=c.bbox("all")))
        canvas.bind("<Configure>", lambda e, c=canvas, w=window_id: c.itemconfigure(w, width=max(1, e.width)))
        scroll_canvases[name] = (outer, canvas)
        return outer, inner

    for name in ("Home", "Vault", "Identity", "Encrypt", "Decrypt", "Deniable", "Entropic Engine", "Inspect", "Self-Test", "Activity", "Help"):
        if name in scrollable_names:
            view, content = _make_scrollable_tab(name)
        else:
            view = ttk.Frame(nb, style="App.TFrame", padding=16)
            content = view
        nb.add(view, text=name)
        tab_views[name] = view
        tabs[name] = content

    def _scroll_long_tab(event):
        try:
            selected = nb.select()
            widget = root.winfo_containing(root.winfo_pointerx(), root.winfo_pointery())
            if widget is None or widget.winfo_class() in {"Text", "Treeview", "Listbox"}:
                return None
            for _name, (view, canvas) in scroll_canvases.items():
                if selected == str(view) and str(widget).startswith(str(view)):
                    delta = int(-1 * (event.delta / 120)) if getattr(event, "delta", 0) else 0
                    if delta:
                        canvas.yview_scroll(delta, "units")
                        return "break"
        except Exception:
            return None
        return None

    root.bind_all("<MouseWheel>", _scroll_long_tab, add="+")

    footer = ttk.Frame(shell, style="App.TFrame", padding=(18, 2, 10, 8)); footer.pack(fill="x")
    status_var = tk.StringVar(value="Ready")
    timing_var = tk.StringVar(value="")
    ttk.Label(footer, textvariable=status_var, style="Muted.TLabel").pack(side="left")
    ttk.Sizegrip(footer).pack(side="right", anchor="se", padx=(8, 0))
    ttk.Label(footer, text=f"{ITERATION}  •  ET 0.13  •  EFI private/deniable envelopes  •  EFI 0.5 inner backend  •  EC100", style="Muted.TLabel").pack(side="right")

    def log(text: str):
        stamp = time.strftime("%H:%M:%S")
        line = f"[{stamp}] {text}"
        activity_lines.append(line)
        if len(activity_lines) > 500: del activity_lines[:-500]
        if 'activity_box' in locals_ref:
            box = locals_ref['activity_box']; box.configure(state="normal"); box.insert("end", line + "\n"); box.see("end"); box.configure(state="disabled")

    locals_ref = {}

    def card(parent, title, body_text=""):
        outer = ttk.Frame(parent, style="Panel.TFrame", padding=18)
        ttk.Label(outer, text=title, style="CardTitle.TLabel").pack(anchor="w")
        if body_text:
            ttk.Label(outer, text=body_text, style="Body.TLabel", wraplength=520, justify="left").pack(anchor="w", pady=(5, 10))
        return outer

    def set_busy(value: bool, label: str = ""):
        busy["value"] = value; busy["label"] = label
        for b in action_buttons:
            try: b.configure(state="disabled" if value else "normal")
            except Exception: pass
        if value:
            busy["started"] = time.perf_counter(); status_var.set(label); header_status.set(label); timing_var.set("Working…")
        else:
            elapsed = time.perf_counter() - busy.get("started", time.perf_counter())
            timing_var.set(_human_seconds(elapsed)); header_status.set("System ready")

    def start_task(label, fn, on_success=None, on_progress=None):
        if busy["value"]: return
        cancel_event.clear(); set_busy(True, label); log(label)
        def runner():
            try: work_q.put(("done", fn(), on_success, None))
            except Exception as exc: work_q.put(("error", None, None, exc))
        threading.Thread(target=runner, daemon=True).start()

    def pump_queue():
        try:
            while True:
                kind, result, callback, exc = work_q.get_nowait()
                if kind == "done":
                    set_busy(False)
                    if callback: callback(result)
                else:
                    set_busy(False); msg = _safe_error(exc); status_var.set("Operation failed"); log("ERROR: " + msg); messagebox.showerror("Entropic Fusion", msg)
        except queue.Empty: pass
        if busy["value"]:
            elapsed = time.perf_counter() - busy["started"]
            timing_var.set(f"{busy['label']}  •  {_human_seconds(elapsed)}")
        root.after(120, pump_queue)

    def browse_open(var, title, types, after=None):
        p = filedialog.askopenfilename(title=title, filetypes=types)
        if p:
            var.set(p)
            if after: after(p)

    def browse_save(var, title, ext, types):
        p = filedialog.asksaveasfilename(title=title, defaultextension=ext, filetypes=types)
        if p: var.set(p)

    def browse_dir(var, title):
        initial = var.get().strip() or str(Path.home())
        p = filedialog.askdirectory(title=title, initialdir=initial if Path(initial).is_dir() else str(Path.home()))
        if p: var.set(p)

    def open_parent(path):
        p = Path(path)
        target = p if p.is_dir() else p.parent
        if os.name == "nt": os.startfile(str(target))

    # HOME
    home = tabs["Home"]
    hero = ttk.Frame(home, style="Panel.TFrame", padding=(26, 24)); hero.pack(fill="x", pady=(0, 12))
    ttk.Label(hero, text="One application. Whole EFI stack.", style="Hero.TLabel").pack(anchor="w")
    ttk.Label(hero, text="Entropic Fusion binds Entropic Notation with dual NIST-standardised post-quantum key establishment: ML-KEM-768 + ML-KEM-1024. AES-256-GCM protects the data.", style="HeroSub.TLabel", wraplength=1050).pack(anchor="w", pady=(4, 4))
    ttk.Label(hero, text="HNDL: Harvest Now, Decrypt Later means encrypted material copied today may be stored for future quantum attacks. EFI uses post-quantum ML-KEM at the root so long-term key establishment does not depend on classical RSA/ECC.", style="HeroSub.TLabel", wraplength=1050).pack(anchor="w", pady=(0, 14))
    actions = ttk.Frame(hero, style="Panel.TFrame"); actions.pack(fill="x")
    for label, tabname in (("Encrypt a file", "Encrypt"), ("Decrypt a file", "Decrypt"), ("Entropic Engine", "Entropic Engine"), ("Vault Manager", "Vault")):
        ttk.Button(actions, text=label, style="Primary.TButton" if label == "Encrypt a file" else "Soft.TButton", command=lambda n=tabname: nb.select(tab_views[n])).pack(side="left", padx=(0, 8))

    metrics = ttk.Frame(home, style="App.TFrame"); metrics.pack(fill="x");
    for i in range(4): metrics.columnconfigure(i, weight=1)
    probes = runtime_probe(False)
    metric_data = [
        ("FUSION", "Notation + 768 + 1024", "Mutually bound root path"),
        ("HNDL", "Harvest Now, Decrypt Later", "Post-quantum key establishment"),
        ("ET + EC", "Tetration/Pentation + EC100", "Finite evolution + 100-stage chain"),
        ("PRIVATE", "EFI envelope", "Metadata privacy + deniable option"),
    ]
    for i, (big, title, small) in enumerate(metric_data):
        c = ttk.Frame(metrics, style="Panel.TFrame", padding=16); c.grid(row=0, column=i, sticky="nsew", padx=(0 if i==0 else 4, 0 if i==3 else 4))
        ttk.Label(c, text=big, style="Metric.TLabel").pack(anchor="w"); ttk.Label(c, text=title, style="CardTitle.TLabel").pack(anchor="w", pady=(2,0)); ttk.Label(c, text=small, style="Body.TLabel").pack(anchor="w", pady=(2,0))

    # VAULT
    vault = tabs["Vault"]
    ttk.Label(vault, text="Entropic Vault", style="Hero.TLabel").pack(anchor="w")
    ttk.Label(vault, text="The full validated Beta 1.1.1 vault manager is packaged inside this application. WinFsp is bundled by the installer and can also be repaired from the application.", style="HeroSub.TLabel", wraplength=900).pack(anchor="w", pady=(3, 14))
    vc = card(vault, "Vault workspace", "Open the full Entropic Vault manager for create, mount, dismount, storage health and compact/rekey operations."); vc.pack(fill="x", pady=(0, 10))
    vstat = tk.StringVar(value=("WinFsp installed" if winfsp_present() else "WinFsp is not currently installed"))
    ttk.Label(vc, textvariable=vstat, style="Body.TLabel").pack(anchor="w", pady=(0, 8))
    vb = ttk.Frame(vc, style="Panel.TFrame"); vb.pack(anchor="w")
    open_vault_btn = ttk.Button(vb, text="Open Full Vault Manager", style="Primary.TButton", command=_launch_vault_manager_child); open_vault_btn.pack(side="left", padx=(0,8)); action_buttons.append(open_vault_btn)
    def install_winfsp_click():
        try:
            _install_bundled_winfsp(); messagebox.showinfo("WinFsp", "Windows has started the bundled WinFsp installer. Complete the UAC prompt, then reopen or refresh the vault manager.")
        except Exception as exc: messagebox.showerror("WinFsp", _safe_error(exc))
    repair_btn = ttk.Button(vb, text="Install / Repair Bundled WinFsp", style="Soft.TButton", command=install_winfsp_click); repair_btn.pack(side="left"); action_buttons.append(repair_btn)
    info = card(vault, "What is bundled", f"Beta 1.1.1 vault engine and manager\nWinFsp {WINFSP_EXPECTED_VERSION}\nExpected WinFsp SHA-256: {WINFSP_EXPECTED_SHA256}\nNo network download is required on the target machine when using the finished installer.")
    info.pack(fill="x")

    # IDENTITY
    ident = tabs["Identity"]
    ttk.Label(ident, text="EFI recipient identity", style="Hero.TLabel").grid(row=0, column=0, columnspan=3, sticky="w")
    ttk.Label(ident, text="Creates an EFI public identity and a password-protected private identity. Share only the public file.", style="HeroSub.TLabel").grid(row=1, column=0, columnspan=3, sticky="w", pady=(3, 12))
    id_pub = tk.StringVar(value=str(Path.home()/"EFI recipient.efi-public.json")); id_prv = tk.StringVar(value=str(Path.home()/"EFI recipient.efi-private.json")); id_pw = tk.StringVar(); id_confirm = tk.StringVar(); id_result = tk.StringVar()
    for row, (lab, var, ext, types) in enumerate((("Public identity", id_pub, ".json", [("EFI public identity","*.json"),("All files","*.*")]), ("Private identity", id_prv, ".json", [("EFI private identity","*.json"),("All files","*.*")])) , start=2):
        ttk.Label(ident, text=lab).grid(row=row,column=0,sticky="w",pady=4); ttk.Entry(ident,textvariable=var).grid(row=row,column=1,sticky="ew",padx=8); ttk.Button(ident,text="Browse…",command=lambda v=var,t=lab,e=ext,ft=types:browse_save(v,"Save "+t,e,ft)).grid(row=row,column=2)
    ttk.Label(ident,text="Password").grid(row=4,column=0,sticky="w",pady=(10,4)); ttk.Entry(ident,textvariable=id_pw,show="•").grid(row=4,column=1,sticky="ew",padx=8)
    ttk.Label(ident,text="Confirm").grid(row=5,column=0,sticky="w",pady=4); ttk.Entry(ident,textvariable=id_confirm,show="•").grid(row=5,column=1,sticky="ew",padx=8)
    def do_identity():
        if len(id_pw.get()) < 10: raise ValueError("password must be at least 10 characters")
        if id_pw.get() != id_confirm.get(): raise ValueError("password confirmation does not match")
        pub, prv = Path(id_pub.get()), Path(id_prv.get())
        if pub.exists() or prv.exists(): raise FileExistsError("refusing to overwrite an existing identity file")
        return backend.generate_identity(et013_dir(), pub, prv, id_pw.get())
    def identity_done(r):
        id_result.set(f"Identity ready • fingerprint {r.get('public_fingerprint','')[:24]}…"); id_pw.set(""); id_confirm.set(""); last_output['path']=id_pub.get(); log("EFI identity created"); messagebox.showinfo("Identity", "EFI identity created successfully.")
    id_btn = ttk.Button(ident,text="Create EFI Identity",style="Primary.TButton",command=lambda:start_task("Generating EFI identity…",do_identity,identity_done)); id_btn.grid(row=6,column=1,sticky="w",padx=8,pady=(8,0)); action_buttons.append(id_btn)
    ttk.Label(ident,textvariable=id_result,style="Muted.TLabel").grid(row=7,column=0,columnspan=3,sticky="w",pady=(12,0)); ident.columnconfigure(1,weight=1)
    ttk.Separator(ident).grid(row=8,column=0,columnspan=3,sticky="ew",pady=18)
    ttk.Label(ident,text="Entropic Vault identities",style="CardTitle.TLabel").grid(row=9,column=0,columnspan=3,sticky="w")
    ttk.Label(ident,text="Vault identities (.efpub / .efprivx) remain available through the packaged Beta 1.1.1 Vault Manager.",style="Muted.TLabel").grid(row=10,column=0,columnspan=3,sticky="w",pady=(4,8))
    ttk.Button(ident,text="Open Vault Identity Tools",style="Soft.TButton",command=_launch_vault_manager_child).grid(row=11,column=0,sticky="w")

    # ENGINE shared variables used by Encrypt too
    mode = tk.StringVar(value="Tetration"); hyper_base = tk.StringVar(value="2"); hyper_height = tk.StringVar(value="4"); standard_steps = tk.StringVar(value="0"); ec_cycles = tk.StringVar(value="20")
    plan_text = tk.StringVar(value=""); engine_status = tk.StringVar(value="Engine ready"); engine_timing = tk.StringVar(value=""); engine_progress = tk.DoubleVar(value=0)

    def current_plan(show_error=False):
        try:
            engine = backend.load_root_engine(et013_dir())
            m = mode.get().lower(); b=int(hyper_base.get() or '2'); h=int(hyper_height.get() or '1'); ss=int(standard_steps.get() or '0')
            p = engine.virtual_plan(m,b,h,ss)
            if p.get('steps') is None: plan_text.set(p['description'] + "  •  symbolic only")
            else: plan_text.set(f"{p['description']}  •  EC {int(ec_cycles.get() or '20')*5} stages")
            return p
        except Exception as exc:
            plan_text.set(_safe_error(exc))
            if show_error: messagebox.showerror("Entropic Engine", _safe_error(exc))
            return None
    def mode_changed(*_):
        if mode.get()=="Tetration": hyper_base.set("2"); hyper_height.set("4")
        elif mode.get()=="Pentation": hyper_base.set("2"); hyper_height.set("3")
        current_plan()
    for v in (mode,hyper_base,hyper_height,standard_steps,ec_cycles): v.trace_add('write',lambda *_: current_plan())
    mode.trace_add('write',mode_changed); current_plan()

    # ENCRYPT
    enc = tabs["Encrypt"]
    ttk.Label(enc,text="Encrypt file",style="Hero.TLabel").grid(row=0,column=0,columnspan=4,sticky="w")
    ttk.Label(enc,text="Creates a metadata-private streaming EFI 1.0.0-beta.5 envelope. Large files are processed in bounded chunks; original filename, exact size and workflow metadata remain encrypted.",style="HeroSub.TLabel").grid(row=1,column=0,columnspan=4,sticky="w",pady=(3,12))
    enc_pub=tk.StringVar(); enc_in=tk.StringVar(); enc_out=tk.StringVar(); enc_result=tk.StringVar(); enc_progress=tk.DoubleVar(value=0.0); enc_progress_text=tk.StringVar(value="")
    def enc_selected(p):
        # Do not leak the source filename through the filesystem name of the capsule.
        enc_out.set(str(Path(p).parent / privacy.suggest_capsule_name()))
    rows=[("Recipient public identity",enc_pub,[("EFI public identity","*.json"),("All files","*.*")],None),("Input file",enc_in,[("All files","*.*")],enc_selected)]
    for r,(lab,var,fts,after) in enumerate(rows,start=2):
        ttk.Label(enc,text=lab).grid(row=r,column=0,sticky="w",pady=4); ttk.Entry(enc,textvariable=var).grid(row=r,column=1,columnspan=2,sticky="ew",padx=8); ttk.Button(enc,text="Browse…",command=lambda v=var,l=lab,f=fts,a=after:browse_open(v,"Choose "+l,f,a)).grid(row=r,column=3)
    ttk.Label(enc,text="EFI capsule").grid(row=4,column=0,sticky="w",pady=4); ttk.Entry(enc,textvariable=enc_out).grid(row=4,column=1,columnspan=2,sticky="ew",padx=8); ttk.Button(enc,text="Browse…",command=lambda:browse_save(enc_out,"Save EFI capsule",".efi",[("EFI capsule","*.efi"),("All files","*.*")])).grid(row=4,column=3)
    settings=ttk.Frame(enc,style="Panel.TFrame",padding=14); settings.grid(row=5,column=0,columnspan=4,sticky="ew",pady=(12,8))
    ttk.Label(settings,text="Entropic Engine",style="CardTitle.TLabel").grid(row=0,column=0,columnspan=8,sticky="w",pady=(0,8))
    for i,name in enumerate(("Standard","Tetration","Pentation")): ttk.Radiobutton(settings,text=name,variable=mode,value=name).grid(row=1,column=i,sticky="w",padx=(0,14))
    ttk.Label(settings,text="Base").grid(row=2,column=0,sticky="w",pady=(10,0)); ttk.Entry(settings,textvariable=hyper_base,width=8).grid(row=2,column=1,sticky="w",pady=(10,0)); ttk.Label(settings,text="Height").grid(row=2,column=2,sticky="w",pady=(10,0)); ttk.Entry(settings,textvariable=hyper_height,width=8).grid(row=2,column=3,sticky="w",pady=(10,0)); ttk.Label(settings,text="Standard steps").grid(row=2,column=4,sticky="w",pady=(10,0)); ttk.Entry(settings,textvariable=standard_steps,width=10).grid(row=2,column=5,sticky="w",pady=(10,0)); ttk.Label(settings,text="EC cycles").grid(row=2,column=6,sticky="w",pady=(10,0)); ttk.Entry(settings,textvariable=ec_cycles,width=7).grid(row=2,column=7,sticky="w",pady=(10,0))
    ttk.Label(settings,textvariable=plan_text,style="Body.TLabel").grid(row=3,column=0,columnspan=8,sticky="w",pady=(10,0))
    def do_encrypt():
        pub,src,out=Path(enc_pub.get()),Path(enc_in.get()),Path(enc_out.get())
        if not pub.is_file() or not src.is_file(): raise FileNotFoundError("choose an existing recipient identity and input file")
        if out.exists(): raise FileExistsError("refusing to overwrite an existing EFI capsule")
        p=current_plan(True)
        if not p or p.get('steps') is None: raise ValueError("selected Entropic Engine plan is not executable in this build")
        enc_progress.set(0.0); enc_progress_text.set("Starting…")
        def stream_progress(phase, done, total):
            work_q.put(("file-progress", ("encrypt", phase, done, total), None, None))
        return privacy.encrypt_file(et013_dir(),pub,src,out,cycles=int(ec_cycles.get()),root_mode=mode.get().lower(),base_value=int(hyper_base.get()),height=int(hyper_height.get()),standard_steps=int(standard_steps.get()),progress=stream_progress,cancel_event=cancel_event)
    def enc_done(r):
        enc_progress.set(100.0); enc_progress_text.set("Complete")
        enc_result.set(f"Metadata protected • streamed • {r.get('stages')} inner stages • {r.get('root_mode')} • {_human_seconds(float(r.get('outer_seconds',r.get('total_seconds',0))))} • {_human_bytes(int(r.get('capsule_bytes',0)))}"); last_output['path']=enc_out.get(); log("Metadata-private streaming encryption complete"); messagebox.showinfo("Encryption complete","Metadata-private EFI capsule created successfully. The source was processed in bounded chunks and its filename, exact size and inner EFI metadata are protected.")
    enc_btn=ttk.Button(enc,text="Encrypt File",style="Primary.TButton",command=lambda:start_task("Encrypting file…",do_encrypt,enc_done)); enc_btn.grid(row=6,column=1,sticky="w",padx=8,pady=(6,0)); action_buttons.append(enc_btn)
    ttk.Button(enc,text="Cancel",style="Soft.TButton",command=cancel_event.set).grid(row=6,column=2,sticky="w",padx=8,pady=(6,0))
    ttk.Progressbar(enc,variable=enc_progress,maximum=100).grid(row=7,column=0,columnspan=4,sticky="ew",pady=(12,3))
    ttk.Label(enc,textvariable=enc_progress_text,style="Muted.TLabel").grid(row=8,column=0,columnspan=4,sticky="w")
    ttk.Label(enc,textvariable=enc_result,style="Muted.TLabel").grid(row=9,column=0,columnspan=4,sticky="w",pady=(8,0)); enc.columnconfigure(1,weight=1); enc.columnconfigure(2,weight=1)

    # DECRYPT
    dec=tabs["Decrypt"]; ttk.Label(dec,text="Decrypt file",style="Hero.TLabel").grid(row=0,column=0,columnspan=3,sticky="w"); ttk.Label(dec,text="Open a metadata-private EFI capsule with the matching private identity. The original filename is revealed only after successful decryption.",style="HeroSub.TLabel",wraplength=920).grid(row=1,column=0,columnspan=3,sticky="w",pady=(3,12))
    dec_prv=tk.StringVar(); dec_in=tk.StringVar(); dec_dir=tk.StringVar(value=str(Path.home())); dec_pw=tk.StringVar(); dec_result=tk.StringVar(); dec_progress=tk.DoubleVar(value=0.0); dec_progress_text=tk.StringVar(value="")
    def dec_selected(p):
        try:
            meta=inspect_capsule(Path(p))
            if meta.get("metadata_privacy")=="PROTECTED":
                dec_result.set(f"Protected EFI envelope • {_human_bytes(int(meta.get('visible_outer_bytes',0)))} • original metadata hidden")
            else:
                dec_result.set(f"Legacy capsule • metadata exposed • {meta.get('filename','unknown file')}")
            if not dec_dir.get().strip(): dec_dir.set(str(Path(p).parent))
        except Exception as exc: dec_result.set("Could not inspect capsule: "+_safe_error(exc))
    fields=[("Private identity",dec_prv,[("EFI private identity","*.json"),("All files","*.*")],None),("EFI capsule",dec_in,[("EFI capsule","*.efi"),("All files","*.*")],dec_selected)]
    for r,(lab,var,fts,after) in enumerate(fields,start=2):
        ttk.Label(dec,text=lab).grid(row=r,column=0,sticky="w",pady=4); ttk.Entry(dec,textvariable=var).grid(row=r,column=1,sticky="ew",padx=8); ttk.Button(dec,text="Browse…",command=lambda v=var,l=lab,f=fts,a=after:browse_open(v,"Choose "+l,f,a)).grid(row=r,column=2)
    ttk.Label(dec,text="Destination folder").grid(row=4,column=0,sticky="w",pady=4); ttk.Entry(dec,textvariable=dec_dir).grid(row=4,column=1,sticky="ew",padx=8); ttk.Button(dec,text="Browse…",command=lambda:browse_dir(dec_dir,"Choose recovery folder")).grid(row=4,column=2)
    ttk.Label(dec,text="Password").grid(row=5,column=0,sticky="w",pady=(10,4)); ttk.Entry(dec,textvariable=dec_pw,show="•").grid(row=5,column=1,sticky="ew",padx=8)
    def do_decrypt():
        prv,cap=Path(dec_prv.get()),Path(dec_in.get()); dest=Path(dec_dir.get() or Path.home())
        if not prv.is_file() or not cap.is_file(): raise FileNotFoundError("choose an existing private identity and EFI capsule")
        if not dest.is_dir(): raise FileNotFoundError("choose an existing destination folder")
        if not dec_pw.get(): raise ValueError("enter the private-identity password")
        if deniable.is_deniable_container(cap): raise ValueError("EFIPRIV4 dual-profile containers are opened from the Deniable tab")
        dec_progress.set(0.0); dec_progress_text.set("Opening protected control…")
        def stream_progress(phase, done, total):
            work_q.put(("file-progress", ("decrypt", phase, done, total), None, None))
        return privacy.decrypt_file(et013_dir(),prv,dec_pw.get(),cap,dest,progress=stream_progress,cancel_event=cancel_event)
    def dec_done(r):
        dec_result.set(f"Recovered {r.get('filename','file')} • {_human_bytes(int(r.get('recovered_bytes',0)))} exactly • {r.get('metadata_privacy')} • {_human_seconds(float(r.get('total_private_workflow_seconds',r.get('total_seconds',0))))}"); dec_pw.set(""); last_output['path']=r.get('output_path',''); log("Decryption complete"); messagebox.showinfo("Decryption complete",f"Recovered file:\n{r.get('output_path','')}")
    dec_btn=ttk.Button(dec,text="Decrypt File",style="Primary.TButton",command=lambda:start_task("Decrypting file…",do_decrypt,dec_done)); dec_btn.grid(row=6,column=1,sticky="w",padx=8,pady=(6,0)); action_buttons.append(dec_btn)
    ttk.Button(dec,text="Cancel",style="Soft.TButton",command=cancel_event.set).grid(row=6,column=2,sticky="w",padx=8,pady=(6,0))
    ttk.Progressbar(dec,variable=dec_progress,maximum=100).grid(row=7,column=0,columnspan=3,sticky="ew",pady=(12,3))
    ttk.Label(dec,textvariable=dec_progress_text,style="Muted.TLabel").grid(row=8,column=0,columnspan=3,sticky="w")
    ttk.Label(dec,textvariable=dec_result,style="Muted.TLabel",wraplength=900).grid(row=9,column=0,columnspan=3,sticky="w",pady=(8,0)); dec.columnconfigure(1,weight=1)

    # DENIABLE DUAL-PROFILE CONTAINERS
    dual=tabs["Deniable"]
    ttk.Label(dual,text="Deniable dual-profile container",style="Hero.TLabel").grid(row=0,column=0,columnspan=2,sticky="w")
    ttk.Label(dual,text="EFIPRIV4 keeps two equal opaque slots. Slot 2 is always present: random cover when unused, or a passphrase-gated hidden EFI profile when used. A deliberate duress credential opens the decoy while replacing the live hidden-slot recovery material.",style="HeroSub.TLabel",wraplength=980).grid(row=1,column=0,columnspan=2,sticky="w",pady=(3,10))
    dual_panels=ttk.Frame(dual,style="App.TFrame"); dual_panels.grid(row=2,column=0,columnspan=2,sticky="nsew")
    dual_create=ttk.LabelFrame(dual_panels,text="Create",padding=12)
    dual_open=ttk.LabelFrame(dual_panels,text="Open",padding=12)
    dual_panels.columnconfigure(0,weight=1); dual_panels.columnconfigure(1,weight=1)
    dual.columnconfigure(0,weight=1); dual.columnconfigure(1,weight=1)

    def _reflow_dual(event=None):
        width = int(getattr(event, "width", dual_panels.winfo_width()) or 0)
        if width and width < 980:
            dual_create.grid(row=0,column=0,columnspan=2,sticky="ew",padx=0,pady=(0,8))
            dual_open.grid(row=1,column=0,columnspan=2,sticky="ew",padx=0,pady=(0,0))
        else:
            dual_create.grid(row=0,column=0,columnspan=1,sticky="nsew",padx=(0,6),pady=0)
            dual_open.grid(row=0,column=1,columnspan=1,sticky="nsew",padx=(6,0),pady=0)
    dual_panels.bind("<Configure>", _reflow_dual)
    dual.after_idle(_reflow_dual)

    d_pub=tk.StringVar(); d_decoy=tk.StringVar(); d_hidden=tk.StringVar(); d_out=tk.StringVar()
    d_hidden_pw=tk.StringVar(); d_hidden_confirm=tk.StringVar(); d_duress_pw=tk.StringVar(); d_duress_confirm=tk.StringVar(); d_reserve_mib=tk.StringVar(); d_result=tk.StringVar()
    def dual_decoy_selected(p): d_out.set(str(Path(p).parent / privacy.suggest_capsule_name()))
    create_fields=[
        ("Recipient public identity",d_pub,[('EFI public identity','*.json'),('All files','*.*')],None),
        ("Decoy file",d_decoy,[('All files','*.*')],dual_decoy_selected),
        ("Hidden file (optional)",d_hidden,[('All files','*.*')],None),
    ]
    for r,(lab,var,fts,after) in enumerate(create_fields,start=0):
        ttk.Label(dual_create,text=lab).grid(row=r,column=0,sticky="w",pady=3)
        ttk.Entry(dual_create,textvariable=var,width=34).grid(row=r,column=1,sticky="ew",padx=6)
        ttk.Button(dual_create,text="Browse…",command=lambda v=var,l=lab,f=fts,a=after:browse_open(v,"Choose "+l,f,a)).grid(row=r,column=2)
    ttk.Label(dual_create,text="Hidden passphrase").grid(row=3,column=0,sticky="w",pady=(8,3)); ttk.Entry(dual_create,textvariable=d_hidden_pw,show="•").grid(row=3,column=1,columnspan=2,sticky="ew",padx=6)
    ttk.Label(dual_create,text="Confirm hidden").grid(row=4,column=0,sticky="w",pady=3); ttk.Entry(dual_create,textvariable=d_hidden_confirm,show="•").grid(row=4,column=1,columnspan=2,sticky="ew",padx=6)
    ttk.Label(dual_create,text="Duress / hidden self-destruct passphrase (optional)").grid(row=5,column=0,sticky="w",pady=(8,3)); ttk.Entry(dual_create,textvariable=d_duress_pw,show="•").grid(row=5,column=1,columnspan=2,sticky="ew",padx=6)
    ttk.Label(dual_create,text="Confirm duress").grid(row=6,column=0,sticky="w",pady=3); ttk.Entry(dual_create,textvariable=d_duress_confirm,show="•").grid(row=6,column=1,columnspan=2,sticky="ew",padx=6)
    ttk.Label(dual_create,text="Reserve per slot (MiB)").grid(row=7,column=0,sticky="w",pady=(8,3)); ttk.Entry(dual_create,textvariable=d_reserve_mib).grid(row=7,column=1,columnspan=2,sticky="ew",padx=6)
    ttk.Label(dual_create,text="Blank = minimum based only on the decoy. Hidden content is never allowed to silently enlarge the public container. Enter a larger reserve here if the hidden profile needs it; the same reserve can also be created with cover only.",style="Muted.TLabel",wraplength=460).grid(row=8,column=0,columnspan=3,sticky="w",pady=(3,5))
    ttk.Label(dual_create,text="Output .efi").grid(row=9,column=0,sticky="w",pady=(6,3)); ttk.Entry(dual_create,textvariable=d_out).grid(row=9,column=1,sticky="ew",padx=6); ttk.Button(dual_create,text="Browse…",command=lambda:browse_save(d_out,"Save deniable EFI capsule",".efi",[("EFI capsule","*.efi"),("All files","*.*")])).grid(row=9,column=2)
    ttk.Label(dual_create,text="IMPORTANT: The duress passphrase is a deliberate hidden-profile self-destruct credential. Using it later opens the decoy normally and destroys the live hidden-profile recovery material in that container copy. It does not wipe the decoy, and ordinary wrong passwords do nothing.",style="Danger.TLabel",wraplength=460).grid(row=10,column=0,columnspan=3,sticky="w",pady=(8,4))
    ttk.Label(dual_create,text="Uses the Entropic Engine settings from the Encrypt/Engine tabs. Hidden and duress passphrases require at least 12 characters.",style="Muted.TLabel",wraplength=460).grid(row=11,column=0,columnspan=3,sticky="w",pady=(2,6))
    dual_create.columnconfigure(1,weight=1)

    d_prv=tk.StringVar(); d_in=tk.StringVar(); d_dest=tk.StringVar(value=str(Path.home())); d_identity_pw=tk.StringVar(); d_profile_pw=tk.StringVar(); d_open_result=tk.StringVar()
    open_fields=[
        ("Private identity",d_prv,[('EFI private identity','*.json'),('All files','*.*')],None),
        ("EFIPRIV4 container",d_in,[('EFI capsule','*.efi'),('All files','*.*')],None),
    ]
    for r,(lab,var,fts,after) in enumerate(open_fields,start=0):
        ttk.Label(dual_open,text=lab).grid(row=r,column=0,sticky="w",pady=3)
        ttk.Entry(dual_open,textvariable=var,width=34).grid(row=r,column=1,sticky="ew",padx=6)
        ttk.Button(dual_open,text="Browse…",command=lambda v=var,l=lab,f=fts,a=after:browse_open(v,"Choose "+l,f,a)).grid(row=r,column=2)
    ttk.Label(dual_open,text="Destination folder").grid(row=2,column=0,sticky="w",pady=3); ttk.Entry(dual_open,textvariable=d_dest).grid(row=2,column=1,sticky="ew",padx=6); ttk.Button(dual_open,text="Browse…",command=lambda:browse_dir(d_dest,"Choose recovery folder")).grid(row=2,column=2)
    ttk.Label(dual_open,text="Identity password").grid(row=3,column=0,sticky="w",pady=(8,3)); ttk.Entry(dual_open,textvariable=d_identity_pw,show="•").grid(row=3,column=1,columnspan=2,sticky="ew",padx=6)
    ttk.Label(dual_open,text="Profile credential").grid(row=4,column=0,sticky="w",pady=3); ttk.Entry(dual_open,textvariable=d_profile_pw,show="•").grid(row=4,column=1,columnspan=2,sticky="ew",padx=6)
    ttk.Label(dual_open,text="IMPORTANT: A configured duress credential is the hidden-profile self-destruct passphrase. Entering it deliberately opens the decoy and destroys the live hidden-slot recovery material in this container copy. It does NOT destroy the decoy or wipe the whole EFI file. Ordinary wrong passwords are non-destructive.",style="Danger.TLabel",wraplength=460).grid(row=5,column=0,columnspan=3,sticky="w",pady=(8,4))
    ttk.Label(dual_open,text="Leave Profile credential blank for the decoy. Enter the hidden credential for the hidden view. Enter the duress credential only when you intentionally want the hidden profile made unrecoverable from this current container copy.",style="Muted.TLabel",wraplength=460).grid(row=6,column=0,columnspan=3,sticky="w",pady=(2,6))
    ttk.Label(dual_open,textvariable=d_open_result,style="Muted.TLabel",wraplength=460).grid(row=8,column=0,columnspan=3,sticky="w",pady=(8,0))
    dual_open.columnconfigure(1,weight=1)

    dual_progress=tk.DoubleVar(value=0.0); dual_progress_text=tk.StringVar(value="")
    ttk.Progressbar(dual,variable=dual_progress,maximum=100).grid(row=3,column=0,columnspan=2,sticky="ew",pady=(10,3))
    ttk.Label(dual,textvariable=dual_progress_text,style="Muted.TLabel").grid(row=4,column=0,columnspan=2,sticky="w")
    ttk.Label(dual,textvariable=d_result,style="Muted.TLabel",wraplength=960).grid(row=5,column=0,columnspan=2,sticky="w",pady=(5,0))

    def do_dual_create():
        pub,decoy,out=Path(d_pub.get()),Path(d_decoy.get()),Path(d_out.get())
        hidden=Path(d_hidden.get()) if d_hidden.get().strip() else None
        if not pub.is_file() or not decoy.is_file(): raise FileNotFoundError("choose an existing recipient identity and decoy file")
        if hidden is not None and not hidden.is_file(): raise FileNotFoundError("choose an existing hidden file")
        if out.exists(): raise FileExistsError("refusing to overwrite an existing EFI capsule")
        if hidden is not None and d_hidden_pw.get()!=d_hidden_confirm.get(): raise ValueError("hidden passphrase confirmation does not match")
        if d_duress_pw.get()!=d_duress_confirm.get(): raise ValueError("duress passphrase confirmation does not match")
        p=current_plan(True)
        if not p or p.get('steps') is None: raise ValueError("selected Entropic Engine plan is not executable in this build")
        reserve_bytes=None
        if d_reserve_mib.get().strip():
            reserve_mib=int(d_reserve_mib.get().strip())
            if reserve_mib <= 0: raise ValueError("reserve capacity must be a positive MiB value")
            reserve_bytes=reserve_mib*1024*1024
        dual_progress.set(0); dual_progress_text.set("Building dual-profile container…")
        def prog(phase,done,total): work_q.put(("dual-progress",(phase,done,total),None,None))
        return deniable.create_container(
            et013_dir(),pub,decoy,out,hidden_path=hidden,
            hidden_passphrase=d_hidden_pw.get() if hidden is not None else None,
            duress_passphrase=d_duress_pw.get() or None, reserve_bytes=reserve_bytes,
            cycles=int(ec_cycles.get()),root_mode=mode.get().lower(),base_value=int(hyper_base.get()),height=int(hyper_height.get()),standard_steps=int(standard_steps.get()),
            progress=prog,cancel_event=cancel_event)
    def dual_create_done(r):
        dual_progress.set(100); dual_progress_text.set("Complete")
        d_result.set(f"EFIPRIV4 created • two fixed opaque slots • {_human_bytes(int(r.get('capsule_bytes',0)))}")
        d_hidden_pw.set(""); d_hidden_confirm.set(""); d_duress_pw.set(""); d_duress_confirm.set("")
        last_output['path']=d_out.get(); log("Deniable EFIPRIV4 container created"); messagebox.showinfo("Deniable container","EFIPRIV4 container created. Public bytes do not state whether the second slot is cover or a hidden profile.")
    dcreate_btn=ttk.Button(dual_create,text="Create Deniable Container",style="Primary.TButton",command=lambda:start_task("Creating deniable EFI container…",do_dual_create,dual_create_done)); dcreate_btn.grid(row=12,column=1,sticky="w",pady=(6,0)); action_buttons.append(dcreate_btn)
    ttk.Button(dual_create,text="Cancel",style="Soft.TButton",command=cancel_event.set).grid(row=12,column=2,sticky="w",pady=(6,0))

    def do_dual_open():
        prv,cap,dest=Path(d_prv.get()),Path(d_in.get()),Path(d_dest.get() or Path.home())
        if not prv.is_file() or not cap.is_file(): raise FileNotFoundError("choose an existing private identity and EFIPRIV4 container")
        if not deniable.is_deniable_container(cap): raise ValueError("selected file is not an EFIPRIV4 deniable container")
        if not dest.is_dir(): raise FileNotFoundError("choose an existing destination folder")
        if not d_identity_pw.get(): raise ValueError("enter the private-identity password")
        dual_progress.set(0); dual_progress_text.set("Opening selected profile…")
        def prog(phase,done,total): work_q.put(("dual-progress",(phase,done,total),None,None))
        return deniable.open_container(et013_dir(),prv,d_identity_pw.get(),cap,dest,profile_passphrase=d_profile_pw.get() or None,progress=prog,cancel_event=cancel_event)
    def dual_open_done(r):
        dual_progress.set(100); dual_progress_text.set("Complete")
        # Deliberately do not display or log whether a duress credential was used.
        d_open_result.set(f"Recovered {r.get('filename','file')} • {_human_bytes(int(r.get('recovered_bytes',0)))} exactly • profile opened")
        d_identity_pw.set(""); d_profile_pw.set(""); last_output['path']=r.get('output_path',''); log("Deniable profile opened"); messagebox.showinfo("Profile opened",f"Recovered file:\n{r.get('output_path','')}")
    dopen_btn=ttk.Button(dual_open,text="Open Profile",style="Primary.TButton",command=lambda:start_task("Opening deniable EFI profile…",do_dual_open,dual_open_done)); dopen_btn.grid(row=7,column=1,sticky="w",pady=(8,0)); action_buttons.append(dopen_btn)
    ttk.Button(dual_open,text="Cancel",style="Soft.TButton",command=cancel_event.set).grid(row=7,column=2,sticky="w",pady=(8,0))

    # ENTROPIC ENGINE
    eng=tabs["Entropic Engine"]; ttk.Label(eng,text="Entropic Engine",style="Hero.TLabel").pack(anchor="w"); ttk.Label(eng,text="The ET 0.13 control panel is back: Standard, Tetration and Pentation, live plan calculation, actual sequential transitions, benchmark, progress and Cancel.",style="HeroSub.TLabel",wraplength=930).pack(anchor="w",pady=(3,12))
    ec=card(eng,"Virtual recursion","Every selected virtual transition is executed sequentially in memory. Only one full EF + dual-ML-KEM root establishment is created."); ec.pack(fill="x",pady=(0,10))
    radios=ttk.Frame(ec,style="Panel.TFrame"); radios.pack(fill="x")
    for name in ("Standard","Tetration","Pentation"): ttk.Radiobutton(radios,text=name,variable=mode,value=name).pack(side="left",padx=(0,20))
    prow=ttk.Frame(ec,style="Panel.TFrame"); prow.pack(fill="x",pady=(10,0))
    for lab,var,w in (("Base",hyper_base,8),("Height",hyper_height,8),("Standard steps",standard_steps,10),("EC cycles",ec_cycles,8)):
        ttk.Label(prow,text=lab,style="Body.TLabel").pack(side="left",padx=(0,5)); ttk.Entry(prow,textvariable=var,width=w).pack(side="left",padx=(0,16))
    ttk.Label(ec,textvariable=plan_text,style="Body.TLabel").pack(anchor="w",pady=(10,0))
    statuscard=card(eng,"Operation status"); statuscard.pack(fill="x",pady=(0,10))
    top=ttk.Frame(statuscard,style="Panel.TFrame"); top.pack(fill="x"); ttk.Label(top,textvariable=engine_status,style="CardTitle.TLabel").pack(side="left"); ttk.Label(top,textvariable=engine_timing,style="Body.TLabel").pack(side="right")
    epb=ttk.Progressbar(statuscard,variable=engine_progress,maximum=100); epb.pack(fill="x",pady=(10,6))
    engine_detail=tk.Text(eng,height=11,wrap="word",font=("Consolas",9)); engine_detail.pack(fill="both",expand=True)
    btnrow=ttk.Frame(eng,style="App.TFrame"); btnrow.pack(fill="x",pady=(8,0))
    engine_busy={"value":False,"started":0.0}
    def run_engine_demo():
        if engine_busy['value']: return
        p=current_plan(True)
        if not p or p.get('steps') is None: return
        cancel_event.clear(); engine_busy['value']=True; engine_busy['started']=time.perf_counter(); engine_status.set("Running sequential virtual transitions…"); engine_progress.set(0)
        engine_detail.delete('1.0','end'); engine_detail.insert('end',f"Executing {p['description']}\n")
        def progress(kind,step,total): work_q.put(("engine-progress",(step,total),None,None))
        def runner():
            try:
                engine=backend.load_root_engine(et013_dir()); key=hashlib.sha256(b'EFI-0.7 GUI engine demo').digest(); ctx=hashlib.sha256(b'EFI-0.7 GUI engine context').digest(); final,metrics=engine.virtual_chain(key,plan=p,context=ctx,progress=progress,cancel=lambda:cancel_event.is_set(),progress_every=max(1,int(p['steps'] or 1)//100)); work_q.put(("engine-done",metrics,None,None))
            except Exception as exc: work_q.put(("engine-error",None,None,exc))
        threading.Thread(target=runner,daemon=True).start()
    def run_benchmark():
        p=current_plan(True)
        if not p or p.get('steps') is None:return
        mode_name=mode.get().lower(); steps=int(p['steps']); start_task("Benchmarking Entropic Engine…",lambda:backend.load_root_engine(et013_dir()).benchmark(steps=steps,mode=mode_name),lambda r:(engine_detail.delete('1.0','end'),engine_detail.insert('end',json.dumps(r,indent=2)),log("Engine benchmark complete")))
    demo_btn=ttk.Button(btnrow,text="Run Engine Demo",style="Primary.TButton",command=run_engine_demo); demo_btn.pack(side="left",padx=(0,8)); action_buttons.append(demo_btn)
    bench_btn=ttk.Button(btnrow,text="Benchmark",style="Soft.TButton",command=run_benchmark); bench_btn.pack(side="left",padx=(0,8)); action_buttons.append(bench_btn)
    cancel_btn=ttk.Button(btnrow,text="Cancel",style="Soft.TButton",command=lambda:cancel_event.set()); cancel_btn.pack(side="left")

    # INSPECT
    ins=tabs["Inspect"]; ttk.Label(ins,text="Inspect EFI capsule",style="Hero.TLabel").grid(row=0,column=0,columnspan=3,sticky="w"); ttk.Label(ins,text="EFI 1.0.0-beta.5 recognises EFIPRIV3 streaming capsules and EFIPRIV4 dual-profile containers. Public inspection never reports whether an EFIPRIV4 reserve contains cover, hidden data or a destroyed hidden profile.",style="HeroSub.TLabel").grid(row=1,column=0,columnspan=3,sticky="w",pady=(3,12))
    ins_path=tk.StringVar(); ttk.Entry(ins,textvariable=ins_path).grid(row=2,column=0,columnspan=2,sticky="ew"); ttk.Button(ins,text="Browse…",command=lambda:browse_open(ins_path,"Choose EFI capsule",[("EFI capsule","*.efi"),("All files","*.*")])).grid(row=2,column=2,padx=(8,0))
    ins_box=tk.Text(ins,wrap="none",font=("Consolas",9)); ins_box.grid(row=4,column=0,columnspan=3,sticky="nsew",pady=(10,0)); ins.rowconfigure(4,weight=1); ins.columnconfigure(0,weight=1); ins.columnconfigure(1,weight=1)
    def ins_done(r): ins_box.delete('1.0','end'); ins_box.insert('end',json.dumps(r,indent=2,ensure_ascii=False))
    ins_btn=ttk.Button(ins,text="Inspect Capsule",style="Soft.TButton",command=lambda:start_task("Inspecting capsule…",lambda:inspect_capsule(Path(ins_path.get())),ins_done)); ins_btn.grid(row=3,column=0,sticky="w",pady=(8,0)); action_buttons.append(ins_btn)

    # SELF TEST
    st=tabs["Self-Test"]; ttk.Label(st,text="System self-test",style="Hero.TLabel").pack(anchor="w"); ttk.Label(st,text="Checks the frozen ET/Beta dependency, ML-KEM/OpenSSL availability, integrated GUI controls, metadata-privacy regression, EFIPRIV4 deniable/duress regression and real identity → encrypt → decrypt round trips.",style="HeroSub.TLabel",wraplength=900).pack(anchor="w",pady=(3,12))
    st_box=tk.Text(st,height=22,wrap="word",font=("Consolas",9)); st_box.pack(fill="both",expand=True)
    def st_done(r): st_box.delete('1.0','end'); st_box.insert('end',json.dumps(r,indent=2)); log("EFI self-test passed"); messagebox.showinfo("Self-Test","Integrated EFI self-test passed.")
    def run_selftest(): return {"runtime":runtime_probe(True),"roundtrip":headless_roundtrip_probe(),"deniable":headless_deniable_probe(),"ui":ui_feature_probe()}
    st_btn=ttk.Button(st,text="Run Integrated Self-Test",style="Primary.TButton",command=lambda:start_task("Running integrated self-test…",run_selftest,st_done)); st_btn.pack(anchor="w",pady=(8,0)); action_buttons.append(st_btn)

    # ACTIVITY
    act=tabs["Activity"]; ttk.Label(act,text="Session activity",style="Hero.TLabel").pack(anchor="w"); ttk.Label(act,text="Passwords, private keys and plaintext are never written to this display.",style="HeroSub.TLabel").pack(anchor="w",pady=(3,10))
    activity_box=tk.Text(act,height=24,wrap="word",font=("Consolas",9),state="disabled"); activity_box.pack(fill="both",expand=True); locals_ref['activity_box']=activity_box
    ttk.Button(act,text="Clear",style="Soft.TButton",command=lambda:(activity_box.configure(state='normal'),activity_box.delete('1.0','end'),activity_box.configure(state='disabled'))).pack(anchor="w",pady=(8,0))

    # HELP
    help_tab=tabs["Help"]
    ttk.Label(help_tab,text="Entropic Fusion Help Centre",style="Hero.TLabel").grid(row=0,column=0,columnspan=3,sticky="w")
    ttk.Label(help_tab,text="Searchable in-application manual for Entropic Fusion, dual ML-KEM, HNDL protection, EFI files, metadata privacy, deniable profiles, duress/self-destruct, the Entropic Engine, EC100, Vault/WinFsp, troubleshooting and research limits.",style="HeroSub.TLabel",wraplength=960).grid(row=1,column=0,columnspan=3,sticky="w",pady=(3,10))
    help_search=tk.StringVar()
    ttk.Label(help_tab,text="Search help").grid(row=2,column=0,sticky="w",pady=(0,6))
    hs=ttk.Entry(help_tab,textvariable=help_search); hs.grid(row=2,column=1,sticky="ew",padx=(8,8),pady=(0,6))
    hclear=ttk.Button(help_tab,text="Clear",style="Soft.TButton",command=lambda:help_search.set("")); hclear.grid(row=2,column=2,sticky="e",pady=(0,6))
    help_pane=ttk.Panedwindow(help_tab,orient="horizontal"); help_pane.grid(row=3,column=0,columnspan=3,sticky="nsew")
    help_nav_frame=ttk.Frame(help_pane,style="Panel.TFrame",padding=6); help_body_frame=ttk.Frame(help_pane,style="Panel.TFrame",padding=10)
    help_pane.add(help_nav_frame,weight=0); help_pane.add(help_body_frame,weight=1)
    help_tree=ttk.Treeview(help_nav_frame,show="tree",selectmode="browse",height=20); help_tree.pack(fill="both",expand=True)
    help_text=tk.Text(help_body_frame,wrap="word",font=("Segoe UI",10),relief="flat",borderwidth=0,padx=8,pady=8); help_text.pack(fill="both",expand=True)
    help_text.tag_configure("h1",font=("Segoe UI Semibold",17),foreground=NAVY,spacing3=10)
    help_text.tag_configure("sub",font=("Segoe UI",10,"italic"),foreground=MUTED,spacing3=14)
    help_text.tag_configure("body",font=("Segoe UI",10),foreground=INK,spacing1=2,spacing3=3)
    help_text.tag_configure("section",font=("Segoe UI Semibold",11),foreground=NAVY,spacing1=10,spacing3=5)
    help_text.tag_configure("important",font=("Segoe UI Semibold",10),foreground=DANGER,spacing1=10,spacing3=8)
    help_status=tk.StringVar(value="")
    ttk.Label(help_tab,textvariable=help_status,style="Muted.TLabel").grid(row=4,column=0,columnspan=2,sticky="w",pady=(6,0))
    def show_help_section(key):
        if key not in HELP_BY_KEY:return
        title,subtitle,body=HELP_BY_KEY[key]
        help_text.configure(state="normal"); help_text.delete("1.0","end")
        help_text.insert("end",title+"\n","h1"); help_text.insert("end",subtitle+"\n\n","sub")
        for line in body.splitlines():
            stripped=line.strip()
            if stripped.startswith("IMPORTANT:"):
                tag="important"
            elif stripped and stripped.upper()==stripped and any(ch.isalpha() for ch in stripped) and len(stripped) <= 90:
                tag="section"
            else:
                tag="body"
            help_text.insert("end",line+"\n",tag)
        help_text.configure(state="disabled"); help_status.set(title)
    def rebuild_help(*_):
        q=help_search.get().strip().lower(); help_tree.delete(*help_tree.get_children())
        matches=[]
        for key,title,subtitle,body in HELP_SECTIONS:
            hay=(title+" "+subtitle+" "+body).lower()
            if not q or q in hay:
                help_tree.insert("", "end", iid=key, text=title); matches.append(key)
        help_status.set(f"{len(matches)} help section{'s' if len(matches)!=1 else ''}" + (f" matching ‘{q}’" if q else ""))
        if matches:
            help_tree.selection_set(matches[0]); help_tree.focus(matches[0]); show_help_section(matches[0])
        else:
            help_text.configure(state="normal"); help_text.delete("1.0","end"); help_text.insert("end","No help sections match that search.\n","body"); help_text.configure(state="disabled")
    def help_selected(_=None):
        sel=help_tree.selection();
        if sel: show_help_section(sel[0])
    help_tree.bind("<<TreeviewSelect>>",help_selected); help_search.trace_add("write",rebuild_help)
    help_tab.rowconfigure(3,weight=1); help_tab.columnconfigure(1,weight=1)
    rebuild_help()

    # Extend queue pump for engine progress messages.
    old_pump = pump_queue
    def pump_queue_extended():
        try:
            while True:
                kind,result,callback,exc=work_q.get_nowait()
                if kind=="file-progress":
                    which,phase,done,total=result
                    pct=100.0*done/total if total else (100.0 if done else 0.0)
                    if which=="encrypt": enc_progress.set(pct); enc_progress_text.set(f"{phase} • {pct:.1f}%" if total else phase)
                    else: dec_progress.set(pct); dec_progress_text.set(f"{phase} • {pct:.1f}%" if total else phase)
                elif kind=="dual-progress":
                    phase,done,total=result
                    pct=100.0*done/total if total else (100.0 if done else 0.0)
                    dual_progress.set(pct); dual_progress_text.set(f"{phase} • {pct:.1f}%" if total else phase)
                elif kind=="engine-progress":
                    step,total=result; engine_progress.set(100.0*step/total if total else 0); engine_timing.set(f"{step:,} / {total:,} transitions")
                elif kind=="engine-done":
                    engine_busy['value']=False; engine_progress.set(100); engine_status.set("Engine demo complete"); engine_timing.set(_human_seconds(time.perf_counter()-engine_busy['started'])); engine_detail.delete('1.0','end'); engine_detail.insert('end',json.dumps(result,indent=2)); log("Entropic Engine demo complete")
                elif kind=="engine-error":
                    engine_busy['value']=False; engine_status.set("Engine demo stopped"); msg=_safe_error(exc); log("Engine: "+msg); messagebox.showerror("Entropic Engine",msg)
                elif kind=="done":
                    set_busy(False); callback(result) if callback else None
                elif kind=="error":
                    set_busy(False); msg=_safe_error(exc); status_var.set("Operation failed"); log("ERROR: "+msg); messagebox.showerror("Entropic Fusion",msg)
        except queue.Empty: pass
        if busy['value']:
            elapsed=time.perf_counter()-busy['started']; timing_var.set(f"{busy['label']}  •  {_human_seconds(elapsed)}")
        root.after(120,pump_queue_extended)

    # Menus and utility buttons.
    menubar=tk.Menu(root); fm=tk.Menu(menubar,tearoff=False); fm.add_command(label="Encrypt file…",command=lambda:nb.select(tab_views['Encrypt'])); fm.add_command(label="Decrypt file…",command=lambda:nb.select(tab_views['Decrypt'])); fm.add_command(label="Deniable container…",command=lambda:nb.select(tab_views['Deniable'])); fm.add_separator(); fm.add_command(label="Exit",command=root.destroy); menubar.add_cascade(label="File",menu=fm)
    em=tk.Menu(menubar,tearoff=False); em.add_command(label="Entropic Engine",command=lambda:nb.select(tab_views['Entropic Engine'])); em.add_command(label="Full Vault Manager",command=_launch_vault_manager_child); menubar.add_cascade(label="Entropic",menu=em)
    hm=tk.Menu(menubar,tearoff=False); hm.add_command(label="Help",command=lambda:nb.select(tab_views['Help'])); hm.add_command(label="About",command=lambda:messagebox.showinfo("About",f"{VERSION}\n{ITERATION}\n\nEFI metadata-private + deniable envelopes + EF + ML-KEM + ET 0.13 + EC100 + Beta 1.1.1 Vault")); menubar.add_cascade(label="Help",menu=hm); root.config(menu=menubar)

    log(f"{VERSION} ready"); log(f"Backend: {BACKEND_VERSION}"); log(f"WinFsp: {'installed' if winfsp_present() else 'not installed'}")
    root.protocol("WM_DELETE_WINDOW",lambda:(cancel_event.set(),root.destroy()))
    root.deiconify(); root.after(100,pump_queue_extended); root.mainloop(); return 0


def _emit_probe(result: dict, output: str | None) -> None:
    text=json.dumps(result,indent=2)+"\n"
    if output: Path(output).write_text(text,encoding="utf-8")
    elif sys.stdout is not None: sys.stdout.write(text)


def main(argv=None) -> int:
    parser=argparse.ArgumentParser(description=VERSION)
    parser.add_argument("--source-probe",action="store_true")
    parser.add_argument("--crypto-probe",action="store_true")
    parser.add_argument("--roundtrip-probe",action="store_true")
    parser.add_argument("--ui-feature-probe",action="store_true")
    parser.add_argument("--deniable-probe",action="store_true")
    parser.add_argument("--vault-manager",action="store_true")
    parser.add_argument("--probe-output")
    args=parser.parse_args(argv)
    if args.source_probe: _emit_probe(runtime_probe(False),args.probe_output); return 0
    if args.crypto_probe:
        r=runtime_probe(True); _emit_probe(r,args.probe_output); return 0 if r.get('mlkem_available') else 1
    if args.roundtrip_probe: _emit_probe(headless_roundtrip_probe(),args.probe_output); return 0
    if args.ui_feature_probe: _emit_probe(ui_feature_probe(),args.probe_output); return 0
    if args.deniable_probe: _emit_probe(headless_deniable_probe(),args.probe_output); return 0
    if args.vault_manager: return _vault_manager_main()
    return launch_gui()


if __name__ == "__main__":
    raise SystemExit(main())
