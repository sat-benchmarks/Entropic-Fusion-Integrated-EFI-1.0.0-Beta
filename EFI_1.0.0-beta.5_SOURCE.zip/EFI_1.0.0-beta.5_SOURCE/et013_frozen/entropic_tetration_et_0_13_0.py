#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import getpass
import hashlib
import hmac
import json
import os
import secrets
import shutil
import sys
import time
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / 'beta1_1_1_rebuild_kit'))

import et010_base as base
import entropic_tetration_et_0_12_4 as et12
import beta1_1_1_rebuild_kit.entropic_fusion_public_identity_v0_11B_23_1 as efid

VERSION = 'Entropic Tetration ET 0.13.0-alpha'
PROTOCOL = 'ET-0.13 virtual recursive state experiment over one full Beta 1.1.1 root establishment'
PUBLIC_FORMAT = 'ET-0.13-VIRTUAL-PUBLIC-1'
PRIVATE_VAULT_FORMAT = 'ET-0.13-VIRTUAL-PRIVATE-VAULT-1'
PRIVATE_INNER_FORMAT = 'ET-0.13-VIRTUAL-PRIVATE-INNER-1'
CAPSULE_FORMAT = 'ET-0.13-VIRTUAL-CAPSULE-1'
PRIVATE_AAD_DOMAIN = b'ENTROPIC-TETRATION/ET-0.13/VIRTUAL-PRIVATE/v1'
VIRTUAL_DOMAIN = b'ENTROPIC-TETRATION/ET-0.13/VIRTUAL-STATE/v1'
FINAL_DOMAIN = b'ENTROPIC-TETRATION/ET-0.13/FINAL-KEY/v1'
PAYLOAD_DOMAIN = 'ENTROPIC-TETRATION/ET-0.13/PAYLOAD/v1'
MODULUS = 18446744073709551557  # public 64-bit prime; mathematical accumulator only
MAX_VIRTUAL_STEPS = 10_000_000


class OperationCancelled(RuntimeError):
    pass


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode('ascii')


def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode('ascii'), validate=True)


def _fingerprint(obj_without_fp: dict) -> str:
    return hashlib.sha256(canonical(obj_without_fp)).hexdigest()


def _derive_password_key(password: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    if not isinstance(password, str) or len(password) < 10:
        raise ValueError('password must be at least 10 characters')
    return Scrypt(salt=salt, length=32, n=n, r=r, p=p).derive(password.encode('utf-8'))


def _private_aad(public_fp: str) -> bytes:
    return PRIVATE_AAD_DOMAIN + b'\x00' + bytes.fromhex(public_fp)


def _pow_cap(base_value: int, exponent: int, cap: int) -> int:
    if exponent == 0:
        return 1
    if base_value in (0, 1):
        return base_value
    result = 1
    x = base_value
    e = exponent
    while e:
        if e & 1:
            if x and result > cap // x:
                return cap + 1
            result *= x
            if result > cap:
                return cap + 1
        e >>= 1
        if e:
            if x and x > cap // x:
                x = cap + 1
            else:
                x *= x
            if x > cap:
                x = cap + 1
    return result


def tetration_value(base_value: int, height: int, cap: int = MAX_VIRTUAL_STEPS) -> int:
    if base_value < 2 or height < 1:
        raise ValueError('tetration requires base >= 2 and height >= 1')
    v = base_value
    for _ in range(2, height + 1):
        v = _pow_cap(base_value, v, cap)
        if v > cap:
            return cap + 1
    return v


def pentation_value(base_value: int, height: int, cap: int = MAX_VIRTUAL_STEPS) -> int:
    if base_value < 2 or height < 1:
        raise ValueError('pentation requires base >= 2 and height >= 1')
    v = base_value
    for _ in range(2, height + 1):
        v = tetration_value(base_value, v, cap)
        if v > cap:
            return cap + 1
    return v


def virtual_plan(mode: str, base_value: int = 2, height: int = 4, standard_steps: int = 0, cap: int = MAX_VIRTUAL_STEPS) -> dict:
    m = mode.strip().lower()
    if m == 'standard':
        if standard_steps < 0 or standard_steps > cap:
            raise ValueError(f'standard virtual steps must be 0..{cap:,}')
        return {
            'mode': 'standard', 'notation': str(standard_steps), 'steps': standard_steps,
            'exact_within_cap': True,
            'description': f'one full EF + dual-ML-KEM root, then {standard_steps:,} virtual transitions',
        }
    if m == 'tetration':
        v = tetration_value(base_value, height, cap)
        notation = f'{base_value}^^{height}'
    elif m == 'pentation':
        v = pentation_value(base_value, height, cap)
        notation = f'{base_value}^^^{height}'
    else:
        raise ValueError('mode must be standard, tetration, or pentation')
    return {
        'mode': m,
        'notation': notation,
        'base': base_value,
        'height': height,
        'steps': v if v <= cap else None,
        'exact_within_cap': v <= cap,
        'description': f'{notation} = {v:,} virtual transitions' if v <= cap else f'{notation} exceeds {cap:,} executable virtual transitions',
    }


def _virtual_context(public_fp: str, transcript: bytes, plan: dict) -> bytes:
    return hashlib.sha256(canonical({
        'domain': 'ET-0.13-VIRTUAL-CONTEXT-1',
        'public_fingerprint': public_fp,
        'root_transcript_sha256': hashlib.sha256(transcript).hexdigest(),
        'mode': plan['mode'],
        'notation': plan['notation'],
        'steps': plan['steps'],
        'base': plan.get('base'),
        'height': plan.get('height'),
        'modulus': MODULUS,
    })).digest()


def virtual_chain(root_key: bytes, *, plan: dict, context: bytes, progress=None, cancel=None, progress_every: int = 2048) -> tuple[bytes, dict]:
    if len(root_key) != 32:
        raise ValueError('root key must be 256 bits')
    if not plan.get('exact_within_cap') or plan.get('steps') is None:
        raise ValueError('selected hyperoperation value is symbolic only in this build')
    steps = int(plan['steps'])
    mode = plan['mode']
    base_value = int(plan.get('base') or 2)
    state = bytes(root_key)
    tet = base_value % MODULUS
    pen = base_value % MODULUS
    start = time.perf_counter()
    if progress:
        progress('virtual', 0, steps)
    for i in range(1, steps + 1):
        if cancel is not None and cancel():
            raise OperationCancelled('virtual recursion cancelled by user')

        if mode == 'tetration':
            # Exact recurrence over the finite field accumulator: t[n+1] = b^t[n] mod p.
            tet = pow(base_value, tet, MODULUS)
            math_bytes = tet.to_bytes(8, 'big')
        elif mode == 'pentation':
            # Experimental nested recurrence. It deliberately performs a second exponentiation
            # driven by the tetration accumulator. This is a finite modular analogue, not a
            # proof that the construction has mathematical pentation hardness.
            tet = pow(base_value, tet, MODULUS)
            pen_base = 2 + (tet % (MODULUS - 3))
            pen = pow(pen_base, pen, MODULUS)
            math_bytes = tet.to_bytes(8, 'big') + pen.to_bytes(8, 'big')
        else:
            math_bytes = b''

        msg = (
            VIRTUAL_DOMAIN + b'\x00' + mode.encode('ascii') + b'\x00' +
            i.to_bytes(8, 'big') + math_bytes + context
        )
        state = hmac.new(state, msg, hashlib.sha256).digest()
        if progress and (i % progress_every == 0 or i == steps):
            progress('virtual', i, steps)

    final_key = hmac.new(state, FINAL_DOMAIN + b'\x00' + context, hashlib.sha256).digest()
    elapsed = time.perf_counter() - start
    return final_key, {
        'mode': mode,
        'notation': plan['notation'],
        'steps': steps,
        'seconds': elapsed,
        'steps_per_second': (steps / elapsed) if elapsed else None,
        'final_tetration_accumulator': tet if mode in ('tetration', 'pentation') else None,
        'final_pentation_accumulator': pen if mode == 'pentation' else None,
        'final_key_id': hashlib.sha256(final_key).hexdigest()[:24],
        'kernel_note': (
            'Every virtual transition was executed sequentially in memory. The HMAC state depends on the previous secret state. '
            'Tetration mode also executes t[n+1]=b^t[n] mod p. Pentation mode adds a nested modular exponentiation. '
            'These are experimental finite modular recurrences, not a proof of tetrational or pentational security.'
        ),
    }


def generate_identity(public_path: Path, private_vault_path: Path, *, password: str, deterministic_seed: int | None = None) -> dict:
    start = time.perf_counter()
    seed = deterministic_seed if deterministic_seed is not None else secrets.randbits(64)
    if not 0 <= seed < (1 << 64):
        raise ValueError('Beta 1.1.1 EF generator accepts 64-bit seeds only')
    pub, priv, rep = et12._identity_in_memory(seed)
    public_obj = {
        'format': PUBLIC_FORMAT,
        'version': VERSION,
        'protocol': PROTOCOL,
        'root_public_identity': pub,
        'root_public_identity_sha256': pub['public_identity_sha256'],
        'security_note': 'One full Entropic Fusion Beta 1.1.1 + ML-KEM-768 + ML-KEM-1024 root identity. No seed, witness or KEM private key is public.',
    }
    public_obj['public_fingerprint'] = _fingerprint(public_obj)
    public_path = Path(public_path)
    public_path.parent.mkdir(parents=True, exist_ok=True)
    public_path.write_text(json.dumps(public_obj, indent=2) + '\n', encoding='utf-8')

    inner = {
        'format': PRIVATE_INNER_FORMAT,
        'version': VERSION,
        'public_fingerprint': public_obj['public_fingerprint'],
        'private_identity': priv,
    }
    raw = canonical(inner)
    salt, nonce = os.urandom(16), os.urandom(12)
    n, r, p = 2**17, 8, 1
    key = _derive_password_key(password, salt, n, r, p)
    ct = AESGCM(key).encrypt(nonce, raw, _private_aad(public_obj['public_fingerprint']))
    vault = {
        'format': PRIVATE_VAULT_FORMAT,
        'version': VERSION,
        'public_fingerprint': public_obj['public_fingerprint'],
        'kdf': {'name': 'scrypt', 'n': n, 'r': r, 'p': p, 'salt_b64': b64e(salt)},
        'aead': 'AES-256-GCM',
        'nonce_b64': b64e(nonce),
        'ciphertext_b64': b64e(ct),
    }
    private_vault_path = Path(private_vault_path)
    private_vault_path.parent.mkdir(parents=True, exist_ok=True)
    private_vault_path.write_text(json.dumps(vault, indent=2) + '\n', encoding='utf-8')
    try:
        os.chmod(private_vault_path, 0o600)
    except OSError:
        pass
    return {
        'version': VERSION,
        'public_fingerprint': public_obj['public_fingerprint'],
        'ef_positions': rep['positions'],
        'ef_edges': rep['edges'],
        'ef_equations_verified': rep['equations_verified'],
        'ef_generator_seed_bits': 64,
        'seed_public': False,
        'seconds': time.perf_counter() - start,
    }


def load_public(path: Path) -> dict:
    obj = json.loads(Path(path).read_text(encoding='utf-8'))
    if obj.get('format') != PUBLIC_FORMAT:
        raise ValueError('not an ET 0.13 virtual public identity')
    claimed = obj.get('public_fingerprint')
    tmp = dict(obj)
    tmp.pop('public_fingerprint', None)
    if claimed != _fingerprint(tmp):
        raise ValueError('public fingerprint mismatch')
    et12._validate_public_identity(obj['root_public_identity'])
    return obj


def open_private(path: Path, password: str) -> dict:
    vault = json.loads(Path(path).read_text(encoding='utf-8'))
    if vault.get('format') != PRIVATE_VAULT_FORMAT:
        raise ValueError('not an ET 0.13 virtual private vault')
    k = vault['kdf']
    key = _derive_password_key(password, b64d(k['salt_b64']), int(k['n']), int(k['r']), int(k['p']))
    raw = AESGCM(key).decrypt(b64d(vault['nonce_b64']), b64d(vault['ciphertext_b64']), _private_aad(vault['public_fingerprint']))
    inner = json.loads(raw.decode('utf-8'))
    if inner.get('format') != PRIVATE_INNER_FORMAT or inner.get('public_fingerprint') != vault['public_fingerprint']:
        raise ValueError('private vault inner mismatch')
    if inner['private_identity'].get('format') != efid.PRIVATE_FORMAT:
        raise ValueError('wrong Beta 1.1.1 private identity format')
    return inner


def _root_sender_record(public_obj: dict) -> tuple[dict, bytes, bytes]:
    pub = public_obj['root_public_identity']
    d = base.derive_level_sender(pub, 1, None, None)
    rec = {
        'level': 1,
        'masked_public_identity': pub,
        'outer_nonce_b64': '',
        'inner_nonce_b64': '',
        'outer_ct_b64': b64e(d['stored_outer']),
        'inner_ct_b64': b64e(d['stored_inner']),
        'transcript_b64': b64e(d['transcript']),
        'prior_key_id': None,
    }
    return rec, d['key'], d['transcript']


def encrypt_file(public_path: Path, input_path: Path, capsule_path: Path, *, mode: str, base_value: int = 2, height: int = 4, standard_steps: int = 0, progress=None, cancel=None) -> dict:
    start = time.perf_counter()
    public_obj = load_public(public_path)
    plan = virtual_plan(mode, base_value, height, standard_steps)
    if not plan['exact_within_cap']:
        raise ValueError('selected hyperoperation value is symbolic only in ET 0.13')
    root_record, root_key, transcript = _root_sender_record(public_obj)
    context = _virtual_context(public_obj['public_fingerprint'], transcript, plan)
    final_key, vm = virtual_chain(root_key, plan=plan, context=context, progress=progress, cancel=cancel)
    data = Path(input_path).read_bytes()
    nonce = os.urandom(12)
    aad = {
        'domain': PAYLOAD_DOMAIN,
        'public_fingerprint': public_obj['public_fingerprint'],
        'filename': Path(input_path).name,
        'plaintext_bytes': len(data),
        'mode': plan['mode'],
        'notation': plan['notation'],
        'steps': plan['steps'],
        'base': plan.get('base'),
        'height': plan.get('height'),
        'virtual_context_sha256': hashlib.sha256(context).hexdigest(),
        'final_key_id': vm['final_key_id'],
    }
    ct = AESGCM(final_key).encrypt(nonce, data, canonical(aad))
    capsule = {
        'format': CAPSULE_FORMAT,
        'version': VERSION,
        'protocol': PROTOCOL,
        'public_fingerprint': public_obj['public_fingerprint'],
        'root': root_record,
        'virtual': plan,
        'payload': {'nonce_b64': b64e(nonce), 'ciphertext_b64': b64e(ct), 'aad': aad},
    }
    capsule_path = Path(capsule_path)
    capsule_path.parent.mkdir(parents=True, exist_ok=True)
    capsule_path.write_text(json.dumps(capsule, indent=2) + '\n', encoding='utf-8')
    return {
        'version': VERSION,
        'mode': plan['mode'],
        'notation': plan['notation'],
        'virtual_steps': plan['steps'],
        'root_full_crypto_establishments': 1,
        'virtual_metrics': vm,
        'capsule_bytes': capsule_path.stat().st_size,
        'total_seconds': time.perf_counter() - start,
    }


def capsule_metadata(path: Path) -> dict:
    obj = json.loads(Path(path).read_text(encoding='utf-8'))
    if obj.get('format') != CAPSULE_FORMAT:
        raise ValueError('not an ET 0.13 virtual capsule')
    aad = obj['payload']['aad']
    filename = Path(str(aad.get('filename') or 'recovered_file')).name
    return {
        'filename': filename if filename not in ('', '.', '..') else 'recovered_file',
        'mode': obj['virtual']['mode'],
        'notation': obj['virtual']['notation'],
        'steps': obj['virtual']['steps'],
        'plaintext_bytes': int(aad.get('plaintext_bytes', 0)),
    }


def decrypt_file(private_path: Path, password: str, capsule_path: Path, output_path: Path, *, progress=None, cancel=None) -> dict:
    start = time.perf_counter()
    inner = open_private(private_path, password)
    capsule = json.loads(Path(capsule_path).read_text(encoding='utf-8'))
    if capsule.get('format') != CAPSULE_FORMAT:
        raise ValueError('not an ET 0.13 virtual capsule')
    if capsule.get('public_fingerprint') != inner.get('public_fingerprint'):
        raise ValueError('capsule/private identity mismatch')
    plan = capsule['virtual']
    root_key, rep, link = base.derive_level_receiver(inner['private_identity'], capsule['root'], 1, None, None)
    transcript = b64d(capsule['root']['transcript_b64'])
    context = _virtual_context(inner['public_fingerprint'], transcript, plan)
    final_key, vm = virtual_chain(root_key, plan=plan, context=context, progress=progress, cancel=cancel)
    payload = capsule['payload']
    pt = AESGCM(final_key).decrypt(b64d(payload['nonce_b64']), b64d(payload['ciphertext_b64']), canonical(payload['aad']))
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(pt)
    return {
        'version': VERSION,
        'mode': plan['mode'],
        'notation': plan['notation'],
        'virtual_steps': plan['steps'],
        'root_relation_verified': rep['positions'] == 81 and rep['edges'] == 216 and rep['equations_verified'] == 432,
        'root_recursive_link_verified': bool(link),
        'virtual_metrics': vm,
        'recovered_bytes': len(pt),
        'total_seconds': time.perf_counter() - start,
    }


def benchmark(*, steps: int = 65536, mode: str = 'tetration') -> dict:
    if steps < 0 or steps > MAX_VIRTUAL_STEPS:
        raise ValueError('benchmark steps outside supported range')
    plan = {'mode': mode, 'notation': f'benchmark-{steps}', 'steps': steps, 'exact_within_cap': True, 'base': 2, 'height': None}
    key = hashlib.sha256(b'ET-0.13 benchmark root').digest()
    ctx = hashlib.sha256(b'ET-0.13 benchmark context').digest()
    final_key, metrics = virtual_chain(key, plan=plan, context=ctx)
    return {'version': VERSION, 'benchmark': metrics, 'final_key_sha256': hashlib.sha256(final_key).hexdigest()}


def self_test(workdir: Path) -> dict:
    workdir = Path(workdir)
    if workdir.exists():
        shutil.rmtree(workdir)
    workdir.mkdir(parents=True)
    pw = 'ET 0.13 virtual self test password 2026'
    pub = workdir / 'virtual.et13pub.json'
    priv = workdir / 'virtual.et13priv.json'
    msg = workdir / 'message.txt'
    cap_t = workdir / 'message_tetration.et13'
    cap_p = workdir / 'message_pentation.et13'
    rec_t = workdir / 'recovered_tetration.txt'
    rec_p = workdir / 'recovered_pentation.txt'
    msg.write_bytes(b'Entropic Tetration ET 0.13 virtual recursion self-test.\n')

    kg = generate_identity(pub, priv, password=pw, deterministic_seed=2026091301)
    enc_t = encrypt_file(pub, msg, cap_t, mode='tetration', base_value=2, height=4)
    dec_t = decrypt_file(priv, pw, cap_t, rec_t)
    enc_p = encrypt_file(pub, msg, cap_p, mode='pentation', base_value=2, height=3)
    dec_p = decrypt_file(priv, pw, cap_p, rec_p)

    wrong_pw = False
    try:
        open_private(priv, pw + ' wrong')
    except InvalidTag:
        wrong_pw = True

    tamper_rejected = False
    obj = json.loads(cap_t.read_text(encoding='utf-8'))
    raw = bytearray(b64d(obj['payload']['ciphertext_b64']))
    raw[-1] ^= 1
    obj['payload']['ciphertext_b64'] = b64e(bytes(raw))
    bad = workdir / 'tampered.et13'
    bad.write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')
    try:
        decrypt_file(priv, pw, bad, workdir / 'should_not_exist')
    except InvalidTag:
        tamper_rejected = True

    result = {
        'version': VERSION,
        'warning': 'Experimental virtual-recursion research. Not production cryptography and not a proof of tetrational/pentational hardness.',
        'runtime_lineage': et12.runtime_lineage(),
        'root_keygen': kg,
        'tetration': {'encrypt': enc_t, 'decrypt': dec_t, 'roundtrip_exact': rec_t.read_bytes() == msg.read_bytes()},
        'pentation': {'encrypt': enc_p, 'decrypt': dec_p, 'roundtrip_exact': rec_p.read_bytes() == msg.read_bytes()},
        'tests': {
            'tetration_2^^4_is_65536': virtual_plan('tetration', 2, 4)['steps'] == 65536,
            'pentation_2^^^3_is_65536': virtual_plan('pentation', 2, 3)['steps'] == 65536,
            'tetration_roundtrip_exact': rec_t.read_bytes() == msg.read_bytes(),
            'pentation_roundtrip_exact': rec_p.read_bytes() == msg.read_bytes(),
            'tetration_root_relation_verified': dec_t['root_relation_verified'],
            'pentation_root_relation_verified': dec_p['root_relation_verified'],
            'wrong_password_rejected': wrong_pw,
            'tampered_payload_rejected': tamper_rejected,
        },
        'suite_pass': False,
    }
    result['suite_pass'] = all(result['tests'].values())
    (workdir / 'ET_0_13_0_SELFTEST_RESULT.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    return result


def _password_from_file(path: Path | None) -> str:
    if path is not None:
        return Path(path).read_text(encoding='utf-8').rstrip('\r\n')
    return getpass.getpass('Private identity password: ')


def main(argv=None):
    ap = argparse.ArgumentParser(description=VERSION)
    sub = ap.add_subparsers(dest='cmd', required=True)

    p = sub.add_parser('plan')
    p.add_argument('--mode', choices=['standard','tetration','pentation'], default='tetration')
    p.add_argument('--base', type=int, default=2)
    p.add_argument('--height', type=int, default=4)
    p.add_argument('--standard-steps', type=int, default=0)

    p = sub.add_parser('keygen')
    p.add_argument('--public', type=Path, required=True)
    p.add_argument('--private', type=Path, required=True)
    p.add_argument('--password-file', type=Path)

    p = sub.add_parser('encrypt')
    p.add_argument('--public', type=Path, required=True)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--mode', choices=['standard','tetration','pentation'], default='tetration')
    p.add_argument('--base', type=int, default=2)
    p.add_argument('--height', type=int, default=4)
    p.add_argument('--standard-steps', type=int, default=0)

    p = sub.add_parser('decrypt')
    p.add_argument('--private', type=Path, required=True)
    p.add_argument('--password-file', type=Path)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)

    p = sub.add_parser('benchmark')
    p.add_argument('--steps', type=int, default=65536)
    p.add_argument('--mode', choices=['standard','tetration','pentation'], default='tetration')

    p = sub.add_parser('self-test')
    p.add_argument('--workdir', type=Path, default=HERE / 'ET_0_13_0_SELFTEST')

    a = ap.parse_args(argv)
    if a.cmd == 'plan':
        res = virtual_plan(a.mode, a.base, a.height, a.standard_steps)
    elif a.cmd == 'keygen':
        res = generate_identity(a.public, a.private, password=_password_from_file(a.password_file))
    elif a.cmd == 'encrypt':
        res = encrypt_file(a.public, a.input, a.output, mode=a.mode, base_value=a.base, height=a.height, standard_steps=a.standard_steps)
    elif a.cmd == 'decrypt':
        res = decrypt_file(a.private, _password_from_file(a.password_file), a.input, a.output)
    elif a.cmd == 'benchmark':
        res = benchmark(steps=a.steps, mode=a.mode)
    elif a.cmd == 'self-test':
        res = self_test(a.workdir)
    else:
        raise AssertionError(a.cmd)
    print(json.dumps(res, indent=2))
    return res


if __name__ == '__main__':
    main()
