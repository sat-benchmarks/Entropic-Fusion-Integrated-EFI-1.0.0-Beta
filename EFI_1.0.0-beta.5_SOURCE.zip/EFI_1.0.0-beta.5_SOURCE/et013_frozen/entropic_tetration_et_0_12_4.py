#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import copy
import getpass
import hashlib
import json
import os
import secrets
import shutil
import sys
import time
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / 'beta1_1_1_rebuild_kit'))

import et010_base as base
import beta1_1_1_rebuild_kit.entropic_fusion_relation_v0_11B_23_1 as efrel
import beta1_1_1_rebuild_kit.entropic_fusion_public_identity_v0_11B_23_1 as efid
from beta1_1_1_rebuild_kit.entropic_fusion_mlkem_runtime_v0_11B_23_1 import keygen_bytes, check_available
from beta1_1_1_rebuild_kit.entropic_openssl_runtime_v0_11B_23_1 import openssl_executable

VERSION = 'Entropic Tetration ET 0.12.4-alpha'
PUBLIC_TOWER_FORMAT = 'ET-0.12-PUBLIC-TOWER-1'
PRIVATE_TOWER_VAULT_FORMAT = 'ET-0.12-PRIVATE-TOWER-VAULT-1'
PRIVATE_TOWER_INNER_FORMAT = 'ET-0.12-PRIVATE-TOWER-INNER-1'
CAPSULE_FORMAT = 'ET-0.12-DEPLOYMENT-CAPSULE-1'
PROTOCOL = 'ET-0.10 recursive crypto protocol, fully audited in ET 0.11'
PRIVATE_AAD_DOMAIN = b'ENTROPIC-TETRATION/ET-0.12/PRIVATE-TOWER-VAULT/v1'

CORE_HASHES = {
    'entropic_bound_fusion_v0_11B_23_1.py': '8fdc7e7c8c8b1d45a12d09a86d799c642eec12170eaf0c221a0acc07473e81b9',
    'entropic_fusion_relation_v0_11B_23_1.py': '2ca99b6b23bcfbaf527fec957f7dd8c041a3f26a6b201f539b7e7150910c1838',
    'entropic_fusion_hybrid_combiner_v0_11B_23_1.py': 'd78f38177866c8a2821c61774cc1362cf515bfeaddd37e6de62f9b95a98e8f5d',
    'entropic_fusion_public_identity_v0_11B_23_1.py': 'e87399245ba047679c8eca388cc65f66fee2b17581ab1c633ec43b561143ed64',
    'entropic_fusion_mlkem_runtime_v0_11B_23_1.py': '4807d984ad15230c40e0f5f8ac57d1f56ed0910824d86e63bd98b587b5b76091',
}


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode('ascii')


def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode('ascii'), validate=True)


def _sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def runtime_lineage() -> dict:
    kit = HERE / 'beta1_1_1_rebuild_kit'
    source_hashes = {}
    if all((kit / n).exists() for n in CORE_HASHES):
        source_hashes = {n: _sha256_file(kit / n) for n in CORE_HASHES}
        exact = all(source_hashes[n] == CORE_HASHES[n] for n in CORE_HASHES)
    else:
        exact = None
    return {
        'beta_lineage': 'Entropic Fusion Beta 1.1.1 / B.23.1',
        'source_hash_gate_exact_when_sources_present': exact,
        'core_hashes_expected': CORE_HASHES,
        'core_hashes_observed': source_hashes or None,
        'openssl': check_available(),
        'openssl_executable': str(openssl_executable()),
        'frozen': bool(getattr(sys, 'frozen', False)),
    }


def _validate_public_identity(pub: dict) -> None:
    if pub.get('format') != efid.PUBLIC_FORMAT:
        raise ValueError('wrong Entropic Fusion public identity format')
    claimed = pub.get('public_identity_sha256')
    tmp = dict(pub)
    tmp.pop('public_identity_sha256', None)
    if claimed != efid.public_fingerprint(tmp):
        raise ValueError('Entropic Fusion public identity fingerprint mismatch')


def _identity_in_memory(seed: int) -> tuple[dict, dict, dict]:
    ef_pub, ef_witness, ef_report, fusion_secret = efrel.generate(seed)
    outer_pk, outer_sk = keygen_bytes('ML-KEM-768')
    inner_pk, inner_sk = keygen_bytes('ML-KEM-1024')
    public_obj = {
        'format': efid.PUBLIC_FORMAT,
        'version': efid.VERSION,
        'outer_kem': 'ML-KEM-768',
        'fused_inner_kem': 'ML-KEM-1024',
        'ef_relation': 'EF-v0.11-full-face-centre',
        'fusion_mode': 'EF-direct-three-leg-combiner',
        'ef_public': ef_pub,
        'ef_fusion_commitment_sha256': ef_report['fusion_commitment_sha256'],
        'outer_public_pem_b64': efid.b64e(outer_pk),
        'inner_public_pem_b64': efid.b64e(inner_pk),
    }
    public_obj['public_identity_sha256'] = efid.public_fingerprint(public_obj)
    private_obj = {
        'format': efid.PRIVATE_FORMAT,
        'version': efid.VERSION,
        'public_identity': public_obj,
        'ef_witness': ef_witness,
        'outer_private_wrapped': efid._wrap(fusion_secret, outer_sk, b'outer-mlkem-768'),
        'inner_private_wrapped': efid._wrap(fusion_secret, inner_sk, b'inner-mlkem-1024'),
    }
    return public_obj, private_obj, ef_report


def _public_bundle_fingerprint(obj_without_fp: dict) -> str:
    return hashlib.sha256(canonical(obj_without_fp)).hexdigest()


def _derive_password_key(password: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    if not isinstance(password, str) or len(password) < 10:
        raise ValueError('password must be at least 10 characters')
    return Scrypt(salt=salt, length=32, n=n, r=r, p=p).derive(password.encode('utf-8'))


def _private_aad(public_fp: str, depth: int) -> bytes:
    return PRIVATE_AAD_DOMAIN + b'\x00' + bytes.fromhex(public_fp) + depth.to_bytes(8, 'big')


def generate_tower(public_path: Path, private_vault_path: Path, *, depth: int, password: str, deterministic_seed0: int | None = None, progress=None) -> dict:
    if depth < 2:
        raise ValueError('depth must be >= 2')
    if depth > 65536:
        raise ValueError('deployment keygen cap is 65,536 levels')
    start = time.perf_counter()
    public_levels = []
    private_levels = []
    for level in range(1, depth + 1):
        if deterministic_seed0 is not None:
            seed = deterministic_seed0 + level - 1
            if not 0 <= seed < (1 << 64):
                raise ValueError('Beta 1.1.1 EF instance generator accepts 64-bit seeds only')
        else:
            # Exact Beta 1.1.1/B.23.1 generator serialises its seed on 8 bytes.
            # Keep the seed private and draw it uniformly from the supported 64-bit domain.
            seed = secrets.randbits(64)
        pub, priv, _rep = _identity_in_memory(seed)
        public_levels.append({'level': level, 'public_identity': pub, 'public_identity_sha256': pub['public_identity_sha256']})
        private_levels.append({'level': level, 'private_identity': priv})
        if progress:
            progress('keygen', level, depth)

    public_obj = {
        'format': PUBLIC_TOWER_FORMAT,
        'version': VERSION,
        'protocol': PROTOCOL,
        'depth': depth,
        'levels': public_levels,
        'security_note': 'Complete public identities only. No EF generation seeds, EF witnesses, or ML-KEM private keys.',
    }
    public_obj['tower_public_sha256'] = _public_bundle_fingerprint(public_obj)
    public_path = Path(public_path)
    public_path.parent.mkdir(parents=True, exist_ok=True)
    public_path.write_text(json.dumps(public_obj, indent=2) + '\n', encoding='utf-8')

    inner = {
        'format': PRIVATE_TOWER_INNER_FORMAT,
        'version': VERSION,
        'protocol': PROTOCOL,
        'depth': depth,
        'tower_public_sha256': public_obj['tower_public_sha256'],
        'levels': private_levels,
    }
    raw = canonical(inner)
    salt = os.urandom(16)
    nonce = os.urandom(12)
    n, r, p = 2**17, 8, 1
    key = _derive_password_key(password, salt, n, r, p)
    ct = AESGCM(key).encrypt(nonce, raw, _private_aad(public_obj['tower_public_sha256'], depth))
    vault = {
        'format': PRIVATE_TOWER_VAULT_FORMAT,
        'version': VERSION,
        'protocol': PROTOCOL,
        'depth': depth,
        'tower_public_sha256': public_obj['tower_public_sha256'],
        'kdf': {'name': 'scrypt', 'n': n, 'r': r, 'p': p, 'salt_b64': b64e(salt)},
        'aead': 'AES-256-GCM',
        'nonce_b64': b64e(nonce),
        'ciphertext_b64': b64e(ct),
        'security_note': 'Single password-protected private tower vault. Plain per-level private identity files are not materialised by ET 0.12.',
    }
    private_vault_path = Path(private_vault_path)
    private_vault_path.parent.mkdir(parents=True, exist_ok=True)
    private_vault_path.write_text(json.dumps(vault, indent=2) + '\n', encoding='utf-8')
    try:
        os.chmod(private_vault_path, 0o600)
    except OSError:
        pass
    return {
        'version': VERSION,
        'depth': depth,
        'tower_public_sha256': public_obj['tower_public_sha256'],
        'public_bytes': public_path.stat().st_size,
        'private_vault_bytes': private_vault_path.stat().st_size,
        'deterministic_test_mode': deterministic_seed0 is not None,
        'ef_generator_seed_bits': 64,
        'ef_generator_seed_serialised_publicly': False,
        'seconds': time.perf_counter() - start,
    }


def load_public_tower(path: Path) -> dict:
    obj = json.loads(Path(path).read_text(encoding='utf-8'))
    if obj.get('format') != PUBLIC_TOWER_FORMAT:
        raise ValueError('not an ET 0.12 public tower')
    claimed = obj.get('tower_public_sha256')
    tmp = dict(obj)
    tmp.pop('tower_public_sha256', None)
    if claimed != _public_bundle_fingerprint(tmp):
        raise ValueError('public tower fingerprint mismatch')
    if len(obj.get('levels', [])) != int(obj['depth']):
        raise ValueError('public tower depth mismatch')
    for i, row in enumerate(obj['levels'], 1):
        if int(row.get('level', -1)) != i:
            raise ValueError('public tower level order mismatch')
        _validate_public_identity(row['public_identity'])
        if row.get('public_identity_sha256') != row['public_identity']['public_identity_sha256']:
            raise ValueError('public identity hash row mismatch')
    return obj


def open_private_tower(path: Path, password: str) -> dict:
    vault = json.loads(Path(path).read_text(encoding='utf-8'))
    if vault.get('format') != PRIVATE_TOWER_VAULT_FORMAT:
        raise ValueError('not an ET 0.12 private tower vault')
    if vault.get('aead') != 'AES-256-GCM':
        raise ValueError('unsupported private tower AEAD')
    k = vault['kdf']
    if k.get('name') != 'scrypt':
        raise ValueError('unsupported private tower KDF')
    depth = int(vault['depth'])
    public_fp = str(vault['tower_public_sha256'])
    key = _derive_password_key(password, b64d(k['salt_b64']), int(k['n']), int(k['r']), int(k['p']))
    raw = AESGCM(key).decrypt(b64d(vault['nonce_b64']), b64d(vault['ciphertext_b64']), _private_aad(public_fp, depth))
    inner = json.loads(raw.decode('utf-8'))
    if inner.get('format') != PRIVATE_TOWER_INNER_FORMAT or int(inner.get('depth', -1)) != depth:
        raise ValueError('private tower inner format mismatch')
    if inner.get('tower_public_sha256') != public_fp:
        raise ValueError('private tower public fingerprint mismatch')
    if len(inner.get('levels', [])) != depth:
        raise ValueError('private tower depth mismatch')
    for i, row in enumerate(inner['levels'], 1):
        if int(row.get('level', -1)) != i:
            raise ValueError('private tower level order mismatch')
        priv = row['private_identity']
        if priv.get('format') != efid.PRIVATE_FORMAT:
            raise ValueError('wrong Entropic Fusion private identity format')
        _validate_public_identity(priv['public_identity'])
    return inner


def encrypt_file(public_tower_path: Path, input_path: Path, capsule_path: Path, *, progress=None) -> dict:
    tower = load_public_tower(public_tower_path)
    depth = int(tower['depth'])
    data = Path(input_path).read_bytes()
    previous_key = None
    prior_key_id = None
    levels = []
    start = time.perf_counter()
    for row in tower['levels']:
        level = int(row['level'])
        pub = row['public_identity']
        masked_pub = copy.deepcopy(pub) if level == 1 else base.transform_public(pub, previous_key, level, +1)
        d = base.derive_level_sender(masked_pub, level, previous_key, prior_key_id)
        levels.append({
            'level': level,
            'masked_public_identity': masked_pub,
            'outer_nonce_b64': b64e(d['outer_nonce']),
            'inner_nonce_b64': b64e(d['inner_nonce']),
            'outer_ct_b64': b64e(d['stored_outer']),
            'inner_ct_b64': b64e(d['stored_inner']),
            'transcript_b64': b64e(d['transcript']),
            'prior_key_id': prior_key_id,
        })
        previous_key = d['key']
        prior_key_id = base.derive_key_id(previous_key)
        if progress:
            progress('encrypt', level, depth)
    nonce = os.urandom(12)
    aad = {
        'domain': 'ENTROPIC-TETRATION/ET-0.12/FINAL-PAYLOAD/v1',
        'protocol': PROTOCOL,
        'depth': depth,
        'filename': Path(input_path).name,
        'plaintext_bytes': len(data),
        'tower_public_sha256': tower['tower_public_sha256'],
        'final_key_id': prior_key_id,
    }
    ct = AESGCM(previous_key).encrypt(nonce, data, canonical(aad))
    capsule = {
        'format': CAPSULE_FORMAT,
        'version': VERSION,
        'protocol': PROTOCOL,
        'depth': depth,
        'tower_public_sha256': tower['tower_public_sha256'],
        'filename': Path(input_path).name,
        'plaintext_bytes': len(data),
        'levels': levels,
        'payload': {'nonce_b64': b64e(nonce), 'ciphertext_b64': b64e(ct), 'aad': aad},
    }
    capsule_path = Path(capsule_path)
    capsule_path.parent.mkdir(parents=True, exist_ok=True)
    capsule_path.write_text(json.dumps(capsule, indent=2) + '\n', encoding='utf-8')
    return {
        'version': VERSION,
        'depth': depth,
        'tower_public_sha256': tower['tower_public_sha256'],
        'final_key_id': prior_key_id,
        'capsule_bytes': capsule_path.stat().st_size,
        'seconds': time.perf_counter() - start,
    }



def capsule_metadata(path: Path) -> dict:
    """Read only non-secret capsule metadata needed by the GUI."""
    obj = json.loads(Path(path).read_text(encoding='utf-8'))
    if obj.get('format') != CAPSULE_FORMAT:
        raise ValueError('not an ET 0.12 deployment capsule')
    filename = Path(str(obj.get('filename') or 'recovered_file')).name
    if filename in ('', '.', '..'):
        filename = 'recovered_file'
    depth = int(obj.get('depth', 0))
    if depth < 2 or depth > 65536:
        raise ValueError('invalid capsule depth')
    return {
        'filename': filename,
        'depth': depth,
        'plaintext_bytes': int(obj.get('plaintext_bytes', 0)),
        'tower_public_sha256': str(obj.get('tower_public_sha256', '')),
    }


def decrypt_file(private_tower_path: Path, password: str, capsule_path: Path, output_path: Path, *, progress=None) -> dict:
    inner = open_private_tower(private_tower_path, password)
    capsule = json.loads(Path(capsule_path).read_text(encoding='utf-8'))
    if capsule.get('format') != CAPSULE_FORMAT:
        raise ValueError('not an ET 0.12 deployment capsule')
    if int(capsule.get('depth', -1)) != int(inner['depth']):
        raise ValueError('capsule/private tower depth mismatch')
    if capsule.get('tower_public_sha256') != inner.get('tower_public_sha256'):
        raise ValueError('capsule/private tower identity mismatch')
    if len(capsule.get('levels', [])) != int(inner['depth']):
        raise ValueError('capsule level count mismatch')
    previous_key = None
    prior_key_id = None
    reports = []
    start = time.perf_counter()
    for prow, cap in zip(inner['levels'], capsule['levels']):
        level = int(prow['level'])
        if int(cap.get('level', -1)) != level:
            raise ValueError('capsule/private level order mismatch')
        priv = prow['private_identity']
        key, rep, link_verified = base.derive_level_receiver(priv, cap, level, previous_key, prior_key_id)
        previous_key = key
        prior_key_id = base.derive_key_id(key)
        reports.append({
            'level': level,
            'recursive_link_verified': bool(link_verified),
            'key_id': prior_key_id,
            'ef_positions': rep['positions'],
            'ef_edges': rep['edges'],
            'ef_equations_verified': rep['equations_verified'],
        })
        if progress:
            progress('decrypt', level, int(inner['depth']))
    payload = capsule['payload']
    pt = AESGCM(previous_key).decrypt(b64d(payload['nonce_b64']), b64d(payload['ciphertext_b64']), canonical(payload['aad']))
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(pt)
    return {
        'version': VERSION,
        'depth': int(inner['depth']),
        'tower_public_sha256': inner['tower_public_sha256'],
        'final_key_id': prior_key_id,
        'recovered_bytes': len(pt),
        'output_sha256': hashlib.sha256(pt).hexdigest(),
        'all_levels_full_relation': all(r['ef_positions'] == 81 and r['ef_edges'] == 216 and r['ef_equations_verified'] == 432 for r in reports),
        'all_recursive_links_verified': all(r['recursive_link_verified'] for r in reports),
        'levels': reports,
        'seconds': time.perf_counter() - start,
    }


def self_test(workdir: Path, *, depth: int = 4) -> dict:
    workdir = Path(workdir)
    if workdir.exists():
        shutil.rmtree(workdir)
    workdir.mkdir(parents=True)
    password = 'ET-0.12 self-test password 2026'
    message = b'Entropic Tetration ET 0.12.0 Windows deployment self-test.\n'
    inp = workdir / 'message.txt'
    pub = workdir / 'test.et12pub.json'
    priv = workdir / 'test.et12priv.json'
    cap = workdir / 'message.et12'
    rec = workdir / 'recovered.txt'
    inp.write_bytes(message)
    lineage = runtime_lineage()
    kg = generate_tower(pub, priv, depth=depth, password=password, deterministic_seed0=2026091201)
    enc = encrypt_file(pub, inp, cap)
    dec = decrypt_file(priv, password, cap, rec)

    public_text = pub.read_text(encoding='utf-8')
    no_private_material_in_public = all(x not in public_text for x in ('ef_witness', 'outer_private', 'inner_private', '"seed"', 'seed0'))
    private_is_vault_only = all(x not in priv.read_text(encoding='utf-8') for x in ('ef_witness', 'outer_private_wrapped', 'inner_private_wrapped'))

    wrong_password_rejected = False
    try:
        open_private_tower(priv, password + ' WRONG')
    except InvalidTag:
        wrong_password_rejected = True

    tampered_capsule_rejected = False
    cap_obj = json.loads(cap.read_text(encoding='utf-8'))
    rawct = bytearray(b64d(cap_obj['payload']['ciphertext_b64']))
    rawct[-1] ^= 1
    cap_obj['payload']['ciphertext_b64'] = b64e(bytes(rawct))
    badcap = workdir / 'tampered.et12'
    badcap.write_text(json.dumps(cap_obj, indent=2) + '\n', encoding='utf-8')
    try:
        decrypt_file(priv, password, badcap, workdir / 'should_not_exist.txt')
    except InvalidTag:
        tampered_capsule_rejected = True

    tampered_public_rejected = False
    p = json.loads(pub.read_text(encoding='utf-8'))
    p['depth'] = int(p['depth']) + 1
    badpub = workdir / 'tampered.et12pub.json'
    badpub.write_text(json.dumps(p, indent=2) + '\n', encoding='utf-8')
    try:
        load_public_tower(badpub)
    except ValueError:
        tampered_public_rejected = True

    exact = rec.read_bytes() == message
    result = {
        'version': VERSION,
        'mode': 'deployment-format-and-windows-packaging-self-test',
        'warning': 'Engineering validation only. Not a security proof.',
        'depth': depth,
        'runtime_lineage': lineage,
        'keygen': kg,
        'encrypt': enc,
        'decrypt': dec,
        'tests': {
            'exact_file_roundtrip': exact,
            'all_levels_full_relation': dec['all_levels_full_relation'],
            'all_recursive_links_verified': dec['all_recursive_links_verified'],
            'public_bundle_contains_no_seed_witness_or_kem_private_fields': no_private_material_in_public,
            'private_file_is_ciphertext_vault_not_plain_private_json': private_is_vault_only,
            'wrong_private_vault_password_rejected': wrong_password_rejected,
            'tampered_payload_ciphertext_rejected': tampered_capsule_rejected,
            'tampered_public_bundle_rejected': tampered_public_rejected,
        },
        'known_limitation': 'ET 0.8 dual-KEM-compromise finding remains open; ET 0.12.x changes deployment containers and Windows packaging, not the cryptographic combiner.',
    }
    result['suite_pass'] = all(result['tests'].values())
    return result


def _password_from_file(path: Path | None, confirm=False) -> str:
    if path:
        pw = Path(path).read_text(encoding='utf-8').rstrip('\r\n')
        if len(pw) < 10:
            raise ValueError('password file must contain at least 10 characters')
        return pw
    pw = getpass.getpass('Private tower password: ')
    if confirm:
        pw2 = getpass.getpass('Confirm password: ')
        if pw != pw2:
            raise ValueError('passwords do not match')
    return pw


def main(argv=None):
    ap = argparse.ArgumentParser(description=VERSION)
    sub = ap.add_subparsers(dest='cmd', required=True)

    p = sub.add_parser('self-test')
    p.add_argument('--workdir', type=Path, default=HERE / 'ET_0_12_0_SELFTEST_OUTPUT')
    p.add_argument('--depth', type=int, default=4)
    p.add_argument('--out-json', type=Path)

    p = sub.add_parser('keygen')
    p.add_argument('--depth', type=int, default=4)
    p.add_argument('--public', type=Path, required=True)
    p.add_argument('--private', type=Path, required=True)
    p.add_argument('--password-file', type=Path)

    p = sub.add_parser('encrypt')
    p.add_argument('--public', type=Path, required=True)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)

    p = sub.add_parser('decrypt')
    p.add_argument('--private', type=Path, required=True)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--password-file', type=Path)

    p = sub.add_parser('runtime-info')
    p.add_argument('--out-json', type=Path)

    a = ap.parse_args(argv)
    if a.cmd == 'self-test':
        res = self_test(a.workdir, depth=a.depth)
        if a.out_json:
            a.out_json.write_text(json.dumps(res, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(res, indent=2))
        return 0 if res['suite_pass'] else 1
    if a.cmd == 'keygen':
        pw = _password_from_file(a.password_file, confirm=a.password_file is None)
        res = generate_tower(a.public, a.private, depth=a.depth, password=pw)
        print(json.dumps(res, indent=2))
        return 0
    if a.cmd == 'encrypt':
        res = encrypt_file(a.public, a.input, a.output)
        print(json.dumps(res, indent=2))
        return 0
    if a.cmd == 'decrypt':
        pw = _password_from_file(a.password_file)
        res = decrypt_file(a.private, pw, a.input, a.output)
        print(json.dumps(res, indent=2))
        return 0
    if a.cmd == 'runtime-info':
        res = runtime_lineage()
        if a.out_json:
            a.out_json.write_text(json.dumps(res, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(res, indent=2))
        return 0
    raise AssertionError(a.cmd)


if __name__ == '__main__':
    raise SystemExit(main())
