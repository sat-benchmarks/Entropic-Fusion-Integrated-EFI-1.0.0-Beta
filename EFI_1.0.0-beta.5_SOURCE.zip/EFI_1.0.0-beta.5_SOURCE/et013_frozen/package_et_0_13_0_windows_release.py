#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent; REL=HERE/'release'
def h(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    REL.mkdir(exist_ok=True); exe=HERE/'dist'/'EntropicTetration.exe'; setup=REL/'EntropicTetration_ET_0_13_0_Setup.exe'
    if not exe.exists(): raise FileNotFoundError(exe)
    if not setup.exists(): raise FileNotFoundError(setup)
    portable=REL/'EntropicTetration_ET_0_13_0_Portable.zip'
    with zipfile.ZipFile(portable,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        z.write(exe,'EntropicTetration.exe'); z.write(HERE/'README.md','README.md'); z.write(HERE/'QUICKSTART_WINDOWS.txt','QUICKSTART_WINDOWS.txt')
    frozen=json.loads((HERE/'ET_0_13_0_FROZEN_RESULT.json').read_text())
    if not frozen.get('all_tests_passed'): raise RuntimeError('refusing release: frozen gate did not pass')
    result={'version':'ET 0.13.0-alpha','scope':'Self-contained Windows virtual-recursion research release','portable_zip':str(portable),'portable_zip_sha256':h(portable),'portable_exe_sha256':h(exe),'installer':str(setup),'installer_sha256':h(setup),'frozen_import_closure_passed':frozen['tests'].get('frozen_beta111_import_closure') is True,'frozen_virtual_probe_passed':frozen['tests'].get('frozen_virtual_probe') is True,'end_user_python_required':False,'end_user_openssl_install_required':False,'end_user_network_required':False,'winfsp_required':False,'all_tests_passed':True}
    (HERE/'ET_0_13_0_WINDOWS_RELEASE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
if __name__=='__main__': main()
