[Setup]
AppId={{F4F06F04-2E2E-4E3D-A70D-001300000001}
AppName=Entropic Tetration
AppVersion=0.13.0-alpha
AppPublisher=Entropic Tetration Research
DefaultDirName={localappdata}\Programs\EntropicTetration
DefaultGroupName=Entropic Tetration
OutputDir=release
OutputBaseFilename=EntropicTetration_ET_0_13_0_Setup
Compression=lzma2/ultra64
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
WizardStyle=modern
UninstallDisplayIcon={app}\EntropicTetration.exe

[Files]
Source: "dist\EntropicTetration.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "QUICKSTART_WINDOWS.txt"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Entropic Tetration"; Filename: "{app}\EntropicTetration.exe"
Name: "{autodesktop}\Entropic Tetration"; Filename: "{app}\EntropicTetration.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"; Flags: unchecked

[Run]
Filename: "{app}\EntropicTetration.exe"; Description: "Launch Entropic Tetration"; Flags: nowait postinstall skipifsilent
