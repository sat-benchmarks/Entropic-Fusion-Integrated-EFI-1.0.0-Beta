#!/usr/bin/env python3
from __future__ import annotations
import ctypes, ctypes.wintypes as wt, json, os

if os.name == 'nt':
    kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
    advapi32=ctypes.WinDLL('advapi32',use_last_error=True)
    INVALID_HANDLE_VALUE=wt.HANDLE(-1).value
    PIPE_ACCESS_DUPLEX=0x00000003; PIPE_TYPE_MESSAGE=0x00000004; PIPE_READMODE_MESSAGE=0x00000002; PIPE_WAIT=0
    PIPE_UNLIMITED_INSTANCES=255; OPEN_EXISTING=3; GENERIC_READ=0x80000000; GENERIC_WRITE=0x40000000
    ERROR_PIPE_CONNECTED=535; ERROR_BROKEN_PIPE=109; TOKEN_QUERY=0x0008; TokenUser=1; SDDL_REVISION_1=1
    class SID_AND_ATTRIBUTES(ctypes.Structure): _fields_=[('Sid',wt.LPVOID),('Attributes',wt.DWORD)]
    class TOKEN_USER(ctypes.Structure): _fields_=[('User',SID_AND_ATTRIBUTES)]
    class SECURITY_ATTRIBUTES(ctypes.Structure):
        _fields_=[('nLength',wt.DWORD),('lpSecurityDescriptor',wt.LPVOID),('bInheritHandle',wt.BOOL)]
    kernel32.GetCurrentProcess.restype=wt.HANDLE
    advapi32.OpenProcessToken.argtypes=[wt.HANDLE,wt.DWORD,ctypes.POINTER(wt.HANDLE)]
    advapi32.GetTokenInformation.argtypes=[wt.HANDLE,ctypes.c_int,wt.LPVOID,wt.DWORD,ctypes.POINTER(wt.DWORD)]
    advapi32.ConvertSidToStringSidW.argtypes=[wt.LPVOID,ctypes.POINTER(wt.LPWSTR)]
    advapi32.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes=[wt.LPCWSTR,wt.DWORD,ctypes.POINTER(wt.LPVOID),ctypes.POINTER(wt.DWORD)]
    kernel32.LocalFree.argtypes=[wt.HLOCAL]; kernel32.CloseHandle.argtypes=[wt.HANDLE]
    kernel32.CreateNamedPipeW.argtypes=[wt.LPCWSTR,wt.DWORD,wt.DWORD,wt.DWORD,wt.DWORD,wt.DWORD,wt.DWORD,ctypes.POINTER(SECURITY_ATTRIBUTES)]
    kernel32.CreateNamedPipeW.restype=wt.HANDLE
    kernel32.ConnectNamedPipe.argtypes=[wt.HANDLE,wt.LPVOID]; kernel32.DisconnectNamedPipe.argtypes=[wt.HANDLE]
    kernel32.ReadFile.argtypes=[wt.HANDLE,wt.LPVOID,wt.DWORD,ctypes.POINTER(wt.DWORD),wt.LPVOID]
    kernel32.WriteFile.argtypes=[wt.HANDLE,wt.LPCVOID,wt.DWORD,ctypes.POINTER(wt.DWORD),wt.LPVOID]
    kernel32.FlushFileBuffers.argtypes=[wt.HANDLE]
    kernel32.CreateFileW.argtypes=[wt.LPCWSTR,wt.DWORD,wt.DWORD,wt.LPVOID,wt.DWORD,wt.DWORD,wt.HANDLE]; kernel32.CreateFileW.restype=wt.HANDLE
    kernel32.SetNamedPipeHandleState.argtypes=[wt.HANDLE,ctypes.POINTER(wt.DWORD),wt.LPVOID,wt.LPVOID]

def _winerr(msg): raise ctypes.WinError(ctypes.get_last_error(),msg)

def current_user_sid_string():
    if os.name!='nt': raise RuntimeError('Windows only')
    token=wt.HANDLE()
    if not advapi32.OpenProcessToken(kernel32.GetCurrentProcess(),TOKEN_QUERY,ctypes.byref(token)): _winerr('OpenProcessToken')
    try:
        needed=wt.DWORD(0); advapi32.GetTokenInformation(token,TokenUser,None,0,ctypes.byref(needed))
        buf=ctypes.create_string_buffer(needed.value)
        if not advapi32.GetTokenInformation(token,TokenUser,buf,needed,ctypes.byref(needed)): _winerr('GetTokenInformation')
        tu=ctypes.cast(buf,ctypes.POINTER(TOKEN_USER)).contents; out=wt.LPWSTR()
        if not advapi32.ConvertSidToStringSidW(tu.User.Sid,ctypes.byref(out)): _winerr('ConvertSidToStringSidW')
        try: return out.value
        finally: kernel32.LocalFree(out)
    finally: kernel32.CloseHandle(token)

def _security_attributes_for_current_user():
    sid=current_user_sid_string(); sddl=f'D:P(A;;GA;;;{sid})'; sd=wt.LPVOID(); size=wt.DWORD()
    if not advapi32.ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl,SDDL_REVISION_1,ctypes.byref(sd),ctypes.byref(size)):
        _winerr('ConvertStringSecurityDescriptorToSecurityDescriptorW')
    sa=SECURITY_ATTRIBUTES(ctypes.sizeof(SECURITY_ATTRIBUTES),sd,False)
    return sa,sd,sid,sddl

def create_server_pipe(pipe_name):
    sa,sd,sid,sddl=_security_attributes_for_current_user()
    try:
        h=kernel32.CreateNamedPipeW(pipe_name,PIPE_ACCESS_DUPLEX,PIPE_TYPE_MESSAGE|PIPE_READMODE_MESSAGE|PIPE_WAIT,PIPE_UNLIMITED_INSTANCES,65536,65536,0,ctypes.byref(sa))
        if h==INVALID_HANDLE_VALUE: _winerr('CreateNamedPipeW')
        return h,sid,sddl
    finally: kernel32.LocalFree(sd)

def connect_server_pipe(h):
    ok=kernel32.ConnectNamedPipe(h,None)
    if not ok and ctypes.get_last_error()!=ERROR_PIPE_CONNECTED: _winerr('ConnectNamedPipe')

def open_client_pipe(pipe_name):
    h=kernel32.CreateFileW(pipe_name,GENERIC_READ|GENERIC_WRITE,0,None,OPEN_EXISTING,0,None)
    if h==INVALID_HANDLE_VALUE: _winerr('CreateFileW named pipe')
    mode=wt.DWORD(PIPE_READMODE_MESSAGE)
    if not kernel32.SetNamedPipeHandleState(h,ctypes.byref(mode),None,None):
        kernel32.CloseHandle(h); _winerr('SetNamedPipeHandleState')
    return h

def close_handle(h):
    if h not in (None,INVALID_HANDLE_VALUE): kernel32.CloseHandle(h)

def disconnect_pipe(h):
    try: kernel32.FlushFileBuffers(h)
    except Exception: pass
    kernel32.DisconnectNamedPipe(h)

def write_json(h,obj):
    data=(json.dumps(obj,separators=(',',':'))+'\n').encode('utf-8'); written=wt.DWORD(); buf=ctypes.create_string_buffer(data)
    if not kernel32.WriteFile(h,buf,len(data),ctypes.byref(written),None): _winerr('WriteFile')
    if written.value!=len(data): raise OSError('short named-pipe write')

def read_json(h,max_bytes=1024*1024):
    chunks=[]; total=0
    while total<max_bytes:
        buf=ctypes.create_string_buffer(65536); got=wt.DWORD(); ok=kernel32.ReadFile(h,buf,len(buf),ctypes.byref(got),None)
        if not ok:
            err=ctypes.get_last_error()
            if err==ERROR_BROKEN_PIPE and total: break
            _winerr('ReadFile')
        if got.value==0: break
        part=buf.raw[:got.value]; chunks.append(part); total+=len(part)
        if b'\n' in part: break
    if total>=max_bytes: raise ValueError('named-pipe request too large')
    line=b''.join(chunks).split(b'\n',1)[0]
    return json.loads(line.decode('utf-8'))
