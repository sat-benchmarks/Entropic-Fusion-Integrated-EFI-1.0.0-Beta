#!/usr/bin/env python3
from __future__ import annotations
from pathlib import PureWindowsPath

VERSION = "Beta1.1.1-path2"
_DEFAULT_STREAM_SUFFIXES = ("::$data", ":$data")


def callback_path(path) -> str:
    """Normalise a Win32/WinFsp callback path into the vault-root namespace.

    Supported aliases intentionally include only the unnamed/default data stream.
    Genuine named alternate streams remain unsupported and therefore do not alias
    ordinary vault files.
    """
    raw = str(path).replace("/", "\\")

    # Common Win32 namespace/device prefixes seen by filesystem callbacks.
    if raw.startswith("\\\\?\\"):
        raw = raw[4:]
    elif raw.startswith("\\??\\"):
        raw = raw[4:]
    elif raw.startswith("\\\\.\\"):
        raw = raw[4:]

    # The backing metadata is volume-root relative, never drive-qualified.
    if len(raw) >= 2 and raw[1] == ":":
        raw = raw[2:]

    # Windows can address the unnamed stream explicitly. Treat those spellings
    # as the file itself. Do not strip arbitrary :stream names.
    low = raw.casefold()
    for suffix in _DEFAULT_STREAM_SUFFIXES:
        if low.endswith(suffix):
            raw = raw[:-len(suffix)]
            break

    p = str(PureWindowsPath(raw))
    if p in ("", ".", "/", "\\"):
        return "\\"
    if not p.startswith("\\"):
        p = "\\" + p
    return p


def parent_path(path) -> str:
    p = PureWindowsPath(callback_path(path))
    q = str(p.parent)
    return "\\" if q in (".", "/", "\\") else callback_path(q)


def leaf_name(path) -> str:
    return PureWindowsPath(callback_path(path)).name
