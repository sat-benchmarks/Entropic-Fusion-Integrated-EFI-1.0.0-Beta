# Namespace marker for ET 0.12 Windows packaging. Core Beta 1.1.1 source files are unchanged.
