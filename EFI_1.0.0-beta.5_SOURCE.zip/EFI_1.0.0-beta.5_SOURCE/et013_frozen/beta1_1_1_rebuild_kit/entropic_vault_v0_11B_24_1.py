#!/usr/bin/env python3
from __future__ import annotations
import os, json, base64, hashlib, hmac, struct
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

VERSION="0.11B.24.1"
MAGIC=b"EFVAULT2"
FORMAT="EF-VAULT-2"
HEADER_REGION=64*1024
SECTOR_SIZE=4096
GEN_SIZE=8
TAG_SIZE=16
RECORD_SIZE=GEN_SIZE+SECTOR_SIZE+TAG_SIZE

def b64e(x:bytes)->str:
    return base64.b64encode(x).decode("ascii")

def b64d(s:str)->bytes:
    return base64.b64decode(s.encode("ascii"), validate=True)

def canonical(obj)->bytes:
    return json.dumps(obj,sort_keys=True,separators=(",",":")).encode("utf-8")

def derive_storage_key(master_key:bytes, vault_id:bytes)->bytes:
    if len(master_key)!=32:
        raise ValueError("vault master key must be 32 bytes")
    return hmac.new(master_key,b"ENTROPIC-VAULT/B24.1/STORAGE/"+vault_id,hashlib.sha256).digest()

def create_vault(path:Path, size_bytes:int, wrapped_master_key:dict, *,
                 label:str="Entropic Vault", vault_id:bytes|None=None)->dict:
    path=Path(path)
    if size_bytes < SECTOR_SIZE:
        raise ValueError("vault too small")
    if vault_id is None:
        vault_id=os.urandom(16)
    if len(vault_id)!=16:
        raise ValueError("vault_id must be 16 bytes")
    sectors=(size_bytes+SECTOR_SIZE-1)//SECTOR_SIZE
    header={
        "format":FORMAT,
        "version":VERSION,
        "label":label,
        "vault_id_b64":b64e(vault_id),
        "sector_size":SECTOR_SIZE,
        "sector_count":sectors,
        "record_size":RECORD_SIZE,
        "wrapped_master_key":wrapped_master_key,
    }
    hb=canonical(header)
    if len(MAGIC)+4+len(hb)>HEADER_REGION:
        raise ValueError("vault header too large")
    path.parent.mkdir(parents=True,exist_ok=True)
    with open(path,"wb") as f:
        f.write(MAGIC)
        f.write(struct.pack(">I",len(hb)))
        f.write(hb)
        f.write(b"\x00"*(HEADER_REGION-len(MAGIC)-4-len(hb)))
        f.truncate(HEADER_REGION+sectors*RECORD_SIZE)
    return {
        "format":FORMAT,
        "version":VERSION,
        "path":str(path),
        "sector_count":sectors,
        "logical_size_bytes":sectors*SECTOR_SIZE,
        "physical_size_bytes":path.stat().st_size,
        "vault_id_sha256":hashlib.sha256(vault_id).hexdigest(),
    }

def read_header(path:Path)->dict:
    path=Path(path)
    with open(path,"rb") as f:
        if f.read(len(MAGIC))!=MAGIC:
            raise ValueError("not an Entropic Vault v2 container")
        n_raw=f.read(4)
        if len(n_raw)!=4:
            raise ValueError("truncated vault header")
        n=struct.unpack(">I",n_raw)[0]
        if n<=0 or n>HEADER_REGION-len(MAGIC)-4:
            raise ValueError("invalid vault header length")
        header=json.loads(f.read(n).decode("utf-8"))
    if header.get("format")!=FORMAT:
        raise ValueError("unsupported Entropic Vault format")
    if int(header.get("sector_size",0))!=SECTOR_SIZE or int(header.get("record_size",0))!=RECORD_SIZE:
        raise ValueError("vault geometry mismatch")
    return header

def _record_offset(index:int)->int:
    return HEADER_REGION+index*RECORD_SIZE

def _sector_nonce(storage_key:bytes,vault_id:bytes,index:int,generation:int)->bytes:
    material=(b"ENTROPIC-VAULT/B24.1/SECTOR-NONCE/"+
              vault_id+index.to_bytes(8,"big")+generation.to_bytes(8,"big"))
    return hmac.new(storage_key,material,hashlib.sha256).digest()[:12]

def _sector_aad(header:dict,index:int,generation:int)->bytes:
    return canonical({
        "format":FORMAT,
        "vault_id_b64":header["vault_id_b64"],
        "sector_index":index,
        "generation":generation,
        "sector_size":SECTOR_SIZE,
    })

def _current_generation(path:Path,index:int)->int:
    with open(path,"rb") as f:
        f.seek(_record_offset(index))
        raw=f.read(GEN_SIZE)
    if len(raw)!=GEN_SIZE:
        raise ValueError("truncated vault sector record")
    return int.from_bytes(raw,"big")

def write_sector(path:Path,master_key:bytes,index:int,plaintext:bytes)->None:
    path=Path(path)
    header=read_header(path)
    count=int(header["sector_count"])
    if not 0<=index<count:
        raise IndexError("sector out of range")
    if len(plaintext)>SECTOR_SIZE:
        raise ValueError("sector plaintext too large")
    pt=plaintext.ljust(SECTOR_SIZE,b"\x00")
    old_gen=_current_generation(path,index)
    if old_gen==(2**64-1):
        raise OverflowError("sector generation counter exhausted")
    gen=old_gen+1
    vault_id=b64d(header["vault_id_b64"])
    key=derive_storage_key(master_key,vault_id)
    nonce=_sector_nonce(key,vault_id,index,gen)
    aad=_sector_aad(header,index,gen)
    ct=AESGCM(key).encrypt(nonce,pt,aad)
    if len(ct)!=SECTOR_SIZE+TAG_SIZE:
        raise RuntimeError("unexpected AEAD sector size")
    with open(path,"r+b") as f:
        f.seek(_record_offset(index))
        f.write(gen.to_bytes(GEN_SIZE,"big"))
        f.write(ct)

def read_sector(path:Path,master_key:bytes,index:int)->bytes:
    path=Path(path)
    header=read_header(path)
    count=int(header["sector_count"])
    if not 0<=index<count:
        raise IndexError("sector out of range")
    with open(path,"rb") as f:
        f.seek(_record_offset(index))
        gen_raw=f.read(GEN_SIZE)
        ct=f.read(SECTOR_SIZE+TAG_SIZE)
    if len(gen_raw)!=GEN_SIZE or len(ct)!=(SECTOR_SIZE+TAG_SIZE):
        raise ValueError("truncated vault sector")
    gen=int.from_bytes(gen_raw,"big")
    if gen==0:
        # Never-written sparse/zero sector.
        return b"\x00"*SECTOR_SIZE
    vault_id=b64d(header["vault_id_b64"])
    key=derive_storage_key(master_key,vault_id)
    nonce=_sector_nonce(key,vault_id,index,gen)
    aad=_sector_aad(header,index,gen)
    return AESGCM(key).decrypt(nonce,ct,aad)

def storage_self_test(tmpdir:Path)->dict:
    p=Path(tmpdir)/"storage_test.efv"
    mk=os.urandom(32)
    wrapped={"mode":"TEST-ONLY"}
    create_vault(p,SECTOR_SIZE*8,wrapped,label="Storage Test",vault_id=b"\x01"*16)
    a=b"A"*SECTOR_SIZE
    b=b"B"*137
    write_sector(p,mk,0,a)
    write_sector(p,mk,3,b)
    first=read_sector(p,mk,0)
    part=read_sector(p,mk,3)
    unwritten=read_sector(p,mk,1)
    # Rewrite same sector and verify generation rises/nonces therefore change.
    gen1=_current_generation(p,0)
    write_sector(p,mk,0,b"C"*SECTOR_SIZE)
    gen2=_current_generation(p,0)
    rewritten=read_sector(p,mk,0)

    tamper=False
    with open(p,"r+b") as f:
        f.seek(_record_offset(3)+GEN_SIZE+10)
        x=f.read(1)
        f.seek(_record_offset(3)+GEN_SIZE+10)
        f.write(bytes([x[0]^1]))
    try:
        read_sector(p,mk,3)
    except Exception:
        tamper=True

    wrong_key=False
    try:
        read_sector(p,os.urandom(32),0)
    except Exception:
        wrong_key=True

    tests={
        "create":True,
        "full_sector_roundtrip":first==a,
        "partial_sector_roundtrip":part[:137]==b and part[137:]==b"\x00"*(SECTOR_SIZE-137),
        "unwritten_sector_is_zero":unwritten==b"\x00"*SECTOR_SIZE,
        "rewrite_generation_increments":gen1==1 and gen2==2,
        "rewrite_roundtrip":rewritten==b"C"*SECTOR_SIZE,
        "tamper_rejected":tamper,
        "wrong_master_key_rejected":wrong_key,
    }
    return {"version":VERSION,"tests":tests,"all_passed":all(tests.values())}
