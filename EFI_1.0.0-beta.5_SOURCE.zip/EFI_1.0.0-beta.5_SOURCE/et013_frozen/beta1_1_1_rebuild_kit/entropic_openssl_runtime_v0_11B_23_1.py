from __future__ import annotations
import os, shutil, sys
from pathlib import Path

def openssl_executable() -> str:
    """Resolve OpenSSL from an explicit override, bundled runtime, or PATH."""
    env = os.environ.get("ENTROPIC_OPENSSL")
    candidates = []
    if env:
        candidates.append(Path(env))

    # PyInstaller one-file extraction directory.
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        candidates.append(Path(meipass) / "openssl" / "openssl.exe")
        candidates.append(Path(meipass) / "openssl" / "openssl")

    # One-folder / developer-local bundled runtime.
    base = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
    candidates.append(base / "openssl" / "openssl.exe")
    candidates.append(base / "runtime" / "openssl" / "openssl.exe")

    # Common Windows developer installs. The build batch already searched these;
    # direct Python validation must do the same.
    if os.name == "nt":
        for raw in (
            r"C:\Program Files\OpenSSL-Win64\bin\openssl.exe",
            r"C:\Program Files\OpenSSL-Win64\openssl.exe",
            r"C:\Program Files (x86)\OpenSSL-Win64\bin\openssl.exe",
            r"C:\Program Files\FireDaemon OpenSSL 3\bin\openssl.exe",
            r"C:\Program Files\FireDaemon OpenSSL 4\bin\openssl.exe",
        ):
            candidates.append(Path(raw))

    for p in candidates:
        if p and p.exists():
            return str(p)

    found = shutil.which("openssl")
    if found:
        return found

    raise FileNotFoundError(
        "OpenSSL 3.5+ with ML-KEM support was not found. "
        "Set ENTROPIC_OPENSSL to openssl.exe, install a supported Windows build, "
        "or run build_windows_exe_b23_1.bat to create the standalone EXE."
    )
