#!/usr/bin/env python3
"""
Entropic Fusion Prototype v0.11
Research harness only. NOT production cryptography.

Transcript-bound noisy modular mutual-binding experiment:
* Genuine 4D n=3 geometry: 81 pieces, 8 faces, 192 proper rotations.
* Hidden modular secret s in Z_q^64 with small coefficients.
* No face publishes a standalone LWE-like (a,b) sample.
* A candidate noisy equation materialises only when two proposed opposing faces
  are combined under a full adjacency transcript: piece nonces, positions,
  orientations, local face indices, world direction, and visible patterns.
* A second, independent centre-shard equation materialises from the same
  candidate adjacency using separate shares and domain separation.
* Public JSON excludes seed, secret, and planted assignment.

Toy research construction only. Not ML-KEM, Kyber, or a security claim.
"""
from __future__ import annotations
import argparse, hashlib, itertools, json, math, random, statistics
from dataclasses import dataclass, asdict
from functools import lru_cache
from typing import Dict, List, Sequence, Tuple

Q=257
DIM=64
NOISE=2
FACE_TOL=2
CENTRE_TOL=2
STATIONS=8
MARKS=3
Vec=Tuple[int,...]
Pos=Tuple[int,...]
Matrix=Tuple[Tuple[int,...],...]
Pattern=Tuple[int,int,int]

def hb(*parts:bytes,length:int=32)->bytes:
    h=hashlib.shake_256()
    for p in parts:
        h.update(len(p).to_bytes(4,'big')); h.update(p)
    return h.digest(length)

def perm_parity(p:Sequence[int])->int:
    return -1 if sum(1 for i in range(len(p)) for j in range(i+1,len(p)) if p[i]>p[j])&1 else 1

@lru_cache(maxsize=None)
def rotations(d:int)->Tuple[Matrix,...]:
    out=[]
    for perm in itertools.permutations(range(d)):
        pp=perm_parity(perm)
        for signs in itertools.product((-1,1),repeat=d):
            if pp*math.prod(signs)!=1: continue
            rows=[]
            for r in range(d):
                row=[0]*d
                for j in range(d):
                    if perm[j]==r: row[j]=signs[j]
                rows.append(tuple(row))
            out.append(tuple(rows))
    return tuple(sorted(set(out)))

def dot(a:Sequence[int],b:Sequence[int])->int:return sum(x*y for x,y in zip(a,b))
def mat_apply(m:Matrix,v:Vec)->Vec:return tuple(dot(r,v) for r in m)
def unit(d:int,a:int,s:int=1)->Vec:
    v=[0]*d;v[a]=s;return tuple(v)
def addp(p:Pos,v:Vec)->Pos:return tuple(a+b for a,b in zip(p,v))
def inside(p:Pos,n:int)->bool:return all(0<=x<n for x in p)
def positions(d:int,n:int)->Tuple[Pos,...]:return tuple(itertools.product(range(n),repeat=d))
def directions(d:int)->Tuple[Vec,...]:return tuple(unit(d,a,s) for a in range(d) for s in (1,-1))
def opposite(v:Vec)->Vec:return tuple(-x for x in v)
def axis_sign(v:Vec)->Tuple[int,int]:
    for i,x in enumerate(v):
        if x:return i,x
    raise ValueError(v)
def centered(x:int)->int:
    x%=Q
    return x-Q if x>Q//2 else x
def moddot(a:Sequence[int],s:Sequence[int])->int:return sum(x*y for x,y in zip(a,s))%Q

def vec_from_hash(label:bytes)->Tuple[int,...]:
    raw=hb(label,length=2*DIM)
    return tuple(int.from_bytes(raw[2*i:2*i+2],'big')%Q for i in range(DIM))
def scalar_from_hash(label:bytes)->int:return int.from_bytes(hb(label,length=2),'big')%Q

STATION_COORDS=tuple(itertools.product((-1,1),repeat=3))
STATION_INDEX={c:i for i,c in enumerate(STATION_COORDS)}
ALL_PATTERNS=[tuple(c) for c in itertools.combinations(range(STATIONS),MARKS)]

def _station_maps():
    out=set()
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product((-1,1),repeat=3):
            mp=[]
            for c in STATION_COORDS:
                nc=tuple(signs[j]*c[perm[j]] for j in range(3));mp.append(STATION_INDEX[nc])
            out.add(tuple(mp))
    return tuple(sorted(out))
STATION_MAPS=_station_maps()

def face_frame(d:int,normal:Vec)->Tuple[Vec,...]:
    axis,sign=axis_sign(normal);tang=[i for i in range(d) if i!=axis];basis=[unit(d,i,1) for i in tang]
    if sign<0:basis[0]=tuple(-x for x in basis[0])
    return tuple(basis[:3])

@lru_cache(maxsize=None)
def rotate_pattern(d:int,local_dir:Vec,p:Pattern,o:int)->Tuple[Vec,Pattern]:
    m=rotations(d)[o];wd=mat_apply(m,local_dir)
    lf=face_frame(d,local_dir);wf=tuple(mat_apply(m,x) for x in lf);tf=face_frame(d,wd);mapped=[]
    for st in p:
        c=STATION_COORDS[st];w=tuple(sum(c[k]*wf[k][j] for k in range(3)) for j in range(d))
        tc=tuple(dot(w,tf[k]) for k in range(3));mapped.append(STATION_INDEX[tc])
    return wd,tuple(sorted(mapped))

def inv_rotation_index(d:int,o:int)->int:
    rots=rotations(d);m=rots[o];mt=tuple(tuple(m[j][i] for j in range(len(m))) for i in range(len(m)));return rots.index(mt)
def inverse_rotate_pattern(d:int,wd:Vec,p:Pattern,o:int)->Tuple[Vec,Pattern]:
    return rotate_pattern(d,wd,p,inv_rotation_index(d,o))

@dataclass(frozen=True)
class FaceRec:
    pattern:Pattern
    face_share:int
    centre_share:int
@dataclass(frozen=True)
class Piece:
    nonce:str
    faces:Tuple[FaceRec,...]
@dataclass(frozen=True)
class Placement:
    piece:int
    orientation:int
@dataclass
class Instance:
    version:str;seed:int;d:int;n:int;pieces:List[Piece];secret:Tuple[int,...];truth:Dict[str,Tuple[int,int]]
    def public_dict(self):
        return {'version':self.version,'d':self.d,'n':self.n,'q':Q,'dim':DIM,'noise':NOISE,
                'pieces':[asdict(p) for p in self.pieces]}

def world_faces(inst:Instance,pl:Placement)->Dict[Vec,Tuple[FaceRec,int]]:
    out={};pc=inst.pieces[pl.piece]
    for li,dd in enumerate(directions(inst.d)):
        wd,wp=rotate_pattern(inst.d,dd,pc.faces[li].pattern,pl.orientation)
        out[wd]=(FaceRec(wp,pc.faces[li].face_share,pc.faces[li].centre_share),li)
    return out

def canonical_adjacency(inst:Instance,p:Pos,pl:Placement,wd:Vec,nb:Pos,npl:Placement):
    pc,npc=inst.pieces[pl.piece],inst.pieces[npl.piece]
    wf=world_faces(inst,pl);nwf=world_faces(inst,npl)
    rec,li=wf[wd];nrec,nli=nwf[opposite(wd)]
    left=(pc.nonce,p,pl.orientation,wd,li,rec.pattern,rec.face_share,rec.centre_share)
    right=(npc.nonce,nb,npl.orientation,opposite(wd),nli,nrec.pattern,nrec.face_share,nrec.centre_share)
    if left[0] <= right[0]: return left,right
    return right,left

def transcript_key(inst:Instance,p:Pos,pl:Placement,wd:Vec,nb:Pos,npl:Placement,domain:bytes)->bytes:
    L,R=canonical_adjacency(inst,p,pl,wd,nb,npl)
    def enc(x):
        nonce,pos,o,wdir,li,pat,fs,cs=x
        axis,sign=axis_sign(wdir)
        return (bytes.fromhex(nonce)+bytes(pos)+o.to_bytes(2,'big')+
                bytes((axis,1 if sign>0 else 0,li))+bytes(pat)+fs.to_bytes(2,'big')+cs.to_bytes(2,'big'))
    return hb(b'entropic/v0.11',domain,enc(L),enc(R))

def materialise_equation(inst:Instance,p:Pos,pl:Placement,wd:Vec,nb:Pos,npl:Placement,domain:bytes):
    L,R=canonical_adjacency(inst,p,pl,wd,nb,npl)
    key=transcript_key(inst,p,pl,wd,nb,npl,domain)
    a=vec_from_hash(key+b'/a');mask=scalar_from_hash(key+b'/mask')
    if domain==b'face': rhs=(L[6]+R[6]-mask)%Q
    else: rhs=(L[7]+R[7]-mask)%Q
    return a,rhs

def equation_ok(a:Sequence[int],rhs:int,s:Sequence[int],tol:int)->bool:
    return abs(centered(rhs-moddot(a,s)))<=tol

def build(seed:int,d:int=4,n:int=3)->Instance:
    rng=random.Random(seed);dirs=directions(d);poss=positions(d,n);rots=rotations(d)
    secret=tuple(rng.randint(-2,2) for _ in range(DIM))
    intrinsic={p:rng.randrange(len(rots)) for p in poss}
    originals=[];pieces=[]
    for pid,p in enumerate(poss):
        nonce=hb(b'nonce/v0.11',seed.to_bytes(8,'big'),pid.to_bytes(4,'big'),length=12).hex();originals.append(nonce)
        faces=[]
        for _ in dirs:
            faces.append(FaceRec(rng.choice(ALL_PATTERNS),rng.randrange(Q),rng.randrange(Q)))
        pieces.append(Piece(nonce,tuple(faces)))
    rng.shuffle(pieces);idx={pc.nonce:i for i,pc in enumerate(pieces)}
    ass={p:Placement(idx[originals[i]],intrinsic[p]) for i,p in enumerate(poss)}
    inst=Instance('0.11',seed,d,n,pieces,secret,{repr(p):(pl.piece,pl.orientation) for p,pl in ass.items()})
    # For each true adjacency, adjust one endpoint share in each channel so that
    # the equation materialised only by the correct transcript is a noisy sample.
    mutable=list(inst.pieces)
    for p in poss:
        for aidx in range(d):
            wd=unit(d,aidx,1);nb=addp(p,wd)
            if not inside(nb,n):continue
            pl,npl=ass[p],ass[nb]
            # Determine canonical owner and local face indices using current records.
            L,R=canonical_adjacency(inst,p,pl,wd,nb,npl)
            keyf=transcript_key(inst,p,pl,wd,nb,npl,b'face');af=vec_from_hash(keyf+b'/a');mf=scalar_from_hash(keyf+b'/mask')
            keyc=transcript_key(inst,p,pl,wd,nb,npl,b'centre');ac=vec_from_hash(keyc+b'/a');mc=scalar_from_hash(keyc+b'/mask')
            targetf=(moddot(af,secret)+rng.randint(-FACE_TOL,FACE_TOL))%Q
            targetc=(moddot(ac,secret)+rng.randint(-CENTRE_TOL,CENTRE_TOL))%Q
            # Update the lexicographically right endpoint share; transcript key includes
            # shares, so use a fixed-point-free key that excludes shares for generation.
            # Recompute with structural transcript only to avoid circularity.
            def structural(domain):
                def encs(x):
                    nonce,pos,o,wdir,li,pat,fs,cs=x;axis,sign=axis_sign(wdir)
                    return bytes.fromhex(nonce)+bytes(pos)+o.to_bytes(2,'big')+bytes((axis,1 if sign>0 else 0,li))+bytes(pat)
                return hb(b'entropic/v0.11-struct',domain,encs(L),encs(R))
            skf=structural(b'face');af=vec_from_hash(skf+b'/a');mf=scalar_from_hash(skf+b'/mask');targetf=(moddot(af,secret)+rng.randint(-FACE_TOL,FACE_TOL))%Q
            skc=structural(b'centre');ac=vec_from_hash(skc+b'/a');mc=scalar_from_hash(skc+b'/mask');targetc=(moddot(ac,secret)+rng.randint(-CENTRE_TOL,CENTRE_TOL))%Q
            # identify R piece/local face
            rnonce,rpos,ro,rwd,rli,rpat,rfs,rcs=R
            rpi=idx[rnonce];rpc=mutable[rpi];rfaces=list(rpc.faces)
            # L shares from current mutable piece record
            lnonce,lpos,lo,lwd,lli,lpat,lfs,lcs=L
            lpi=idx[lnonce];lrec=mutable[lpi].faces[lli]
            newfs=(targetf+mf-lrec.face_share)%Q
            newcs=(targetc+mc-lrec.centre_share)%Q
            old=rfaces[rli];rfaces[rli]=FaceRec(old.pattern,newfs,newcs);mutable[rpi]=Piece(rpc.nonce,tuple(rfaces));inst.pieces=mutable
    return inst

# Structural transcript functions used by the actual decoder, excluding shares.
def structural_key(inst:Instance,p:Pos,pl:Placement,wd:Vec,nb:Pos,npl:Placement,domain:bytes)->bytes:
    L,R=canonical_adjacency(inst,p,pl,wd,nb,npl)
    def encs(x):
        nonce,pos,o,wdir,li,pat,fs,cs=x;axis,sign=axis_sign(wdir)
        return bytes.fromhex(nonce)+bytes(pos)+o.to_bytes(2,'big')+bytes((axis,1 if sign>0 else 0,li))+bytes(pat)
    return hb(b'entropic/v0.11-struct',domain,encs(L),encs(R))

def materialise(inst,p,pl,wd,nb,npl,domain):
    L,R=canonical_adjacency(inst,p,pl,wd,nb,npl);key=structural_key(inst,p,pl,wd,nb,npl,domain)
    a=vec_from_hash(key+b'/a');mask=scalar_from_hash(key+b'/mask')
    rhs=((L[6]+R[6]) if domain==b'face' else (L[7]+R[7]))-mask
    return a,rhs%Q

def truth_map(inst):return {eval(k):Placement(v[0],v[1]) for k,v in inst.truth.items()}

def public_safe(inst):
    d=inst.public_dict();s=json.dumps(d)
    forbidden=('"seed"','secret','truth','"a"','"b"')
    long_vectors=[]
    def walk(x):
        if isinstance(x,dict):
            for v in x.values():walk(v)
        elif isinstance(x,list):
            if len(x)==DIM and all(isinstance(v,int) for v in x):long_vectors.append(x)
            for v in x:walk(v)
    walk(d)
    return {'safe':all(x not in s for x in forbidden) and not long_vectors,
            'standalone_lwe_vectors':len(long_vectors),'forbidden_tokens_present':[x for x in forbidden if x in s]}

def truth_diagnostics(inst):
    ass=truth_map(inst);fr=[];cr=[];edges=0
    for p in positions(inst.d,inst.n):
        for aidx in range(inst.d):
            wd=unit(inst.d,aidx,1);nb=addp(p,wd)
            if not inside(nb,inst.n):continue
            edges+=1;af,bf=materialise(inst,p,ass[p],wd,nb,ass[nb],b'face');ac,bc=materialise(inst,p,ass[p],wd,nb,ass[nb],b'centre')
            fr.append(abs(centered(bf-moddot(af,inst.secret))));cr.append(abs(centered(bc-moddot(ac,inst.secret))))
    return {'edges':edges,'face_max_residual':max(fr),'face_all_within_tolerance':all(x<=FACE_TOL for x in fr),
            'centre_max_residual':max(cr),'centre_all_within_tolerance':all(x<=CENTRE_TOL for x in cr)}

def wrong_secret_test(inst,flips=32):
    ass=truth_map(inst);edges=[]
    for p in positions(inst.d,inst.n):
        for aidx in range(inst.d):
            wd=unit(inst.d,aidx,1);nb=addp(p,wd)
            if inside(nb,inst.n):edges.append((p,wd,nb))
    out=[]
    for i in range(min(flips,DIM)):
        bad=list(inst.secret);bad[i]+=1;broken=0
        for p,wd,nb in edges:
            a,b=materialise(inst,p,ass[p],wd,nb,ass[nb],b'face')
            if not equation_ok(a,b,bad,FACE_TOL):broken+=1
        out.append(broken)
    return {'tested':len(out),'broken_min':min(out),'broken_median':statistics.median(out),'broken_max':max(out)}

def wrong_placement_probe(inst,trials=5000,seed=1):
    rng=random.Random(seed);truth=truth_map(inst);poss=list(positions(inst.d,inst.n));rots=rotations(inst.d)
    picks=[poss[0],poss[len(poss)//4],poss[len(poss)//2],poss[-1]];tested=frej=crej=survive=0
    for pos in picks:
        for _ in range(trials//len(picks)):
            pl=Placement(rng.randrange(len(inst.pieces)),rng.randrange(len(rots)))
            if pl==truth[pos]:continue
            tested+=1;faceok=True
            for wd in directions(inst.d):
                nb=addp(pos,wd)
                if not inside(nb,inst.n):continue
                a,b=materialise(inst,pos,pl,wd,nb,truth[nb],b'face')
                if not equation_ok(a,b,inst.secret,FACE_TOL):faceok=False;break
            if not faceok:frej+=1;continue
            centreok=True
            for wd in directions(inst.d):
                nb=addp(pos,wd)
                if not inside(nb,inst.n):continue
                a,b=materialise(inst,pos,pl,wd,nb,truth[nb],b'centre')
                if not equation_ok(a,b,inst.secret,CENTRE_TOL):centreok=False;break
            if not centreok:crej+=1
            else:survive+=1
    return {'tested':tested,'face_rejects':frej,'centre_rejects':crej,'survivors':survive}

def public_only_attack(inst):
    pub=inst.public_dict();faces=sum(len(p['faces']) for p in pub['pieces'])
    # There are no public coefficient vectors or rhs values. An attacker must first
    # hypothesise an adjacency transcript to materialise even one equation.
    pair_hypotheses=(len(inst.pieces)*8)*(len(inst.pieces)*8-1)//2
    return {'public_faces':faces,'standalone_equations':0,'standalone_coefficient_vectors':0,
            'unordered_face_pair_hypotheses':pair_hypotheses,
            'reassembly_used_to_materialise_truth_equations':True,
            'plain_lwe_matrix_available':False}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,default=20260730);ap.add_argument('--out-json');a=ap.parse_args()
    inst=build(a.seed,4,3)
    report={'version':'0.11','shape':'4D n=3','pieces':len(inst.pieces),'orientations':len(rotations(4)),
            'faces_per_piece':8,'q':Q,'secret_dimension':DIM,'truth':truth_diagnostics(inst),
            'public_surface':public_safe(inst),'public_only_attack':public_only_attack(inst),
            'wrong_secret':wrong_secret_test(inst),'wrong_placement':wrong_placement_probe(inst,seed=a.seed^0xBEEF),
            'interpretation':['No standalone face-level LWE samples are published.',
                              'A candidate noisy equation materialises only from a proposed opposing-face adjacency transcript.',
                              'This is a toy diagnostic, not a security proof or ML-KEM.']}
    print(json.dumps(report,indent=2))
    if a.out_json:
        with open(a.out_json,'w') as f:json.dump({'public_instance':inst.public_dict(),'report':report},f,indent=2)
if __name__=='__main__':main()
