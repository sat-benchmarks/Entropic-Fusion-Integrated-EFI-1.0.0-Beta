#!/usr/bin/env python3
"""Entropic Fusion B.23.1 fused public-recipient file encryption CLI."""
from __future__ import annotations
import base64,hashlib,json,tempfile,os
from pathlib import Path
from cryptography.exceptions import InvalidTag
from entropic_fusion_public_identity_v0_11B_23_1 import VERSION,generate_identity,load_public,load_private,encapsulate_fused,decapsulate_fused,derive_ef_gated_session
from entropic_fusion_mlkem_runtime_v0_11B_23_1 import check_available
from entropic_fusion_hybrid_combiner_v0_11B_23_1 import derive_aes256_key,derive_key_id
from entropic_fusion_aesgcm_v0_11B_23_1 import encrypt as aes_encrypt,decrypt as aes_decrypt

FORMAT='EF-B23-BOX-1'; CONTEXT_DEFAULT='Entropic Fusion B.23 fused public-recipient file encryption'
def b64e(x): return base64.b64encode(x).decode('ascii')
def b64d(x): return base64.b64decode(x.encode('ascii'),validate=True)
def canonical(o): return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def _transcript(pub,outer_ct,inner_ct,context):
    return canonical({'domain':'ENTROPIC-FUSION/B23/FUSED-TRANSCRIPT/v1','public_identity_sha256':pub['public_identity_sha256'],'ef_fusion_commitment_sha256':pub['ef_fusion_commitment_sha256'],'outer_ct_sha256':hashlib.sha256(outer_ct).hexdigest(),'inner_ct_sha256':hashlib.sha256(inner_ct).hexdigest(),'context':context})

def encrypt_file(public_identity_path,in_file,out_file,context=CONTEXT_DEFAULT):
    pub=load_public(public_identity_path); plaintext=Path(in_file).read_bytes()
    outer_ct,outer_ss,inner_ct,inner_ss=encapsulate_fused(pub)
    transcript=_transcript(pub,outer_ct,inner_ct,context)
    ef_session_ss=derive_ef_gated_session(inner_ss,pub['ef_fusion_commitment_sha256'],transcript)
    key=derive_aes256_key(outer_ss,inner_ss,ef_session_ss,transcript,context.encode())
    header={'format':FORMAT,'version':VERSION,'outer_kem':'ML-KEM-768','fused_inner_kem':'ML-KEM-1024','ef_relation':'EF-v0.11-full-face-centre','fusion_mode':'EF-witness-gated-dual-KEM','aead':'AES-256-GCM','public_identity_sha256':pub['public_identity_sha256'],'ef_fusion_commitment_sha256':pub['ef_fusion_commitment_sha256'],'transcript_sha256':hashlib.sha256(transcript).hexdigest(),'context':context,'original_name':Path(in_file).name}
    row=aes_encrypt(key,plaintext,canonical(header))
    box={'header':header,'outer_kem_ciphertext_b64':b64e(outer_ct),'inner_kem_ciphertext_b64':b64e(inner_ct),'nonce_b64':b64e(bytes.fromhex(row['nonce_hex'])),'ciphertext_b64':b64e(bytes.fromhex(row['ciphertext_hex']))}
    Path(out_file).write_text(json.dumps(box,indent=2)+'\n')
    return {'version':VERSION,'public_only_encryption':True,'fusion_mode':'EF-direct-three-leg-combiner','input_bytes':len(plaintext),'output_bytes':Path(out_file).stat().st_size,'traffic_key_id':derive_key_id(key),'outer_mlkem_ciphertext_bytes':len(outer_ct),'inner_mlkem_ciphertext_bytes':len(inner_ct)}

def original_name_from_box(in_file):
    box=json.loads(Path(in_file).read_text());header=box.get('header',{})
    if header.get('format')!=FORMAT: raise ValueError('unsupported Entropic Fusion container format')
    name=str(header.get('original_name',''))
    if not name or '\x00' in name or Path(name).name!=name or name in {'.','..'}: raise ValueError('container has invalid original filename')
    return name

def output_path_for_folder(in_file,destination_folder):
    folder=Path(destination_folder)
    if not folder.exists() or not folder.is_dir(): raise ValueError('destination folder does not exist')
    return folder/original_name_from_box(in_file)

def decrypt_file(private_identity_path,in_file,out_file):
    priv=load_private(private_identity_path);pub=priv['public_identity'];box=json.loads(Path(in_file).read_text());header=box.get('header',{})
    if header.get('format')!=FORMAT: raise ValueError('unsupported B.23 box format')
    if header.get('public_identity_sha256')!=pub['public_identity_sha256']: raise ValueError('recipient identity mismatch')
    outer_ct=b64d(box['outer_kem_ciphertext_b64']);inner_ct=b64d(box['inner_kem_ciphertext_b64']);context=str(header.get('context',''))
    transcript=_transcript(pub,outer_ct,inner_ct,context)
    if hashlib.sha256(transcript).hexdigest()!=header.get('transcript_sha256'): raise ValueError('fused transcript mismatch')
    outer_ss,inner_ss,ef_report,fusion_secret=decapsulate_fused(priv,outer_ct,inner_ct)
    # The live EF relation must have executed successfully before inner_ss exists
    # on the official recipient path. Bind that gated per-file value directly
    # into the final three-leg traffic-key combiner.
    ef_session_ss=derive_ef_gated_session(inner_ss,pub['ef_fusion_commitment_sha256'],transcript)
    key=derive_aes256_key(outer_ss,inner_ss,ef_session_ss,transcript,context.encode())
    try: plaintext=aes_decrypt(key,b64d(box['nonce_b64']),b64d(box['ciphertext_b64']),canonical(header))
    except InvalidTag as e: raise ValueError('authentication failed: wrong identity, EF witness, or modified ciphertext') from e
    Path(out_file).write_bytes(plaintext)
    return {'version':VERSION,'recovered_bytes':len(plaintext),'traffic_key_id':derive_key_id(key),'original_name':header.get('original_name',''),'public_identity_sha256':pub['public_identity_sha256'],'ef_equations_verified':ef_report['equations_verified'],'fusion_mode':'EF-direct-three-leg-combiner'}

def decrypt_file_to_folder(private_identity_path,in_file,destination_folder):
    out=output_path_for_folder(in_file,destination_folder);r=decrypt_file(private_identity_path,in_file,out);r['recovered_path']=str(out);return r

def decrypt_file_with_private_bytes(private_identity_bytes,in_file,out_file):
    with tempfile.TemporaryDirectory(prefix='ef_b231_priv_') as td:
        p=Path(td)/'identity.efpriv';p.write_bytes(private_identity_bytes)
        try: os.chmod(p,0o600)
        except Exception: pass
        return decrypt_file(p,in_file,out_file)
def decrypt_file_with_private_bytes_to_folder(private_identity_bytes,in_file,destination_folder):
    out=output_path_for_folder(in_file,destination_folder);r=decrypt_file_with_private_bytes(private_identity_bytes,in_file,out);r['recovered_path']=str(out);return r

def self_test():
    import entropic_fusion_relation_v0_11B_23_1 as efrel
    import entropic_fusion_hybrid_combiner_v0_11B_23_1 as comb
    rel=efrel.mutation_self_test()
    result={'version':VERSION,'openssl':None,'relation_tests':rel,'combiner_tests':comb.self_test(),'tests':{'ef_relation_live':rel['all_passed'],'ef_materialised_equations_verified':rel['reference']['equations_verified']>0,'three_leg_combiner':comb.self_test()['tests']['all_boolean_tests_passed'] and comb.self_test()['tests']['mutation_sweep_collisions']==0}}
    # Full PQ test is attempted only where OpenSSL exposes both ML-KEM algorithms.
    result['openssl']=check_available()
    with tempfile.TemporaryDirectory(prefix='ef_b231_self_') as td:
        d=Path(td);pub=d/'a.efpub';priv=d/'a.efpriv';msg=d/'m.txt';box=d/'m.efb';out=d/'out.txt';msg.write_bytes(b'Entropic Fusion B.23.1 fused self-test')
        generate_identity(pub,priv,seed=20270851);enc=encrypt_file(pub,msg,box);dec=decrypt_file(priv,box,out)
        result['tests']['round_trip']=out.read_bytes()==msg.read_bytes()
        # Corrupt EF secret and require failure before KEM decapsulation succeeds.
        pobj=json.loads(priv.read_text());pobj['ef_witness']['secret'][0]+=1;bad=d/'bad.efpriv';bad.write_text(json.dumps(pobj))
        rejected=False
        try: decrypt_file(bad,box,d/'bad.out')
        except Exception: rejected=True
        result['tests']['mutated_ef_witness_rejected']=rejected
        result['encryption']=enc;result['decryption']=dec
    result['all_tests_passed']=all(result['tests'].values());return result
