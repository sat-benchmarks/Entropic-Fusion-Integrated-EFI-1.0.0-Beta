#!/usr/bin/env python3
"""Live EF relation gate for Entropic Fusion B.23.1.

This module deliberately calls the v0.11 materialisation/equation machinery in
the decryption key path. A private EF witness must describe one complete
bijection of pieces to positions and satisfy BOTH face and centre equations on
every true adjacency before the fusion secret is released.

This is an implementation binding property, not a hardness proof.
"""
from __future__ import annotations
import hashlib, json, importlib
from dataclasses import asdict
import entropic_bound_fusion_v0_11B_23_1 as m

DOMAIN=b'ENTROPIC-FUSION/B23/EF-RELATION-GATE/v1'

def canonical(o): return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def public_hash(pub): return hashlib.sha256(canonical(pub)).hexdigest()

def generate(seed:int):
    inst=m.build(seed,4,3)
    witness={
        'secret':list(inst.secret),
        'truth':{k:[int(v[0]),int(v[1])] for k,v in inst.truth.items()},
    }
    pub=inst.public_dict()
    report,secret=verify_and_derive(pub,witness)
    return pub,witness,report,secret

def _reconstruct(pub,witness):
    pieces=[]
    for p in pub['pieces']:
        faces=tuple(m.FaceRec(tuple(f['pattern']),int(f['face_share']),int(f['centre_share'])) for f in p['faces'])
        pieces.append(m.Piece(str(p['nonce']),faces))
    truth={str(k):(int(v[0]),int(v[1])) for k,v in witness['truth'].items()}
    secret=tuple(int(x) for x in witness['secret'])
    return m.Instance(str(pub.get('version','0.11')),0,int(pub['d']),int(pub['n']),pieces,secret,truth)

def _layout_transcript(inst,truth):
    rows=[]
    for pos in m.positions(inst.d,inst.n):
        pl=truth[pos]
        rows.append({'position':list(pos),'piece':pl.piece,'piece_nonce':inst.pieces[pl.piece].nonce,'orientation':pl.orientation})
    return rows

def verify_and_derive(pub,witness):
    inst=_reconstruct(pub,witness)
    if len(inst.secret)!=m.DIM: raise ValueError('EF witness secret dimension mismatch')
    poss=m.positions(inst.d,inst.n); rots=m.rotations(inst.d)
    expected={repr(p) for p in poss}
    if set(inst.truth)!=expected: raise ValueError('EF witness does not cover the complete geometry')
    truth=m.truth_map(inst)
    pieces=[truth[p].piece for p in poss]
    if sorted(pieces)!=list(range(len(inst.pieces))): raise ValueError('EF witness is not a one-to-one complete piece placement')
    if any(not (0<=truth[p].orientation<len(rots)) for p in poss): raise ValueError('EF witness contains invalid orientation')

    eq_rows=[]; edges=0
    for p in poss:
        for axis in range(inst.d):
            wd=m.unit(inst.d,axis,1); nb=m.addp(p,wd)
            if not m.inside(nb,inst.n): continue
            edges += 1
            for domain,tol in ((b'face',m.FACE_TOL),(b'centre',m.CENTRE_TOL)):
                # These are the research relation operations that were absent from B.22.9.
                a,b=m.materialise(inst,p,truth[p],wd,nb,truth[nb],domain)
                if not m.equation_ok(a,b,inst.secret,tol):
                    raise ValueError(f'EF relation failure at {p} -> {nb} ({domain.decode()})')
                residual=m.centered(b-m.moddot(a,inst.secret))
                eq_rows.append({'p':list(p),'wd':list(wd),'nb':list(nb),'domain':domain.decode(),'a_sha256':hashlib.sha256(bytes().join(int(x).to_bytes(2,'big') for x in a)).hexdigest(),'rhs':int(b),'residual':int(residual)})

    layout=_layout_transcript(inst,truth)
    ph=public_hash(pub)
    th=hashlib.sha256(canonical(layout)).hexdigest()
    eh=hashlib.sha256(canonical(eq_rows)).hexdigest()
    h=hashlib.shake_256(); h.update(DOMAIN); h.update(bytes.fromhex(ph)); h.update(bytes.fromhex(th)); h.update(bytes.fromhex(eh)); h.update(canonical(list(inst.secret)))
    fusion_secret=h.digest(32)
    report={'relation':'EF-v0.11-full-face-centre','positions':len(poss),'edges':edges,'equations_verified':len(eq_rows),'face_and_centre_required':True,'complete_bijection_required':True,'public_sha256':ph,'layout_transcript_sha256':th,'equation_transcript_sha256':eh,'fusion_commitment_sha256':hashlib.sha256(b'EF-B23/commit/'+fusion_secret).hexdigest()}
    return report,fusion_secret

def mutation_self_test(seed=20270851):
    pub,wit,rep,sec=generate(seed)
    bad=json.loads(json.dumps(wit)); bad['secret'][0]+=1
    bad_secret_rejected=False
    try: verify_and_derive(pub,bad)
    except Exception: bad_secret_rejected=True
    bad2=json.loads(json.dumps(wit)); keys=sorted(bad2['truth']); bad2['truth'][keys[0]],bad2['truth'][keys[1]]=bad2['truth'][keys[1]],bad2['truth'][keys[0]]
    bad_layout_rejected=False
    try: verify_and_derive(pub,bad2)
    except Exception: bad_layout_rejected=True
    return {'reference':rep,'bad_secret_rejected':bad_secret_rejected,'bad_layout_rejected':bad_layout_rejected,'all_passed':bad_secret_rejected and bad_layout_rejected and rep['equations_verified']>0}
