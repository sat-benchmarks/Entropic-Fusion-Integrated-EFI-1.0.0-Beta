#!/usr/bin/env python3
from __future__ import annotations

import base64
import ctypes
import ctypes.wintypes as wt
import json
import os
import secrets
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

from entropic_windows_pipe_acl_v0_11B_24_32 import (
    open_client_pipe, close_handle, write_json, read_json
)
from entropic_error_policy_beta1_1_1 import record_to_product_message, product_mount_error

HOST_SCRIPT=Path(__file__).with_name('entropic_mount_host_aclpipe_beta1_1_1.py')
VERSION='Beta1.1.1-client2'

if os.name=='nt':
    crypt32=ctypes.WinDLL('crypt32',use_last_error=True)
    kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
    CRYPTPROTECT_UI_FORBIDDEN=0x1

    class DATA_BLOB(ctypes.Structure):
        _fields_=[('cbData',wt.DWORD),('pbData',ctypes.POINTER(ctypes.c_byte))]

    crypt32.CryptProtectData.argtypes=[
        ctypes.POINTER(DATA_BLOB),wt.LPCWSTR,
        ctypes.POINTER(DATA_BLOB),ctypes.c_void_p,ctypes.c_void_p,
        wt.DWORD,ctypes.POINTER(DATA_BLOB)
    ]
    crypt32.CryptProtectData.restype=wt.BOOL
    crypt32.CryptUnprotectData.argtypes=[
        ctypes.POINTER(DATA_BLOB),ctypes.POINTER(wt.LPWSTR),
        ctypes.POINTER(DATA_BLOB),ctypes.c_void_p,ctypes.c_void_p,
        wt.DWORD,ctypes.POINTER(DATA_BLOB)
    ]
    crypt32.CryptUnprotectData.restype=wt.BOOL
    kernel32.LocalFree.argtypes=[wt.HLOCAL]
    kernel32.LocalFree.restype=wt.HLOCAL

def _blob_from_bytes(data: bytes):
    buf=(ctypes.c_byte*len(data)).from_buffer_copy(data)
    blob=DATA_BLOB(len(data),ctypes.cast(buf,ctypes.POINTER(ctypes.c_byte)))
    return blob,buf

def dpapi_protect(data: bytes)->str:
    if os.name!='nt':
        raise RuntimeError('DPAPI reconnect is Windows-only')
    src,srcbuf=_blob_from_bytes(bytes(data))
    out=DATA_BLOB()
    if not crypt32.CryptProtectData(
        ctypes.byref(src),'Entropic Fusion mount-host token',
        None,None,None,CRYPTPROTECT_UI_FORBIDDEN,ctypes.byref(out)
    ):
        raise ctypes.WinError(ctypes.get_last_error(),'CryptProtectData')
    try:
        raw=ctypes.string_at(out.pbData,out.cbData)
        return base64.b64encode(raw).decode('ascii')
    finally:
        kernel32.LocalFree(out.pbData)

def dpapi_unprotect(encoded: str)->bytes:
    if os.name!='nt':
        raise RuntimeError('DPAPI reconnect is Windows-only')
    raw=base64.b64decode(encoded,validate=True)
    src,srcbuf=_blob_from_bytes(raw)
    out=DATA_BLOB()
    desc=wt.LPWSTR()
    if not crypt32.CryptUnprotectData(
        ctypes.byref(src),ctypes.byref(desc),
        None,None,None,CRYPTPROTECT_UI_FORBIDDEN,ctypes.byref(out)
    ):
        raise ctypes.WinError(ctypes.get_last_error(),'CryptUnprotectData')
    try:
        return ctypes.string_at(out.pbData,out.cbData)
    finally:
        if desc:
            kernel32.LocalFree(desc)
        kernel32.LocalFree(out.pbData)

def state_dir():
    p=Path(tempfile.gettempdir())/'EntropicFusion'/'mount-hosts'
    p.mkdir(parents=True,exist_ok=True)
    return p

def _atomic_state(path: Path,obj: dict):
    path=Path(path)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
    try: os.chmod(tmp,0o600)
    except Exception: pass
    os.replace(tmp,path)

def _state_with_token(st: dict)->dict:
    if st.get('token'):
        return st
    blob=st.get('token_dpapi_b64')
    if not blob:
        raise ValueError('mount-host state has no reconnect token')
    out=dict(st)
    out['token']=dpapi_unprotect(blob).decode('ascii')
    return out

def command(state,name,token=None,timeout=5.0):
    state=_state_with_token(state)
    end=time.time()+float(timeout)
    while True:
        try:
            h=open_client_pipe(state['pipe'])
            break
        except (FileNotFoundError,OSError):
            if time.time()>=end:
                raise
            time.sleep(.02)
    try:
        write_json(h,{'token':state['token'] if token is None else token,'command':name})
        return read_json(h)
    finally:
        close_handle(h)

def _host_launch_command(host_executable=None):
    """Return the exact isolated host command for source, frozen, or validator mode."""
    if host_executable is not None:
        host_exe=Path(host_executable).resolve()
        if not host_exe.is_file(): raise FileNotFoundError(host_exe)
        return [str(host_exe)]
    if getattr(sys,'frozen',False):
        app_dir=Path(sys.executable).resolve().parent
        host_exe=app_dir/'EntropicFusionHost.exe'
        if not host_exe.exists():
            raise FileNotFoundError(f'EntropicFusionHost.exe not found beside {Path(sys.executable).name}')
        return [str(host_exe)]
    return [sys.executable,str(HOST_SCRIPT)]

def start_host(vault,private_identity,drive,password,timeout=180,host_executable=None,diagnostics=False):
    root=state_dir()
    ident=uuid.uuid4().hex
    state_path=root/f'{ident}.json'
    error_path=root/f'{ident}.error.json'
    pipe_name=rf'\\.\pipe\EntropicFusionACL-{ident}'
    token=secrets.token_urlsafe(32)

    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)|getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
    cmd=_host_launch_command(host_executable)+[
         '--vault',str(Path(vault).resolve()),
         '--private',str(Path(private_identity).resolve()),
         '--drive',str(drive),
         '--state',str(state_path),
         '--error',str(error_path),
         '--pipe',pipe_name]
    env=os.environ.copy()
    if diagnostics: env['ENTROPIC_FUSION_DIAGNOSTICS']='1'
    proc=subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
        text=True,close_fds=True,creationflags=flags,env=env
    )
    proc.stdin.write(json.dumps({'password':password,'token':token})+'\n')
    proc.stdin.flush()
    proc.stdin.close()

    end=time.time()+timeout
    while time.time()<end:
        if state_path.exists():
            state=json.loads(state_path.read_text(encoding='utf-8'))

            # Persist only the DPAPI-protected token. Never persist plaintext.
            state['token_dpapi_b64']=dpapi_protect(token.encode('ascii'))
            state['client_state_version']=VERSION
            _atomic_state(state_path,state)

            live=dict(state)
            live['token']=token
            live['_state_path']=str(state_path)
            resp=command(live,'status')
            if not resp.get('ok'):
                raise RuntimeError(product_mount_error(resp.get('error'),'HostStatusError'))
            return live

        if error_path.exists():
            err=json.loads(error_path.read_text(encoding='utf-8'))
            error_path.unlink(missing_ok=True)
            raise RuntimeError(record_to_product_message(err))

        if proc.poll() is not None:
            raise RuntimeError('The vault host could not be started.')
        time.sleep(.1)

    raise TimeoutError('The vault host did not become ready in time.')

def discover_hosts():
    found=[]
    root=state_dir()
    for p in sorted(root.glob('*.json'),key=lambda x:x.stat().st_mtime,reverse=True):
        if p.name.endswith('.error.json'):
            continue
        try:
            st=json.loads(p.read_text(encoding='utf-8'))
            st=_state_with_token(st)
            st['_state_path']=str(p)
            resp=command(st,'status',timeout=.5)
            if resp.get('ok') and resp.get('status')=='mounted':
                found.append(st)
            else:
                p.unlink(missing_ok=True)
        except Exception:
            try: p.unlink(missing_ok=True)
            except Exception: pass
    return found

def dismount_host(state,timeout=20):
    resp=command(state,'dismount',timeout=min(5.0,float(timeout)))
    if not resp.get('ok'):
        raise RuntimeError(resp.get('error','dismount failed'))
    end=time.time()+timeout
    while time.time()<end:
        try:
            command(state,'status',timeout=.25)
        except Exception:
            try: Path(state.get('_state_path','')).unlink(missing_ok=True)
            except Exception: pass
            return True
        time.sleep(.1)
    raise TimeoutError('host did not dismount')
