#!/usr/bin/env python3
from __future__ import annotations

VERSION = "Beta1.1.1-errors3"
_GENERIC = "The vault could not be mounted. Check the vault, private identity and password, then try again."


def product_mount_error(error=None, error_type: str | None = None) -> str:
    """Return an end-user-safe mount error. Never echo arbitrary exception text."""
    msg = str(error or "").strip()
    low = msg.casefold()
    if error_type:
        et = str(error_type).casefold()
    elif error is not None:
        et = type(error).__name__.casefold()
    else:
        et = ""

    if "password must be at least 10 characters" in low:
        return "The password must be at least 10 characters."
    if (
        et == "invalidtag"
        or "invalidtag" in low
        or "authentication failed" in low
        or low == "incorrect password or the protected identity could not be unlocked."
    ):
        return "Incorrect password or the protected identity could not be unlocked."
    if "recipient identity mismatch" in low or "wrong identity" in low or "does not match the selected vault" in low:
        return "This private identity does not match the selected vault."
    if "no such file" in low or "filenotfounderror" in low:
        return "A required vault or identity file could not be found."
    # Deliberately no pass-through fallback. A novel/internal exception must not
    # become product UI merely because it is short.
    return _GENERIC


def record_to_product_message(record: dict | None) -> str:
    row = dict(record or {})
    return product_mount_error(row.get("error"), row.get("error_type"))


def contains_python_internals(text: str) -> bool:
    low = str(text or "").casefold()
    return any(x in low for x in ("traceback", "file \\\"", ".py\\\"", " line ", "\\n  file "))
