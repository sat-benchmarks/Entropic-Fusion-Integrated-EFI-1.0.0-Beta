#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, json, traceback
from pathlib import Path
from entropic_vault_path_beta1_1_1 import callback_path
from entropic_error_policy_beta1_1_1 import product_mount_error, contains_python_internals, VERSION as ERR_VERSION

VERSION="Entropic Fusion Beta 1.1.1"
BASELINE="Entropic Fusion Beta 1.1 manual gate rejected"
KIT_REVISION="R3-opened-context-fix"
RESULT=Path("BETA1_1_1_SOURCE_RESULT.json")
HERE=Path(__file__).resolve().parent
UNCHANGED={'entropic_bound_fusion_v0_11B_23_1.py': '8fdc7e7c8c8b1d45a12d09a86d799c642eec12170eaf0c221a0acc07473e81b9', 'entropic_fusion_aesgcm_v0_11B_23_1.py': '4c3441e84f9190be887abf5fd62021fd298784cb90e6d2b104f0c900effb0a83', 'entropic_fusion_cli_v0_11B_23_1.py': '1e31d1226c4f176bb0e1c959a7afce1fe173685cd4aeee2b3772e89fcebe5096', 'entropic_fusion_gui_v0_11B_23_1.py': '5dd467ff0292438e1e4749d5db7b2cbbad337db514cba226395f2c4fda61beb1', 'entropic_fusion_hybrid_combiner_v0_11B_23_1.py': 'd78f38177866c8a2821c61774cc1362cf515bfeaddd37e6de62f9b95a98e8f5d', 'entropic_fusion_mlkem_runtime_v0_11B_23_1.py': '4807d984ad15230c40e0f5f8ac57d1f56ed0910824d86e63bd98b587b5b76091', 'entropic_fusion_private_vault_v0_11B_23_1.py': '1dca17feafb764e60a3e0e110a6348ba6370d26503eaacb21d8a40d970bc8cd0', 'entropic_fusion_public_identity_v0_11B_23_1.py': 'e87399245ba047679c8eca388cc65f66fee2b17581ab1c633ec43b561143ed64', 'entropic_fusion_relation_v0_11B_23_1.py': '2ca99b6b23bcfbaf527fec957f7dd8c041a3f26a6b201f539b7e7150910c1838', 'entropic_fusion_release_utils_v0_11B_23_1.py': '004efc85e4009215ecebed83fb1d1965d19690edb0733b116857382772db07fb', 'entropic_openssl_runtime_v0_11B_23_1.py': 'b6f202a460259eeac01d5f4fcadac44deb7eadaf6b93f1e2124e96c1e11f8572', 'entropic_vault_compact_v0_11B_24_4_1.py': '63140eec5b2b315fac6b88baa0ffe0ed59b1087c17d4df8a1c145ba6cffdf844', 'entropic_vault_cow_v0_11B_24_3.py': '9ab1ad131b58a0088e14a2e780a26f6c5a2cea727eec12957262d518ce9848cf', 'entropic_vault_fusion_wrap_v0_11B_24_1.py': 'f4f854b93ee788312820159051f709c731b9009bc88dea4d94e848b93feaafa2', 'entropic_vault_manager_v0_11B_24_1.py': '614c96c8e1022cf402a59d5e9bf6cb89ba4abfa160f3f86322e3fa142e922186', 'entropic_vault_v0_11B_24_1.py': 'f3e647357f72fa90ea9c0f196df949b63fff80d697a1c8de72dc4b9e3c09742b', 'entropic_windows_pipe_acl_v0_11B_24_32.py': '3ac2c221ea30eb006a53071e54e33c50c23817c4d5d23577082f61bc8b003a93'}

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    r={"version":VERSION,"baseline":BASELINE,"kit_revision":KIT_REVISION,"tests":{},"observed":{}}
    try:
        newfiles=['entropic_vault_path_beta1_1_1.py','entropic_error_policy_beta1_1_1.py','entropic_diagnostics_beta1_1_1.py','entropic_vault_mount_beta1_1_1.py','entropic_mount_host_aclpipe_beta1_1_1.py','entropic_mount_host_aclpipe_client_beta1_1_1.py','entropic_fusion_gui_beta1_1_1.py','entropic_fusion_desktop_beta1_1_1.py']
        for n in newfiles: ast.parse((HERE/n).read_text(encoding='utf-8'),filename=n)
        r['tests']['all_new_python_sources_parse']=True
        cases={
            r'\file.docx':r'\file.docx',
            r'Z:\file.docx':r'\file.docx',
            r'\\?\Z:\file.docx':r'\file.docx',
            r'\??\Z:\file.docx':r'\file.docx',
            r'\\.\Z:\file.docx':r'\file.docx',
            r'\file.docx::$DATA':r'\file.docx',
            r'\file.docx:$DATA':r'\file.docx',
            r'Z:\Folder\File.DOCX::$data':r'\Folder\File.DOCX',
        }
        actual={k:callback_path(k) for k in cases}
        r['tests']['callback_path_matrix_exact']=all(actual[k]==v for k,v in cases.items())
        r['observed']['callback_path_matrix']=actual
        r['tests']['named_stream_not_aliased']=callback_path(r'\file.docx:secret')==r'\file.docx:secret'

        raw='Traceback (most recent call last):\n  File "secret.py", line 44\nValueError: internal'
        safe=product_mount_error(RuntimeError(raw),'RuntimeError')
        r['tests']['generic_traceback_sanitised']=not contains_python_internals(safe) and 'internal' not in safe.casefold()
        r['tests']['short_password_message_safe']=product_mount_error(ValueError('password must be at least 10 characters'),'ValueError')=='The password must be at least 10 characters.'
        r['tests']['invalidtag_message_safe']=product_mount_error('', 'InvalidTag')=='Incorrect password or the protected identity could not be unlocked.'
        r['tests']['already_safe_password_message_preserved']=product_mount_error('Incorrect password or the protected identity could not be unlocked.','RuntimeError')=='Incorrect password or the protected identity could not be unlocked.'
        r['tests']['error_policy_version_exact']=ERR_VERSION=='Beta1.1.1-errors3'

        host=(HERE/'entropic_mount_host_aclpipe_beta1_1_1.py').read_text(encoding='utf-8')
        client=(HERE/'entropic_mount_host_aclpipe_client_beta1_1_1.py').read_text(encoding='utf-8')
        gui=(HERE/'entropic_fusion_gui_beta1_1_1.py').read_text(encoding='utf-8')
        desktop=(HERE/'entropic_fusion_desktop_beta1_1_1.py').read_text(encoding='utf-8')
        mount=(HERE/'entropic_vault_mount_beta1_1_1.py').read_text(encoding='utf-8')
        r['tests']['unique_runtime_module_names']=all(x in (host+client+gui+desktop+mount) for x in ['beta1_1_1','Beta 1.1.1'])
        r['tests']['host_user_error_record_has_no_traceback_field']="'traceback':" not in host and '"traceback":' not in host
        r['tests']['host_atomic_json_uses_real_newline']="json.dumps(obj,indent=2)+'\\\\n'" not in host and "json.dumps(obj,indent=2)+'\\n'" in host
        r['tests']['host_runtime_version_r3']="VERSION='Beta1.1.1-host3'" in host
        r['tests']['host_records_separate_developer_diagnostic']="record_exception('mount-host startup failure'" in host and "'diagnostic_id':diagnostic_log_path().name" in host
        r['tests']['client_sanitises_host_error_record']='record_to_product_message(err)' in client
        r['tests']['gui_has_final_error_sanitiser']='return product_mount_error(err' in gui
        r['tests']['frozen_desktop_provenance_probe']='--build-info-json' in desktop and '--error-policy-probe' in desktop
        r['tests']['frozen_host_provenance_probe']='--build-info-json' in host
        r['tests']['default_stream_compatibility_active']='callback_path as canon' in mount
        tree=ast.parse(mount,filename='entropic_vault_mount_beta1_1_1.py')
        class_names={n.name for n in tree.body if isinstance(n,ast.ClassDef)}
        r['tests']['opened_context_class_present']='Opened' in class_names
        r['tests']['opened_context_canonicalises_path']='self.path = canon(path)' in mount
        r['tests']['open_and_create_return_opened_context']=mount.count('return Opened(p)') >= 2
        r['tests']['developer_diagnostics_not_beside_frozen_module']='tempfile.gettempdir()' in (HERE/'entropic_diagnostics_beta1_1_1.py').read_text(encoding='utf-8')
        r['tests']['managed_vault_controls_retained']=all(x in gui for x in ['managed_vault_dir','Hide physical vault file','Show vault location','not an access-control boundary'])
        r['tests']['desktop_version_beta_1_1_1']='VERSION = "Beta 1.1.1"' in desktop
        r['tests']['gui_version_beta_1_1_1']='VERSION = "Beta 1.1.1"' in gui
        r['tests']['unchanged_crypto_storage_files_exact']=all((HERE/n).is_file() and sha(HERE/n)==h for n,h in UNCHANGED.items())
        r['observed']['unchanged_file_count']=len(UNCHANGED)
        r['observed']['scope']=['runtime provenance','product error boundary','Win32/WinFsp callback path compatibility','managed vault controls retained']
        r['failed_tests']=[k for k,v in r['tests'].items() if v is not True]
        r['all_tests_passed']=not r['failed_tests']
        RESULT.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8'); print(json.dumps(r,indent=2))
        return 0 if r['all_tests_passed'] else 1
    except Exception:
        r['fatal_error']=traceback.format_exc();r['all_tests_passed']=False
        RESULT.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');traceback.print_exc();return 2
if __name__=='__main__': raise SystemExit(main())
