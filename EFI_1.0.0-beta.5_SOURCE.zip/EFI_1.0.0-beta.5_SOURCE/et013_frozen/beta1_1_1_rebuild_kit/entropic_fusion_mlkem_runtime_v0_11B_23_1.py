#!/usr/bin/env python3
"""OpenSSL ML-KEM byte adapter for Entropic Fusion B.23.1.

Private KEM keys are passed to OpenSSL over stdin for public-key derivation.
On OpenSSL 4.0.1 for Windows, pkeyutl does not accept `-inkey -` for
decapsulation, so the current compatibility path uses a short-lived private
temporary key file, restricts it where possible, overwrites it on cleanup, and
deletes it immediately. Ciphertexts/shared-secret scratch files remain inside
an isolated temporary directory because OpenSSL pkeyutl exposes the KEM shared
secret via its -secret file option.

The production hardening target remains in-process ML-KEM so private KEM keys
do not touch the filesystem during decapsulation.
"""
from __future__ import annotations
import subprocess, tempfile, os
from pathlib import Path
from entropic_openssl_runtime_v0_11B_23_1 import openssl_executable

SUPPORTED=("ML-KEM-768","ML-KEM-1024")

def _subprocess_kwargs():
    # Keep OpenSSL completely silent on Windows.  Python's subprocess calls
    # otherwise briefly create console windows when the GUI is launched with
    # pythonw.exe.
    if os.name == "nt":
        return {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}
    return {}

def _run(args, *, input_bytes=None, capture=False):
    cp=subprocess.run(args,input=input_bytes,stdout=subprocess.PIPE if capture else subprocess.PIPE,stderr=subprocess.PIPE,**_subprocess_kwargs())
    if cp.returncode:
        raise RuntimeError(cp.stderr.decode('utf-8','replace').strip() or 'OpenSSL command failed')
    return cp.stdout

def check_available():
    exe=openssl_executable()
    ver=subprocess.check_output([exe,'version'],**_subprocess_kwargs()).decode().strip()
    cp=subprocess.run([exe,'list','-kem-algorithms'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,**_subprocess_kwargs())
    text=(cp.stdout+cp.stderr).decode('utf-8','replace')
    missing=[a for a in SUPPORTED if a not in text and a.replace('-','') not in text]
    if missing: raise RuntimeError('OpenSSL does not expose: '+', '.join(missing))
    return ver

def keygen_bytes(alg):
    if alg not in SUPPORTED: raise ValueError('unsupported KEM')
    check_available(); exe=openssl_executable()
    sk=_run([exe,'genpkey','-algorithm',alg,'-outform','PEM'],capture=True)
    pk=_run([exe,'pkey','-pubout','-outform','PEM'],input_bytes=sk,capture=True)
    return pk,sk

def encapsulate_bytes(pk_pem, alg):
    if alg not in SUPPORTED: raise ValueError('unsupported KEM')
    check_available(); exe=openssl_executable()
    with tempfile.TemporaryDirectory(prefix='ef_b231_enc_') as td:
        td=Path(td); pk=td/'pk.pem'; ct=td/'ct.bin'; ss=td/'ss.bin'
        pk.write_bytes(pk_pem)  # public material only
        _run([exe,'pkeyutl','-encap','-inkey',str(pk),'-pubin','-out',str(ct),'-secret',str(ss)])
        return ct.read_bytes(),ss.read_bytes()

def _best_effort_wipe_file(path):
    """Overwrite a temporary private-key file before deletion.

    This reduces ordinary recovery risk, but cannot guarantee physical erasure
    on SSDs, snapshots, journalling filesystems or backups.
    """
    try:
        path=Path(path)
        size=path.stat().st_size
        with open(path,'r+b',buffering=0) as f:
            f.seek(0)
            block=b'\x00'*min(65536,max(1,size))
            remaining=size
            while remaining:
                n=min(len(block),remaining)
                f.write(block[:n])
                remaining-=n
            f.flush()
            try: os.fsync(f.fileno())
            except OSError: pass
    except Exception:
        pass
    try: Path(path).unlink(missing_ok=True)
    except Exception: pass

def _load_libcrypto():
    """Locate the libcrypto DLL that belongs to the configured OpenSSL."""
    import ctypes, ctypes.util
    exe=Path(openssl_executable()).resolve()
    candidates=[]

    # Prefer the DLL beside the exact openssl.exe we are using.
    for pattern in ("libcrypto-4-x64.dll","libcrypto-4.dll",
                    "libcrypto-3-x64.dll","libcrypto-3.dll",
                    "libcrypto*.dll"):
        candidates.extend(exe.parent.glob(pattern))

    # Also check common parent/lib/bin layouts.
    for parent in (exe.parent, exe.parent.parent, exe.parent.parent/"bin"):
        try:
            for p in parent.glob("libcrypto*.dll"):
                candidates.append(p)
        except Exception:
            pass

    seen=set()
    errors=[]
    for p in candidates:
        ps=str(p)
        if ps.lower() in seen:
            continue
        seen.add(ps.lower())
        try:
            return ctypes.WinDLL(ps), ps
        except Exception as e:
            errors.append(f"{ps}: {e}")

    found=ctypes.util.find_library("crypto")
    if found:
        try:
            return ctypes.WinDLL(found), found
        except Exception as e:
            errors.append(f"{found}: {e}")

    raise RuntimeError("Could not load OpenSSL libcrypto DLL. Tried: " + "; ".join(errors[-8:]))

def _openssl_error_text(lib):
    import ctypes
    try:
        lib.ERR_get_error.argtypes=[]
        lib.ERR_get_error.restype=ctypes.c_ulong
        lib.ERR_error_string_n.argtypes=[ctypes.c_ulong,ctypes.c_char_p,ctypes.c_size_t]
        lib.ERR_error_string_n.restype=None
        rows=[]
        while True:
            code=lib.ERR_get_error()
            if not code:
                break
            buf=ctypes.create_string_buffer(512)
            lib.ERR_error_string_n(code,buf,len(buf))
            rows.append(buf.value.decode("utf-8","replace"))
        return " | ".join(rows) if rows else "unknown OpenSSL error"
    except Exception as e:
        return f"OpenSSL error unavailable: {e}"

def _decapsulate_inprocess_windows(sk_pem, ct_bytes):
    """OpenSSL EVP decapsulation with private PEM held entirely in memory."""
    import ctypes
    lib,lib_path=_load_libcrypto()

    # BIO / PEM
    lib.BIO_new_mem_buf.argtypes=[ctypes.c_void_p,ctypes.c_int]
    lib.BIO_new_mem_buf.restype=ctypes.c_void_p
    lib.BIO_free.argtypes=[ctypes.c_void_p]
    lib.BIO_free.restype=ctypes.c_int
    lib.PEM_read_bio_PrivateKey.argtypes=[
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_void_p),
        ctypes.c_void_p,
        ctypes.c_void_p
    ]
    lib.PEM_read_bio_PrivateKey.restype=ctypes.c_void_p

    # EVP_PKEY
    lib.EVP_PKEY_free.argtypes=[ctypes.c_void_p]
    lib.EVP_PKEY_free.restype=None

    # Prefer modern OpenSSL 3/4 context constructor.
    if hasattr(lib,"EVP_PKEY_CTX_new_from_pkey"):
        lib.EVP_PKEY_CTX_new_from_pkey.argtypes=[
            ctypes.c_void_p,ctypes.c_void_p,ctypes.c_char_p
        ]
        lib.EVP_PKEY_CTX_new_from_pkey.restype=ctypes.c_void_p
        make_ctx=lambda pkey: lib.EVP_PKEY_CTX_new_from_pkey(None,pkey,None)
    else:
        lib.EVP_PKEY_CTX_new.argtypes=[ctypes.c_void_p,ctypes.c_void_p]
        lib.EVP_PKEY_CTX_new.restype=ctypes.c_void_p
        make_ctx=lambda pkey: lib.EVP_PKEY_CTX_new(pkey,None)

    lib.EVP_PKEY_CTX_free.argtypes=[ctypes.c_void_p]
    lib.EVP_PKEY_CTX_free.restype=None
    lib.EVP_PKEY_decapsulate_init.argtypes=[ctypes.c_void_p,ctypes.c_void_p]
    lib.EVP_PKEY_decapsulate_init.restype=ctypes.c_int
    lib.EVP_PKEY_decapsulate.argtypes=[
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_size_t),
        ctypes.c_void_p,
        ctypes.c_size_t
    ]
    lib.EVP_PKEY_decapsulate.restype=ctypes.c_int

    sk_buf=ctypes.create_string_buffer(bytes(sk_pem))
    bio=lib.BIO_new_mem_buf(sk_buf,len(sk_pem))
    if not bio:
        raise RuntimeError("BIO_new_mem_buf failed: "+_openssl_error_text(lib))

    pkey=None
    ctx=None
    try:
        pkey=lib.PEM_read_bio_PrivateKey(bio,None,None,None)
        if not pkey:
            raise RuntimeError("PEM_read_bio_PrivateKey failed: "+_openssl_error_text(lib))

        ctx=make_ctx(pkey)
        if not ctx:
            raise RuntimeError("EVP_PKEY_CTX creation failed: "+_openssl_error_text(lib))

        if lib.EVP_PKEY_decapsulate_init(ctx,None) <= 0:
            raise RuntimeError("EVP_PKEY_decapsulate_init failed: "+_openssl_error_text(lib))

        ct_buf=ctypes.create_string_buffer(bytes(ct_bytes))

        # Query required shared-secret length.
        outlen=ctypes.c_size_t(0)
        rc=lib.EVP_PKEY_decapsulate(
            ctx,None,ctypes.byref(outlen),ct_buf,len(ct_bytes)
        )
        if rc <= 0 or outlen.value <= 0 or outlen.value > 4096:
            raise RuntimeError(
                f"EVP_PKEY_decapsulate size query failed rc={rc} len={outlen.value}: "
                + _openssl_error_text(lib)
            )

        out=(ctypes.c_ubyte*outlen.value)()
        rc=lib.EVP_PKEY_decapsulate(
            ctx,out,ctypes.byref(outlen),ct_buf,len(ct_bytes)
        )
        if rc <= 0:
            raise RuntimeError("EVP_PKEY_decapsulate failed: "+_openssl_error_text(lib))

        return bytes(out[:outlen.value]),lib_path
    finally:
        if ctx:
            lib.EVP_PKEY_CTX_free(ctx)
        if pkey:
            lib.EVP_PKEY_free(pkey)
        lib.BIO_free(bio)
        # Best effort zero of the Python-owned PEM scratch buffer.
        try:
            ctypes.memset(ctypes.addressof(sk_buf),0,len(sk_buf))
        except Exception:
            pass

def decapsulate_bytes(sk_pem, ct_bytes, alg):
    if alg not in SUPPORTED:
        raise ValueError('unsupported KEM')
    check_available()

    if os.name == 'nt':
        ss,_ = _decapsulate_inprocess_windows(sk_pem,ct_bytes)
        return ss

    # Existing compatibility fallback for non-Windows development.
    exe=openssl_executable()
    with tempfile.TemporaryDirectory(prefix='ef_b231_dec_') as td:
        td=Path(td); ct=td/'ct.bin'; ss=td/'ss.bin'; sk=td/'sk.pem'
        ct.write_bytes(ct_bytes)
        with open(sk,'wb') as f:
            f.write(sk_pem)
            f.flush()
            try: os.fsync(f.fileno())
            except OSError: pass
        try:
            try: os.chmod(sk,0o600)
            except OSError: pass
            _run([exe,'pkeyutl','-decap','-inkey',str(sk),'-in',str(ct),'-secret',str(ss)])
            return ss.read_bytes()
        finally:
            _best_effort_wipe_file(sk)
