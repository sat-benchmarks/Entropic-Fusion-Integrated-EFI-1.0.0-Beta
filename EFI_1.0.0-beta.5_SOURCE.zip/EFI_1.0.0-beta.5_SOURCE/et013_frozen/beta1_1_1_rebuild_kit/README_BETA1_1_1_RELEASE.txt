ENTROPIC FUSION BETA 1.1.1
============================

Corrective beta build after the Beta 1.1 manual gate failed.

Run EntropicFusion.exe with EntropicFusionHost.exe in the same folder.
WinFsp is required for mounted vaults.

See CHANGELOG.txt for the exact fixes and preserved Beta 1.1 failure record.
