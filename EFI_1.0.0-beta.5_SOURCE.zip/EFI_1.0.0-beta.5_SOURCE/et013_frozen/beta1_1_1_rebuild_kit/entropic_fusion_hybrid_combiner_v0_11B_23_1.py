#!/usr/bin/env python3
"""Entropic Fusion B.23.1 three-leg final traffic-key combiner.

Final traffic key depends on:
  1. ML-KEM-768 shared secret
  2. ML-KEM-1024 shared secret
  3. EF-gated per-file session contribution
  4. complete authenticated transcript and application context

The EF-gated contribution is produced only after binding the ML-KEM-1024
session secret to the Entropic Fusion relation commitment and complete
ciphertext transcript. On decryption the official path cannot recover that
inner session secret until the live EF relation verifies and releases the
wrapped ML-KEM-1024 private key.

This is an implementation-fusion property. It is not a claim that the EF leg
has an independently quantified hardness level.
"""
from __future__ import annotations
import hashlib,hmac

VERSION="0.11B.23.1"
DOMAIN=b"ENTROPIC-FUSION/B23.1/THREE-LEG-COMBINER/v1"

def _lp(x:bytes)->bytes:
    if len(x)>0xffffffff: raise ValueError("input too long")
    return len(x).to_bytes(4,"big")+x

def derive_aes256_key(outer_ss:bytes, inner_ss:bytes, ef_session_ss:bytes,
                      transcript:bytes, context:bytes=b"")->bytes:
    for name,x in (("outer ML-KEM",outer_ss),("inner ML-KEM",inner_ss),("EF-gated session",ef_session_ss)):
        if len(x)<16: raise ValueError(f"{name} shared secret unexpectedly short")
    th=hashlib.sha256(transcript).digest()
    ch=hashlib.sha256(context).digest()
    extract_key=DOMAIN+b"/extract/"+ch
    ikm=_lp(outer_ss)+_lp(inner_ss)+_lp(ef_session_ss)+th
    prk=hmac.new(extract_key,ikm,hashlib.sha256).digest()
    return hmac.new(prk,DOMAIN+b"/aes-256-gcm/"+th,hashlib.sha256).digest()

def derive_key_id(key:bytes)->str:
    return hashlib.sha256(DOMAIN+b"/key-id/"+key).hexdigest()[:24]

def self_test(rounds:int=3000)->dict:
    outer=hashlib.sha256(b"b231-outer").digest()
    inner=hashlib.sha256(b"b231-inner").digest()
    ef=hashlib.sha256(b"b231-ef-gated").digest()
    transcript=b"Entropic Fusion B.23.1 complete transcript"
    context=b"file-encryption"
    ref=derive_aes256_key(outer,inner,ef,transcript,context)
    tests={
        "deterministic":ref==derive_aes256_key(outer,inner,ef,transcript,context),
        "outer_required":ref!=derive_aes256_key(bytes([outer[0]^1])+outer[1:],inner,ef,transcript,context),
        "inner_required":ref!=derive_aes256_key(outer,bytes([inner[0]^1])+inner[1:],ef,transcript,context),
        "ef_leg_required":ref!=derive_aes256_key(outer,inner,bytes([ef[0]^1])+ef[1:],transcript,context),
        "transcript_bound":ref!=derive_aes256_key(outer,inner,ef,transcript+b"!",context),
        "context_bound":ref!=derive_aes256_key(outer,inner,ef,transcript,context+b"!"),
        "key_is_256_bits":len(ref)==32,
    }
    collisions=0
    vals=[outer,inner,ef]
    for i in range(rounds):
        which=i%3
        x=bytearray(vals[which]); x[(i//3)%len(x)]^=1<<((i//11)%8)
        args=[outer,inner,ef]; args[which]=bytes(x)
        collisions += int(derive_aes256_key(args[0],args[1],args[2],transcript,context)==ref)
    tests["mutation_sweep_rounds"]=rounds
    tests["mutation_sweep_collisions"]=collisions
    tests["all_boolean_tests_passed"]=all(v is True for v in tests.values() if isinstance(v,bool))
    return {"version":VERSION,"reference_key_id":derive_key_id(ref),"tests":tests}
