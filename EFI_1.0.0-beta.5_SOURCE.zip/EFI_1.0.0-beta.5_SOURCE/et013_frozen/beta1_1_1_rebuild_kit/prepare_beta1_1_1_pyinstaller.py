#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
HERE=Path(__file__).resolve().parent

def collect_openssl():
    from entropic_openssl_runtime_v0_11B_23_1 import openssl_executable
    exe=Path(openssl_executable()).resolve()
    if not exe.exists(): raise FileNotFoundError(exe)
    binaries=[(str(exe),'openssl')]
    for p in exe.parent.glob('*.dll'): binaries.append((str(p),'openssl'))
    for root in (exe.parent.parent/'lib'/'ossl-modules',exe.parent/'ossl-modules',exe.parent.parent/'lib64'/'ossl-modules'):
        if root.is_dir():
            for p in root.glob('*'):
                if p.is_file(): binaries.append((str(p),'openssl/ossl-modules'))
    return exe,binaries

def spec_text(script,name,binaries,console=False):
    return f"""# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all
datas=[]
binaries={binaries!r}
hiddenimports=[]
for pkg in ('winfspy','cryptography'):
    try:
        d,b,h=collect_all(pkg); datas+=d; binaries+=b; hiddenimports+=h
    except Exception:
        pass
a=Analysis([{script!r}],pathex=[{str(HERE)!r}],binaries=binaries,datas=datas,hiddenimports=hiddenimports,hookspath=[],hooksconfig={{}},runtime_hooks=[],excludes=[],noarchive=False,optimize=0)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,a.binaries,a.datas,[],name={name!r},debug=False,bootloader_ignore_signals=False,strip=False,upx=False,console={console!r},disable_windowed_traceback=True)
"""

def main():
    exe,binaries=collect_openssl()
    (HERE/'EntropicFusion_Beta1_1_1.spec').write_text(spec_text('entropic_fusion_desktop_beta1_1_1.py','EntropicFusion',binaries,False),encoding='utf-8')
    (HERE/'EntropicFusionHost_Beta1_1_1.spec').write_text(spec_text('entropic_mount_host_aclpipe_beta1_1_1.py','EntropicFusionHost',binaries,False),encoding='utf-8')
    print('Using OpenSSL:',exe)
if __name__=='__main__': main()
