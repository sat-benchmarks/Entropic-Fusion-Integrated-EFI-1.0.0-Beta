#!/usr/bin/env python3
from __future__ import annotations
import hashlib, os
from pathlib import Path
from entropic_fusion_private_vault_v0_11B_23_1 import unprotect_private_identity

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda:f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()

def display_fingerprint(path: Path) -> str:
    d=sha256_file(path)
    return " ".join(d[i:i+8] for i in range(0,len(d),8))

def verify_vault(raw_private: Path, vault: Path, password: str) -> dict:
    raw=Path(raw_private).read_bytes()
    recovered=unprotect_private_identity(Path(vault),password)
    return {
        "verified": raw==recovered,
        "raw_sha256": hashlib.sha256(raw).hexdigest(),
        "vault_plaintext_sha256": hashlib.sha256(recovered).hexdigest()
    }

def best_effort_remove(path: Path) -> dict:
    p=Path(path)
    if not p.exists():
        return {"removed":True,"existed":False}
    try:
        n=p.stat().st_size
        with p.open("r+b",buffering=0) as f:
            block=b"\x00"*65536
            left=n
            while left:
                k=min(left,len(block))
                f.write(block[:k]); left-=k
            f.flush()
            try: os.fsync(f.fileno())
            except Exception: pass
    except Exception:
        pass
    p.unlink(missing_ok=True)
    return {
        "removed": not p.exists(),
        "existed": True,
        "note":"Best-effort only; SSD wear levelling, snapshots, backups, and journalling may retain prior blocks."
    }
