#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, sys, time
from pathlib import Path
from entropic_vault_mount_beta1_1_1 import mount_vault, VERSION as MOUNT_VERSION
from entropic_vault_path_beta1_1_1 import VERSION as PATH_VERSION
from entropic_error_policy_beta1_1_1 import product_mount_error, VERSION as ERROR_POLICY_VERSION
from entropic_diagnostics_beta1_1_1 import record_exception, diagnostic_log_path, VERSION as DIAGNOSTICS_VERSION
from entropic_windows_pipe_acl_v0_11B_24_32 import create_server_pipe,connect_server_pipe,read_json,write_json,disconnect_pipe,close_handle

VERSION='Beta1.1.1-host3'

def atomic_json(path,obj):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
    os.replace(tmp,path)

def build_info():
    return {'host_version':VERSION,'mount_version':MOUNT_VERSION,'path_version':PATH_VERSION,'error_policy_version':ERROR_POLICY_VERSION,'diagnostics_version':DIAGNOSTICS_VERSION}

def main():
    if '--build-info-json' in sys.argv:
        i=sys.argv.index('--build-info-json')
        if i+1>=len(sys.argv): return 2
        atomic_json(Path(sys.argv[i+1]),build_info()); return 0

    ap=argparse.ArgumentParser()
    ap.add_argument('--vault',required=True); ap.add_argument('--private',required=True); ap.add_argument('--drive',required=True)
    ap.add_argument('--state',required=True); ap.add_argument('--error',required=True); ap.add_argument('--pipe',required=True)
    a=ap.parse_args()
    vault_path=Path(a.vault).resolve(); private_path=Path(a.private).resolve(); state_path=Path(a.state).resolve(); error_path=Path(a.error).resolve(); drive=a.drive; pipe_name=a.pipe
    fs=ops=unlock=mk=None; server_handle=None
    try:
        startup=json.loads(input()); password=startup.get('password'); token=startup.get('token')
        if not password or not token: raise ValueError('missing startup secret')
        fs,ops,unlock,mk=mount_vault(vault_path,private_path,drive,password); password=None; fs.start()
        server_handle,sid,sddl=create_server_pipe(pipe_name)
        atomic_json(state_path,{'version':VERSION,'mount_version':MOUNT_VERSION,'status':'mounted','pid':os.getpid(),'drive':drive,'vault':str(vault_path),'private_identity':str(private_path),'pipe':pipe_name,'pipe_acl_sid':sid,'pipe_acl_sddl':sddl,'ef_equations_verified':unlock.get('ef_equations_verified'),'fusion_mode':unlock.get('fusion_mode'),'created_at':time.time()})
        stop=False
        while not stop:
            h=server_handle; server_handle=None; connect_server_pipe(h)
            try:
                req=read_json(h)
                if req.get('token')!=token: resp={'ok':False,'error':'unauthorised'}
                elif req.get('command')=='status': resp={'ok':True,'status':'mounted','pid':os.getpid(),'drive':drive,'vault':str(vault_path),'host_version':VERSION,'mount_version':MOUNT_VERSION,'ef_equations_verified':unlock.get('ef_equations_verified'),'fusion_mode':unlock.get('fusion_mode'),'stats':ops.store.stats()}
                elif req.get('command')=='dismount': resp={'ok':True,'status':'dismounting'}; stop=True
                else: resp={'ok':False,'error':'unknown command'}
                write_json(h,resp)
            except Exception as e:
                record_exception('named-pipe request failure',e)
                try: write_json(h,{'ok':False,'error':'The vault host could not complete the request.'})
                except Exception: pass
            finally: disconnect_pipe(h); close_handle(h)
            if not stop: server_handle,_,_=create_server_pipe(pipe_name)
        try: ops.store.flush_pending()
        finally: fs.stop(); fs=None
        ops.store.mark_clean_shutdown(); state_path.unlink(missing_ok=True); return 0
    except BaseException as exc:
        # Full developer detail is kept in a separate diagnostic log. The IPC/error
        # record deliberately carries only a product-safe message and type label.
        record_exception('mount-host startup failure',exc,vault=str(vault_path),drive=drive)
        try:
            atomic_json(error_path,{'version':VERSION,'error':product_mount_error(exc,type(exc).__name__),'error_type':type(exc).__name__,'diagnostic_id':diagnostic_log_path().name,'pid':os.getpid(),'drive':drive})
        except Exception: pass
        return 2
    finally:
        if server_handle is not None: close_handle(server_handle)
        if fs is not None:
            try:
                if ops is not None: ops.store.flush_pending()
            except Exception: pass
            try: fs.stop()
            except Exception: pass
        if mk is not None:
            try:
                for i in range(len(mk)): mk[i]=0
            except Exception: pass
if __name__=='__main__': raise SystemExit(main())
