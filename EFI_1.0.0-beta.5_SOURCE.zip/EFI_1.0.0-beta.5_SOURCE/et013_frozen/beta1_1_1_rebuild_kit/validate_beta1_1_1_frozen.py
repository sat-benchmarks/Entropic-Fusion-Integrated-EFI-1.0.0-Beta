#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,subprocess,tempfile,time,traceback
from pathlib import Path
VERSION='Entropic Fusion Beta 1.1.1'; BASELINE='Beta 1.1 manual gate rejected'; KIT_REVISION='R3-opened-context-fix'; RESULT=Path('BETA1_1_1_FROZEN_RESULT.json'); HERE=Path(__file__).resolve().parent

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def run_probe(exe,args,out,timeout=30):
    out.unlink(missing_ok=True)
    cp=subprocess.run([str(exe),*args,str(out)],cwd=str(HERE),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=timeout)
    if cp.returncode!=0: raise RuntimeError(f'{exe.name} probe returned {cp.returncode}')
    if not out.is_file(): raise FileNotFoundError(out)
    return json.loads(out.read_text(encoding='utf-8'))

def main():
    r={'version':VERSION,'baseline':BASELINE,'kit_revision':KIT_REVISION,'tests':{},'observed':{}};proc=None
    try:
        desk=HERE/'dist'/'EntropicFusion.exe';host=HERE/'dist'/'EntropicFusionHost.exe'
        r['tests']['desktop_exe_exists']=desk.is_file();r['tests']['host_exe_exists']=host.is_file()
        if not desk.is_file() or not host.is_file(): raise FileNotFoundError('frozen EXE missing')
        r['observed']['desktop_exe_sha256']=sha(desk);r['observed']['host_exe_sha256']=sha(host)
        r['tests']['desktop_and_host_distinct']=sha(desk)!=sha(host)
        td=Path(tempfile.mkdtemp(prefix='ef_b111_frozen_'))
        di=run_probe(desk,['--build-info-json'],td/'desktop.json')
        hi=run_probe(host,['--build-info-json'],td/'host.json')
        ep=run_probe(desk,['--error-policy-probe'],td/'error.json')
        r['observed']['desktop_build_info']=di;r['observed']['host_build_info']=hi;r['observed']['error_probe']=ep
        r['tests']['desktop_runtime_exact']=di=={'desktop_version':'Beta 1.1.1','gui_version':'Beta 1.1.1','client_version':'Beta1.1.1-client2','error_policy_version':'Beta1.1.1-errors3','path_version':'Beta1.1.1-path2'}
        r['tests']['host_runtime_exact']=hi=={'host_version':'Beta1.1.1-host3','mount_version':'Beta1.1.1-mount3','path_version':'Beta1.1.1-path2','error_policy_version':'Beta1.1.1-errors3','diagnostics_version':'Beta1.1.1-diagnostics1'}
        msg=str(ep.get('message',''))
        low=msg.casefold()
        r['tests']['frozen_error_probe_sanitised']=bool(msg) and all(x not in low for x in ['traceback','internal.py',' line 99','secret internal'])
        proc=subprocess.Popen([str(desk)],cwd=str(HERE),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        time.sleep(3);r['tests']['frozen_desktop_starts_and_stays_alive']=proc.poll() is None
        if proc.poll() is None:
            proc.terminate()
            try:proc.wait(timeout=10)
            except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
        proc=None
        r['tests']['changelog_present']=(HERE/'CHANGELOG_BETA1_1_1.txt').is_file()
        r['failed_tests']=[k for k,v in r['tests'].items() if v is not True];r['all_tests_passed']=not r['failed_tests']
        RESULT.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r,indent=2));return 0 if r['all_tests_passed'] else 1
    except Exception:
        r['fatal_error']=traceback.format_exc();r['all_tests_passed']=False;RESULT.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');traceback.print_exc();return 2
    finally:
        if proc is not None and proc.poll() is None:
            try:proc.kill()
            except Exception:pass
if __name__=='__main__': raise SystemExit(main())
