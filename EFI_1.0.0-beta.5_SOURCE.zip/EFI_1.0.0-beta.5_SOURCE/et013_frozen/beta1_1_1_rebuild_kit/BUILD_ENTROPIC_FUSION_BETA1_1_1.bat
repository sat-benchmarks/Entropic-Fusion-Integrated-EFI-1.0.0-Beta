@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo   Entropic Fusion Beta 1.1.1 - Corrective Rebuild + Gate
echo ============================================================
echo.
echo Beta 1.1 manual gate was rejected.
echo This BAT builds the correction and runs the diagnostics automatically.
echo No Command Prompt diagnostics are required from you.
echo.

python validate_beta1_1_1_source.py
if errorlevel 1 goto :fail

python -c "import PyInstaller" >nul 2>nul
if errorlevel 1 python -m pip install --upgrade pyinstaller
if errorlevel 1 goto :fail

python prepare_beta1_1_1_pyinstaller.py
if errorlevel 1 goto :fail

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

python -m PyInstaller --noconfirm --clean EntropicFusion_Beta1_1_1.spec
if errorlevel 1 goto :fail
python -m PyInstaller --noconfirm --clean EntropicFusionHost_Beta1_1_1.spec
if errorlevel 1 goto :fail

python validate_beta1_1_1_frozen.py
if errorlevel 1 goto :fail

python validate_beta1_1_1_windows_integration.py
if errorlevel 1 goto :fail

python assemble_beta1_1_1_release.py
if errorlevel 1 goto :fail

echo.
echo ============================================================
echo   ENTROPIC FUSION BETA 1.1.1 BUILD + GATES PASSED
echo ============================================================
echo.
echo Send me:
echo   BETA1_1_1_SOURCE_RESULT.json
echo   BETA1_1_1_FROZEN_RESULT.json
echo   BETA1_1_1_WINDOWS_INTEGRATION_RESULT.json
echo.
echo Finished application package:
echo   release\EntropicFusion_Beta_1_1_1.zip
echo.
pause
exit /b 0

:fail
echo.
echo ============================================================
echo   BETA 1.1.1 BUILD OR GATE FAILED
echo ============================================================
echo.
echo Send me whichever of these were created:
echo   BETA1_1_1_SOURCE_RESULT.json
echo   BETA1_1_1_FROZEN_RESULT.json
echo   BETA1_1_1_WINDOWS_INTEGRATION_RESULT.json
echo.
echo Do not run manual diagnostics. The result JSON captures the diagnostic tail.
echo.
pause
exit /b 1
