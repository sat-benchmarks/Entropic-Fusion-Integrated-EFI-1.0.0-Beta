#!/usr/bin/env python3
from __future__ import annotations
import datetime, json, os, tempfile, traceback
from pathlib import Path

VERSION = "Beta1.1.1-diagnostics1"


def diagnostics_dir() -> Path:
    p = Path(tempfile.gettempdir()) / "EntropicFusion" / "diagnostics"
    p.mkdir(parents=True, exist_ok=True)
    return p


def diagnostic_log_path() -> Path:
    return diagnostics_dir() / f"mount-{os.getpid()}.log"


def diagnostics_enabled() -> bool:
    return os.environ.get("ENTROPIC_FUSION_DIAGNOSTICS", "").strip() == "1"


def trace_event(name: str, **fields) -> None:
    if not diagnostics_enabled():
        return
    try:
        row = {"time": datetime.datetime.now().isoformat(timespec="milliseconds"), "event": name, **fields}
        with diagnostic_log_path().open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, default=str, sort_keys=True) + "\\n")
    except Exception:
        pass


def record_exception(name: str, exc: BaseException, **fields) -> None:
    try:
        stamp = datetime.datetime.now().isoformat(timespec="milliseconds")
        with diagnostic_log_path().open("a", encoding="utf-8") as f:
            f.write(f"\\n[{stamp}] {name}\\n")
            if fields:
                f.write(json.dumps(fields, default=str, sort_keys=True) + "\\n")
            f.write(f"{type(exc).__name__}: {exc}\\n")
            f.write(traceback.format_exc())
            f.write("\\n")
    except Exception:
        pass
