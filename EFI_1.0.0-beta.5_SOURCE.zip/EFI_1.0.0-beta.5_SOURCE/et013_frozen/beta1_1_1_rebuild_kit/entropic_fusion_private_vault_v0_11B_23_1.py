#!/usr/bin/env python3
"""Password-protected private identity storage for Entropic Fusion v0.11B.23.1."""
from __future__ import annotations
import base64, json, os
from pathlib import Path
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

FORMAT = "EF-B21-PRIVATE-VAULT-1"
AAD = b"ENTROPIC-FUSION/B21/PRIVATE-IDENTITY-VAULT/v1"

def _b64e(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")

def _b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"), validate=True)

def _derive(password: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    if not isinstance(password, str) or len(password) < 10:
        raise ValueError("password must be at least 10 characters")
    kdf = Scrypt(salt=salt, length=32, n=n, r=r, p=p)
    return kdf.derive(password.encode("utf-8"))

def protect_private_identity(src_private: Path, dst_vault: Path, password: str) -> dict:
    raw = Path(src_private).read_bytes()
    salt = os.urandom(16)
    nonce = os.urandom(12)
    n, r, p = 2**17, 8, 1
    key = _derive(password, salt, n, r, p)
    ct = AESGCM(key).encrypt(nonce, raw, AAD)
    row = {
        "format": FORMAT,
        "kdf": {"name": "scrypt", "n": n, "r": r, "p": p, "salt_b64": _b64e(salt)},
        "aead": "AES-256-GCM",
        "nonce_b64": _b64e(nonce),
        "ciphertext_b64": _b64e(ct),
    }
    Path(dst_vault).write_text(json.dumps(row, indent=2) + "\n", encoding="utf-8")
    return {"format": FORMAT, "protected_bytes": len(raw), "vault_bytes": Path(dst_vault).stat().st_size}

def unprotect_private_identity(vault_path: Path, password: str) -> bytes:
    row = json.loads(Path(vault_path).read_text(encoding="utf-8"))
    if row.get("format") != FORMAT:
        raise ValueError("unsupported private identity vault format")
    k = row["kdf"]
    key = _derive(password, _b64d(k["salt_b64"]), int(k["n"]), int(k["r"]), int(k["p"]))
    return AESGCM(key).decrypt(_b64d(row["nonce_b64"]), _b64d(row["ciphertext_b64"]), AAD)

def is_protected_private_identity(path: Path) -> bool:
    try:
        row = json.loads(Path(path).read_text(encoding="utf-8"))
        return row.get("format") == FORMAT
    except Exception:
        return False
