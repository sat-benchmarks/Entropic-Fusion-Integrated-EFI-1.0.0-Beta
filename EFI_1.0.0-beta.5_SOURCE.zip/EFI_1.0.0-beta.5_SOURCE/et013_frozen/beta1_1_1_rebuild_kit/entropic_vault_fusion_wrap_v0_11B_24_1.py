#!/usr/bin/env python3
from __future__ import annotations
import os, json, base64, hashlib, tempfile
from pathlib import Path
from cryptography.exceptions import InvalidTag

from entropic_fusion_public_identity_v0_11B_23_1 import (
    load_public, load_private, encapsulate_fused, decapsulate_fused, derive_ef_gated_session
)
from entropic_fusion_hybrid_combiner_v0_11B_23_1 import derive_aes256_key, derive_key_id
from entropic_fusion_aesgcm_v0_11B_23_1 import encrypt as aes_encrypt, decrypt as aes_decrypt
from entropic_fusion_private_vault_v0_11B_23_1 import unprotect_private_identity
from entropic_vault_v0_11B_24_1 import canonical, b64e, b64d

VERSION="0.11B.24.1"
WRAP_FORMAT="EF-VAULT-FUSION-WRAP-1"
CONTEXT="Entropic Fusion B.24.1 vault master-key protection"

def _transcript(pub:dict,vault_id:bytes,outer_ct:bytes,inner_ct:bytes)->bytes:
    return canonical({
        "domain":"ENTROPIC-FUSION/B24.1/VAULT-MASTER-KEY-TRANSCRIPT/v1",
        "public_identity_sha256":pub["public_identity_sha256"],
        "ef_fusion_commitment_sha256":pub["ef_fusion_commitment_sha256"],
        "vault_id_sha256":hashlib.sha256(vault_id).hexdigest(),
        "outer_ct_sha256":hashlib.sha256(outer_ct).hexdigest(),
        "inner_ct_sha256":hashlib.sha256(inner_ct).hexdigest(),
        "context":CONTEXT,
    })

def wrap_master_key(public_identity_path:Path,master_key:bytes,vault_id:bytes)->dict:
    if len(master_key)!=32:
        raise ValueError("vault master key must be 32 bytes")
    if len(vault_id)!=16:
        raise ValueError("vault_id must be 16 bytes")
    pub=load_public(public_identity_path)
    outer_ct,outer_ss,inner_ct,inner_ss=encapsulate_fused(pub)
    transcript=_transcript(pub,vault_id,outer_ct,inner_ct)
    ef_session=derive_ef_gated_session(inner_ss,pub["ef_fusion_commitment_sha256"],transcript)
    wrap_key=derive_aes256_key(outer_ss,inner_ss,ef_session,transcript,CONTEXT.encode())
    capsule_header={
        "format":WRAP_FORMAT,
        "version":VERSION,
        "fusion_mode":"EF-direct-three-leg-combiner",
        "public_identity_sha256":pub["public_identity_sha256"],
        "ef_fusion_commitment_sha256":pub["ef_fusion_commitment_sha256"],
        "vault_id_sha256":hashlib.sha256(vault_id).hexdigest(),
        "transcript_sha256":hashlib.sha256(transcript).hexdigest(),
        "context":CONTEXT,
    }
    row=aes_encrypt(wrap_key,master_key,canonical(capsule_header))
    return {
        "header":capsule_header,
        "outer_kem_ciphertext_b64":b64e(outer_ct),
        "inner_kem_ciphertext_b64":b64e(inner_ct),
        "nonce_b64":b64e(bytes.fromhex(row["nonce_hex"])),
        "ciphertext_b64":b64e(bytes.fromhex(row["ciphertext_hex"])),
        "wrap_key_id":derive_key_id(wrap_key),
    }

def _unwrap_with_private_obj(priv:dict,capsule:dict,vault_id:bytes)->tuple[bytes,dict]:
    header=capsule.get("header",{})
    if header.get("format")!=WRAP_FORMAT:
        raise ValueError("unsupported vault Fusion wrapper")
    pub=priv["public_identity"]
    if header.get("public_identity_sha256")!=pub["public_identity_sha256"]:
        raise ValueError("vault recipient identity mismatch")
    if header.get("vault_id_sha256")!=hashlib.sha256(vault_id).hexdigest():
        raise ValueError("vault ID mismatch")
    outer_ct=b64d(capsule["outer_kem_ciphertext_b64"])
    inner_ct=b64d(capsule["inner_kem_ciphertext_b64"])
    transcript=_transcript(pub,vault_id,outer_ct,inner_ct)
    if hashlib.sha256(transcript).hexdigest()!=header.get("transcript_sha256"):
        raise ValueError("vault Fusion transcript mismatch")
    outer_ss,inner_ss,ef_report,_fusion_secret=decapsulate_fused(priv,outer_ct,inner_ct)
    ef_session=derive_ef_gated_session(inner_ss,pub["ef_fusion_commitment_sha256"],transcript)
    wrap_key=derive_aes256_key(outer_ss,inner_ss,ef_session,transcript,CONTEXT.encode())
    try:
        master_key=aes_decrypt(
            wrap_key,
            b64d(capsule["nonce_b64"]),
            b64d(capsule["ciphertext_b64"]),
            canonical(header),
        )
    except InvalidTag as e:
        raise ValueError("vault master-key authentication failed") from e
    if len(master_key)!=32:
        raise ValueError("invalid recovered vault master key length")
    report={
        "fusion_mode":"EF-direct-three-leg-combiner",
        "ef_equations_verified":ef_report["equations_verified"],
        "wrap_key_id":derive_key_id(wrap_key),
        "public_identity_sha256":pub["public_identity_sha256"],
    }
    return master_key,report

def unwrap_master_key(private_identity_path:Path,capsule:dict,vault_id:bytes)->tuple[bytes,dict]:
    return _unwrap_with_private_obj(load_private(private_identity_path),capsule,vault_id)

def unwrap_master_key_from_protected_vault(private_vault_path:Path,password:str,capsule:dict,vault_id:bytes)->tuple[bytes,dict]:
    raw=unprotect_private_identity(private_vault_path,password)
    # Avoid changing the locked B23.1 private-identity API. Parse the authenticated
    # vault result in memory instead of persisting it again.
    priv=json.loads(raw.decode("utf-8"))
    return _unwrap_with_private_obj(priv,capsule,vault_id)
