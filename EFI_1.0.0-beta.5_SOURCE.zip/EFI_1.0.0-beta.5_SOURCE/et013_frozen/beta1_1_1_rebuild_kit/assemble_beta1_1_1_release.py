#!/usr/bin/env python3
from pathlib import Path
import hashlib,shutil,zipfile,json
HERE=Path(__file__).resolve().parent;REL=HERE/'release'/'EntropicFusion_Beta_1_1_1';ZIP=HERE/'release'/'EntropicFusion_Beta_1_1_1.zip'
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def main():
    # Release only after every generated gate says pass.
    for n in ['BETA1_1_1_SOURCE_RESULT.json','BETA1_1_1_FROZEN_RESULT.json','BETA1_1_1_WINDOWS_INTEGRATION_RESULT.json']:
        p=HERE/n
        if not p.is_file(): raise FileNotFoundError(p)
        if not json.loads(p.read_text(encoding='utf-8')).get('all_tests_passed'): raise RuntimeError(f'{n} did not pass')
    desk=HERE/'dist'/'EntropicFusion.exe';host=HERE/'dist'/'EntropicFusionHost.exe'
    if REL.exists():shutil.rmtree(REL)
    REL.mkdir(parents=True)
    shutil.copy2(desk,REL/'EntropicFusion.exe');shutil.copy2(host,REL/'EntropicFusionHost.exe')
    shutil.copy2(HERE/'README_BETA1_1_1_RELEASE.txt',REL/'README.txt');shutil.copy2(HERE/'CHANGELOG_BETA1_1_1.txt',REL/'CHANGELOG.txt')
    provenance={'version':'Entropic Fusion Beta 1.1.1','desktop_exe_sha256':sha(desk),'host_exe_sha256':sha(host),'source_gate':'PASS','frozen_gate':'PASS','windows_integration_gate':'PASS'}
    (REL/'PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
    files=[p for p in REL.iterdir() if p.is_file()];mf=REL/'RELEASE_MANIFEST.sha256.txt';mf.write_text('\n'.join(f'{sha(p)}  {p.name}' for p in sorted(files))+'\n',encoding='utf-8')
    ZIP.parent.mkdir(exist_ok=True)
    if ZIP.exists():ZIP.unlink()
    with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(REL.iterdir()):
            if p.is_file():z.write(p,Path(REL.name)/p.name)
    print('Release ZIP:',ZIP);print('SHA-256:',sha(ZIP))
if __name__=='__main__':main()
