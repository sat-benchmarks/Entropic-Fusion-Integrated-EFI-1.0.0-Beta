#!/usr/bin/env python3
"""
Entropic Vault B.24.4 rekeying compaction.

B.24.3 intentionally never reuses a physical sector. B.24.4 reclaims space
without weakening that invariant by compacting into a NEW .efv vault with:
- fresh random vault_id
- fresh random 256-bit vault master key
- fresh Fusion wrapping capsule for the same recipient public identity

Only the current committed logical filesystem is copied. Superseded/orphaned
physical sectors from the source are not copied.

This is intentionally an out-of-place compactor. It never rewrites free sectors
inside the old vault under the old master key.
"""
from __future__ import annotations

import argparse
import copy
import getpass
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath

import entropic_vault_v0_11B_24_1 as vault
import entropic_vault_manager_v0_11B_24_1 as manager
from entropic_vault_cow_v0_11B_24_3 import EntropicCOWStore, BLOCK_SIZE

VERSION = "0.11B.24.4.1"

def _unlock(private_identity: Path, password: str | None, vault_path: Path):
    if password is None:
        return manager.unlock_fused_vault(private_identity, vault_path)
    return manager.unlock_fused_vault_protected(private_identity, password, vault_path)

def _depth(path: str) -> int:
    return len(PureWindowsPath(path).parts)

def _copy_entry_metadata(dst: EntropicCOWStore, path: str, src_entry: dict):
    fields = {}
    for k in ("attributes", "creation_time", "last_access_time", "last_write_time", "change_time"):
        if k in src_entry:
            fields[k] = int(src_entry[k])
    if fields:
        dst.update_entry(path, **fields)

def compact_vault(
    source_vault: Path,
    destination_vault: Path,
    public_identity: Path,
    private_identity: Path,
    password: str | None,
    *,
    destination_size_bytes: int | None = None,
    label: str = "Entropic Vault",
    chunk_blocks: int = 64,
) -> dict:
    source_vault = Path(source_vault)
    destination_vault = Path(destination_vault)
    public_identity = Path(public_identity)
    private_identity = Path(private_identity)

    if destination_vault.exists():
        raise FileExistsError(destination_vault)
    if source_vault.resolve() == destination_vault.resolve():
        raise ValueError("B.24.4 compaction must be out-of-place")

    old_key, old_unlock = _unlock(private_identity, password, source_vault)
    src = EntropicCOWStore(source_vault, old_key, create_if_blank=False)
    old_header = vault.read_header(source_vault)
    old_stats = src.stats()

    if destination_size_bytes is None:
        destination_size_bytes = int(old_header["sector_count"]) * int(old_header["sector_size"])

    manager.create_fused_vault(
        public_identity, destination_vault, int(destination_size_bytes), label
    )
    new_key, new_unlock = _unlock(private_identity, password, destination_vault)
    dst = EntropicCOWStore(destination_vault, new_key, create_if_blank=True)

    # Recreate directories shallowest-first, excluding root.
    entries = src.list_entries()
    dirs = sorted(
        (p for p, e in entries.items() if p != "\\" and e["kind"] == "dir"),
        key=lambda p: (_depth(p), p.lower()),
    )
    files = sorted(
        (p for p, e in entries.items() if e["kind"] == "file"),
        key=lambda p: p.lower(),
    )

    for p in dirs:
        e = entries[p]
        dst.create_entry(p, "dir", int(e.get("attributes", 0)), int(e.get("creation_time", 0)))
        _copy_entry_metadata(dst, p, e)

    copied_bytes = 0
    chunk_size = max(1, int(chunk_blocks)) * BLOCK_SIZE
    for p in files:
        e = entries[p]
        dst.create_entry(p, "file", int(e.get("attributes", 0)), int(e.get("creation_time", 0)))
        size = int(e.get("size", 0))
        offset = 0
        while offset < size:
            n = min(chunk_size, size - offset)
            data = src.read_file(p, offset, n)
            if len(data) != n:
                raise IOError(f"short source read during compaction: {p} @ {offset}")
            dst.write_file(p, offset, data)
            copied_bytes += len(data)
            offset += len(data)
        _copy_entry_metadata(dst, p, e)

    # Verify destination logical state before returning success.
    dst_entries = dst.list_entries()
    if set(dst_entries) != set(entries):
        raise RuntimeError("destination entry set differs from source")

    for p in files:
        src_e = entries[p]
        dst_e = dst_entries[p]
        if int(src_e.get("size", 0)) != int(dst_e.get("size", 0)):
            raise RuntimeError(f"destination size mismatch: {p}")
        size = int(src_e.get("size", 0))
        h1 = hashlib.sha256()
        h2 = hashlib.sha256()
        off = 0
        while off < size:
            n = min(chunk_size, size - off)
            h1.update(src.read_file(p, off, n))
            h2.update(dst.read_file(p, off, n))
            off += n
        if h1.digest() != h2.digest():
            raise RuntimeError(f"destination content mismatch: {p}")

    new_header = vault.read_header(destination_vault)
    new_stats = dst.stats()

    if old_key == new_key:
        raise RuntimeError("master key did not rotate")
    if old_header["vault_id_b64"] == new_header["vault_id_b64"]:
        raise RuntimeError("vault id did not rotate")
    if not new_stats["all_written_sectors_generation_one"]:
        raise RuntimeError("new vault violated generation-one invariant")

    report = {
        "version": VERSION,
        "source": {
            "vault_id_b64": old_header["vault_id_b64"],
            "logical_size_bytes": int(old_header["sector_count"]) * int(old_header["sector_size"]),
            "stats": old_stats,
            "entry_count": len(entries),
        },
        "destination": {
            "vault_id_b64": new_header["vault_id_b64"],
            "logical_size_bytes": int(new_header["sector_count"]) * int(new_header["sector_size"]),
            "stats": new_stats,
            "entry_count": len(dst_entries),
        },
        "security": {
            "fresh_master_key": old_key != new_key,
            "fresh_vault_id": old_header["vault_id_b64"] != new_header["vault_id_b64"],
            "destination_generation_one_invariant": new_stats["all_written_sectors_generation_one"],
            "out_of_place": True,
            "old_physical_sectors_reused": False,
        },
        "fusion": {
            "source_mode": old_unlock.get("fusion_mode"),
            "destination_mode": new_unlock.get("fusion_mode"),
            "source_ef_equations": old_unlock.get("ef_equations_verified"),
            "destination_ef_equations": new_unlock.get("ef_equations_verified"),
        },
        "copied_live_bytes": copied_bytes,
        "logical_verification": "PASS",
    }
    return report

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source_vault")
    ap.add_argument("destination_vault")
    ap.add_argument("public_identity")
    ap.add_argument("private_identity")
    ap.add_argument("--raw-private", action="store_true")
    ap.add_argument("--size-mib", type=int, default=None)
    ap.add_argument("--label", default="Entropic Vault")
    args = ap.parse_args()
    password = None if args.raw_private else getpass.getpass("Private vault password: ")
    size = None if args.size_mib is None else args.size_mib * 1024 * 1024
    report = compact_vault(
        Path(args.source_vault),
        Path(args.destination_vault),
        Path(args.public_identity),
        Path(args.private_identity),
        password,
        destination_size_bytes=size,
        label=args.label,
    )
    print(json.dumps(report, indent=2))
    Path("B24_4_COMPACTION_RESULT.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )

if __name__ == "__main__":
    main()
