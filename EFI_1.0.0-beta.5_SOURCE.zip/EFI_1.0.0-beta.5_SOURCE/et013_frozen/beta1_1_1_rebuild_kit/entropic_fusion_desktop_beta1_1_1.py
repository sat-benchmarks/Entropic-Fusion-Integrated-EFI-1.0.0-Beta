#!/usr/bin/env python3
"""
Entropic Fusion Desktop v0.11B.24.14

Product-facing Windows desktop application built on the validated B.24.13.6
release line.

No cryptographic composition or vault-format changes are introduced here.
"""
from __future__ import annotations

import json
import os
import sys
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

from entropic_fusion_gui_beta1_1_1 import PrettyApp, VERSION as GUI_VERSION, friendly_mount_error
from entropic_mount_host_aclpipe_client_beta1_1_1 import discover_hosts, VERSION as CLIENT_VERSION

VERSION = "Beta 1.1.1"
STORAGE_BASELINE = "B.24.10"
PORTABLE_BASELINE = "B.24.11"
FROZEN_BASELINE = "B.24.12"
RELEASE_BASELINE = "B.24.13.6"

NAVY = "#101828"
INK = "#172033"
MUTED = "#667085"
BG = "#F4F7FB"
PANEL = "#FFFFFF"
ACCENT = "#1877F2"
SUCCESS = "#15803D"
DANGER = "#B42318"
BORDER = "#D8E0EA"

WINDOW_DEFAULT_W = 1180
WINDOW_DEFAULT_H = 750
WINDOW_MIN_W = 760
WINDOW_MIN_H = 520

def fit_window_to_work_area(work_w: int, work_h: int, saved_w: int | None = None, saved_h: int | None = None) -> tuple[int, int]:
    """Return a sensible initial client size for the available monitor work area."""
    work_w = max(640, int(work_w))
    work_h = max(480, int(work_h))

    target_w = int(saved_w or WINDOW_DEFAULT_W)
    target_h = int(saved_h or WINDOW_DEFAULT_H)

    # Leave visible breathing room around the application. This is especially
    # important on laptops and mixed-DPI multi-monitor setups.
    max_w = max(WINDOW_MIN_W, int(work_w * 0.90))
    max_h = max(WINDOW_MIN_H, int(work_h * 0.88))

    width = min(target_w, max_w)
    height = min(target_h, max_h)

    # Never request a minimum larger than the usable work area.
    width = min(max(WINDOW_MIN_W, width), max(320, work_w - 16))
    height = min(max(WINDOW_MIN_H, height), max(320, work_h - 16))
    return int(width), int(height)


def frozen_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent

def about_text() -> str:
    return (
        f"Entropic Fusion {VERSION}\n"
        "Desktop application\n"
        f"Storage baseline: {STORAGE_BASELINE}\n"
        f"Portable key baseline: {PORTABLE_BASELINE}\n"
        f"Frozen Windows baseline: {FROZEN_BASELINE}\n"
        f"Validated release baseline: {RELEASE_BASELINE}"
    )

def build_info() -> dict:
    from entropic_error_policy_beta1_1_1 import VERSION as error_policy_version
    from entropic_vault_path_beta1_1_1 import VERSION as path_version
    return {
        "desktop_version": VERSION,
        "gui_version": GUI_VERSION,
        "client_version": CLIENT_VERSION,
        "error_policy_version": error_policy_version,
        "path_version": path_version,
    }

def self_check() -> dict:
    root = frozen_root()
    host = root / "EntropicFusionHost.exe"
    if not getattr(sys, "frozen", False):
        host_ok = (root / "entropic_mount_host_aclpipe_beta1_1_1.py").exists()
    else:
        host_ok = host.exists()

    winfsp = False
    if os.name == "nt":
        candidates = [
            Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "WinFsp",
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "WinFsp",
        ]
        winfsp = any(p.exists() for p in candidates)

    return {
        "version": VERSION,
        "windows": os.name == "nt",
        "host_present": host_ok,
        "winfsp_present": winfsp,
        "release_baseline": RELEASE_BASELINE,
        "ready": bool(host_ok and (winfsp if os.name == "nt" else True)),
    }

class DesktopApp(PrettyApp):
    def __init__(self):
        super().__init__()
        self.withdraw()
        self.title("Entropic Fusion")
        self.resizable(True, True)
        self.minsize(WINDOW_MIN_W, WINDOW_MIN_H)
        self._install_menu()
        self._install_home_tab()
        self._apply_adaptive_window_geometry()
        self._refresh_home_status()
        self.after(1200, self._refresh_home_status)
        self.deiconify()
        self.lift()

    def _monitor_work_area(self):
        """Return (left, top, right, bottom) for the monitor nearest this window."""
        self.update_idletasks()
        if os.name == "nt":
            try:
                import ctypes
                from ctypes import wintypes

                MONITOR_DEFAULTTONEAREST = 2

                class RECT(ctypes.Structure):
                    _fields_ = [
                        ("left", wintypes.LONG), ("top", wintypes.LONG),
                        ("right", wintypes.LONG), ("bottom", wintypes.LONG),
                    ]

                class MONITORINFO(ctypes.Structure):
                    _fields_ = [
                        ("cbSize", wintypes.DWORD),
                        ("rcMonitor", RECT),
                        ("rcWork", RECT),
                        ("dwFlags", wintypes.DWORD),
                    ]

                user32 = ctypes.WinDLL("user32", use_last_error=True)
                user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
                user32.MonitorFromWindow.restype = wintypes.HANDLE
                user32.GetMonitorInfoW.argtypes = [wintypes.HANDLE, ctypes.POINTER(MONITORINFO)]
                user32.GetMonitorInfoW.restype = wintypes.BOOL

                hwnd = self.winfo_id()
                mon = user32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)
                mi = MONITORINFO()
                mi.cbSize = ctypes.sizeof(MONITORINFO)
                if mon and user32.GetMonitorInfoW(mon, ctypes.byref(mi)):
                    r = mi.rcWork
                    return int(r.left), int(r.top), int(r.right), int(r.bottom)
            except Exception:
                pass

        return 0, 0, int(self.winfo_screenwidth()), int(self.winfo_screenheight())

    def _apply_adaptive_window_geometry(self):
        left, top, right, bottom = self._monitor_work_area()
        work_w = max(320, right - left)
        work_h = max(320, bottom - top)
        width, height = fit_window_to_work_area(work_w, work_h)
        x = left + max(0, (work_w - width) // 2)
        y = top + max(0, (work_h - height) // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")
        self.update_idletasks()

    def _home_mousewheel(self, event):
        try:
            if self.nb.select() != str(self.t_home_outer):
                return
            if event.widget.winfo_toplevel() is not self:
                return
            if not str(event.widget).startswith(str(self.t_home_outer)):
                return
            delta = int(-1 * (event.delta / 120))
            if delta:
                self.home_canvas.yview_scroll(delta, "units")
                return "break"
        except Exception:
            return

    def _home_reflow(self, event=None):
        """Use one card column when the Home tab becomes narrow."""
        try:
            width = self.home_canvas.winfo_width()
            if width < 900:
                self._home_left.grid(row=0, column=0, sticky="nsew", padx=0, pady=(0, 8))
                self._home_right.grid(row=1, column=0, sticky="nsew", padx=0, pady=(0, 0))
                self._home_row.columnconfigure(0, weight=1)
                self._home_row.columnconfigure(1, weight=0)
            else:
                self._home_left.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=0)
                self._home_right.grid(row=0, column=1, sticky="nsew", padx=(6, 0), pady=0)
                self._home_row.columnconfigure(0, weight=1)
                self._home_row.columnconfigure(1, weight=1)
        except Exception:
            pass

    def _configure_style(self):
        super()._configure_style()
        style = ttk.Style(self)
        style.configure(
            "Hero.TLabel",
            background=PANEL,
            foreground=INK,
            font=("Segoe UI Semibold", 25),
        )
        style.configure(
            "HeroSub.TLabel",
            background=PANEL,
            foreground=MUTED,
            font=("Segoe UI", 11),
        )
        style.configure(
            "Metric.TLabel",
            background=PANEL,
            foreground=INK,
            font=("Segoe UI Semibold", 17),
        )
        style.configure(
            "MetricSub.TLabel",
            background=PANEL,
            foreground=MUTED,
            font=("Segoe UI", 9),
        )
        style.configure(
            "Primary.TButton",
            background=ACCENT, foreground="#FFFFFF",
            font=("Segoe UI Semibold", 10), padding=(16, 10), borderwidth=0,
        )
        style.map("Primary.TButton", background=[("active", "#0F66D8"), ("pressed", "#0B57B7")])
        style.configure(
            "Secondary.TButton",
            background="#EEF2F6", foreground=INK,
            font=("Segoe UI Semibold", 10), padding=(14, 10), borderwidth=0,
        )
        style.map("Secondary.TButton", background=[("active", "#E2E8F0")])
        style.configure(
            "CardTitle.TLabel", background=PANEL, foreground=INK,
            font=("Segoe UI Semibold", 13),
        )

    def _install_menu(self):
        menubar = tk.Menu(self)
        filem = tk.Menu(menubar, tearoff=False)
        filem.add_command(label="Mount vault…", command=self._go_mount)
        filem.add_command(label="Create vault…", command=self._go_create_vault)
        filem.add_separator()
        filem.add_command(label="Exit", command=self._on_close)
        menubar.add_cascade(label="File", menu=filem)

        sec = tk.Menu(menubar, tearoff=False)
        sec.add_command(label="Create identity…", command=self._go_identity)
        sec.add_command(label="Encrypt file…", command=self._go_encrypt)
        sec.add_command(label="Decrypt file…", command=self._go_decrypt)
        menubar.add_cascade(label="Security", menu=sec)

        helpm = tk.Menu(menubar, tearoff=False)
        helpm.add_command(label="Quick start", command=self.show_help_dialog)
        helpm.add_command(label="About Entropic Fusion", command=self._show_about)
        menubar.add_cascade(label="Help", menu=helpm)
        self.config(menu=menubar)

    def _install_home_tab(self):
        self.t_home_outer = ttk.Frame(self.nb, style="App.TFrame")
        self.home_canvas = tk.Canvas(self.t_home_outer, background=BG, highlightthickness=0)
        self.home_scroll = ttk.Scrollbar(self.t_home_outer, orient="vertical", command=self.home_canvas.yview)
        self.home_canvas.configure(yscrollcommand=self.home_scroll.set)
        self.home_scroll.pack(side="right", fill="y")
        self.home_canvas.pack(side="left", fill="both", expand=True)

        self.t_home = ttk.Frame(self.home_canvas, style="App.TFrame", padding=16)
        self._home_canvas_window = self.home_canvas.create_window((0, 0), window=self.t_home, anchor="nw")
        self.t_home.bind(
            "<Configure>",
            lambda _e: self.home_canvas.configure(scrollregion=self.home_canvas.bbox("all")),
        )
        self.home_canvas.bind(
            "<Configure>",
            lambda e: (
                self.home_canvas.itemconfigure(self._home_canvas_window, width=e.width),
                self._home_reflow(e),
            ),
        )
        self.bind_all("<MouseWheel>", self._home_mousewheel, add="+")

        self.nb.insert(0, self.t_home_outer, text="Home")
        self.nb.select(self.t_home_outer)

        hero = ttk.Frame(self.t_home, style="Panel.TFrame", padding=(26, 24))
        hero.pack(fill="x", pady=(0, 12))

        ttk.Label(hero, text="Your encrypted workspace", style="Hero.TLabel").pack(anchor="w")
        ttk.Label(
            hero,
            text="Open, create and protect your encrypted vaults from one place.",
            style="HeroSub.TLabel",
        ).pack(anchor="w", pady=(4, 14))

        actions = ttk.Frame(hero, style="Panel.TFrame")
        actions.pack(fill="x")
        ttk.Button(
            actions, text="Open vault", command=self._go_mount, style="Primary.TButton"
        ).pack(side="left", padx=(0, 8))
        ttk.Button(
            actions, text="Create vault", command=self._go_create_vault, style="Secondary.TButton"
        ).pack(side="left", padx=(0, 8))
        ttk.Button(
            actions, text="Create identity", command=self._go_identity, style="Secondary.TButton"
        ).pack(side="left", padx=(0, 8))
        ttk.Button(
            actions, text="Encrypt file", command=self._go_encrypt, style="Secondary.TButton"
        ).pack(side="left")

        row = self._home_row = ttk.Frame(self.t_home, style="App.TFrame")
        row.pack(fill="both", expand=True)
        row.columnconfigure(0, weight=1)
        row.columnconfigure(1, weight=1)

        left = self._home_left = ttk.Frame(row, style="App.TFrame")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        right = self._home_right = ttk.Frame(row, style="App.TFrame")
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))

        status = ttk.Frame(left, style="Panel.TFrame", padding=20)
        status.pack(fill="x", pady=(0, 12))
        ttk.Label(status, text="Your vault", style="CardTitle.TLabel").pack(anchor="w")
        self.home_vault_state = tk.StringVar(value="No vault open")
        self.home_vault_detail = tk.StringVar(value="Choose Open vault to mount an existing Entropic vault.")
        ttk.Label(status, textvariable=self.home_vault_state, style="Metric.TLabel").pack(
            anchor="w", pady=(10, 2)
        )
        ttk.Label(
            status,
            textvariable=self.home_vault_detail,
            style="Body.TLabel",
            wraplength=480,
            justify="left",
        ).pack(anchor="w")
        ttk.Button(
            status, text="Open vault", command=self._go_mount, style="Secondary.TButton"
        ).pack(anchor="w", pady=(12, 0))

        first = ttk.Frame(left, style="Panel.TFrame", padding=20)
        first.pack(fill="x")
        ttk.Label(first, text="First time here?", style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(
            first,
            text=(
                "1. Create your identity\n"
                "2. Create a vault\n"
                "3. Open it as a Windows drive"
            ),
            style="Body.TLabel",
            justify="left",
        ).pack(anchor="w", pady=(8, 10))
        ttk.Button(
            first, text="Create identity", command=self._go_identity, style="Primary.TButton"
        ).pack(anchor="w")

        secure = ttk.Frame(right, style="Panel.TFrame", padding=20)
        secure.pack(fill="x", pady=(0, 12))
        ttk.Label(secure, text="Protected by Entropic Fusion", style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(
            secure,
            text=(
                "Your vault opens only through the complete Fusion unlock path.\n\n"
                "Vault contents stay encrypted at rest, while your protected identity "
                "remains separate from the vault itself."
            ),
            style="Body.TLabel",
            justify="left",
            wraplength=470,
        ).pack(anchor="w", pady=(8, 0))

        product = ttk.Frame(right, style="Panel.TFrame", padding=20)
        product.pack(fill="x")
        ttk.Label(product, text="System status", style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(product, text="Ready", style="Metric.TLabel").pack(
            anchor="w", pady=(10, 0)
        )
        ttk.Label(
            product,
            text="Host and Windows vault support detected.",
            style="Body.TLabel",
            justify="left",
        ).pack(anchor="w", pady=(3, 10))
        ttk.Button(
            product, text="Run system check", command=self._go_self_test, style="Secondary.TButton"
        ).pack(anchor="w")


    def _polish_header_controls(self):
        try:
            self._polish_widget_tree(self)
        except Exception:
            pass

    def _polish_widget_tree(self, widget):
        try:
            txt = widget.cget("text")
        except Exception:
            txt = None
        if txt == "Ready":
            try: widget.configure(text="System ready")
            except Exception: pass
        elif txt == "?":
            try: widget.configure(text="Help")
            except Exception: pass
        try:
            for child in widget.winfo_children():
                self._polish_widget_tree(child)
        except Exception:
            pass

    def _refresh_home_status(self):
        try:
            hosts = discover_hosts()
            if hosts:
                h = hosts[0]
                drive = h.get("drive", "")
                eq = h.get("ef_equations_verified", "")
                self.home_vault_state.set(f"Mounted as {drive}")
                detail = "Fusion active"
                if eq not in ("", None):
                    detail += f" • {eq} live EF equations"
                self.home_vault_detail.set(detail)
            else:
                self.home_vault_state.set("No vault open")
                self.home_vault_detail.set("Choose Open vault to mount an existing Entropic vault.")
        except Exception:
            self.home_vault_state.set("Status unavailable")
            self.home_vault_detail.set("Open the Vault workspace to inspect the current state.")
        if self.winfo_exists():
            self.after(2500, self._refresh_home_status)

    def _go_mount(self):
        self.nb.select(self.t_vault_outer)
        try:
            self.mount_btn.focus_set()
        except Exception:
            pass

    def _go_create_vault(self):
        self.nb.select(self.t_vault_outer)

    def _go_identity(self):
        self.nb.select(self.t_id)

    def _go_encrypt(self):
        self.nb.select(self.t_enc)

    def _go_decrypt(self):
        self.nb.select(self.t_dec)

    def _go_self_test(self):
        self.nb.select(self.t_test)

    def _show_about(self):
        messagebox.showinfo("About Entropic Fusion", about_text(), parent=self)

if __name__ == "__main__":
    if "--build-info-json" in sys.argv:
        idx=sys.argv.index("--build-info-json")
        if idx+1>=len(sys.argv): raise SystemExit(2)
        Path(sys.argv[idx+1]).write_text(json.dumps(build_info(),indent=2)+"\n",encoding="utf-8")
        raise SystemExit(0)
    if "--error-policy-probe" in sys.argv:
        idx=sys.argv.index("--error-policy-probe")
        if idx+1>=len(sys.argv): raise SystemExit(2)
        synthetic='Traceback (most recent call last):\n  File "internal.py", line 99\nRuntimeError: secret internal detail'
        msg=friendly_mount_error(RuntimeError(synthetic))
        Path(sys.argv[idx+1]).write_text(json.dumps({"version":VERSION,"message":msg},indent=2)+"\n",encoding="utf-8")
        raise SystemExit(0)
    if "--ui-geometry-probe" in sys.argv:
        idx = sys.argv.index("--ui-geometry-probe")
        if idx + 1 >= len(sys.argv):
            raise SystemExit(2)
        out_path = Path(sys.argv[idx + 1])
        app = DesktopApp()
        app.update_idletasks()
        l, t, r, b = app._monitor_work_area()
        result = {
            "version": VERSION,
            "geometry": app.geometry(),
            "x": app.winfo_x(),
            "y": app.winfo_y(),
            "width": app.winfo_width(),
            "height": app.winfo_height(),
            "min_width": app.minsize()[0],
            "min_height": app.minsize()[1],
            "work_area": [l, t, r, b],
            "home_scrollable": hasattr(app, "home_canvas") and hasattr(app, "home_scroll"),
            "home_outer_selected": app.nb.select() == str(app.t_home_outer),
        }
        out_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        app.destroy()
        raise SystemExit(0)
    if "--about" in sys.argv:
        print(about_text())
        raise SystemExit(0)
    if "--self-check" in sys.argv:
        result = self_check()
        print(json.dumps(result, indent=2))
        raise SystemExit(0 if result["ready"] else 1)
    DesktopApp().mainloop()
