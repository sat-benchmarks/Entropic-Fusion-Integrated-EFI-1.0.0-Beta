#!/usr/bin/env python3
"""
AES-256-GCM adapter for Entropic Fusion B.15.

Requires the Python 'cryptography' package.
The key supplied to this module should come from
entropic_fusion_hybrid_combiner_v0_11B_22_9.py.
"""
from __future__ import annotations
import argparse, json, os
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def encrypt(key: bytes, plaintext: bytes, aad: bytes) -> dict:
    if len(key) != 32:
        raise ValueError("AES-256-GCM requires a 32-byte key")
    nonce = os.urandom(12)
    ct = AESGCM(key).encrypt(nonce, plaintext, aad)
    return {"nonce_hex": nonce.hex(), "ciphertext_hex": ct.hex()}


def decrypt(key: bytes, nonce: bytes, ciphertext: bytes, aad: bytes) -> bytes:
    if len(key) != 32:
        raise ValueError("AES-256-GCM requires a 32-byte key")
    return AESGCM(key).decrypt(nonce, ciphertext, aad)


def self_test():
    key = bytes(range(32))
    aad = b"EF-B15-AAD"
    msg = b"Entropic Fusion B.15 AES-GCM regression vector"
    row = encrypt(key, msg, aad)
    recovered = decrypt(key, bytes.fromhex(row["nonce_hex"]),
                        bytes.fromhex(row["ciphertext_hex"]), aad)
    tamper_rejected = False
    bad = bytearray.fromhex(row["ciphertext_hex"])
    bad[-1] ^= 1
    try:
        decrypt(key, bytes.fromhex(row["nonce_hex"]), bytes(bad), aad)
    except Exception:
        tamper_rejected = True
    result = {
        "round_trip": recovered == msg,
        "tamper_rejected": tamper_rejected,
        "nonce_bytes": len(bytes.fromhex(row["nonce_hex"])),
        "key_bytes": len(key),
    }
    print(json.dumps(result, indent=2))
    if not (result["round_trip"] and result["tamper_rejected"]):
        raise SystemExit(1)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--self-test", action="store_true")
    a = ap.parse_args()
    if a.self_test:
        self_test()
