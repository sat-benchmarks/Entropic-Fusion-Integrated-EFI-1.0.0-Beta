#!/usr/bin/env python3
"""Entropic Fusion v0.11B.22 hardened desktop GUI."""
from __future__ import annotations
import hashlib, json, os, tempfile, threading, time, tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

import entropic_fusion_cli_v0_11B_23_1 as core
from entropic_fusion_public_identity_v0_11B_23_1 import generate_identity, load_public, load_private
from entropic_fusion_release_utils_v0_11B_23_1 import display_fingerprint, verify_vault, best_effort_remove
from entropic_fusion_private_vault_v0_11B_23_1 import (
    protect_private_identity, unprotect_private_identity, is_protected_private_identity
)

VERSION = "0.11B.23.1"

def fingerprint(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def human_size(n: int) -> str:
    for unit in ("B","KB","MB","GB","TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f} {unit}" if isinstance(n, float) else f"{n} {unit}"
        n = n / 1024

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Entropic Fusion {VERSION}")
        self.geometry("1080x760")
        self.minsize(930, 660)
        self.status_var = tk.StringVar(value="Ready")
        self._build()

    def ask_password_pair(self, title="Private vault password", prompt="Choose a password (minimum 10 characters):"):
        """Single modal password dialog with confirmation fields, kept above the main GUI."""
        win = tk.Toplevel(self)
        win.title(title)
        win.transient(self)
        win.grab_set()
        win.resizable(False, False)

        ttk.Label(win, text=prompt, padding=(14,14,14,6)).grid(row=0,column=0,columnspan=2,sticky="w")
        ttk.Label(win, text="Password:", padding=(14,4,8,4)).grid(row=1,column=0,sticky="e")
        ttk.Label(win, text="Confirm:", padding=(14,4,8,4)).grid(row=2,column=0,sticky="e")

        p1=tk.StringVar(); p2=tk.StringVar()
        e1=ttk.Entry(win,textvariable=p1,show="*",width=34)
        e2=ttk.Entry(win,textvariable=p2,show="*",width=34)
        e1.grid(row=1,column=1,padx=(0,14),pady=4)
        e2.grid(row=2,column=1,padx=(0,14),pady=4)

        result={"value":None}
        err=tk.StringVar(value="")
        ttk.Label(win,textvariable=err,padding=(14,4,14,4)).grid(row=3,column=0,columnspan=2,sticky="w")

        def ok():
            if len(p1.get()) < 10:
                err.set("Password must be at least 10 characters.")
                return
            if p1.get() != p2.get():
                err.set("Passwords do not match.")
                return
            result["value"]=p1.get()
            win.destroy()

        def cancel():
            result["value"]=None
            win.destroy()

        bf=ttk.Frame(win,padding=(14,6,14,14)); bf.grid(row=4,column=0,columnspan=2,sticky="e")
        ttk.Button(bf,text="Cancel",command=cancel).pack(side="right",padx=(6,0))
        ttk.Button(bf,text="OK",command=ok).pack(side="right")

        win.protocol("WM_DELETE_WINDOW",cancel)
        win.bind("<Return>",lambda _e:ok())
        win.bind("<Escape>",lambda _e:cancel())

        self.update_idletasks()
        win.update_idletasks()
        x=self.winfo_rootx()+max(40,(self.winfo_width()-win.winfo_width())//2)
        y=self.winfo_rooty()+max(40,(self.winfo_height()-win.winfo_height())//3)
        win.geometry(f"+{x}+{y}")
        win.lift()
        win.attributes("-topmost", True)
        win.after(150, lambda: win.attributes("-topmost", False))
        e1.focus_set()
        self.wait_window(win)
        return result["value"]

    def ask_password_once(self, title="Private identity password", prompt="Enter password:"):
        """Single modal password entry kept above the main GUI."""
        win=tk.Toplevel(self)
        win.title(title)
        win.transient(self)
        win.grab_set()
        win.resizable(False,False)
        ttk.Label(win,text=prompt,padding=(14,14,14,6)).pack(anchor="w")
        value=tk.StringVar()
        entry=ttk.Entry(win,textvariable=value,show="*",width=34)
        entry.pack(padx=14,pady=(0,8))
        result={"value":None}
        bf=ttk.Frame(win,padding=(14,4,14,14)); bf.pack(fill="x")
        def ok():
            result["value"]=value.get()
            win.destroy()
        def cancel():
            result["value"]=None
            win.destroy()
        ttk.Button(bf,text="Cancel",command=cancel).pack(side="right",padx=(6,0))
        ttk.Button(bf,text="OK",command=ok).pack(side="right")
        win.protocol("WM_DELETE_WINDOW",cancel)
        win.bind("<Return>",lambda _e:ok())
        win.bind("<Escape>",lambda _e:cancel())
        self.update_idletasks(); win.update_idletasks()
        x=self.winfo_rootx()+max(40,(self.winfo_width()-win.winfo_width())//2)
        y=self.winfo_rooty()+max(40,(self.winfo_height()-win.winfo_height())//3)
        win.geometry(f"+{x}+{y}")
        win.lift()
        win.attributes("-topmost", True)
        win.after(150, lambda: win.attributes("-topmost", False))
        entry.focus_set()
        self.wait_window(win)
        return result["value"]

    def show_help_dialog(self):
        """Compact on-screen instructions opened by the ? button."""
        win=tk.Toplevel(self)
        win.title("Entropic Fusion - Quick Start")
        win.transient(self)
        win.geometry("680x620")
        win.minsize(560,500)

        text="""CREATE AN IDENTITY

• Identity tab: choose locations for .efpub, .efpriv and .efprivx.
• Create a strong password.
• Share ONLY the .efpub file.

ENCRYPT

• Choose the recipient .efpub.
• Choose the file to encrypt.
• Choose where to save the .efb file.
• Confirm the recipient fingerprint and click Encrypt.

DECRYPT

• Choose your .efprivx vault (preferred) or .efpriv.
• Choose the .efb file.
• Choose the destination FOLDER only.
• The exact original filename is restored automatically.

FILE TYPES

.efpub   Public identity, safe to share.
.efpriv  Raw private identity, keep secret.
.efprivx Password-protected private vault.
.efb     Encrypted Entropic Fusion file.

IMPORTANT

Keep a secure backup of your private identity. If it is lost, encrypted files cannot be recovered.

If the original filename already exists in the destination folder, Entropic Fusion asks before overwriting it.
"""
        box=tk.Text(win,wrap="word",padx=14,pady=14,font=("Segoe UI",10))
        box.pack(fill="both",expand=True)
        box.insert("1.0",text)
        box.configure(state="disabled")
        ttk.Button(win,text="Close",command=win.destroy).pack(pady=(0,12))
        win.lift()
        win.attributes("-topmost", True)
        win.after(150, lambda: win.attributes("-topmost", False))

    def _build(self):
        root = ttk.Frame(self, padding=12); root.pack(fill="both", expand=True)
        titlebar=ttk.Frame(root); titlebar.pack(fill="x")
        ttk.Label(titlebar, text=f"Entropic Fusion {VERSION}", font=("Segoe UI", 20, "bold")).pack(side="left",anchor="w")
        ttk.Button(titlebar,text="?",width=3,command=self.show_help_dialog).pack(side="right")
        ttk.Label(root, text="FUSED public-recipient encryption: live EF relation + ML-KEM-768 + ML-KEM-1024 + AES-256-GCM").pack(anchor="w", pady=(0,8))
        nb = ttk.Notebook(root); nb.pack(fill="both", expand=True)
        self.t_id=ttk.Frame(nb,padding=12); self.t_enc=ttk.Frame(nb,padding=12); self.t_dec=ttk.Frame(nb,padding=12)
        self.t_keys=ttk.Frame(nb,padding=12); self.t_test=ttk.Frame(nb,padding=12); self.t_log=ttk.Frame(nb,padding=12)
        self.t_help=ttk.Frame(nb,padding=12)
        for tab, name in [(self.t_id,"Identity"),(self.t_enc,"Encrypt"),(self.t_dec,"Decrypt"),(self.t_keys,"Key tools"),(self.t_test,"Self-test"),(self.t_log,"Activity"),(self.t_help,"Help / Quick Start")]:
            nb.add(tab,text=name)
        self._identity(); self._encrypt(); self._decrypt(); self._keytools(); self._test(); self._activity(); self._help()
        ttk.Separator(root).pack(fill="x", pady=(8,5))
        ttk.Label(root, textvariable=self.status_var).pack(anchor="w")
        ttk.Label(root, text="B.22 hardening: public/private workflow preserved; optional password-protected .efprivx vaults, fingerprints, validation, safer overwrite handling, and a release build script added. Independent Entropic hardness remains a separate research claim.", wraplength=1020).pack(anchor="w", pady=(5,0))

    def log(self, msg: str):
        ts = time.strftime("%H:%M:%S")
        line = f"[{ts}] {msg}\n"
        try:
            self.logbox.insert("end", line); self.logbox.see("end")
        except Exception:
            pass

    def set_status(self, s: str):
        self.status_var.set(s); self.update_idletasks()

    def _row(self,parent,label,var,save=False,ext=None):
        f=ttk.Frame(parent); f.pack(fill="x",pady=4)
        ttk.Label(f,text=label,width=26).pack(side="left")
        ttk.Entry(f,textvariable=var).pack(side="left",fill="x",expand=True,padx=6)
        def choose():
            if save:
                opts = {"defaultextension": ext} if ext else {}
                p=filedialog.asksaveasfilename(**opts)
            else:
                p=filedialog.askopenfilename()
            if p: var.set(p)
        ttk.Button(f,text="Browse",command=choose).pack(side="left")

    def _run(self, label, fn, done):
        self.set_status(label); self.log(label)
        def worker():
            try:
                r = fn()
                self.after(0, lambda result=r: done(result, None))
            except Exception as e:
                self.after(0, lambda err=e: done(None, err))
        threading.Thread(target=worker,daemon=True).start()

    def _confirm_overwrite(self, p: Path) -> bool:
        if p.exists():
            return messagebox.askyesno("Overwrite?", f"{p.name} already exists.\n\nReplace it?")
        return True

    def _identity(self):
        ttk.Label(self.t_id,text="Create recipient identity",font=("Segoe UI",12,"bold")).pack(anchor="w")
        ttk.Label(self.t_id,text="1. Choose where to save the identity files.  2. Create a strong vault password.  3. Share ONLY the .efpub file.",wraplength=930).pack(anchor="w",pady=(2,8))
        ttk.Label(self.t_id,text="Share the .efpub file. Protect the private identity with a password before normal use.").pack(anchor="w",pady=(0,8))
        self.id_pub=tk.StringVar(value="recipient.efpub")
        self.id_priv=tk.StringVar(value="recipient.efpriv")
        self.id_vault=tk.StringVar(value="recipient.efprivx")
        self.id_seed=tk.StringVar(value="20270851"); self.id_path=tk.StringVar(value="6"); self.id_decoys=tk.StringVar(value="64")
        self._row(self.t_id,"Public identity (.efpub)",self.id_pub,True,".efpub")
        self._row(self.t_id,"Raw private identity (.efpriv)",self.id_priv,True,".efpriv")
        self._row(self.t_id,"Protected private vault (.efprivx)",self.id_vault,True,".efprivx")
        f=ttk.Frame(self.t_id); f.pack(fill="x",pady=6)
        for lab,var,w in [("Seed",self.id_seed,14),("Path",self.id_path,7),("Decoys",self.id_decoys,7)]:
            ttk.Label(f,text=lab).pack(side="left",padx=(0,4)); ttk.Entry(f,textvariable=var,width=w).pack(side="left",padx=(0,18))
        ttk.Button(self.t_id,text="Generate + protect identity",command=self.do_id).pack(anchor="w",pady=8)
        self.id_detail=tk.Text(self.t_id,height=12,wrap="word"); self.id_detail.pack(fill="both",expand=True)

    def do_id(self):
        pub, priv, vault = Path(self.id_pub.get()), Path(self.id_priv.get()), Path(self.id_vault.get())
        if not all([str(pub),str(priv),str(vault)]): return messagebox.showerror("Identity","Choose all three identity paths.")
        for p in (pub,priv,vault):
            if not self._confirm_overwrite(p): return
        pw = self.ask_password_pair(
            "Protect private identity",
            "Choose a password for the .efprivx vault (minimum 10 characters):"
        )
        if pw is None: return
        def job():
            r=generate_identity(pub,priv,seed=int(self.id_seed.get()),path_length=int(self.id_path.get()),decoys=int(self.id_decoys.get()))
            v=protect_private_identity(priv,vault,pw)
            return r,v
        def done(rv,e):
            if e:
                self.set_status("Identity generation failed"); self.log(f"ERROR identity: {e}"); return messagebox.showerror("Identity",str(e))
            r,v=rv
            try: os.chmod(priv,0o600)
            except Exception: pass
            detail = {
                "public_fingerprint_sha256": fingerprint(pub),
                "public_fingerprint_display": display_fingerprint(pub),
                "protected_private_vault_sha256": fingerprint(vault),
                "public_identity_sha256": r.get("public_identity_sha256"),
                "branch_kem": "ML-KEM-1024",
                "outer_kem": "ML-KEM-768",
                "private_vault": v,
                "warning": "The raw .efpriv file still exists. Store it securely or delete it after verifying the .efprivx vault."
            }
            self.id_detail.delete("1.0","end"); self.id_detail.insert("end",json.dumps(detail,indent=2))
            self.set_status("Identity ready"); self.log("Identity generated and password-protected vault created.")
        self._run("Generating PQ identity and protected private vault...",job,done)

    def _encrypt(self):
        ttk.Label(self.t_enc,text="Encrypt for a recipient",font=("Segoe UI",12,"bold")).pack(anchor="w")
        ttk.Label(self.t_enc,text="Choose the recipient .efpub file, choose the file to protect, choose an .efb output location, confirm the fingerprint, then Encrypt.",wraplength=930).pack(anchor="w",pady=(2,8))
        ttk.Label(self.t_enc,text="Only the recipient's public .efpub identity is required.").pack(anchor="w",pady=(0,8))
        self.e_rec=tk.StringVar(); self.e_in=tk.StringVar(); self.e_out=tk.StringVar()
        self._row(self.t_enc,"Recipient public identity",self.e_rec)
        self._row(self.t_enc,"Input file",self.e_in)
        self._row(self.t_enc,"Encrypted output (.efb)",self.e_out,True,".efb")
        ttk.Button(self.t_enc,text="Validate recipient key",command=self.validate_pub).pack(anchor="w",pady=(6,2))
        ttk.Button(self.t_enc,text="Encrypt",command=self.do_enc).pack(anchor="w",pady=6)
        self.e_detail=tk.Text(self.t_enc,height=13,wrap="word"); self.e_detail.pack(fill="both",expand=True)

    def validate_pub(self):
        try:
            p=Path(self.e_rec.get()); obj=load_public(p)
            info={"file_sha256":fingerprint(p),"public_identity_sha256":obj.get("public_identity_sha256"),"fused_inner_kem":obj.get("fused_inner_kem"),"valid":True}
            self.e_detail.delete("1.0","end"); self.e_detail.insert("end",json.dumps(info,indent=2)); self.log("Recipient public identity validated.")
        except Exception as e:
            messagebox.showerror("Public key",str(e)); self.log(f"ERROR public validation: {e}")

    def do_enc(self):
        rec, src, out = Path(self.e_rec.get()),Path(self.e_in.get()),Path(self.e_out.get())
        if not self._confirm_overwrite(out): return
        def done(r,e):
            if e: self.set_status("Encryption failed"); self.log(f"ERROR encrypt: {e}"); return messagebox.showerror("Encrypt",str(e))
            self.e_detail.delete("1.0","end"); self.e_detail.insert("end",json.dumps(r,indent=2))
            self.set_status("Encryption complete"); self.log(f"Encrypted {src.name} -> {out.name}")
        try:
            fpr = display_fingerprint(rec)
        except Exception as e:
            return messagebox.showerror("Encrypt", f"Cannot fingerprint recipient key: {e}")
        if not messagebox.askyesno("Confirm recipient", f"Encrypt to this recipient fingerprint?\n\n{fpr}"):
            return
        self._run("Encrypting...",lambda:core.encrypt_file(rec,src,out),done)

    def _decrypt(self):
        ttk.Label(self.t_dec,text="Decrypt with private identity",font=("Segoe UI",12,"bold")).pack(anchor="w")
        ttk.Label(self.t_dec,text="Choose your .efprivx vault (preferred) or .efpriv, choose the encrypted .efb, then choose only the destination folder. The original filename is restored automatically.",wraplength=930).pack(anchor="w",pady=(2,8))
        ttk.Label(self.t_dec,text="Use either a raw .efpriv file or a password-protected .efprivx vault.").pack(anchor="w",pady=(0,8))
        self.d_id=tk.StringVar(); self.d_in=tk.StringVar(); self.d_out=tk.StringVar()
        self._row(self.t_dec,"Private identity / vault",self.d_id)
        self._row(self.t_dec,"Encrypted input (.efb)",self.d_in)
        f=ttk.Frame(self.t_dec); f.pack(fill="x",pady=4)
        ttk.Label(f,text="Destination folder",width=26).pack(side="left")
        ttk.Entry(f,textvariable=self.d_out).pack(side="left",fill="x",expand=True,padx=6)
        def choose_dest_folder():
            p=filedialog.askdirectory()
            if p: self.d_out.set(p)
        ttk.Button(f,text="Browse",command=choose_dest_folder).pack(side="left")
        ttk.Label(self.t_dec,text="The recovered filename is locked to the original authenticated filename stored inside the .efb container.",wraplength=900).pack(anchor="w",pady=(2,6))
        ttk.Button(self.t_dec,text="Decrypt",command=self.do_dec).pack(anchor="w",pady=8)
        self.d_detail=tk.Text(self.t_dec,height=13,wrap="word"); self.d_detail.pack(fill="both",expand=True)

    def do_dec(self):
        ident, src, folder = Path(self.d_id.get()),Path(self.d_in.get()),Path(self.d_out.get())
        if not ident.exists() or not src.exists():
            return messagebox.showerror("Decrypt","Choose an existing private identity and encrypted .efb file.")
        if not folder.exists() or not folder.is_dir():
            return messagebox.showerror("Decrypt","Choose an existing destination folder.")
        try:
            original_name = core.original_name_from_box(src)
            out = folder / original_name
        except Exception as e:
            return messagebox.showerror("Decrypt",f"Cannot read original filename from container: {e}")
        if not self._confirm_overwrite(out): return
        password = None
        protected = is_protected_private_identity(ident)
        if protected:
            password = self.ask_password_once("Private identity password","Enter password:")
            if password is None: return
        def job():
            if protected:
                raw = unprotect_private_identity(ident,password)
                return core.decrypt_file_with_private_bytes_to_folder(raw,src,folder)
            return core.decrypt_file_to_folder(ident,src,folder)
        def done(r,e):
            if e:
                self.set_status("Decryption failed"); self.log(f"ERROR decrypt: {e}")
                return messagebox.showerror("Decrypt",str(e))
            self.d_detail.delete("1.0","end"); self.d_detail.insert("end",json.dumps(r,indent=2))
            self.set_status("Decryption complete")
            self.log(f"Decrypted {src.name} -> {original_name}")
            messagebox.showinfo("Decryption complete",f"Recovered as:\n\n{original_name}\n\nin:\n{folder}")
        self._run("Decrypting...",job,done)

    def _keytools(self):
        ttk.Label(self.t_keys,text="Key inspection and protection",font=("Segoe UI",12,"bold")).pack(anchor="w")
        self.k_path=tk.StringVar()
        self._row(self.t_keys,"Identity file",self.k_path)
        f=ttk.Frame(self.t_keys); f.pack(fill="x",pady=8)
        ttk.Button(f,text="Fingerprint / inspect",command=self.inspect_key).pack(side="left",padx=(0,6))
        ttk.Button(f,text="Protect raw .efpriv",command=self.protect_existing).pack(side="left")
        self.k_detail=tk.Text(self.t_keys,height=22,wrap="word"); self.k_detail.pack(fill="both",expand=True)

    def inspect_key(self):
        try:
            p=Path(self.k_path.get())
            info={"file":str(p),"size_bytes":p.stat().st_size,"sha256":fingerprint(p),"protected_private_vault":is_protected_private_identity(p)}
            if p.suffix.lower()==".efpub":
                q=load_public(p); info.update({"type":"public","public_identity_sha256":q.get("public_identity_sha256"),"fused_inner_kem":q.get("fused_inner_kem")})
            elif p.suffix.lower()==".efpriv":
                q=load_private(p); info.update({"type":"private","public_identity_sha256":q["public_identity"].get("public_identity_sha256")})
            elif p.suffix.lower()==".efprivx":
                info.update({"type":"password-protected private vault"})
            self.k_detail.delete("1.0","end"); self.k_detail.insert("end",json.dumps(info,indent=2)); self.log(f"Inspected {p.name}")
        except Exception as e:
            messagebox.showerror("Key tools",str(e)); self.log(f"ERROR inspect: {e}")

    def protect_existing(self):
        src=Path(self.k_path.get())
        if not src.exists(): return messagebox.showerror("Protect","Choose an existing raw .efpriv file.")
        dst=Path(filedialog.asksaveasfilename(defaultextension=".efprivx",initialfile=src.stem+".efprivx"))
        if not str(dst): return
        if not self._confirm_overwrite(dst): return
        pw=self.ask_password_pair("Protect private identity","Choose a password (minimum 10 characters):")
        if pw is None:return
        try:
            r=protect_private_identity(src,dst,pw)
            self.k_detail.delete("1.0","end"); self.k_detail.insert("end",json.dumps({"result":r,"vault_sha256":fingerprint(dst)},indent=2))
            self.log(f"Protected {src.name} -> {dst.name}")
        except Exception as e:
            messagebox.showerror("Protect",str(e)); self.log(f"ERROR protect: {e}")

    def _test(self):
        ttk.Label(self.t_test,text="Runs the B.23 fused workflow, including live EF-relation mutation tests and private-vault tests.",wraplength=900).pack(anchor="w")
        ttk.Button(self.t_test,text="Run B.23 fusion self-test",command=self.do_test).pack(anchor="w",pady=8)
        self.test=tk.Text(self.t_test,height=26,wrap="word"); self.test.pack(fill="both",expand=True)

    def do_test(self):
        self.test.delete("1.0","end"); self.test.insert("end","Running B.23 fusion self-test...\n")
        def job():
            result=core.self_test()
            import tempfile as _tf
            with _tf.TemporaryDirectory(prefix="ef_b21_vault_") as td:
                td=Path(td)
                pub=td/"a.efpub"; priv=td/"a.efpriv"; vault=td/"a.efprivx"
                generate_identity(pub,priv,seed=20270891)
                pw="CorrectHorseBatteryStaple!"
                protect_private_identity(priv,vault,pw)
                raw=unprotect_private_identity(vault,pw)
                result["tests"]["private_vault_round_trip"]=raw==priv.read_bytes()
                bad=False
                try: unprotect_private_identity(vault,"wrong-password-123")
                except Exception: bad=True
                result["tests"]["wrong_vault_password_rejected"]=bad
                result["all_tests_passed"]=all(result["tests"].values())
            return result
        def done(r,e):
            self.test.delete("1.0","end"); self.test.insert("end",str(e) if e else json.dumps(r,indent=2))
            if e: self.log(f"ERROR self-test: {e}"); messagebox.showerror("Self-test",str(e))
            elif r.get("all_tests_passed"): self.log("All B.22 self-tests passed."); messagebox.showinfo("Self-test","All B.22 tests passed")
        self._run("Running complete B.22 self-test...",job,done)

    def _activity(self):
        ttk.Label(self.t_log,text="Session activity",font=("Segoe UI",12,"bold")).pack(anchor="w")
        ttk.Label(self.t_log,text="No plaintext, keys, passwords, or secret values are written to this log.").pack(anchor="w",pady=(0,8))
        self.logbox=tk.Text(self.t_log,height=28,wrap="word"); self.logbox.pack(fill="both",expand=True)
        ttk.Button(self.t_log,text="Clear",command=lambda:self.logbox.delete("1.0","end")).pack(anchor="w",pady=6)


    def _help(self):
        ttk.Label(
            self.t_help,
            text="Entropic Fusion Help",
            font=("Segoe UI", 14, "bold"),
        ).pack(anchor="w")

        help_text = """GETTING STARTED

Entropic Fusion uses two identity files for normal use:

.efpub   Your PUBLIC identity. This is safe to share.
.efprivx Your PASSWORD-PROTECTED PRIVATE identity. Keep this secret.

If two people want to exchange encrypted files, each person can send the other
their .efpub file. Public identities are meant to be shared. Private identities
are not.


CREATE YOUR IDENTITY

1. Open the Identity tab.
2. Choose a name and location for your identity.
3. Click the identity creation button.
4. Choose a strong password when asked.
5. Keep the resulting .efprivx file private.
6. Share only your .efpub file with people who need to encrypt files for you.

Keep a secure backup of your .efprivx identity. If it is lost, files encrypted
to that identity cannot be recovered.


ENCRYPT A FILE

Encryption is always addressed to a recipient.

1. Obtain the recipient's .efpub public identity file.
2. Open the Encrypt tab.
3. Choose the RECIPIENT'S .efpub file.
4. Choose the normal file you want to encrypt.
5. Choose where to save the new .efb encrypted file.
6. Check the displayed recipient fingerprint if you have one to compare.
7. Click Encrypt.

Entropic Fusion creates an .efb file that can be sent, copied or stored like
any other file. The recipient uses their matching private identity to decrypt it.

If you and another person both want to send encrypted files to each other,
simply exchange .efpub files. Your .efpub file does not need to be kept secret.

Important: do not send your .efprivx or raw .efpriv file to anyone.


DECRYPT A FILE

1. Open the Decrypt tab.
2. Choose your .efprivx protected private identity.
3. Choose the .efb encrypted file.
4. Choose the destination folder.
5. Enter your identity password when prompted.
6. Entropic Fusion restores the original filename automatically.

The .efb file must have been encrypted to the public identity that matches your
private identity.


CREATE A VAULT

1. Open the Vault tab.
2. Choose your .efpub public identity.
3. Choose where the new .efv vault should be stored.
4. Choose the vault size.
5. Click Create vault.

Creating a vault does not mount it. It creates the encrypted .efv container.


OPEN / MOUNT A VAULT

1. Open the Vault tab.
2. Choose the .efv vault.
3. Choose the matching .efprivx protected private identity.
4. Choose a free Windows drive letter.
5. Click Mount vault.
6. Enter your password.

The vault appears in Windows as a normal drive. You can copy, open, edit,
rename and delete files there.

When finished, return to Entropic Fusion and click Dismount. The Windows drive
disappears and the vault is locked again.


COMPACT / REKEY

You do not need Compact / Rekey for normal everyday use.

Use it after substantial deleting or rewriting when you want to create a fresh
vault containing only the current live files. The destination vault receives a
fresh master key and vault ID. The source vault is left unchanged.


KEY FILES

.efpub   Public identity. Safe and intended to share.
.efpriv  Raw private identity. Keep secret.
.efprivx Password-protected private identity. Preferred for normal use.
.efb     Encrypted single file.
.efv     Encrypted mounted vault.


VERIFYING A RECIPIENT

A public identity can be copied or sent openly, but you still want to know it
really belongs to the intended person.

When possible, compare the recipient fingerprint using a separate trusted
channel, for example by reading it to each other or comparing it in person.
This helps prevent accidentally encrypting to the wrong public identity.


ACTIVITY AND PRIVACY

The Activity tab records operational events. It does not intentionally log
plaintext file contents, passwords, private keys or shared secrets.


THE SIMPLE VERSION

To receive encrypted files:
Share your .efpub file.

To send an encrypted file:
Use the recipient's .efpub file.

To decrypt:
Use your matching .efprivx file and password.

For an encrypted drive:
Create vault → Mount → Use → Dismount.
"""

        box = tk.Text(
            self.t_help,
            wrap="word",
            height=30,
            padx=14,
            pady=14,
            font=("Segoe UI", 10),
        )
        box.pack(fill="both", expand=True, pady=(8, 0))
        box.insert("1.0", help_text)
        box.configure(state="disabled")

if __name__ == "__main__":
    App().mainloop()
