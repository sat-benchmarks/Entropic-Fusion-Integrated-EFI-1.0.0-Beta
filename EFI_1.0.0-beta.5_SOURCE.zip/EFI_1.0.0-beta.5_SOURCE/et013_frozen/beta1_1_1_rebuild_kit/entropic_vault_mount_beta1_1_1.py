#!/usr/bin/env python3
from __future__ import annotations

import getpass
import hashlib
import threading
from pathlib import Path, PureWindowsPath

from winfspy import (
    FileSystem, BaseFileSystemOperations, FILE_ATTRIBUTE,
    CREATE_FILE_CREATE_OPTIONS, NTStatusObjectNameNotFound,
    NTStatusDirectoryNotEmpty, NTStatusNotADirectory,
    NTStatusObjectNameCollision, NTStatusAccessDenied, NTStatusEndOfFile,
)
from winfspy.plumbing.win32_filetime import filetime_now
from winfspy.plumbing.security_descriptor import SecurityDescriptor

import entropic_vault_manager_v0_11B_24_1 as manager
from entropic_vault_cow_v0_11B_24_3 import EntropicCOWStore, BLOCK_SIZE

VERSION = "Beta1.1.1-mount3"

from entropic_vault_path_beta1_1_1 import callback_path as canon, parent_path as parent, leaf_name as name_of
from entropic_diagnostics_beta1_1_1 import trace_event, record_exception

class Opened:
    """Opaque WinFsp file context carrying the canonical vault path."""
    def __init__(self, path):
        self.path = canon(path)

def _log_callback_failure(name, exc, **fields):
    # Object-not-found is routine Windows probing, not a backend fault.
    if isinstance(exc, NTStatusObjectNameNotFound):
        return
    record_exception(f"WinFsp callback failure: {name}", exc, **fields)

class EntropicCOWOperations(BaseFileSystemOperations):
    def __init__(self, store, label="Entropic Vault"):
        super().__init__()
        self.store = store
        self._thread_lock = threading.RLock()
        self.sd = SecurityDescriptor.from_string(
            "O:BAG:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;FA;;;WD)"
        )
        self.label = label

    def _find_existing_path(self, path):
        """Return the stored metadata spelling for a Windows path, if present."""
        p = canon(path)
        entries = self.store._active_meta()["entries"]
        if p in entries:
            return p
        folded = p.casefold()
        for existing in entries:
            if existing.casefold() == folded:
                return existing
        return None

    def _resolve_existing_path(self, path):
        resolved = self._find_existing_path(path)
        if resolved is None:
            raise NTStatusObjectNameNotFound()
        return resolved

    def _entry(self, path):
        with self._thread_lock:
            resolved = self._resolve_existing_path(path)
            return self.store._active_meta()["entries"][resolved]

    def _info(self, e):
        isdir = e["kind"] == "dir"
        attrs = int(e.get("attributes", 0))
        if isdir:
            attrs |= FILE_ATTRIBUTE.FILE_ATTRIBUTE_DIRECTORY
        else:
            attrs |= FILE_ATTRIBUTE.FILE_ATTRIBUTE_ARCHIVE
        size = int(e.get("size", 0))
        return {
            "file_attributes": attrs,
            "allocation_size": 0 if isdir else ((size + BLOCK_SIZE - 1)//BLOCK_SIZE)*BLOCK_SIZE,
            "file_size": size,
            "creation_time": int(e.get("creation_time", 0)),
            "last_access_time": int(e.get("last_access_time", 0)),
            "last_write_time": int(e.get("last_write_time", 0)),
            "change_time": int(e.get("change_time", 0)),
            "index_number": int(e.get("inode", 0)),
        }

    def get_volume_info(self):
        try:
            st = self.store.stats()
            total = self.store.sector_count * BLOCK_SIZE
            free = st["free_physical_sectors"] * BLOCK_SIZE
            return {"total_size": total, "free_size": free, "volume_label": self.label}
        except Exception as exc:
            _log_callback_failure("get_volume_info", exc)
            raise
    def set_volume_label(self, volume_label):
        self.label = str(volume_label)[:31]

    def get_security_by_name(self, file_name):
        try:
            trace_event("get_security_by_name", raw=str(file_name), canonical=canon(file_name))
            e = self._entry(file_name)
            return (self._info(e)["file_attributes"], self.sd.handle, self.sd.size)
        except Exception as exc:
            _log_callback_failure("get_security_by_name", exc)
            raise
    def create(self, file_name, create_options, granted_access, file_attributes, security_descriptor, allocation_size):
        try:
            with self._thread_lock:
                p = canon(file_name)
                if self._find_existing_path(p) is not None:
                    raise NTStatusObjectNameCollision()
                par = self._resolve_existing_path(parent(p))
                pe = self._entry(par)
                if pe["kind"] != "dir":
                    raise NTStatusNotADirectory()
                # Preserve the requested leaf spelling but anchor it to the
                # metadata spelling of the actual parent directory.
                p = canon(PureWindowsPath(par) / name_of(p))
                kind = "dir" if create_options & CREATE_FILE_CREATE_OPTIONS.FILE_DIRECTORY_FILE else "file"
                attrs = int(file_attributes)
                if kind == "dir":
                    attrs |= int(FILE_ATTRIBUTE.FILE_ATTRIBUTE_DIRECTORY)
                now = filetime_now()
                self.store.create_entry(p, kind, attrs, now)
                if kind == "file" and allocation_size:
                    self.store.truncate_file(p, int(allocation_size))
                return Opened(p)
        except Exception as exc:
            _log_callback_failure("create", exc)
            raise
    def open(self, file_name, create_options, granted_access):
        try:
            trace_event("open", raw=str(file_name), canonical=canon(file_name), create_options=int(create_options), granted_access=int(granted_access))
            # Resolve to the metadata spelling once. All later callbacks on
            # this handle then use an authoritative internal path.
            p = self._resolve_existing_path(file_name)
            self._entry(p)
            return Opened(p)
        except Exception as exc:
            _log_callback_failure("open", exc)
            raise
    def close(self, file_context):
        try:
            with self._thread_lock:
                self.store.flush_pending()
        except Exception as exc:
            _log_callback_failure("close", exc)
            raise
    def get_security(self, file_context):
        return self.sd

    def set_security(self, file_context, security_information, modification_descriptor):
        # B.24.3 uses a single inherited descriptor. ACL persistence is a later
        # product-hardening item and is not silently claimed here.
        pass

    def get_file_info(self, file_context):
        return self._info(self._entry(file_context.path))

    def set_basic_info(self, file_context, file_attributes, creation_time, last_access_time, last_write_time, change_time, file_info):
        try:
            with self._thread_lock:
                self.store.flush_pending()
                e = self._entry(file_context.path)
                fields = {}
                if file_attributes != FILE_ATTRIBUTE.INVALID_FILE_ATTRIBUTES:
                    fields["attributes"] = int(file_attributes)
                if creation_time: fields["creation_time"] = int(creation_time)
                if last_access_time: fields["last_access_time"] = int(last_access_time)
                if last_write_time: fields["last_write_time"] = int(last_write_time)
                if change_time: fields["change_time"] = int(change_time)
                if fields:
                    self.store.update_entry(file_context.path, **fields)
                return self._info(self._entry(file_context.path))
        except Exception as exc:
            _log_callback_failure("set_basic_info", exc)
            raise
    def set_file_size(self, file_context, new_size, set_allocation_size):
        try:
            with self._thread_lock:
                self.store.flush_pending()
                e = self._entry(file_context.path)
                if e["kind"] != "file":
                    raise NTStatusAccessDenied()
                # Allocation-size requests are advisory. File-size requests are durable.
                if not set_allocation_size:
                    self.store.truncate_file(file_context.path, int(new_size))
        except Exception as exc:
            _log_callback_failure("set_file_size", exc)
            raise
    def can_delete(self, file_context, file_name):
        # WinFsp may supply a path form here that does not match our canonical
        # namespace exactly. The already-open file_context is authoritative.
        p = canon(file_context.path)
        e = self._entry(p)
        if e["kind"] == "dir":
            pref = p.rstrip("\\") + "\\"
            if any(x.startswith(pref) for x in self.store._active_meta()["entries"] if x != p):
                raise NTStatusDirectoryNotEmpty()

    def rename(self, file_context, file_name, new_file_name, replace_if_exists):
        try:
            with self._thread_lock:
                self.store.flush_pending()
                old = canon(file_context.path)

                # WinFsp can provide new_file_name as a name relative to the
                # source directory (for example "r_0000.bin") rather than as
                # a root-qualified path. canon("r_0000.bin") would incorrectly
                # turn that into "\\r_0000.bin", moving the file to vault
                # root. Resolve relative destinations against parent(old).
                raw_new = str(new_file_name).replace("/", "\\")

                # WinFsp/Windows may surface the destination in several forms:
                #   r_0000.bin
                #   \small\r_0000.bin
                #   D:\small\r_0000.bin
                #   \\?\D:\small\r_0000.bin
                #   \??\D:\small\r_0000.bin
                #
                # Strip any Win32 namespace/drive prefix first so our internal
                # namespace always remains vault-root relative.
                if raw_new.startswith("\\\\?\\"):
                    raw_new = raw_new[4:]
                elif raw_new.startswith("\\??\\"):
                    raw_new = raw_new[4:]

                if len(raw_new) >= 2 and raw_new[1] == ":":
                    raw_new = raw_new[2:]
                    if not raw_new.startswith("\\"):
                        raw_new = "\\" + raw_new

                if raw_new.startswith("\\"):
                    candidate = canon(raw_new)
                else:
                    candidate = canon(PureWindowsPath(parent(old)) / raw_new)

                # Windows paths are case-insensitive. WinFsp can hand the
                # destination parent back with different case, e.g. "\\SMALL"
                # while metadata stores "\\small". Resolve the destination
                # parent against existing directory keys case-insensitively.
                old_parent = parent(old)
                cand_parent = parent(candidate)
                cand_name = PureWindowsPath(candidate).name

                if cand_parent.casefold() == old_parent.casefold():
                    resolved_parent = old_parent
                else:
                    entries_now = self.store._active_meta()["entries"]
                    resolved_parent = next(
                        (
                            p for p, e in entries_now.items()
                            if e.get("kind") == "dir"
                            and p.casefold() == cand_parent.casefold()
                        ),
                        cand_parent,
                    )

                new = canon(PureWindowsPath(resolved_parent) / cand_name)
                entries = self.store._active_meta()["entries"]
                if old not in entries:
                    raise NTStatusObjectNameNotFound()
                if new in entries:
                    if not replace_if_exists:
                        raise NTStatusObjectNameCollision()
                    if entries[new]["kind"] == "dir":
                        raise NTStatusAccessDenied()
                    self.store.delete_entry(new)
                self.store.rename_prefix(old, new)
                file_context.path = new
                # WinFsp/Windows can issue Cleanup(Delete) on the same source
                # handle after a successful rename. The context now refers to
                # the destination, so suppress that one stale delete request.
        except Exception as exc:
            _log_callback_failure("rename", exc)
            raise
    def read_directory(self, file_context, marker):
        try:
            with self._thread_lock:
                e = self._entry(file_context.path)
                if e["kind"] != "dir":
                    raise NTStatusNotADirectory()
                base = canon(file_context.path)
                rows = []
                if base != "\\":
                    rows.append({"file_name": ".", **self._info(e)})
                    rows.append({"file_name": "..", **self._info(self._entry(parent(base)))})
                for p, child in self.store._active_meta()["entries"].items():
                    if p != base and parent(p) == base:
                        rows.append({"file_name": name_of(p), **self._info(child)})
                rows.sort(key=lambda x: x["file_name"].lower())
                if marker is None:
                    return rows
                for i, row in enumerate(rows):
                    if row["file_name"].casefold() == str(marker).casefold():
                        return rows[i+1:]
                return []
        except Exception as exc:
            _log_callback_failure("read_directory", exc)
            raise
    def get_dir_info_by_name(self, file_context, file_name):
        trace_event("get_dir_info_by_name", parent=str(file_context.path), raw_name=str(file_name))
        p = canon(PureWindowsPath(file_context.path) / file_name)
        e = self._entry(p)
        return {"file_name": file_name, **self._info(e)}

    def read(self, file_context, offset, length):
        try:
            trace_event("read", path=str(file_context.path), offset=int(offset), length=int(length))
            with self._thread_lock:
                e = self._entry(file_context.path)
                if e["kind"] != "file":
                    raise NTStatusAccessDenied()
                data = self.store.read_file(file_context.path, int(offset), int(length))
                if not data and int(offset) >= int(e["size"]):
                    raise NTStatusEndOfFile()
                return data
        except Exception as exc:
            _log_callback_failure("read", exc)
            raise
    def write(self, file_context, buffer, offset, write_to_end_of_file, constrained_io):
        try:
            with self._thread_lock:
                e = self._entry(file_context.path)
                if e["kind"] != "file":
                    raise NTStatusAccessDenied()
                if constrained_io:
                    if int(offset) >= int(e["size"]):
                        return 0
                    buffer = buffer[:max(0, int(e["size"]) - int(offset))]
                return self.store.write_file_buffered(
                    file_context.path, int(offset), bytes(buffer),
                    append=bool(write_to_end_of_file)
                )
        except Exception as exc:
            _log_callback_failure("write", exc)
            raise
    def overwrite(self, file_context, file_attributes, replace_file_attributes, allocation_size):
        try:
            with self._thread_lock:
                self.store.flush_pending()
                e = self._entry(file_context.path)
                if e["kind"] != "file":
                    raise NTStatusAccessDenied()
                self.store.truncate_file(file_context.path, 0)
                attrs = int(file_attributes) | int(FILE_ATTRIBUTE.FILE_ATTRIBUTE_ARCHIVE)
                if replace_file_attributes:
                    self.store.update_entry(file_context.path, attributes=attrs)
                else:
                    self.store.update_entry(file_context.path, attributes=int(e.get("attributes",0)) | attrs)
        except Exception as exc:
            _log_callback_failure("overwrite", exc)
            raise
    def cleanup(self, file_context, file_name, flags):
        try:
            FspCleanupDelete = 0x01
            with self._thread_lock:
                # Commit all encrypted buffered writes before Windows releases the
                # handle or asks for deletion.
                self.store.flush_pending()
                if flags & FspCleanupDelete:
                    p = canon(file_context.path)
                    e = self._entry(p)
                    if e["kind"] == "dir":
                        pref = p.rstrip("\\") + "\\"
                        if any(x.startswith(pref) for x in self.store._active_meta()["entries"] if x != p):
                            return
                    self.store.delete_entry(p)
        except Exception as exc:
            _log_callback_failure("cleanup", exc)
            raise
    def flush(self, file_context):
        try:
            with self._thread_lock:
                self.store.flush_pending()
        except Exception as exc:
            _log_callback_failure("flush", exc)
            raise
def unlock_store(vault_path, private_identity, password):
    if password is None:
        master_key, unlock = manager.unlock_fused_vault(private_identity, vault_path)
    else:
        master_key, unlock = manager.unlock_fused_vault_protected(private_identity, password, vault_path)
    return master_key, unlock, EntropicCOWStore(vault_path, master_key)

def mount_vault(vault_path: Path, private_identity: Path, mountpoint: str, password: str | None):
    master_key, unlock, store = unlock_store(vault_path, private_identity, password)
    ops = EntropicCOWOperations(store)
    fs = FileSystem(
        mountpoint, ops,
        sector_size=512,
        sectors_per_allocation_unit=8,
        volume_creation_time=filetime_now(),
        volume_serial_number=int.from_bytes(hashlib.sha256(str(vault_path).encode()).digest()[:4],"big"),
        file_info_timeout=1000,
        case_sensitive_search=0,
        case_preserved_names=1,
        unicode_on_disk=1,
        persistent_acls=0,
        post_cleanup_when_modified_only=1,
        um_file_context_is_user_context2=1,
        file_system_name="EntropicVault",
        reject_irp_prior_to_transact0=False,
    )
    return fs, ops, unlock, bytearray(master_key)

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("vault")
    ap.add_argument("private_identity")
    ap.add_argument("mountpoint")
    ap.add_argument("--raw-private", action="store_true")
    args = ap.parse_args()
    password = None if args.raw_private else getpass.getpass("Private vault password: ")
    fs = None
    mk = None
    try:
        fs, ops, unlock, mk = mount_vault(Path(args.vault), Path(args.private_identity), args.mountpoint, password)
        print("Three-leg Fusion:", unlock.get("fusion_mode"))
        print("Live EF equations:", unlock.get("ef_equations_verified"))
        print("Storage:", ops.store.stats())
        fs.start()
        print(f"Mounted as {args.mountpoint}. Press ENTER to dismount.")
        input()
    finally:
        if fs is not None:
            try:
                if 'ops' in locals():
                    ops.store.flush_pending()
            except Exception:
                pass
            try:
                fs.stop()
                if 'ops' in locals():
                    ops.store.mark_clean_shutdown()
            except Exception:
                pass
        if mk is not None:
            for i in range(len(mk)):
                mk[i] = 0
        print("Dismounted.")

if __name__ == "__main__":
    main()
