ENTROPIC FUSION BETA 1.1.1
REBUILD KIT REVISION: R3-opened-context-fix REBUILD KIT
=========================================

This is the corrective build after the Beta 1.1 manual runtime gate failed.

RUN
---
1. Extract this ZIP completely. Do not run it inside the ZIP.
2. Double-click:
       BUILD_ENTROPIC_FUSION_BETA1_1_1.bat
3. Let the BAT complete. It performs source validation, builds both Windows
   EXEs, proves frozen module provenance, and automatically runs a disposable
   WinFsp/Win32 integration test against the newly built host.

SEND
----
Send these three files back:
    BETA1_1_1_SOURCE_RESULT.json
    BETA1_1_1_FROZEN_RESULT.json
    BETA1_1_1_WINDOWS_INTEGRATION_RESULT.json

If all three pass, the BAT also creates:
    release\EntropicFusion_Beta_1_1_1.zip

You do not need to run Command Prompt diagnostics manually.
