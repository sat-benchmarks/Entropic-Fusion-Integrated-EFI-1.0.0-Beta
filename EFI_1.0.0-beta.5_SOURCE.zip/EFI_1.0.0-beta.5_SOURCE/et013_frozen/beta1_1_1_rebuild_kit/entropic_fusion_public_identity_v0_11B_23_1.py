#!/usr/bin/env python3
"""Entropic Fusion B.23.1 public/private identity.

B.23.1 removes the 390-branch hidden-path transport. The live EF relation now
protects BOTH recipient ML-KEM private keys. The inner ML-KEM-1024 private key
is therefore no longer merely selected by geometry: it cannot be recovered by
the legitimate decryption path until the complete EF witness passes all
materialised face+centre equations.
"""
from __future__ import annotations
import base64,hashlib,json,os
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import entropic_fusion_relation_v0_11B_23_1 as efrel
from entropic_fusion_mlkem_runtime_v0_11B_23_1 import keygen_bytes,encapsulate_bytes,decapsulate_bytes

VERSION='0.11B.23.1'; PUBLIC_FORMAT='EF-B23-PUBLIC-IDENTITY-1'; PRIVATE_FORMAT='EF-B23-PRIVATE-IDENTITY-1'
WRAP_AAD=b'ENTROPIC-FUSION/B23/EF-WITNESS-KEM-PRIVATE-WRAP/v1'
EF_SESSION_DOMAIN=b'ENTROPIC-FUSION/B23.1/EF-GATED-SESSION/v1'
def b64e(x): return base64.b64encode(x).decode('ascii')
def b64d(x): return base64.b64decode(x.encode('ascii'),validate=True)
def canonical(o): return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def public_fingerprint(o): return hashlib.sha256(canonical(o)).hexdigest()

def _wrap(key,raw,label):
    nonce=os.urandom(12); aad=WRAP_AAD+b'\x00'+label
    return {'nonce_b64':b64e(nonce),'ciphertext_b64':b64e(AESGCM(key).encrypt(nonce,raw,aad))}
def _unwrap(key,row,label):
    aad=WRAP_AAD+b'\x00'+label
    return AESGCM(key).decrypt(b64d(row['nonce_b64']),b64d(row['ciphertext_b64']),aad)


def derive_ef_gated_session(inner_ss: bytes, fusion_commitment_sha256: str, transcript: bytes) -> bytes:
    """Domain-separated live EF leg for the final combiner.

    The entropy comes from the ML-KEM-1024 session secret. The Entropic relation
    is what gates legitimate recovery of that secret, and its public commitment
    plus the complete ciphertext transcript are bound into this contribution.

    This is deliberately NOT claimed as an independent Entropic hardness source.
    """
    if len(inner_ss) < 16:
        raise ValueError("inner ML-KEM shared secret unexpectedly short")
    commit = bytes.fromhex(fusion_commitment_sha256)
    th = hashlib.sha256(transcript).digest()
    return hashlib.sha256(EF_SESSION_DOMAIN + commit + th + inner_ss).digest()


def generate_identity(public_path,private_path,*,seed,**_legacy):
    public_path=Path(public_path);private_path=Path(private_path);public_path.parent.mkdir(parents=True,exist_ok=True);private_path.parent.mkdir(parents=True,exist_ok=True)
    ef_pub,ef_witness,ef_report,fusion_secret=efrel.generate(seed)
    outer_pk,outer_sk=keygen_bytes('ML-KEM-768'); inner_pk,inner_sk=keygen_bytes('ML-KEM-1024')
    public_obj={'format':PUBLIC_FORMAT,'version':VERSION,'outer_kem':'ML-KEM-768','fused_inner_kem':'ML-KEM-1024','ef_relation':'EF-v0.11-full-face-centre','fusion_mode':'EF-direct-three-leg-combiner','ef_public':ef_pub,'ef_fusion_commitment_sha256':ef_report['fusion_commitment_sha256'],'outer_public_pem_b64':b64e(outer_pk),'inner_public_pem_b64':b64e(inner_pk)}
    fp=public_fingerprint(public_obj); public_obj['public_identity_sha256']=fp
    private_obj={'format':PRIVATE_FORMAT,'version':VERSION,'public_identity':public_obj,'ef_witness':ef_witness,'outer_private_wrapped':_wrap(fusion_secret,outer_sk,b'outer-mlkem-768'),'inner_private_wrapped':_wrap(fusion_secret,inner_sk,b'inner-mlkem-1024')}
    public_path.write_text(json.dumps(public_obj,indent=2)+'\n'); private_path.write_text(json.dumps(private_obj,indent=2)+'\n')
    try: os.chmod(private_path,0o600)
    except OSError: pass
    return {'version':VERSION,'public_identity_sha256':fp,'fusion_mode':public_obj['fusion_mode'],'ef_positions':ef_report['positions'],'ef_edges':ef_report['edges'],'ef_equations_verified':ef_report['equations_verified'],'public_file':str(public_path),'private_file':str(private_path)}

def _validate_pub(o):
    if o.get('format')!=PUBLIC_FORMAT: raise ValueError('not a B.23 public identity')
    claimed=o.get('public_identity_sha256');tmp=dict(o);tmp.pop('public_identity_sha256',None)
    if claimed!=public_fingerprint(tmp): raise ValueError('public identity fingerprint mismatch')

def load_public(path):
    o=json.loads(Path(path).read_text());_validate_pub(o);return o

def load_private(path):
    o=json.loads(Path(path).read_text());
    if o.get('format')!=PRIVATE_FORMAT: raise ValueError('not a B.23 private identity')
    _validate_pub(o['public_identity']);return o

def encapsulate_fused(pub):
    outer_ct,outer_ss=encapsulate_bytes(b64d(pub['outer_public_pem_b64']),'ML-KEM-768')
    inner_ct,inner_ss=encapsulate_bytes(b64d(pub['inner_public_pem_b64']),'ML-KEM-1024')
    return outer_ct,outer_ss,inner_ct,inner_ss

def decapsulate_fused(priv,outer_ct,inner_ct):
    pub=priv['public_identity']
    report,fusion_secret=efrel.verify_and_derive(pub['ef_public'],priv['ef_witness'])
    if report['fusion_commitment_sha256']!=pub['ef_fusion_commitment_sha256']:
        raise ValueError('EF fusion commitment mismatch')
    outer_sk=_unwrap(fusion_secret,priv['outer_private_wrapped'],b'outer-mlkem-768')
    inner_sk=_unwrap(fusion_secret,priv['inner_private_wrapped'],b'inner-mlkem-1024')
    outer_ss=decapsulate_bytes(outer_sk,outer_ct,'ML-KEM-768')
    inner_ss=decapsulate_bytes(inner_sk,inner_ct,'ML-KEM-1024')
    return outer_ss,inner_ss,report,fusion_secret
