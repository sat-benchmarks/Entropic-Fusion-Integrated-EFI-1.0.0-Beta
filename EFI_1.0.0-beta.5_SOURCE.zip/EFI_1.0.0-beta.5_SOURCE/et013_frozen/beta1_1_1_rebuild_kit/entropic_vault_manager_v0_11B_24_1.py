#!/usr/bin/env python3
from __future__ import annotations
import os, hashlib
from pathlib import Path

import entropic_vault_v0_11B_24_1 as vault
import entropic_vault_fusion_wrap_v0_11B_24_1 as fusion

VERSION="0.11B.24.1"

def create_fused_vault(public_identity_path:Path,vault_path:Path,size_bytes:int,label:str="Entropic Vault")->dict:
    master_key=os.urandom(32)
    vault_id=os.urandom(16)
    capsule=fusion.wrap_master_key(public_identity_path,master_key,vault_id)
    result=vault.create_vault(vault_path,size_bytes,capsule,label=label,vault_id=vault_id)
    result.update({
        "fusion_mode":"EF-direct-three-leg-combiner",
        "public_identity_sha256":capsule["header"]["public_identity_sha256"],
        "master_key_sha256_internal_test_only":hashlib.sha256(master_key).hexdigest(),
    })
    return result

def unlock_fused_vault(private_identity_path:Path,vault_path:Path)->tuple[bytes,dict]:
    header=vault.read_header(vault_path)
    vault_id=vault.b64d(header["vault_id_b64"])
    master_key,report=fusion.unwrap_master_key(private_identity_path,header["wrapped_master_key"],vault_id)
    return master_key,report

def unlock_fused_vault_protected(private_vault_path:Path,password:str,vault_path:Path)->tuple[bytes,dict]:
    header=vault.read_header(vault_path)
    vault_id=vault.b64d(header["vault_id_b64"])
    master_key,report=fusion.unwrap_master_key_from_protected_vault(
        private_vault_path,password,header["wrapped_master_key"],vault_id
    )
    return master_key,report
