#!/usr/bin/env python3
"""
Entropic Vault B.24.3 copy-on-write storage engine.

Design:
- B.24.1 authenticated 4096-byte sectors remain the cryptographic substrate.
- Physical sectors are append-only within this generation of the engine.
- A logical file block update allocates a fresh physical sector.
- Files use compact logical->physical extents.
- Metadata is copy-on-write and committed by an append-only authenticated
  commit record.
- Data and metadata are fsync'd before the commit record is written.
- Recovery scans for the newest valid commit and ignores orphan/torn writes.
- No physical sector is deliberately rewritten, preventing generation/nonce
  reuse within the B.24.3 storage layer.
"""
from __future__ import annotations

import copy
import hashlib
import hmac
import json
import os
import struct
from pathlib import Path

import entropic_vault_v0_11B_24_1 as vault

VERSION = "0.11B.24.3"
FS_FORMAT = "EF-COW-FS-1"
BLOCK_SIZE = vault.SECTOR_SIZE

META_MAGIC = b"EFMETA3\x00"
COMMIT_MAGIC = b"EFCMT3\x00\x00"
DELTA_COMMIT_MAGIC = b"EFDLT3\x00\x00"
DELTA_FORMAT = "EF-COW-DELTA-1"
CHECKPOINT_INTERVAL = 128
FAST_ANCHOR_OFFSET = vault.HEADER_REGION - 8192
FAST_ANCHOR_SIZE = 8192
FAST_ANCHOR_MAGIC = b"EFANCH10"
FAST_ANCHOR_VERSION = 1
META_HDR = 64
META_PAYLOAD = BLOCK_SIZE - META_HDR
COMMIT_HDR = 8 + 8 + 8 + 4 + 8 + 32 + 8

def _canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")

def _fsync_container(path: Path):
    with open(path, "r+b", buffering=0) as f:
        os.fsync(f.fileno())

def _unused(path: Path, index: int) -> bool:
    return vault._current_generation(path, index) == 0

def _write_once(path: Path, key: bytes, index: int, payload: bytes):
    if not _unused(path, index):
        raise RuntimeError(f"B.24.3 refuses physical-sector reuse: {index}")
    vault.write_sector(path, key, index, payload)

def _meta_pack(txid: int, idx: int, count: int, total_len: int, digest: bytes, chunk: bytes) -> bytes:
    if len(digest) != 32 or len(chunk) > META_PAYLOAD:
        raise ValueError("invalid metadata chunk")
    header = (
        META_MAGIC
        + txid.to_bytes(8, "big")
        + idx.to_bytes(4, "big")
        + count.to_bytes(4, "big")
        + total_len.to_bytes(8, "big")
        + digest
    )
    assert len(header) == META_HDR
    return header + chunk

def _meta_unpack(pt: bytes):
    if len(pt) != BLOCK_SIZE or pt[:8] != META_MAGIC:
        return None
    txid = int.from_bytes(pt[8:16], "big")
    idx = int.from_bytes(pt[16:20], "big")
    count = int.from_bytes(pt[20:24], "big")
    total_len = int.from_bytes(pt[24:32], "big")
    digest = pt[32:64]
    return txid, idx, count, total_len, digest, pt[64:]

def _commit_pack(txid: int, meta_start: int, meta_count: int, meta_len: int, digest: bytes, highwater: int) -> bytes:
    if len(digest) != 32:
        raise ValueError("bad digest")
    raw = (
        COMMIT_MAGIC
        + txid.to_bytes(8, "big")
        + meta_start.to_bytes(8, "big")
        + meta_count.to_bytes(4, "big")
        + meta_len.to_bytes(8, "big")
        + digest
        + highwater.to_bytes(8, "big")
    )
    return raw.ljust(BLOCK_SIZE, b"\x00")

def _commit_unpack(pt: bytes):
    if len(pt) != BLOCK_SIZE or pt[:8] != COMMIT_MAGIC:
        return None
    txid = int.from_bytes(pt[8:16], "big")
    meta_start = int.from_bytes(pt[16:24], "big")
    meta_count = int.from_bytes(pt[24:28], "big")
    meta_len = int.from_bytes(pt[28:36], "big")
    digest = pt[36:68]
    highwater = int.from_bytes(pt[68:76], "big")
    return {
        "txid": txid,
        "meta_start": meta_start,
        "meta_count": meta_count,
        "meta_len": meta_len,
        "digest": digest,
        "highwater": highwater,
    }

def _delta_commit_pack(txid: int, meta_start: int, meta_count: int, meta_len: int, digest: bytes, highwater: int) -> bytes:
    if len(digest) != 32:
        raise ValueError("bad digest")
    raw = (
        DELTA_COMMIT_MAGIC
        + txid.to_bytes(8, "big")
        + meta_start.to_bytes(8, "big")
        + meta_count.to_bytes(4, "big")
        + meta_len.to_bytes(8, "big")
        + digest
        + highwater.to_bytes(8, "big")
    )
    return raw.ljust(BLOCK_SIZE, b"\x00")

def _delta_commit_unpack(pt: bytes):
    if len(pt) != BLOCK_SIZE or pt[:8] != DELTA_COMMIT_MAGIC:
        return None
    txid = int.from_bytes(pt[8:16], "big")
    meta_start = int.from_bytes(pt[16:24], "big")
    meta_count = int.from_bytes(pt[24:28], "big")
    meta_len = int.from_bytes(pt[28:36], "big")
    digest = pt[36:68]
    highwater = int.from_bytes(pt[68:76], "big")
    return {
        "txid": txid,
        "meta_start": meta_start,
        "meta_count": meta_count,
        "meta_len": meta_len,
        "digest": digest,
        "highwater": highwater,
        "delta": True,
    }

def _metadata_delta(old_meta, new_meta, txid):
    old_entries = old_meta.get("entries", {})
    new_entries = new_meta.get("entries", {})
    upserts = {}
    deletes = []
    for path, entry in new_entries.items():
        if path not in old_entries or old_entries[path] != entry:
            upserts[path] = entry
    for path in old_entries:
        if path not in new_entries:
            deletes.append(path)
    return {
        "format": DELTA_FORMAT,
        "txid": int(txid),
        "base_txid": int(old_meta.get("txid", 0)),
        "next_inode": int(new_meta.get("next_inode", old_meta.get("next_inode", 2))),
        "upserts": upserts,
        "deletes": deletes,
    }

def _apply_metadata_delta(meta, delta):
    if delta.get("format") != DELTA_FORMAT:
        raise ValueError("bad metadata delta format")
    if int(delta.get("base_txid", -1)) != int(meta.get("txid", -2)):
        raise ValueError("metadata delta base mismatch")
    out = copy.deepcopy(meta)
    entries = out["entries"]
    for path in delta.get("deletes", []):
        entries.pop(path, None)
    for path, entry in delta.get("upserts", {}).items():
        entries[path] = entry
    out["next_inode"] = int(delta.get("next_inode", out.get("next_inode", 2)))
    out["txid"] = int(delta["txid"])
    return out

def _anchor_key(master_key: bytes, vault_id: bytes) -> bytes:
    return hmac.new(
        master_key,
        b"ENTROPIC-VAULT/B24.10/CLEAN-MOUNT-ANCHOR/" + vault_id,
        hashlib.sha256,
    ).digest()

def _anchor_mac(key: bytes, payload: bytes) -> bytes:
    return hmac.new(key, FAST_ANCHOR_MAGIC + payload, hashlib.sha256).digest()

def _write_anchor_region(path: Path, raw: bytes):
    if len(raw) > FAST_ANCHOR_SIZE:
        raise ValueError("clean-mount anchor too large")
    with open(path, "rb", buffering=0) as f:
        f.seek(len(vault.MAGIC))
        n_raw = f.read(4)
        if len(n_raw) != 4:
            raise ValueError("truncated vault header")
        header_len = int.from_bytes(n_raw, "big")
    header_end = len(vault.MAGIC) + 4 + header_len
    if header_end > FAST_ANCHOR_OFFSET:
        raise RuntimeError("vault header leaves no room for B.24.10 clean anchor")
    with open(path, "r+b", buffering=0) as f:
        f.seek(FAST_ANCHOR_OFFSET)
        f.write(raw.ljust(FAST_ANCHOR_SIZE, b"\x00"))
        f.flush()
        os.fsync(f.fileno())

def _default_metadata():
    return {
        "format": FS_FORMAT,
        "version": VERSION,
        "txid": 0,
        "next_inode": 2,
        "entries": {
            "\\": {
                "inode": 1,
                "kind": "dir",
                "attributes": 16,
                "creation_time": 0,
                "last_access_time": 0,
                "last_write_time": 0,
                "change_time": 0,
                "size": 0,
                "extents": [],
            }
        }
    }

def _extent_map(extents):
    d = {}
    for lstart, pstart, count in extents:
        for i in range(count):
            d[lstart + i] = pstart + i
    return d

def _coalesce(mapping):
    if not mapping:
        return []
    items = sorted(mapping.items())
    out = []
    ls, ps = items[0]
    prev_l, prev_p = ls, ps
    count = 1
    for l, p in items[1:]:
        if l == prev_l + 1 and p == prev_p + 1:
            count += 1
        else:
            out.append([ls, ps, count])
            ls, ps, count = l, p, 1
        prev_l, prev_p = l, p
    out.append([ls, ps, count])
    return out

class EntropicCOWStore:
    def __init__(self, path: Path, master_key: bytes, *, create_if_blank=True):
        self.path = Path(path)
        self.key = bytes(master_key)
        self.header = vault.read_header(self.path)
        self.sector_count = int(self.header["sector_count"])
        self.meta = None
        self.txid = 0
        self.highwater = 0
        self.last_commit_sector = None
        self.pending_meta = None
        self.pending_data_dirty = False
        self._read_fp = None
        self._read_storage_key = None
        self._read_vault_id = None
        self._read_aesgcm = None
        self._read_aesgcm = None
        self.last_full_commit_sector = None
        self.last_full_txid = None
        self.delta_commit_sectors = []
        self.recovery_mode = "unknown"
        self._recover()
        if self.meta is None:
            if not create_if_blank:
                raise ValueError("no committed B.24.3 filesystem found")
            self.meta = _default_metadata()
            self._commit(copy.deepcopy(self.meta))

        # A clean anchor is usable only while the vault is closed. Invalidate
        # it synchronously before this store can be exposed through WinFsp.
        self._mark_anchor_dirty()

    def _read_sector_safe(self, index):
        try:
            return vault.read_sector(self.path, self.key, index)
        except Exception:
            return None

    def _recover_payload(self, c):
        if c["meta_count"] <= 0:
            return None
        if c["meta_start"] < 0 or c["meta_start"] + c["meta_count"] > self.sector_count:
            return None
        chunks = []
        for j in range(c["meta_count"]):
            pt = self._read_sector_safe(c["meta_start"] + j)
            if pt is None:
                return None
            m = _meta_unpack(pt)
            if m is None:
                return None
            txid, idx, count, total_len, digest, chunk = m
            if txid != c["txid"] or idx != j or count != c["meta_count"] or total_len != c["meta_len"] or digest != c["digest"]:
                return None
            chunks.append(chunk)
        raw = b"".join(chunks)[:c["meta_len"]]
        if hashlib.sha256(raw).digest() != c["digest"]:
            return None
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return None

    def _recover_metadata(self, c):
        doc = self._recover_payload(c)
        if doc is None:
            return None
        if doc.get("format") != FS_FORMAT or int(doc.get("txid", -1)) != c["txid"]:
            return None
        return doc

    def _anchor_payload(self):
        if self.last_full_commit_sector is None or self.last_full_txid is None:
            return None
        return {
            "anchor_version": FAST_ANCHOR_VERSION,
            "vault_id_b64": self.header["vault_id_b64"],
            "clean": True,
            "txid": int(self.txid),
            "highwater": int(self.highwater),
            "last_commit_sector": int(self.last_commit_sector),
            "last_full_commit_sector": int(self.last_full_commit_sector),
            "last_full_txid": int(self.last_full_txid),
            "delta_commit_sectors": [int(x) for x in self.delta_commit_sectors],
        }

    def _read_clean_anchor(self):
        try:
            with open(self.path, "rb", buffering=0) as f:
                f.seek(FAST_ANCHOR_OFFSET)
                raw = f.read(FAST_ANCHOR_SIZE)
            if len(raw) != FAST_ANCHOR_SIZE or raw[:8] != FAST_ANCHOR_MAGIC:
                return None
            n = int.from_bytes(raw[8:12], "big")
            if n <= 0 or n > FAST_ANCHOR_SIZE - 44:
                return None
            payload = raw[12:12+n]
            mac = raw[12+n:12+n+32]
            vault_id = vault.b64d(self.header["vault_id_b64"])
            key = _anchor_key(self.key, vault_id)
            if not hmac.compare_digest(mac, _anchor_mac(key, payload)):
                return None
            doc = json.loads(payload.decode("utf-8"))
            if (
                int(doc.get("anchor_version", -1)) != FAST_ANCHOR_VERSION
                or doc.get("vault_id_b64") != self.header["vault_id_b64"]
                or doc.get("clean") is not True
            ):
                return None
            return doc
        except Exception:
            return None

    def _mark_anchor_dirty(self):
        try:
            _write_anchor_region(self.path, b"")
        except RuntimeError:
            # Legacy vaults with exceptionally large JSON headers remain
            # compatible but use full recovery scans.
            pass

    def mark_clean_shutdown(self):
        payload_obj = self._anchor_payload()
        if payload_obj is None:
            return False
        payload = _canonical(payload_obj)
        vault_id = vault.b64d(self.header["vault_id_b64"])
        key = _anchor_key(self.key, vault_id)
        raw = (
            FAST_ANCHOR_MAGIC
            + len(payload).to_bytes(4, "big")
            + payload
            + _anchor_mac(key, payload)
        )
        _write_anchor_region(self.path, raw)
        return True

    def _recover_from_anchor(self, a):
        try:
            highwater = int(a["highwater"])
            txid_final = int(a["txid"])
            full_sector = int(a["last_full_commit_sector"])
            full_txid = int(a["last_full_txid"])
            delta_sectors = [int(x) for x in a.get("delta_commit_sectors", [])]

            if not (0 <= full_sector < highwater <= self.sector_count):
                return False
            if len(delta_sectors) > CHECKPOINT_INTERVAL - 1:
                return False
            if any(not (0 <= x < highwater) for x in delta_sectors):
                return False

            # Cheap physical-frontier sanity check.
            if highwater < self.sector_count:
                with open(self.path, "rb", buffering=0) as f:
                    f.seek(vault._record_offset(highwater))
                    raw = f.read(vault.GEN_SIZE)
                if len(raw) != vault.GEN_SIZE or int.from_bytes(raw, "big") != 0:
                    return False

            pt = self._read_sector_safe(full_sector)
            if pt is None:
                return False
            c = _commit_unpack(pt)
            if c is None or int(c["txid"]) != full_txid:
                return False
            meta = self._recover_metadata(c)
            if meta is None:
                return False

            tx = full_txid
            last_commit_sector = full_sector
            for sec in delta_sectors:
                pt = self._read_sector_safe(sec)
                if pt is None:
                    return False
                dc = _delta_commit_unpack(pt)
                if dc is None or int(dc["txid"]) != tx + 1:
                    return False
                delta = self._recover_payload(dc)
                if (
                    delta is None
                    or delta.get("format") != DELTA_FORMAT
                    or int(delta.get("txid", -1)) != tx + 1
                    or int(delta.get("base_txid", -1)) != tx
                ):
                    return False
                meta = _apply_metadata_delta(meta, delta)
                tx += 1
                last_commit_sector = sec

            if tx != txid_final or last_commit_sector != int(a["last_commit_sector"]):
                return False

            self.meta = meta
            self.txid = tx
            self.last_commit_sector = last_commit_sector
            self.highwater = highwater
            self.last_full_commit_sector = full_sector
            self.last_full_txid = full_txid
            self.delta_commit_sectors = delta_sectors
            self.recovery_mode = "fast_clean_anchor"
            return True
        except Exception:
            return False

    def _physical_highwater(self):
        """Return first never-written sector using the append-only dense-prefix invariant.

        B.24.3+ allocates physical sectors monotonically. A crash may leave a
        prefix of encrypted orphan sectors after the last authenticated commit,
        but it cannot create a valid later allocation beyond the first unwritten
        sector. Scan generation counters with ONE open file handle and stop at
        the first zero generation.
        """
        with open(self.path, "rb", buffering=0) as f:
            for i in range(self.sector_count):
                f.seek(vault._record_offset(i))
                raw = f.read(vault.GEN_SIZE)
                if len(raw) != vault.GEN_SIZE:
                    raise ValueError("truncated vault sector record")
                if int.from_bytes(raw, "big") == 0:
                    return i
        return self.sector_count

    def _recover(self):
        anchor = self._read_clean_anchor()
        if anchor is not None and self._recover_from_anchor(anchor):
            return

        self.recovery_mode = "full_crash_scan"
        physical_highwater = self._physical_highwater()
        full = {}
        deltas = {}

        for i in range(physical_highwater):
            pt = self._read_sector_safe(i)
            if pt is None:
                continue
            c = _commit_unpack(pt)
            if c is not None:
                doc = self._recover_metadata(c)
                if doc is not None:
                    full[int(c["txid"])] = (i, c, doc)
                continue
            dc = _delta_commit_unpack(pt)
            if dc is not None:
                doc = self._recover_payload(dc)
                if doc is not None and doc.get("format") == DELTA_FORMAT and int(doc.get("txid",-1)) == int(dc["txid"]):
                    deltas[int(dc["txid"])] = (i, dc, doc)

        if full:
            base_txid = max(full)
            commit_sector, c, meta = full[base_txid]
            tx = base_txid
            last_commit_sector = commit_sector
            delta_chain = []
            while (tx + 1) in deltas:
                dsector, dc, delta = deltas[tx + 1]
                if int(delta.get("base_txid",-1)) != tx:
                    break
                try:
                    meta = _apply_metadata_delta(meta, delta)
                except Exception:
                    break
                tx += 1
                last_commit_sector = dsector
                delta_chain.append(dsector)
            self.meta = meta
            self.txid = tx
            self.last_commit_sector = last_commit_sector
            self.highwater = physical_highwater
            self.last_full_commit_sector = commit_sector
            self.last_full_txid = base_txid
            self.delta_commit_sectors = delta_chain
        else:
            self.highwater = physical_highwater

    def _ensure_read_context(self):
        if self._read_fp is None or self._read_fp.closed:
            self._read_fp = open(self.path, "rb", buffering=0)
        if self._read_vault_id is None:
            self._read_vault_id = vault.b64d(self.header["vault_id_b64"])
        if self._read_storage_key is None:
            self._read_storage_key = vault.derive_storage_key(self.key, self._read_vault_id)
        if self._read_aesgcm is None:
            self._read_aesgcm = vault.AESGCM(self._read_storage_key)

    def close_read_context(self):
        if self._read_fp is not None:
            try:
                self._read_fp.close()
            except Exception:
                pass
        self._read_fp = None
        self._read_storage_key = None
        self._read_vault_id = None
        self._read_aesgcm = None

    def _read_sector_fast(self, index):
        self._ensure_read_context()
        f = self._read_fp
        f.seek(vault._record_offset(index))
        gen_raw = f.read(vault.GEN_SIZE)
        if len(gen_raw) != vault.GEN_SIZE:
            raise ValueError("truncated vault sector record")
        gen = int.from_bytes(gen_raw, "big")
        if gen == 0:
            return b"\x00" * BLOCK_SIZE
        ct = f.read(BLOCK_SIZE + vault.TAG_SIZE)
        if len(ct) != BLOCK_SIZE + vault.TAG_SIZE:
            raise ValueError("truncated vault sector ciphertext")
        nonce = vault._sector_nonce(self._read_storage_key, self._read_vault_id, index, gen)
        aad = vault._sector_aad(self.header, index, gen)
        return self._read_aesgcm.decrypt(nonce, ct, aad)

    def stats(self):
        """Fast O(1) operational stats for GUI/WinFsp hot paths."""
        used = int(self.highwater)
        return {
            "version": VERSION,
            "txid": self.txid,
            "highwater": self.highwater,
            "last_commit_sector": self.last_commit_sector,
            "used_physical_sectors": used,
            "free_physical_sectors": max(0, self.sector_count - used),
            "max_generation": 1 if used else 0,
            "all_written_sectors_generation_one": True,
            "stats_mode": "fast_append_only",
            "recovery_mode": self.recovery_mode,
        }

    def deep_stats(self):
        """Expensive full physical verification. Never call from WinFsp callbacks."""
        generations = []
        used = 0
        for i in range(self.sector_count):
            g = vault._current_generation(self.path, i)
            if g:
                used += 1
                generations.append(g)
        return {
            "version": VERSION,
            "txid": self.txid,
            "highwater": self.highwater,
            "last_commit_sector": self.last_commit_sector,
            "used_physical_sectors": used,
            "free_physical_sectors": self.sector_count - used,
            "max_generation": max(generations) if generations else 0,
            "all_written_sectors_generation_one": all(g == 1 for g in generations),
            "stats_mode": "deep_scan",
        }

    def _alloc(self, n=1):
        n = int(n)
        if n <= 0:
            raise ValueError("allocation size must be positive")
        if self.highwater + n > self.sector_count:
            raise OSError("Entropic Vault physical log is full")

        start = self.highwater

        # Defensive invariant check in one handle. Under normal operation every
        # sector at/after highwater is zero. If this ever fails, advance over
        # the already-written contiguous tail rather than reusing it.
        with open(self.path, "rb", buffering=0) as f:
            while start + n <= self.sector_count:
                collision = None
                for i in range(start, start + n):
                    f.seek(vault._record_offset(i))
                    raw = f.read(vault.GEN_SIZE)
                    if len(raw) != vault.GEN_SIZE:
                        raise ValueError("truncated vault sector record")
                    if int.from_bytes(raw, "big") != 0:
                        collision = i
                        break
                if collision is None:
                    self.highwater = start + n
                    return start
                start = collision + 1

        raise OSError("Entropic Vault physical log is full")


    def _commit(self, new_meta, *, fault_stage=None):
        self.close_read_context()
        txid = self.txid + 1
        new_meta["txid"] = txid

        write_full = (self.txid == 0) or (txid % CHECKPOINT_INTERVAL == 0)
        if write_full:
            payload_obj = new_meta
        else:
            payload_obj = _metadata_delta(self.meta, new_meta, txid)

        raw = _canonical(payload_obj)
        digest = hashlib.sha256(raw).digest()
        count = max(1, (len(raw) + META_PAYLOAD - 1) // META_PAYLOAD)
        meta_start = self._alloc(count)
        for j in range(count):
            chunk = raw[j*META_PAYLOAD:(j+1)*META_PAYLOAD]
            _write_once(self.path, self.key, meta_start+j, _meta_pack(txid, j, count, len(raw), digest, chunk))
        _fsync_container(self.path)

        if fault_stage == "after_metadata_before_commit":
            raise RuntimeError("INJECTED_CRASH_AFTER_METADATA_BEFORE_COMMIT")

        commit_sector = self._alloc(1)
        packer = _commit_pack if write_full else _delta_commit_pack
        _write_once(self.path, self.key, commit_sector, packer(
            txid, meta_start, count, len(raw), digest, commit_sector + 1
        ))
        _fsync_container(self.path)

        if fault_stage == "after_commit":
            raise RuntimeError("INJECTED_CRASH_AFTER_COMMIT")

        self.meta = new_meta
        self.txid = txid
        self.last_commit_sector = commit_sector
        self.highwater = commit_sector + 1
        if write_full:
            self.last_full_commit_sector = commit_sector
            self.last_full_txid = txid
            self.delta_commit_sectors = []
        else:
            self.delta_commit_sectors.append(commit_sector)

    def _active_meta(self):
        return self.pending_meta if self.pending_meta is not None else self.meta

    def _entry(self, path):
        try:
            return self._active_meta()["entries"][path]
        except KeyError:
            raise FileNotFoundError(path)

    def list_entries(self):
        return copy.deepcopy(self._active_meta()["entries"])

    def _ensure_pending(self):
        if self.pending_meta is None:
            self.pending_meta = copy.deepcopy(self.meta)
        return self.pending_meta

    def flush_pending(self):
        """Durably commit all buffered file writes as one filesystem transaction."""
        if self.pending_meta is None:
            return False
        if self.pending_data_dirty:
            _fsync_container(self.path)
        pending = self.pending_meta
        self.pending_meta = None
        self.pending_data_dirty = False
        self._commit(pending)
        return True

    def discard_pending(self):
        """Drop uncommitted metadata. Fresh encrypted data sectors become orphaned."""
        self.pending_meta = None
        self.pending_data_dirty = False

    def create_entry(self, path, kind, attributes=0, times=None):
        self.flush_pending()
        if path in self.meta["entries"]:
            raise FileExistsError(path)
        m = copy.deepcopy(self.meta)
        now = int(times or 0)
        m["entries"][path] = {
            "inode": m["next_inode"],
            "kind": kind,
            "attributes": int(attributes),
            "creation_time": now,
            "last_access_time": now,
            "last_write_time": now,
            "change_time": now,
            "size": 0,
            "extents": [],
        }
        m["next_inode"] += 1
        self._commit(m)

    def delete_entry(self, path):
        self.flush_pending()
        if path == "\\":
            raise PermissionError("cannot delete root")
        m = copy.deepcopy(self.meta)
        if path not in m["entries"]:
            raise FileNotFoundError(path)
        del m["entries"][path]
        self._commit(m)

    def rename_prefix(self, old, new):
        self.flush_pending()
        m = copy.deepcopy(self.meta)
        entries = m["entries"]
        if old not in entries:
            raise FileNotFoundError(old)
        moved = {}
        prefix = old.rstrip("\\") + "\\"
        for p in list(entries):
            if p == old or p.startswith(prefix):
                suffix = p[len(old):]
                moved[new + suffix] = entries.pop(p)
        entries.update(moved)
        self._commit(m)

    def update_entry(self, path, **fields):
        self.flush_pending()
        m = copy.deepcopy(self.meta)
        e = m["entries"][path]
        for k, v in fields.items():
            e[k] = v
        self._commit(m)

    def _read_block_from_entry(self, entry, lblock):
        mapping = _extent_map(entry.get("extents", []))
        p = mapping.get(lblock)
        if p is None:
            return b"\x00" * BLOCK_SIZE
        return self._read_sector_fast(p)

    def read_file(self, path, offset, length):
        e = self._entry(path)
        size = int(e["size"])
        offset = int(offset)
        length = int(length)
        if offset >= size or length <= 0:
            return b""
        end = min(size, offset + length)
        first = offset // BLOCK_SIZE
        last = (end - 1) // BLOCK_SIZE

        # B.24.8.1: the old path called _read_block_from_entry() for every
        # block. That helper rebuilt the ENTIRE extent map every time. For a
        # 100 MiB file (~25,600 blocks) this became effectively O(n^2).
        mapping = _extent_map(e.get("extents", []))

        out = bytearray()
        for lb in range(first, last + 1):
            p = mapping.get(lb)
            block = b"\x00" * BLOCK_SIZE if p is None else self._read_sector_fast(p)
            a = 0 if lb != first else offset % BLOCK_SIZE
            b = BLOCK_SIZE if lb != last else ((end - 1) % BLOCK_SIZE) + 1
            out.extend(block[a:b])
        return bytes(out)

    def write_file(self, path, offset, data: bytes, *, append=False, fault_stage=None):
        m = copy.deepcopy(self.meta)
        e = m["entries"][path]
        if e["kind"] != "file":
            raise IsADirectoryError(path)
        if append:
            offset = int(e["size"])
        if not data:
            return 0
        old_mapping = _extent_map(e.get("extents", []))
        new_mapping = dict(old_mapping)
        end = offset + len(data)
        first = offset // BLOCK_SIZE
        last = (end - 1) // BLOCK_SIZE
        pos = 0
        for lb in range(first, last + 1):
            old = self._read_block_from_entry(e, lb)
            block = bytearray(old)
            s = offset % BLOCK_SIZE if lb == first else 0
            t = min(BLOCK_SIZE, s + (len(data) - pos))
            take = t - s
            block[s:t] = data[pos:pos+take]
            pos += take
            p = self._alloc(1)
            _write_once(self.path, self.key, p, bytes(block))
            new_mapping[lb] = p
        _fsync_container(self.path)

        if fault_stage == "after_data_before_metadata":
            raise RuntimeError("INJECTED_CRASH_AFTER_DATA_BEFORE_METADATA")

        e["extents"] = _coalesce(new_mapping)
        e["size"] = max(int(e["size"]), end)
        self._commit(m, fault_stage=fault_stage)
        return len(data)

    def _write_new_blocks_batch(self, start_sector, blocks):
        """Write fresh COW sectors through one container handle.

        Each physical sector must still be generation 0. Encryption happens
        immediately before the ciphertext is written. This avoids thousands of
        open/read-header/open cycles during an ordinary Windows file copy.
        """
        if not blocks:
            return
        header = self.header
        vault_id = vault.b64d(header["vault_id_b64"])
        storage_key = vault.derive_storage_key(self.key, vault_id)
        with open(self.path, "r+b", buffering=0) as f:
            for j, plaintext in enumerate(blocks):
                index = start_sector + j
                if len(plaintext) != BLOCK_SIZE:
                    raise RuntimeError(
                        f"internal block-size invariant failed: got {len(plaintext)}, expected {BLOCK_SIZE}"
                    )
                f.seek(vault._record_offset(index))
                gen_raw = f.read(vault.GEN_SIZE)
                if len(gen_raw) != vault.GEN_SIZE:
                    raise ValueError("truncated vault sector record")
                if int.from_bytes(gen_raw, "big") != 0:
                    raise RuntimeError(f"B.24.5.4.1 refuses physical-sector reuse: {index}")
                pt = bytes(plaintext).ljust(BLOCK_SIZE, b"\x00")
                gen = 1
                nonce = vault._sector_nonce(storage_key, vault_id, index, gen)
                aad = vault._sector_aad(header, index, gen)
                ct = vault.AESGCM(storage_key).encrypt(nonce, pt, aad)
                if len(ct) != BLOCK_SIZE + vault.TAG_SIZE:
                    raise RuntimeError(
                        f"internal ciphertext-size invariant failed: got {len(ct)}"
                    )
                f.seek(vault._record_offset(index))
                f.write(gen.to_bytes(vault.GEN_SIZE, "big"))
                f.write(ct)

    def write_file_buffered(self, path, offset, data: bytes, *, append=False):
        """Encrypt immediately; commit the updated extent map on Flush/Close."""
        m = self._ensure_pending()
        e = m["entries"][path]
        if e["kind"] != "file":
            raise IsADirectoryError(path)
        if append:
            offset = int(e["size"])
        if not data:
            return 0

        mapping = _extent_map(e.get("extents", []))
        end = offset + len(data)
        first = offset // BLOCK_SIZE
        last = (end - 1) // BLOCK_SIZE
        count = last - first + 1
        blocks = []
        logical_blocks = []
        pos = 0

        for lb in range(first, last + 1):
            p_old = mapping.get(lb)
            if p_old is None:
                old = b"\x00" * BLOCK_SIZE
            else:
                old = vault.read_sector(self.path, self.key, p_old)
            block = bytearray(old)
            start = offset % BLOCK_SIZE if lb == first else 0
            take = min(BLOCK_SIZE - start, len(data) - pos)
            block[start:start+take] = data[pos:pos+take]
            pos += take
            blocks.append(bytes(block))
            logical_blocks.append(lb)

        # New COW data sectors are contiguous. Allocate once and write through
        # one container handle.
        pstart = self._alloc(count)
        self._write_new_blocks_batch(pstart, blocks)
        for j, lb in enumerate(logical_blocks):
            mapping[lb] = pstart + j

        e["extents"] = _coalesce(mapping)
        e["size"] = max(int(e["size"]), end)
        self.pending_data_dirty = True
        return len(data)

    def truncate_file(self, path, new_size):
        self.flush_pending()
        new_size = max(0, int(new_size))
        m = copy.deepcopy(self.meta)
        e = m["entries"][path]
        mapping = _extent_map(e.get("extents", []))
        keep_blocks = (new_size + BLOCK_SIZE - 1) // BLOCK_SIZE
        mapping = {lb:p for lb,p in mapping.items() if lb < keep_blocks}
        if new_size and new_size % BLOCK_SIZE and (keep_blocks - 1) in mapping:
            lb = keep_blocks - 1
            old = self._read_block_from_entry(e, lb)
            b = bytearray(old)
            b[new_size % BLOCK_SIZE:] = b"\x00" * (BLOCK_SIZE - (new_size % BLOCK_SIZE))
            p = self._alloc(1)
            _write_once(self.path, self.key, p, bytes(b))
            _fsync_container(self.path)
            mapping[lb] = p
        e["extents"] = _coalesce(mapping)
        e["size"] = new_size
        self._commit(m)

    def read_all(self, path):
        return self.read_file(path, 0, int(self._entry(path)["size"]))
