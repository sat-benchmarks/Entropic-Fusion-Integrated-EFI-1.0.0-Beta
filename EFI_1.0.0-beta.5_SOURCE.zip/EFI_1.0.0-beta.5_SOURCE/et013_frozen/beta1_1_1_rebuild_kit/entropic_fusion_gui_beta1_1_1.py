#!/usr/bin/env python3
"""
Entropic Fusion v0.11B.24.5 Windows GUI.

Product-integration layer over locked baselines:
- B.23.1 Fusion
- B.24.1 vault format
- B.24.2 WinFsp mount
- B.24.3 COW/crash consistency
- B.24.4.1 rekeying compaction

No cryptographic composition changes are introduced here.
"""
from __future__ import annotations

import hashlib
import json
import os
import string
import subprocess
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from entropic_fusion_gui_v0_11B_23_1 import App as LegacyApp
import entropic_vault_manager_v0_11B_24_1 as vault_manager
import entropic_vault_v0_11B_24_1 as vault_format
from entropic_mount_host_aclpipe_client_beta1_1_1 import (
    start_host, dismount_host, discover_hosts, command as host_command
)
from entropic_vault_compact_v0_11B_24_4_1 import compact_vault
from entropic_error_policy_beta1_1_1 import product_mount_error

VERSION = "Beta 1.1.1"

BG = "#F4F7FB"
PANEL = "#FFFFFF"

def storage_health_from_stats(stats: dict) -> dict:
    """
    Convert append-only physical-log counters into product-facing storage health.
    This is not logical file usage. Deletes and rewrites can leave old physical
    sectors consumed until a compact/rekey operation creates a fresh vault.
    """
    total = int(stats.get("used_physical_sectors", 0)) + int(stats.get("free_physical_sectors", 0))
    used = int(stats.get("used_physical_sectors", 0))
    free = int(stats.get("free_physical_sectors", 0))
    pct = (100.0 * used / total) if total > 0 else 0.0

    if total <= 0:
        level = "unknown"
        headline = "Storage health unavailable"
        advice = "Refresh after the vault is mounted."
    elif free <= 0 or pct >= 98.0:
        level = "critical"
        headline = "Physical log almost full"
        advice = "Dismount and compact/rekey this vault before adding more data."
    elif pct >= 90.0:
        level = "critical"
        headline = "Physical log critically low"
        advice = "Compact/rekey very soon. Deletes alone do not reclaim this append-only space."
    elif pct >= 80.0:
        level = "warning"
        headline = "Physical log getting full"
        advice = "Plan a compact/rekey soon to reclaim space consumed by old writes and deletes."
    else:
        level = "good"
        headline = "Physical log healthy"
        advice = "No maintenance is currently needed."

    return {
        "level": level,
        "headline": headline,
        "advice": advice,
        "used": used,
        "free": free,
        "total": total,
        "percent_used": pct,
    }

INK = "#172033"
MUTED = "#667085"
NAVY = "#14213D"
ACCENT = "#1877F2"
ACCENT_DARK = "#125DC0"
SUCCESS = "#15803D"
WARN = "#A16207"
DANGER = "#B42318"
BORDER = "#D8E0EA"

def human_size(n: int) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f} {unit}"
        n /= 1024

def free_drive_letters():
    out = []
    for letter in string.ascii_uppercase[::-1]:
        root = f"{letter}:\\"
        if not os.path.exists(root):
            out.append(f"{letter}:")
    return out

FILE_ATTRIBUTE_HIDDEN = 0x2
INVALID_FILE_ATTRIBUTES = 0xFFFFFFFF

def managed_vault_dir() -> Path:
    """Default product-managed location for physical .efv containers."""
    base = os.environ.get("LOCALAPPDATA")
    if base:
        return Path(base) / "Entropic Fusion" / "Vaults"
    return Path.home() / "AppData" / "Local" / "Entropic Fusion" / "Vaults"

def next_managed_vault_path(stem: str = "Entropic Vault") -> Path:
    root = managed_vault_dir()
    candidate = root / f"{stem}.efv"
    i = 2
    while candidate.exists():
        candidate = root / f"{stem} {i}.efv"
        i += 1
    return candidate

def is_vault_hidden(path: Path) -> bool:
    path = Path(path)
    if os.name != "nt" or not path.exists():
        return False
    import ctypes
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.GetFileAttributesW.argtypes = [ctypes.c_wchar_p]
    kernel32.GetFileAttributesW.restype = ctypes.c_uint32
    attrs = kernel32.GetFileAttributesW(str(path))
    if attrs == INVALID_FILE_ATTRIBUTES:
        raise ctypes.WinError(ctypes.get_last_error())
    return bool(attrs & FILE_ATTRIBUTE_HIDDEN)

def set_vault_hidden(path: Path, hidden: bool) -> bool:
    """Set only the Windows Hidden bit; this is a usability control, not an ACL."""
    path = Path(path)
    if os.name != "nt":
        return False
    if not path.exists():
        raise FileNotFoundError(path)
    import ctypes
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.GetFileAttributesW.argtypes = [ctypes.c_wchar_p]
    kernel32.GetFileAttributesW.restype = ctypes.c_uint32
    kernel32.SetFileAttributesW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32]
    kernel32.SetFileAttributesW.restype = ctypes.c_int
    attrs = kernel32.GetFileAttributesW(str(path))
    if attrs == INVALID_FILE_ATTRIBUTES:
        raise ctypes.WinError(ctypes.get_last_error())
    updated = (attrs | FILE_ATTRIBUTE_HIDDEN) if hidden else (attrs & ~FILE_ATTRIBUTE_HIDDEN)
    if not kernel32.SetFileAttributesW(str(path), updated):
        raise ctypes.WinError(ctypes.get_last_error())
    return bool(updated & FILE_ATTRIBUTE_HIDDEN)

def friendly_mount_error(err) -> str:
    # Final UI boundary. Never pass arbitrary exception text into a message box.
    return product_mount_error(err, type(err).__name__ if err is not None else None)

class PrettyApp(LegacyApp):
    def __init__(self):
        self._mounted_fs = None
        self._mounted_ops = None
        self._mounted_master_key = None
        self._mounted_host = None
        self._mounted_drive = None
        self._mounted_vault = None
        super().__init__()
        self.title(f"Entropic Fusion {VERSION}")
        self.geometry("1180x800")
        self.minsize(1020, 700)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(250, self._reattach_existing_host)

    def _configure_style(self):
        self.configure(bg=BG)
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure(".", font=("Segoe UI", 10))
        style.configure("App.TFrame", background=BG)
        style.configure("Panel.TFrame", background=PANEL, relief="flat")
        style.configure("Header.TFrame", background=NAVY)
        style.configure("Header.TLabel", background=NAVY, foreground="white")
        style.configure("Title.TLabel", background=NAVY, foreground="white",
                        font=("Segoe UI Semibold", 22))
        style.configure("SubTitle.TLabel", background=NAVY, foreground="#D8E4F4",
                        font=("Segoe UI", 10))
        style.configure("Section.TLabel", background=PANEL, foreground=INK,
                        font=("Segoe UI Semibold", 13))
        style.configure("CardTitle.TLabel", background=PANEL, foreground=INK,
                        font=("Segoe UI Semibold", 15))
        style.configure("Body.TLabel", background=PANEL, foreground=MUTED)
        style.configure("Muted.TLabel", background=BG, foreground=MUTED)
        style.configure("Good.TLabel", background=PANEL, foreground=SUCCESS,
                        font=("Segoe UI Semibold", 10))
        style.configure("Warn.TLabel", background=PANEL, foreground=WARN,
                        font=("Segoe UI Semibold", 10))
        style.configure("Danger.TLabel", background=PANEL, foreground=DANGER,
                        font=("Segoe UI Semibold", 10))

        style.configure("Accent.TButton", padding=(16, 10), font=("Segoe UI Semibold", 10))
        style.map("Accent.TButton",
                  background=[("active", ACCENT_DARK), ("!disabled", ACCENT)],
                  foreground=[("!disabled", "white")])
        style.configure("Soft.TButton", padding=(14, 9))
        style.configure("Danger.TButton", padding=(14, 9))
        style.map("Danger.TButton",
                  background=[("active", "#912018"), ("!disabled", DANGER)],
                  foreground=[("!disabled", "white")])

        # B.24.14.3 visual freeze: flatter application navigation.
        style.configure("Pretty.TNotebook", background=BG, borderwidth=0, tabmargins=(0, 0, 0, 0))
        style.configure(
            "Pretty.TNotebook.Tab",
            padding=(18, 11),
            font=("Segoe UI Semibold", 10),
            borderwidth=0,
            focuscolor=BG,
        )
        style.map(
            "Pretty.TNotebook.Tab",
            background=[
                ("selected", ACCENT),
                ("active", "#DDEBFF"),
                ("!selected", BG),
            ],
            foreground=[
                ("selected", "white"),
                ("active", ACCENT_DARK),
                ("!selected", MUTED),
            ],
        )
        style.configure("TEntry", padding=6)
        style.configure("TCombobox", padding=5)

    def _build(self):
        self._configure_style()

        shell = ttk.Frame(self, style="App.TFrame")
        shell.pack(fill="both", expand=True)

        header = ttk.Frame(shell, style="Header.TFrame", padding=(24, 18))
        header.pack(fill="x")

        left = ttk.Frame(header, style="Header.TFrame")
        left.pack(side="left", fill="x", expand=True)
        ttk.Label(left, text="Entropic Fusion", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            left,
            text="Encrypted vaults and files, protected through Entropic Fusion.",
            style="SubTitle.TLabel",
        ).pack(anchor="w", pady=(3, 0))

        right = ttk.Frame(header, style="Header.TFrame")
        right.pack(side="right")
        self.header_status = tk.StringVar(value="System ready")
        ttk.Label(right, textvariable=self.header_status, style="Header.TLabel").pack(
            side="left", padx=(0, 12)
        )
        ttk.Button(
            right,
            text="Help",
            command=self.show_help_dialog,
            style="Soft.TButton",
        ).pack(side="left")

        body = ttk.Frame(shell, style="App.TFrame", padding=(18, 14, 18, 10))
        body.pack(fill="both", expand=True)

        self.nb = ttk.Notebook(body, style="Pretty.TNotebook")
        self.nb.pack(fill="both", expand=True)

        self.t_vault_outer = ttk.Frame(self.nb, style="App.TFrame")
        self.vault_canvas = tk.Canvas(self.t_vault_outer, background=BG, highlightthickness=0)
        self.vault_scroll = ttk.Scrollbar(self.t_vault_outer, orient="vertical", command=self.vault_canvas.yview)
        self.vault_canvas.configure(yscrollcommand=self.vault_scroll.set)
        self.vault_scroll.pack(side="right", fill="y")
        self.vault_canvas.pack(side="left", fill="both", expand=True)
        self.t_vault = ttk.Frame(self.vault_canvas, padding=16, style="App.TFrame")
        self._vault_canvas_window = self.vault_canvas.create_window((0,0), window=self.t_vault, anchor="nw")
        self.t_vault.bind("<Configure>", lambda e: self.vault_canvas.configure(scrollregion=self.vault_canvas.bbox("all")))
        self.vault_canvas.bind("<Configure>", lambda e: self.vault_canvas.itemconfigure(self._vault_canvas_window, width=e.width))
        self.bind_all("<MouseWheel>", self._vault_mousewheel, add="+")
        self.t_enc = ttk.Frame(self.nb, padding=16)
        self.t_dec = ttk.Frame(self.nb, padding=16)
        self.t_id = ttk.Frame(self.nb, padding=16)
        self.t_keys = ttk.Frame(self.nb, padding=16)
        self.t_test = ttk.Frame(self.nb, padding=16)
        self.t_log = ttk.Frame(self.nb, padding=16)
        self.t_help = ttk.Frame(self.nb, padding=16)

        for tab, name in [
            (self.t_vault_outer, "Vault"),
            (self.t_enc, "Encrypt"),
            (self.t_dec, "Decrypt"),
            (self.t_id, "Identity"),
            (self.t_keys, "Key tools"),
            (self.t_test, "Self-test"),
            (self.t_log, "Activity"),
            (self.t_help, "Help"),
        ]:
            self.nb.add(tab, text=name)

        self._vault_tab()
        self.after(5000, self._storage_health_tick)
        # Reuse the already validated B.23.1 file-encryption/identity UI logic.
        self._encrypt()
        self._decrypt()
        self._identity()
        self._keytools()
        self._test()
        self._activity()
        self._help()

        footer = ttk.Frame(shell, style="App.TFrame", padding=(18, 0, 18, 12))
        footer.pack(fill="x")
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(footer, textvariable=self.status_var, style="Muted.TLabel").pack(side="left")
        ttk.Label(
            footer,
            text=f"Entropic Fusion {VERSION}  •  Vault engine B.24.10",
            style="Muted.TLabel",
        ).pack(side="right")

    def set_status(self, s: str):
        self.status_var.set(s)
        self.header_status.set(s)
        self.update_idletasks()

    def _card(self, parent, title, body):
        outer = ttk.Frame(parent, style="Panel.TFrame", padding=18)
        ttk.Label(outer, text=title, style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(
            outer, text=body, style="Body.TLabel", wraplength=470, justify="left"
        ).pack(anchor="w", pady=(5, 12))
        return outer

    def _path_row(self, parent, label, var, *, save=False, ext=None, directory=False):
        row = ttk.Frame(parent, style="Panel.TFrame")
        row.pack(fill="x", pady=4)
        ttk.Label(row, text=label, style="Body.TLabel", width=20).pack(side="left")
        ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True, padx=(8, 8))

        def choose():
            if directory:
                p = filedialog.askdirectory()
            elif save:
                kwargs = {}
                if ext:
                    kwargs["defaultextension"] = ext
                if ext == ".efv":
                    kwargs["initialfile"] = "Entropic Vault.efv"
                p = filedialog.asksaveasfilename(**kwargs)
            else:
                p = filedialog.askopenfilename()
            if p:
                var.set(p)
                self._refresh_vault_preview()

        ttk.Button(row, text="Browse", command=choose, style="Soft.TButton").pack(side="left")

    def _vault_mousewheel(self, event):
        """Scroll Vault only when the wheel event originates inside this window's Vault tab."""
        try:
            if event.widget.winfo_toplevel() is not self:
                return
            if self.nb.select() != str(self.t_vault_outer):
                return
            w = event.widget
            vault_prefix = str(self.t_vault_outer)
            if not str(w).startswith(vault_prefix):
                return
            self.vault_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            return "break"
        except Exception:
            return

    def _centre_modal(self, win, focus_widget=None):
        """Place modal over the main window, therefore on the same monitor."""
        self.update_idletasks()
        win.update_idletasks()
        ww, wh = win.winfo_reqwidth(), win.winfo_reqheight()
        px, py = self.winfo_rootx(), self.winfo_rooty()
        pw, ph = self.winfo_width(), self.winfo_height()
        x = px + max(0, (pw - ww) // 2)
        y = py + max(0, (ph - wh) // 2)
        win.geometry(f"+{x}+{y}")
        win.deiconify()
        win.lift(self)
        try:
            win.attributes("-topmost", True)
            win.after(250, lambda: win.attributes("-topmost", False))
        except Exception:
            pass
        if focus_widget is not None:
            win.after(80, focus_widget.focus_force)

    def ask_password_once(self, title="Private identity password", prompt="Enter password:"):
        win=tk.Toplevel(self)
        win.withdraw()
        win.title(title); win.transient(self); win.resizable(False,False)
        ttk.Label(win,text=prompt,padding=(14,14,14,6)).pack(anchor="w")
        value=tk.StringVar()
        entry=ttk.Entry(win,textvariable=value,show="*",width=34)
        entry.pack(padx=14,pady=(0,8))
        result={"value":None}
        bf=ttk.Frame(win,padding=(14,4,14,14)); bf.pack(fill="x")
        def ok():
            result["value"]=value.get(); win.destroy()
        def cancel():
            result["value"]=None; win.destroy()
        ttk.Button(bf,text="Cancel",command=cancel).pack(side="right",padx=(6,0))
        ttk.Button(bf,text="OK",command=ok).pack(side="right")
        win.protocol("WM_DELETE_WINDOW",cancel)
        win.bind("<Return>",lambda _e:ok()); win.bind("<Escape>",lambda _e:cancel())
        self._centre_modal(win, entry)
        win.grab_set()
        self.wait_window(win)
        return result["value"]

    def ask_password_pair(self, title="Private vault password", prompt="Choose a password (minimum 10 characters):"):
        win=tk.Toplevel(self)
        win.withdraw()
        win.title(title); win.transient(self); win.resizable(False,False)
        ttk.Label(win,text=prompt,padding=(14,14,14,6)).grid(row=0,column=0,columnspan=2,sticky="w")
        ttk.Label(win,text="Password:",padding=(14,4,8,4)).grid(row=1,column=0,sticky="e")
        ttk.Label(win,text="Confirm:",padding=(14,4,8,4)).grid(row=2,column=0,sticky="e")
        p1=tk.StringVar(); p2=tk.StringVar()
        e1=ttk.Entry(win,textvariable=p1,show="*",width=34); e2=ttk.Entry(win,textvariable=p2,show="*",width=34)
        e1.grid(row=1,column=1,padx=(0,14),pady=4); e2.grid(row=2,column=1,padx=(0,14),pady=4)
        result={"value":None}; err=tk.StringVar(value="")
        ttk.Label(win,textvariable=err,padding=(14,4,14,4)).grid(row=3,column=0,columnspan=2,sticky="w")
        def ok():
            if len(p1.get()) < 10:
                err.set("Password must be at least 10 characters."); return
            if p1.get() != p2.get():
                err.set("Passwords do not match."); return
            result["value"]=p1.get(); win.destroy()
        def cancel():
            result["value"]=None; win.destroy()
        bf=ttk.Frame(win,padding=(14,6,14,14)); bf.grid(row=4,column=0,columnspan=2,sticky="e")
        ttk.Button(bf,text="Cancel",command=cancel).pack(side="right",padx=(6,0))
        ttk.Button(bf,text="OK",command=ok).pack(side="right")
        win.protocol("WM_DELETE_WINDOW",cancel)
        win.bind("<Return>",lambda _e:ok()); win.bind("<Escape>",lambda _e:cancel())
        self._centre_modal(win, e1)
        win.grab_set()
        self.wait_window(win)
        return result["value"]

    def _reattach_existing_host(self):
        try:
            hosts = discover_hosts()
            if not hosts or self._mounted_host is not None:
                return
            state = hosts[0]
            self._mounted_host = state
            self._mounted_drive = state.get("drive")
            self._mounted_vault = state.get("vault")
            self.v_vault.set(self._mounted_vault or "")
            self.v_priv.set(state.get("private_identity") or "")
            self.v_drive.set(self._mounted_drive or "")
            self.mount_btn.configure(state="disabled")
            self.dismount_btn.configure(state="normal")
            self.mount_state.set(
                f"Mounted as {self._mounted_drive}   •   Fusion active   •   "
                f"{state.get('ef_equations_verified')} live EF equations"
            )
            self._set_mount_light("green", f"Mounted as {self._mounted_drive} — host reattached")
            self.set_status(f"Reattached {self._mounted_drive}")
            self.log(f"Reattached to isolated mount host PID {state.get('pid')}")
            self._refresh_vault_preview()
        except Exception as exc:
            self.log(f"Mount-host discovery: {exc}")

    def _vault_tab(self):
        top = ttk.Frame(self.t_vault, style="App.TFrame")
        top.pack(fill="x")

        ttk.Label(
            top, text="Entropic Vault", font=("Segoe UI Semibold", 20),
            background=BG, foreground=INK
        ).pack(anchor="w")
        ttk.Label(
            top,
            text="First time? Create an identity, then create a vault. After that, just mount and use it like a normal drive.",
            style="Muted.TLabel",
        ).pack(anchor="w", pady=(3, 12))

        # Very obvious first-time strip.
        first = ttk.Frame(self.t_vault, style="Panel.TFrame", padding=16)
        first.pack(fill="x", pady=(0, 12))
        ttk.Label(first, text="FIRST TIME SETUP", style="Section.TLabel").pack(anchor="w")
        ttk.Label(
            first,
            text="1  Create an Identity   →   2  Create a Vault   →   3  Mount the Vault",
            style="Body.TLabel",
        ).pack(anchor="w", pady=(5, 8))
        ttk.Label(
            first,
            text="Your Identity creates two files: a public .efpub file and your private .efprivx file. "
                 "Use the public file to create the vault. Use the private file later to unlock it.",
            style="Body.TLabel", wraplength=980, justify="left"
        ).pack(anchor="w")
        ttk.Button(
            first, text="Step 1: Go to Identity",
            command=lambda: self.nb.select(self.t_id),
            style="Soft.TButton"
        ).pack(anchor="w", pady=(10, 0))

        grid = ttk.Frame(self.t_vault, style="App.TFrame")
        grid.pack(fill="both", expand=True)
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)

        # LEFT: create first, because that is the first-time user's path.
        left = ttk.Frame(grid, style="App.TFrame")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        create = self._card(
            left,
            "Step 2: Create a new vault",
            "Already made your Identity? Choose its PUBLIC .efpub file, choose a vault filename and size, then click Create vault.",
        )
        create.pack(fill="x", pady=(0, 10))
        self.c_pub = tk.StringVar()
        self.c_out = tk.StringVar(value=str(next_managed_vault_path()))
        self.c_hide = tk.BooleanVar(value=True)
        self.c_size = tk.StringVar(value="1024")
        self.c_unit = tk.StringVar(value="MiB")
        self.c_label = tk.StringVar(value="Entropic Vault")

        self._path_row(create, "Public Identity (.efpub)", self.c_pub)
        ttk.Label(
            create,
            text="This is the public file made in the Identity tab. It is safe to share and does not unlock the vault.",
            style="Body.TLabel", wraplength=470, justify="left"
        ).pack(anchor="w", padx=(0, 0), pady=(0, 5))
        self._path_row(create, "Save vault as (.efv)", self.c_out, save=True, ext=".efv")

        managed_row = ttk.Frame(create, style="Panel.TFrame")
        managed_row.pack(fill="x", pady=(3, 5))
        ttk.Button(
            managed_row, text="Use managed location",
            command=self.use_managed_vault_location, style="Soft.TButton"
        ).pack(side="left")
        ttk.Checkbutton(
            managed_row, text="Hide physical vault file", variable=self.c_hide
        ).pack(side="left", padx=(12, 0))
        ttk.Label(
            create,
            text="Managed vaults are stored under your Windows profile. Hiding is a convenience feature, not an access-control boundary.",
            style="Body.TLabel", wraplength=470, justify="left"
        ).pack(anchor="w", pady=(0, 5))

        sz = ttk.Frame(create, style="Panel.TFrame")
        sz.pack(fill="x", pady=4)
        ttk.Label(sz, text="Vault size", style="Body.TLabel", width=20).pack(side="left")
        ttk.Entry(sz, textvariable=self.c_size, width=12).pack(side="left", padx=(8, 6))
        ttk.Combobox(
            sz, textvariable=self.c_unit, state="readonly", values=("MiB", "GiB"), width=7
        ).pack(side="left")

        lr = ttk.Frame(create, style="Panel.TFrame")
        lr.pack(fill="x", pady=4)
        ttk.Label(lr, text="Name shown in Windows", style="Body.TLabel", width=20).pack(side="left")
        ttk.Entry(lr, textvariable=self.c_label).pack(
            side="left", fill="x", expand=True, padx=(8, 0)
        )
        ttk.Button(
            create, text="Create vault", command=self.do_create_vault, style="Accent.TButton"
        ).pack(anchor="w", pady=(10, 0))

        mount = self._card(
            left,
            "Step 3: Mount and use your vault",
            "Choose the .efv vault you created and your PRIVATE .efprivx identity. "
            "Mount it, enter your password, and it appears in Windows as a normal drive.",
        )
        mount.pack(fill="x", pady=(0, 10))

        self.v_vault = tk.StringVar()
        self.v_priv = tk.StringVar()
        self.v_drive = tk.StringVar()
        self._path_row(mount, "Vault file (.efv)", self.v_vault)
        self._path_row(mount, "Private Identity (.efprivx)", self.v_priv)

        vault_file_row = ttk.Frame(mount, style="Panel.TFrame")
        vault_file_row.pack(fill="x", pady=(4, 5))
        self.v_hide_physical = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            vault_file_row, text="Hide physical vault file",
            variable=self.v_hide_physical, command=self.apply_selected_vault_visibility
        ).pack(side="left")
        ttk.Button(
            vault_file_row, text="Show vault location",
            command=self.show_selected_vault_location, style="Soft.TButton"
        ).pack(side="left", padx=(10, 0))

        drive_row = ttk.Frame(mount, style="Panel.TFrame")
        drive_row.pack(fill="x", pady=4)
        ttk.Label(drive_row, text="Windows drive letter", style="Body.TLabel", width=20).pack(side="left")
        self.drive_combo = ttk.Combobox(
            drive_row, textvariable=self.v_drive, state="readonly", width=8
        )
        self.drive_combo.pack(side="left", padx=(8, 8))
        ttk.Button(
            drive_row, text="Refresh", command=self._refresh_drives, style="Soft.TButton"
        ).pack(side="left")

        btns = ttk.Frame(mount, style="Panel.TFrame")
        btns.pack(fill="x", pady=(10, 0))
        self.mount_btn = ttk.Button(
            btns, text="Mount vault", command=self.do_mount_vault, style="Accent.TButton"
        )
        self.mount_btn.pack(side="left")
        self.dismount_btn = ttk.Button(
            btns, text="Dismount", command=self.do_dismount_vault,
            style="Danger.TButton", state="disabled"
        )
        self.dismount_btn.pack(side="left", padx=(8, 0))

        lightrow = ttk.Frame(mount, style="Panel.TFrame")
        lightrow.pack(fill="x", pady=(10, 0))
        self.mount_light = ttk.Label(lightrow, text="●", font=("Segoe UI", 16), foreground="#D92D20", background=PANEL)
        self.mount_light.pack(side="left")
        self.mount_light_text = tk.StringVar(value="Vault is locked / not mounted")
        ttk.Label(lightrow, textvariable=self.mount_light_text, style="Body.TLabel").pack(side="left", padx=(6,0))
        self.mount_state = tk.StringVar(value="Not mounted")

        # RIGHT: status and maintenance.
        right = ttk.Frame(grid, style="App.TFrame")
        right.grid(row=0, column=1, sticky="nsew", padx=(8, 0))

        status = self._card(
            right,
            "Vault status",
            "A quick view of the selected or currently mounted vault.",
        )
        status.pack(fill="x", pady=(0, 10))

        self.v_status_title = tk.StringVar(value="No vault selected")
        self.v_status_detail = tk.StringVar(
            value="Choose an .efv file on the left to inspect its public header."
        )
        ttk.Label(status, textvariable=self.v_status_title, style="Section.TLabel").pack(anchor="w")
        ttk.Label(
            status, textvariable=self.v_status_detail, style="Body.TLabel",
            wraplength=470, justify="left"
        ).pack(anchor="w", pady=(6, 10))
        ttk.Button(
            status, text="Inspect selected vault", command=self._refresh_vault_preview,
            style="Soft.TButton"
        ).pack(anchor="w")

        health = self._card(
            right,
            "Storage health",
            "Entropic Vault uses an append-only physical log. Rewriting or deleting files does not immediately reclaim old physical sectors.",
        )
        health.pack(fill="x", pady=(0, 10))

        self.v_storage_headline = tk.StringVar(value="Mount a vault to see storage health")
        self.v_storage_detail = tk.StringVar(
            value="The mounted host reports physical-log usage without scanning the whole vault."
        )
        ttk.Label(health, textvariable=self.v_storage_headline, style="Section.TLabel").pack(anchor="w")
        ttk.Label(
            health, textvariable=self.v_storage_detail, style="Body.TLabel",
            wraplength=470, justify="left"
        ).pack(anchor="w", pady=(6, 8))
        ttk.Button(
            health, text="Refresh storage health",
            command=self.refresh_storage_health, style="Soft.TButton"
        ).pack(side="left")
        ttk.Button(
            health, text="Prepare compaction",
            command=self.prepare_compaction_from_mounted, style="Soft.TButton"
        ).pack(side="left", padx=(8, 0))

        compact = self._card(
            right,
            "Compact / rekey",
            "Reclaims append-only physical space after lots of deleting or rewriting. It makes a fresh vault, keeps only "
            "the live files, uses a fresh key/vault ID, and leaves the old vault unchanged.",
        )
        compact.pack(fill="x", pady=(0, 10))

        self.x_src = tk.StringVar()
        self.x_dst = tk.StringVar()
        self.x_pub = tk.StringVar()
        self.x_priv = tk.StringVar()

        self._path_row(compact, "Old vault (.efv)", self.x_src)
        self._path_row(compact, "New vault (.efv)", self.x_dst, save=True, ext=".efv")
        self._path_row(compact, "Public Identity (.efpub)", self.x_pub)
        self._path_row(compact, "Private Identity (.efprivx)", self.x_priv)

        ttk.Button(
            compact, text="Compact and rekey", command=self.do_compact_vault,
            style="Accent.TButton"
        ).pack(anchor="w", pady=(10, 0))

        tips = self._card(
            right,
            "Everyday use",
            "Most days you only need two buttons:\n\n"
            "Mount vault  →  work normally in Windows  →  Dismount\n\n"
            "You do NOT create a new vault every time.",
        )
        tips.pack(fill="x")

        self._refresh_drives()

    def _set_mount_light(self, state, text=None):
        colors = {"red": "#D92D20", "yellow": "#F5A524", "green": "#12B76A"}
        if hasattr(self, "mount_light"):
            self.mount_light.configure(foreground=colors.get(state, colors["red"]))
        if text is not None and hasattr(self, "mount_light_text"):
            self.mount_light_text.set(text)

    def _identity(self):
        ttk.Label(self.t_id, text="Create your Entropic Identity", font=("Segoe UI Semibold", 16)).pack(anchor="w")
        ttk.Label(
            self.t_id,
            text="Choose one name and one folder. Entropic Fusion creates the three identity files for you and will NOT overwrite existing files.",
            wraplength=930
        ).pack(anchor="w", pady=(3,10))

        self.id_name = tk.StringVar(value="My Entropic Identity")
        self.id_folder = tk.StringVar(value=str(Path.home() / "Documents"))
        self.id_pub = tk.StringVar()
        self.id_priv = tk.StringVar()
        self.id_vault = tk.StringVar()
        self.id_seed=tk.StringVar(value="20270851"); self.id_path=tk.StringVar(value="6"); self.id_decoys=tk.StringVar(value="64")

        f=ttk.Frame(self.t_id); f.pack(fill="x",pady=4)
        ttk.Label(f,text="Identity name",width=26).pack(side="left")
        ent=ttk.Entry(f,textvariable=self.id_name); ent.pack(side="left",fill="x",expand=True,padx=6)
        ent.bind("<KeyRelease>", lambda _e:self._update_identity_paths())

        f=ttk.Frame(self.t_id); f.pack(fill="x",pady=4)
        ttk.Label(f,text="Save folder",width=26).pack(side="left")
        ttk.Entry(f,textvariable=self.id_folder).pack(side="left",fill="x",expand=True,padx=6)
        def choose_folder():
            q=filedialog.askdirectory(initialdir=self.id_folder.get() or str(Path.home()))
            if q:
                self.id_folder.set(q); self._update_identity_paths()
        ttk.Button(f,text="Browse",command=choose_folder).pack(side="left")

        self.id_paths_preview=tk.StringVar()
        ttk.Label(self.t_id,textvariable=self.id_paths_preview,wraplength=930,justify="left").pack(anchor="w",pady=(8,8))

        ttk.Label(
            self.t_id,
            text="PUBLIC .efpub: safe to share.   PRIVATE .efprivx: keep secret; this unlocks your vaults.",
            wraplength=930
        ).pack(anchor="w",pady=(0,8))

        f=ttk.Frame(self.t_id); f.pack(fill="x",pady=6)
        for lab,var,w in [("Seed",self.id_seed,14),("Path",self.id_path,7),("Decoys",self.id_decoys,7)]:
            ttk.Label(f,text=lab).pack(side="left",padx=(0,4)); ttk.Entry(f,textvariable=var,width=w).pack(side="left",padx=(0,18))

        ttk.Button(self.t_id,text="Create Identity",command=self.do_id,style="Accent.TButton").pack(anchor="w",pady=8)
        self.id_detail=tk.Text(self.t_id,height=12,wrap="word"); self.id_detail.pack(fill="both",expand=True)
        self._update_identity_paths()

    def _update_identity_paths(self):
        name = (self.id_name.get().strip() or "My Entropic Identity").replace("/","_").replace("\\\\","_")
        folder = Path(self.id_folder.get() or str(Path.home()/"Documents"))
        self.id_pub.set(str(folder / f"{name}.efpub"))
        self.id_priv.set(str(folder / f"{name}.efpriv"))
        self.id_vault.set(str(folder / f"{name}.efprivx"))
        if hasattr(self,"id_paths_preview"):
            self.id_paths_preview.set(
                f"Will create:\n{name}.efpub\n{name}.efpriv\n{name}.efprivx"
            )

    def do_id(self):
        self._update_identity_paths()
        pub, priv, vault = Path(self.id_pub.get()), Path(self.id_priv.get()), Path(self.id_vault.get())
        folder = pub.parent
        if not folder.exists():
            return messagebox.showerror("Identity", "Choose an existing save folder.")
        existing=[x for x in (pub,priv,vault) if x.exists()]
        if existing:
            return messagebox.showerror(
                "Identity files already exist",
                "Entropic Fusion will not overwrite identity files.\n\nAlready exists:\n" +
                "\n".join(x.name for x in existing) +
                "\n\nChoose a different Identity name or folder."
            )
        pw = self.ask_password_pair(
            "Protect private identity",
            "Choose a password for your private .efprivx identity (minimum 10 characters):"
        )
        if pw is None: return
        self.set_status("Creating identity… this can take a little while")
        def job():
            r=generate_identity(pub,priv,seed=int(self.id_seed.get()),path_length=int(self.id_path.get()),decoys=int(self.id_decoys.get()))
            v=protect_private_identity(priv,vault,pw)
            return r,v
        def done(rv,e):
            if e:
                self.set_status("Identity generation failed"); self.log(f"ERROR identity: {e}"); return messagebox.showerror("Identity",str(e))
            r,v=rv
            try: os.chmod(priv,0o600)
            except Exception: pass
            detail={
                "public_fingerprint_sha256": fingerprint(pub),
                "public_fingerprint_display": display_fingerprint(pub),
                "protected_private_vault_sha256": fingerprint(vault),
                "public_identity_sha256": r.get("public_identity_sha256"),
                "public_file": str(pub),
                "private_file": str(vault),
                "warning": "The raw .efpriv file still exists. Store it securely or delete it after verifying the .efprivx vault."
            }
            self.id_detail.delete("1.0","end"); self.id_detail.insert("end",json.dumps(detail,indent=2))
            if hasattr(self,"c_pub"): self.c_pub.set(str(pub))
            if hasattr(self,"v_priv"): self.v_priv.set(str(vault))
            self.set_status("Identity ready")
            self.log("Identity generated. Existing files were not overwritten.")
            messagebox.showinfo("Identity ready", f"Created:\n{pub.name}\n{vault.name}\n\nThe Vault tab has been pre-filled for you.")
        self._run("Creating identity… please wait",job,done)

    def use_managed_vault_location(self):
        self.c_out.set(str(next_managed_vault_path()))
        self.c_hide.set(True)

    def _selected_physical_vault(self):
        candidate = self._mounted_vault or self.v_vault.get() or self.c_out.get() or self.x_src.get()
        return Path(candidate) if candidate else None

    def _sync_selected_vault_visibility(self, path=None):
        try:
            p = Path(path) if path else self._selected_physical_vault()
            if p is not None and p.exists():
                self.v_hide_physical.set(is_vault_hidden(p))
        except Exception as exc:
            self.log(f"Vault visibility status unavailable: {exc}")

    def apply_selected_vault_visibility(self):
        p = self._selected_physical_vault()
        if p is None or not p.exists():
            self.v_hide_physical.set(False)
            return messagebox.showinfo("Vault file visibility", "Choose an existing .efv vault first.")
        try:
            hidden = set_vault_hidden(p, bool(self.v_hide_physical.get()))
            self.v_hide_physical.set(hidden)
            self.log(f"Vault file {'hidden' if hidden else 'revealed'}: {p.name}")
        except Exception as exc:
            self._sync_selected_vault_visibility(p)
            messagebox.showerror("Vault file visibility", f"Could not change the vault file visibility: {exc}")

    def show_selected_vault_location(self):
        p = self._selected_physical_vault()
        if p is None:
            return messagebox.showinfo("Vault location", "Choose a vault first.")
        folder = p.parent
        if not folder.exists():
            return messagebox.showinfo("Vault location", f"The folder does not exist yet:\n{folder}")
        try:
            os.startfile(str(folder))
        except Exception as exc:
            messagebox.showerror("Vault location", f"Could not open the vault folder: {exc}")

    def _refresh_drives(self):
        drives = free_drive_letters()
        self.drive_combo["values"] = drives
        if drives and self.v_drive.get() not in drives:
            self.v_drive.set(drives[0])

    def _refresh_vault_preview(self):
        candidate = self._mounted_vault or self.v_vault.get() or self.x_src.get()
        if not candidate:
            self.v_status_title.set("No vault selected")
            self.v_status_detail.set("Choose an .efv file to inspect its public header.")
            return
        p = Path(candidate)
        self._sync_selected_vault_visibility(p)
        try:
            h = vault_format.read_header(p)
            logical = int(h["sector_count"]) * int(h["sector_size"])
            lines = [
                f"{p.name}",
                f"Capacity: {human_size(logical)}",
                f"Container file: {human_size(p.stat().st_size)}",
                f"Sectors: {h['sector_count']:,} × {h['sector_size']:,} bytes",
            ]
            if self._mounted_vault and Path(self._mounted_vault) == p and self._mounted_host:
                resp = host_command(self._mounted_host, "status", timeout=1.0)
                st = resp["stats"]
                used = int(st["used_physical_sectors"]) * int(h["sector_size"])
                free = int(st["free_physical_sectors"]) * int(h["sector_size"])
                lines += [
                    f"Mounted as: {self._mounted_drive}",
                    f"Physical used: {human_size(used)}",
                    f"Physical free: {human_size(free)}",
                    f"Generation-one invariant: {'Yes' if st['all_written_sectors_generation_one'] else 'NO'}",
                ]
                self.v_status_title.set("Mounted and unlocked")
            else:
                self.v_status_title.set("Vault header looks readable")
            self.v_status_detail.set("\n".join(lines))
        except Exception as e:
            self.v_status_title.set("Cannot inspect vault")
            self.v_status_detail.set(str(e))

    def do_create_vault(self):
        try:
            pub = Path(self.c_pub.get())
            out = Path(self.c_out.get())
            if not pub.exists():
                raise ValueError("Choose an existing .efpub public identity.")
            if not str(out):
                raise ValueError("Choose where to save the new .efv vault.")
            if out.exists():
                raise ValueError(
                    f"{out.name} already exists. Entropic Fusion will not overwrite an existing vault. "
                    "Choose a different filename."
                )
            raw = float(self.c_size.get())
            if raw <= 0:
                raise ValueError("Vault size must be greater than zero.")
            mult = 1024 * 1024 if self.c_unit.get() == "MiB" else 1024 * 1024 * 1024
            size = int(raw * mult)
            label = self.c_label.get().strip() or "Entropic Vault"
        except Exception as e:
            return messagebox.showerror("Create vault", str(e))

        def job():
            managed = managed_vault_dir()
            if out.parent == managed:
                managed.mkdir(parents=True, exist_ok=True)
            if out.exists():
                out.unlink()
            result = vault_manager.create_fused_vault(pub, out, size, label)
            hidden = False
            if self.c_hide.get():
                hidden = set_vault_hidden(out, True)
            return result, hidden

        def done(result, err):
            if err:
                self.set_status("Vault creation failed")
                self.log(f"ERROR vault create: {err}")
                return messagebox.showerror("Create vault", str(err))
            _created, hidden = result
            self.v_vault.set(str(out))
            self.x_src.set(str(out))
            self.v_hide_physical.set(bool(hidden))
            self.set_status("Vault created")
            self.log(f"Created vault {out.name}")
            self._refresh_vault_preview()
            messagebox.showinfo(
                "Vault created",
                f"{out.name} is ready.\n\nYou can mount it from the Vault tab.",
            )

        self._run("Creating Fusion-protected vault...", job, done)

    def do_mount_vault(self):
        if self._mounted_host is not None:
            return messagebox.showinfo("Vault already mounted", "Dismount the current vault first.")

        vault_path = Path(self.v_vault.get())
        priv = Path(self.v_priv.get())
        drive = self.v_drive.get().strip()

        if not vault_path.exists():
            return messagebox.showerror("Mount vault", "Choose an existing .efv vault.")
        if not priv.exists():
            return messagebox.showerror("Mount vault", "Choose your .efprivx or .efpriv identity.")
        if not drive:
            return messagebox.showerror("Mount vault", "Choose a free drive letter.")

        password = None
        if priv.suffix.lower() == ".efprivx":
            password = self.ask_password_once("Unlock Entropic Vault", "Enter private identity password:")
            if password is None:
                return

        self.mount_btn.configure(state="disabled")
        self.dismount_btn.configure(state="disabled")
        self._set_mount_light("yellow", "Unlocking Fusion and starting isolated vault host… please wait")
        self.set_status("Starting isolated vault host…")

        def job():
            return start_host(vault_path, priv, drive, password)

        def done(state, err):
            self.mount_btn.configure(state="normal")
            if err:
                self._set_mount_light("red", "Mount failed / vault not mounted")
                self.set_status("Mount failed")
                friendly = friendly_mount_error(err)
                self.log(f"Mount failed: {friendly}")
                return messagebox.showerror("Mount vault", friendly)

            self._mounted_host = state
            self._mounted_drive = drive
            self._mounted_vault = str(vault_path)
            self.dismount_btn.configure(state="normal")
            self.mount_btn.configure(state="disabled")
            self.mount_state.set(
                f"Mounted as {drive}   •   Fusion active   •   "
                f"{state.get('ef_equations_verified')} live EF equations"
            )
            self._set_mount_light("green", f"Mounted as {drive} — isolated host active")
            self.set_status(f"Mounted {drive}")
            self.log(f"Mounted {vault_path.name} as {drive} in host PID {state.get('pid')}")
            self._refresh_vault_preview()
            self.refresh_storage_health(quiet=False)
            messagebox.showinfo(
                "Vault mounted",
                f"{vault_path.name} is mounted as {drive}\n\n"
                "The vault host is isolated from the Entropic Fusion window.",
            )

        self._run("Unlocking and mounting vault...", job, done)

    def do_dismount_vault(self):
        if self._mounted_host is None:
            return
        drive = self._mounted_drive
        state = self._mounted_host

        self.dismount_btn.configure(state="disabled")
        self._set_mount_light("yellow", f"Dismounting {drive}…")
        self.set_status("Dismounting vault…")

        def job():
            return dismount_host(state, timeout=20.0)

        def done(_result, err):
            if err:
                self.dismount_btn.configure(state="normal")
                self._set_mount_light("green", f"{drive} still mounted")
                self.set_status("Dismount failed")
                self.log(f"ERROR dismount host: {err}")
                return messagebox.showerror("Dismount", str(err))

            self._mounted_host = None
            self._mounted_fs = None
            self._mounted_ops = None
            self._mounted_master_key = None
            self._mounted_drive = None
            self._mounted_vault = None
            self.mount_btn.configure(state="normal")
            self.dismount_btn.configure(state="disabled")
            self.mount_state.set("Not mounted")
            self._set_mount_light("red", "Vault is locked / not mounted")
            self.set_status("Vault dismounted")
            self.log(f"Dismounted {drive}")
            self._refresh_drives()
            self._refresh_vault_preview()
            self.v_storage_headline.set("Mount a vault to see storage health")
            self.v_storage_detail.set(
                "The mounted host reports physical-log usage without scanning the whole vault."
            )

        self._run("Dismounting vault...", job, done)

    def _apply_storage_health(self, stats):
        h = storage_health_from_stats(stats or {})
        if h["level"] == "unknown":
            self.v_storage_headline.set(h["headline"])
            self.v_storage_detail.set(h["advice"])
            return h

        pct = h["percent_used"]
        self.v_storage_headline.set(f'{h["headline"]} — {pct:.1f}% consumed')
        self.v_storage_detail.set(
            f'Physical sectors used: {h["used"]:,} of {h["total"]:,}  •  '
            f'free: {h["free"]:,}\\n{h["advice"]}'
        )
        return h

    def refresh_storage_health(self, quiet=False):
        if self._mounted_host is None:
            self.v_storage_headline.set("Mount a vault to see storage health")
            self.v_storage_detail.set(
                "Storage health is available while a vault is mounted. "
                "This measures append-only physical-log consumption, not logical file size."
            )
            return

        try:
            resp = host_command(self._mounted_host, "status")
            if not resp.get("ok"):
                raise RuntimeError(resp.get("error", "host status failed"))
            h = self._apply_storage_health(resp.get("stats") or {})
            if not quiet and h["level"] in ("warning", "critical"):
                title = "Vault maintenance recommended" if h["level"] == "warning" else "Vault space critical"
                messagebox.showwarning(
                    title,
                    f'{h["headline"]}\\n\\n'
                    f'{h["percent_used"]:.1f}% of the physical log is consumed.\\n\\n'
                    f'{h["advice"]}'
                )
        except Exception as e:
            self.v_storage_headline.set("Storage health unavailable")
            self.v_storage_detail.set(str(e))
            if not quiet:
                messagebox.showerror("Storage health", str(e))

    def _storage_health_tick(self):
        try:
            if self._mounted_host is not None:
                self.refresh_storage_health(quiet=True)
        finally:
            try:
                self.after(5000, self._storage_health_tick)
            except Exception:
                pass

    def prepare_compaction_from_mounted(self):
        if self._mounted_host is None or not self._mounted_vault:
            return messagebox.showinfo(
                "Prepare compaction",
                "Mount the vault you want to maintain first."
            )

        src = Path(self._mounted_vault)
        self.x_src.set(str(src))
        priv = self._mounted_host.get("private_identity")
        if priv:
            self.x_priv.set(str(priv))

        candidate = src.with_name(src.stem + "_compacted.efv")
        i = 2
        while candidate.exists():
            candidate = src.with_name(f"{src.stem}_compacted_{i}.efv")
            i += 1
        self.x_dst.set(str(candidate))

        messagebox.showinfo(
            "Compaction prepared",
            "Source, private identity and a new destination filename have been filled in.\\n\\n"
            "Choose the matching public .efpub identity, dismount the vault, then click Compact and rekey.\\n\\n"
            "The original vault is never overwritten."
        )

    def do_compact_vault(self):
        src = Path(self.x_src.get())
        dst = Path(self.x_dst.get())
        pub = Path(self.x_pub.get())
        priv = Path(self.x_priv.get())

        if not src.exists():
            return messagebox.showerror("Compact vault", "Choose an existing source vault.")
        if not pub.exists():
            return messagebox.showerror("Compact vault", "Choose the recipient .efpub file.")
        if not priv.exists():
            return messagebox.showerror("Compact vault", "Choose the matching private identity.")
        if not str(dst):
            return messagebox.showerror("Compact vault", "Choose a new destination .efv file.")
        if dst.exists():
            return messagebox.showerror(
                "Compact vault",
                "The compacted destination must be a new file. Choose a filename that does not exist.",
            )
        if self._mounted_vault and Path(self._mounted_vault).resolve() == src.resolve():
            return messagebox.showerror(
                "Compact vault",
                "Dismount this vault before compacting it.",
            )

        password = None
        if priv.suffix.lower() == ".efprivx":
            password = self.ask_password_once("Compact / rekey vault", "Enter private identity password:")
            if password is None:
                return

        if not messagebox.askyesno(
            "Compact and rekey?",
            "A new vault will be created with a fresh master key and vault ID.\n\n"
            "The source vault will remain unchanged.\n\nContinue?",
        ):
            return

        def job():
            return compact_vault(src, dst, pub, priv, password)

        def done(result, err):
            if err:
                self.set_status("Compaction failed")
                self.log(f"ERROR compact: {err}")
                return messagebox.showerror("Compact vault", str(err))
            self.set_status("Compaction complete")
            self.log(f"Compacted {src.name} -> {dst.name}")
            oldn = result["source"]["stats"]["used_physical_sectors"]
            newn = result["destination"]["stats"]["used_physical_sectors"]
            reclaimed = oldn - newn
            messagebox.showinfo(
                "Compaction complete",
                f"New vault: {dst.name}\n\n"
                f"Physical sectors: {oldn:,} → {newn:,}\n"
                f"Reclaimed: {reclaimed:,} sectors\n\n"
                "The original vault was not changed.",
            )

        self._run("Compacting and rekeying vault...", job, done)

    def _current_help_section(self):
        """Return the Help section most relevant to the selected workspace."""
        try:
            selected = self.nametowidget(self.nb.select())
        except Exception:
            return "start"

        mapping = {
            getattr(self, "t_vault_outer", None): "vault",
            getattr(self, "t_enc", None): "encrypt",
            getattr(self, "t_dec", None): "decrypt",
            getattr(self, "t_id", None): "identity",
            getattr(self, "t_keys", None): "keys",
            getattr(self, "t_test", None): "check",
            getattr(self, "t_log", None): "activity",
            getattr(self, "t_help", None): "start",
            getattr(self, "t_home", None): "start",
        }
        return mapping.get(selected, "start")

    def show_help_dialog(self, section=None):
        """
        Open Help at the section that matches the current tab.

        Example:
        Encrypt tab + Help -> Encrypting a file.
        Vault tab + Help   -> Vaults.
        """
        if section is None:
            section = self._current_help_section()

        win = tk.Toplevel(self)
        win.title("Entropic Fusion - Help")
        win.transient(self)
        win.geometry("760x680")
        win.minsize(640, 540)
        win.configure(bg=BG)

        text = """ENTROPIC FUSION — HELP

GETTING STARTED

Entropic Fusion gives each user a public identity and a private identity.

• .efpub is PUBLIC. It is safe and intended to be shared.
• .efprivx is PRIVATE. It is password-protected and must be kept secret.

If two people want to exchange encrypted files, they can exchange .efpub files.
Each person then uses the OTHER PERSON'S .efpub when encrypting a file for them.

[[IDENTITY]]
CREATE YOUR IDENTITY

1. Open the Identity tab.
2. Choose a name and location.
3. Create the identity and choose a strong password.
4. Keep the .efprivx private.
5. Share only the .efpub public identity.

Keep a secure backup of your .efprivx. If it is lost, files encrypted to that
identity cannot be recovered.


[[ENCRYPT]]
ENCRYPT A FILE

Encryption is addressed to a recipient.

1. Obtain the recipient's .efpub public identity.
2. Open the Encrypt tab.
3. Choose the RECIPIENT'S .efpub file.
4. Choose the normal file you want to encrypt.
5. Choose where to save the new .efb encrypted file.
6. Check the recipient fingerprint if you have one to compare.
7. Click Encrypt.

The resulting .efb file can be sent, copied or stored normally. Only someone
with the matching private identity and password can use the normal decrypt path.

If you and another person both want to send encrypted files to one another,
exchange .efpub files. Never exchange .efprivx or .efpriv files.


[[DECRYPT]]
DECRYPT A FILE

1. Open the Decrypt tab.
2. Choose your .efprivx protected private identity.
3. Choose the .efb encrypted file.
4. Choose the destination folder.
5. Enter your identity password when prompted.
6. The original filename is restored automatically.

The encrypted file must have been created for the public identity matching your
private identity.


[[VAULT]]
VAULTS

Create a vault:
1. Open the Vault tab.
2. Choose your .efpub identity.
3. Choose where to save the new .efv vault.
4. Choose the vault size.
5. Click Create vault.

Open a vault:
1. Choose the .efv vault.
2. Choose the matching .efprivx identity.
3. Pick a free Windows drive letter.
4. Click Mount vault.
5. Enter your password.

The vault appears as a normal Windows drive. Use it normally, then click
Dismount when finished.


COMPACT / REKEY

Compact / Rekey is maintenance, not an everyday step. It creates a fresh vault
containing only the current live files, with a fresh master key and vault ID.
The source vault is left unchanged.


[[KEYS]]
PUBLIC KEYS, PRIVATE KEYS AND FINGERPRINTS

.efpub   Public identity. Safe and intended to share.
.efpriv  Raw private identity. Keep secret.
.efprivx Password-protected private identity. Preferred for normal use.
.efb     Encrypted single file.
.efv     Encrypted mounted vault.

A public identity does not need secrecy, but authenticity still matters.
When practical, compare the recipient fingerprint through a separate trusted
channel, such as in person or by reading it to each other.


[[CHECK]]
SYSTEM CHECK

The Self-test / Check area verifies important application components and the
local environment. If a check fails, note the message before continuing.


[[ACTIVITY]]
ACTIVITY

The Activity tab records operational events. It does not intentionally record
plaintext contents, passwords, private keys or shared secrets.


THE SIMPLE VERSION

To receive encrypted files:
Share your .efpub.

To send an encrypted file:
Use the recipient's .efpub.

To decrypt:
Use your matching .efprivx and password.

For an encrypted drive:
Create vault → Mount → Use → Dismount.
"""

        box = tk.Text(
            win,
            wrap="word",
            padx=18,
            pady=18,
            font=("Segoe UI", 10),
            borderwidth=0,
            background=PANEL,
            foreground=INK,
        )
        box.pack(fill="both", expand=True, padx=16, pady=(16, 8))

        # Convert lightweight section markers into Tk text marks.
        marker_map = {
            "[[IDENTITY]]": "identity",
            "[[ENCRYPT]]": "encrypt",
            "[[DECRYPT]]": "decrypt",
            "[[VAULT]]": "vault",
            "[[KEYS]]": "keys",
            "[[CHECK]]": "check",
            "[[ACTIVITY]]": "activity",
        }

        cursor = 0
        while cursor < len(text):
            next_hit = None
            next_marker = None
            for marker, name in marker_map.items():
                pos = text.find(marker, cursor)
                if pos >= 0 and (next_hit is None or pos < next_hit):
                    next_hit = pos
                    next_marker = marker
            if next_hit is None:
                box.insert("end", text[cursor:])
                break

            box.insert("end", text[cursor:next_hit])
            mark_name = marker_map[next_marker]
            box.mark_set(mark_name, "end")
            box.mark_gravity(mark_name, "left")
            cursor = next_hit + len(next_marker)

        box.mark_set("start", "1.0")
        box.configure(state="disabled")

        # Context-sensitive scroll. Delay until geometry is established.
        if section not in {"start", *marker_map.values()}:
            section = "start"
        win.after(80, lambda: box.see(section))

        ttk.Button(
            win,
            text="Close",
            command=win.destroy,
            style="Soft.TButton",
        ).pack(pady=(0, 14))

        win.lift()
        win.attributes("-topmost", True)
        win.after(150, lambda: win.attributes("-topmost", False))

    def _on_close(self):
        if self._mounted_host is not None:
            choice = messagebox.askyesnocancel(
                "Vault is mounted",
                f"{self._mounted_drive} is still mounted.\n\n"
                "Yes = dismount and close\n"
                "No = leave vault mounted and close\n"
                "Cancel = return to Entropic Fusion",
            )
            if choice is None:
                return
            if choice is True:
                try:
                    dismount_host(self._mounted_host, timeout=20.0)
                except Exception as exc:
                    return messagebox.showerror("Close Entropic Fusion", f"Could not dismount vault:\n{exc}")
        self.destroy()

if __name__ == "__main__":
    PrettyApp().mainloop()
