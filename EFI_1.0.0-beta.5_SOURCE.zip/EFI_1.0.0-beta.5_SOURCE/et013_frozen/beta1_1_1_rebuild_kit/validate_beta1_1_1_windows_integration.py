#!/usr/bin/env python3
from __future__ import annotations
import ctypes, hashlib, json, os, shutil, string, tempfile, time, traceback
from pathlib import Path

VERSION='Entropic Fusion Beta 1.1.1'; KIT_REVISION='R3-opened-context-fix'; RESULT=Path('BETA1_1_1_WINDOWS_INTEGRATION_RESULT.json'); HERE=Path(__file__).resolve().parent
PASSWORD='Beta111-Integration-Password-2026'

def digest(b): return hashlib.sha256(b).hexdigest()

def free_drive():
    mask=ctypes.windll.kernel32.GetLogicalDrives()
    for letter in reversed(string.ascii_uppercase[3:]):
        if not (mask & (1 << (ord(letter)-ord('A')))): return letter+':'
    raise RuntimeError('no free Windows drive letter')

def latest_diag_tail():
    root=Path(tempfile.gettempdir())/'EntropicFusion'/'diagnostics'
    if not root.is_dir(): return []
    rows=[]
    for p in sorted(root.glob('mount-*.log'),key=lambda x:x.stat().st_mtime,reverse=True)[:3]:
        try: rows.append({'file':p.name,'tail':p.read_text(encoding='utf-8',errors='replace')[-12000:]})
        except Exception: pass
    return rows

def win32_read(path: str, check_attributes: bool=True):
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    GENERIC_READ=0x80000000; SHARE=1|2|4; OPEN_EXISTING=3; NORMAL=0x80; INVALID=ctypes.c_void_p(-1).value
    k.GetFileAttributesW.argtypes=[ctypes.c_wchar_p];k.GetFileAttributesW.restype=ctypes.c_uint32
    attrs=None
    if check_attributes:
        attrs=k.GetFileAttributesW(path)
        if attrs==0xFFFFFFFF: raise ctypes.WinError(ctypes.get_last_error(),'GetFileAttributesW')
    k.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p]
    k.CreateFileW.restype=ctypes.c_void_p
    k.ReadFile.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint32,ctypes.POINTER(ctypes.c_uint32),ctypes.c_void_p]
    k.ReadFile.restype=ctypes.c_int
    k.CloseHandle.argtypes=[ctypes.c_void_p]
    k.CloseHandle.restype=ctypes.c_int
    h=k.CreateFileW(path,GENERIC_READ,SHARE,None,OPEN_EXISTING,NORMAL,None)
    if h==INVALID: raise ctypes.WinError(ctypes.get_last_error(),'CreateFileW')
    try:
        buf=ctypes.create_string_buffer(4096);got=ctypes.c_uint32()
        if not k.ReadFile(h,buf,len(buf),ctypes.byref(got),None): raise ctypes.WinError(ctypes.get_last_error(),'ReadFile')
        return attrs,bytes(buf.raw[:got.value])
    finally:k.CloseHandle(h)

def main():
    r={'version':VERSION,'kit_revision':KIT_REVISION,'scope':'Automated disposable Windows integration against the newly frozen host.','tests':{},'observed':{}};state=None
    work=Path(tempfile.mkdtemp(prefix='ef_beta111_integration_'));drive=None
    try:
        if os.name!='nt': raise RuntimeError('Windows integration gate must run on Windows')
        from entropic_fusion_public_identity_v0_11B_23_1 import generate_identity
        from entropic_fusion_private_vault_v0_11B_23_1 import protect_private_identity
        from entropic_vault_manager_v0_11B_24_1 import create_fused_vault
        from entropic_mount_host_aclpipe_client_beta1_1_1 import start_host,dismount_host

        host=HERE/'dist'/'EntropicFusionHost.exe'
        if not host.is_file(): raise FileNotFoundError(host)
        pub=work/'Integration.efpub';priv=work/'Integration.efpriv';privx=work/'Integration.efprivx';vault=work/'Integration.efv'
        gen=generate_identity(pub,priv,seed=0xB1112026)
        protect_private_identity(priv,privx,PASSWORD);priv.unlink(missing_ok=True)
        create_fused_vault(pub,vault,32*1024*1024,label='Entropic Beta 1.1.1 Integration')
        r['tests']['disposable_identity_and_vault_created']=all(p.is_file() for p in [pub,privx,vault])
        r['observed']['ef_equations_generated']=gen.get('ef_equations_verified')

        drive=free_drive();r['observed']['drive']=drive
        try:start_host(vault,privx,drive,'bad',timeout=60,host_executable=host,diagnostics=True)
        except Exception as e: wrong_short=str(e)
        else: wrong_short='';raise RuntimeError('short wrong-password mount unexpectedly succeeded')
        low=wrong_short.casefold();r['observed']['short_wrong_password_product_message']=wrong_short
        r['tests']['frozen_short_wrong_password_rejected']=bool(wrong_short)
        r['tests']['frozen_short_wrong_password_no_python_internals']=all(x not in low for x in ['traceback','file "','.py"',' line ','secret internal'])

        # Exercise the authenticated-decryption failure path too. This password is
        # long enough to pass policy but is deliberately incorrect, so it should
        # reach InvalidTag without exposing the exception or traceback.
        try:start_host(vault,privx,drive,'Wrong-Password-2026',timeout=60,host_executable=host,diagnostics=True)
        except Exception as e: wrong_valid=str(e)
        else: wrong_valid='';raise RuntimeError('valid-length wrong-password mount unexpectedly succeeded')
        low_valid=wrong_valid.casefold();r['observed']['valid_length_wrong_password_product_message']=wrong_valid
        r['tests']['frozen_valid_length_wrong_password_rejected']=bool(wrong_valid)
        r['tests']['frozen_valid_length_wrong_password_message_exact']=wrong_valid=='Incorrect password or the protected identity could not be unlocked.'
        r['tests']['frozen_valid_length_wrong_password_no_python_internals']=all(x not in low_valid for x in ['traceback','file "','.py"',' line ','invalidtag','secret internal'])

        state=start_host(vault,privx,drive,PASSWORD,timeout=180,host_executable=host,diagnostics=True)
        r['tests']['frozen_host_mount']=state.get('version')=='Beta1.1.1-host3'
        r['tests']['frozen_host_mount_module_exact']=state.get('mount_version')=='Beta1.1.1-mount3'
        r['tests']['live_ef_432']=int(state.get('ef_equations_verified') or 0)==432
        r['tests']['three_leg_fusion']=state.get('fusion_mode')=='EF-direct-three-leg-combiner'

        root=Path(drive+'\\');name='Entropic_Fusion_v0.13_Development_Baseline.docx';p=root/name
        payload=(b'PK\\x03\\x04'+os.urandom(32768)+b'BETA111')
        p.write_bytes(payload)
        r['tests']['mounted_write_created']=p.exists()
        attrs,raw=win32_read(str(p));r['tests']['win32_exact_path_open']=raw==payload[:len(raw)] and len(raw)>0
        attrs2,raw2=win32_read(str(p).upper());r['tests']['win32_case_insensitive_open']=raw2==payload[:len(raw2)] and len(raw2)>0
        attrs3,raw3=win32_read(str(p)+'::$DATA',check_attributes=False);r['tests']['win32_default_stream_open']=raw3==payload[:len(raw3)] and len(raw3)>0
        longp='\\\\?\\'+str(p);attrs4,raw4=win32_read(longp);r['tests']['win32_long_path_open']=raw4==payload[:len(raw4)] and len(raw4)>0
        copied=work/'copied-out.docx';shutil.copyfile(p,copied)
        r['tests']['python_copy_out_exact']=copied.read_bytes()==payload
        r['observed']['payload_sha256']=digest(payload);r['observed']['copied_sha256']=digest(copied.read_bytes())
        dismount_host(state);state=None;r['tests']['clean_dismount']=not Path(drive+'\\').exists()

        # Remount and prove the same file remains readable through Win32.
        state=start_host(vault,privx,drive,PASSWORD,timeout=180,host_executable=host,diagnostics=True)
        _,raw5=win32_read(str(Path(drive+'\\')/name));r['tests']['persistent_win32_open_after_remount']=raw5==payload[:len(raw5)] and len(raw5)>0
        dismount_host(state);state=None;r['tests']['final_clean_dismount']=True
        r['failed_tests']=[k for k,v in r['tests'].items() if v is not True];r['all_tests_passed']=not r['failed_tests']
        if not r['all_tests_passed']: r['developer_diagnostics']=latest_diag_tail()
        RESULT.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r,indent=2));return 0 if r['all_tests_passed'] else 1
    except Exception:
        r['fatal_error']=traceback.format_exc();r['all_tests_passed']=False;r['developer_diagnostics']=latest_diag_tail()
        RESULT.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');traceback.print_exc();return 2
    finally:
        if state is not None:
            try:
                from entropic_mount_host_aclpipe_client_beta1_1_1 import dismount_host
                dismount_host(state)
            except Exception:pass
        # Preserve the disposable work directory only on failure for local inspection.
        if r.get('all_tests_passed'):
            try:shutil.rmtree(work)
            except Exception:pass
if __name__=='__main__': raise SystemExit(main())
