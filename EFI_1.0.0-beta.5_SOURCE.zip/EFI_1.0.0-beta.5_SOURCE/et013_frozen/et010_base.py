#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import copy
import hashlib
import hmac
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

HERE = Path(__file__).resolve().parent
KIT = HERE / 'beta1_1_1_rebuild_kit'
sys.path.insert(0, str(KIT))

from entropic_fusion_public_identity_v0_11B_23_1 import (
    generate_identity,
    load_public,
    load_private,
    encapsulate_fused,
    decapsulate_fused,
    derive_ef_gated_session,
    public_fingerprint,
)
from entropic_fusion_hybrid_combiner_v0_11B_23_1 import derive_aes256_key, derive_key_id
from entropic_fusion_mlkem_runtime_v0_11B_23_1 import check_available, keygen_bytes, decapsulate_bytes
from entropic_openssl_runtime_v0_11B_23_1 import openssl_executable
import entropic_fusion_relation_v0_11B_23_1 as efrel
import entropic_fusion_public_identity_v0_11B_23_1 as efid

VERSION = 'Entropic Tetration ET 0.10.0-alpha'
FORMAT = 'ET-0.10-RECURSIVE-CAPSULE-1'
Q = 257
CONTEXT = b'ET-0.10-real-recursive-runtime'
SHARE_LINK_DOMAIN = b'ENTROPIC-TETRATION/ET-0.10/EF-SHARE-LINK/v1'
CT_LINK_DOMAIN = b'ENTROPIC-TETRATION/ET-0.10/KEM-CIPHERTEXT-LINK/v1'
TRANSCRIPT_DOMAIN = 'ENTROPIC-TETRATION/ET-0.10/RECURSIVE-TRANSCRIPT/v1'
PAYLOAD_AAD_DOMAIN = 'ENTROPIC-TETRATION/ET-0.10/FINAL-PAYLOAD/v1'
CORE_HASHES = {
    'entropic_bound_fusion_v0_11B_23_1.py': '8fdc7e7c8c8b1d45a12d09a86d799c642eec12170eaf0c221a0acc07473e81b9',
    'entropic_fusion_relation_v0_11B_23_1.py': '2ca99b6b23bcfbaf527fec957f7dd8c041a3f26a6b201f539b7e7150910c1838',
    'entropic_fusion_hybrid_combiner_v0_11B_23_1.py': 'd78f38177866c8a2821c61774cc1362cf515bfeaddd37e6de62f9b95a98e8f5d',
    'entropic_fusion_public_identity_v0_11B_23_1.py': 'e87399245ba047679c8eca388cc65f66fee2b17581ab1c633ec43b561143ed64',
    'entropic_fusion_mlkem_runtime_v0_11B_23_1.py': '4807d984ad15230c40e0f5f8ac57d1f56ed0910824d86e63bd98b587b5b76091',
}


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(',', ':')).encode('utf-8')


def b64e(data: bytes) -> str:
    return base64.b64encode(data).decode('ascii')


def b64d(text: str) -> bytes:
    return base64.b64decode(text.encode('ascii'))


def sha256_file(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_gate() -> dict:
    observed = {name: sha256_file(KIT / name) for name in CORE_HASHES}
    exact = all(observed[name] == expected for name, expected in CORE_HASHES.items())
    cp = subprocess.run(
        [sys.executable, str(KIT / 'validate_beta1_1_1_source.py')],
        cwd=KIT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    src = json.loads(cp.stdout) if cp.returncode == 0 else {'all_tests_passed': False, 'stderr': cp.stderr}
    if not exact or not src.get('all_tests_passed'):
        raise RuntimeError('Exact Beta 1.1.1 source gate failed')
    return {
        'source_hash_gate_passed': exact,
        'beta_source_validation_passed': True,
        'core_hashes': observed,
        'openssl': check_available(),
    }


def _refresh_fingerprint(pub: dict) -> dict:
    pub.pop('public_identity_sha256', None)
    pub['public_identity_sha256'] = public_fingerprint(pub)
    return pub


def _share_delta(key: bytes, level: int, nonce_hex: str, face_index: int, tag: bytes) -> int:
    msg = (
        SHARE_LINK_DOMAIN + b'\x00' + level.to_bytes(4, 'big') + bytes.fromhex(nonce_hex)
        + face_index.to_bytes(2, 'big') + b'\x00' + tag
    )
    return int.from_bytes(hmac.new(key, msg, hashlib.sha256).digest()[:4], 'big') % Q


def transform_public(pub: dict, key: bytes, level: int, sign: int) -> dict:
    out = copy.deepcopy(pub)
    for piece in out['ef_public']['pieces']:
        nonce = piece['nonce']
        for fi, face in enumerate(piece['faces']):
            face['face_share'] = (int(face['face_share']) + sign * _share_delta(key, level, nonce, fi, b'face')) % Q
            face['centre_share'] = (int(face['centre_share']) + sign * _share_delta(key, level, nonce, fi, b'centre')) % Q
    return _refresh_fingerprint(out)


def _link_key(previous_key: bytes, level: int) -> bytes:
    return hmac.new(previous_key, CT_LINK_DOMAIN + b'\x00' + level.to_bytes(4, 'big'), hashlib.sha256).digest()


def wrap_kem_ciphertext(previous_key: bytes, level: int, label: bytes, raw_ct: bytes) -> tuple[bytes, bytes]:
    nonce = os.urandom(12)
    aad = CT_LINK_DOMAIN + b'\x00' + level.to_bytes(4, 'big') + b'\x00' + label
    wrapped = AESGCM(_link_key(previous_key, level)).encrypt(nonce, raw_ct, aad)
    return nonce, wrapped


def unwrap_kem_ciphertext(previous_key: bytes, level: int, label: bytes, nonce: bytes, wrapped_ct: bytes) -> bytes:
    aad = CT_LINK_DOMAIN + b'\x00' + level.to_bytes(4, 'big') + b'\x00' + label
    return AESGCM(_link_key(previous_key, level)).decrypt(nonce, wrapped_ct, aad)


def tower_transcript(level: int, masked_pub: dict, stored_outer: bytes, stored_inner: bytes, prior_key_id: str | None) -> bytes:
    return canonical({
        'domain': TRANSCRIPT_DOMAIN,
        'level': level,
        'masked_public_identity_sha256': masked_pub['public_identity_sha256'],
        'ef_fusion_commitment_sha256': masked_pub['ef_fusion_commitment_sha256'],
        'stored_outer_ct_sha256': hashlib.sha256(stored_outer).hexdigest(),
        'stored_inner_ct_sha256': hashlib.sha256(stored_inner).hexdigest(),
        'prior_key_id': prior_key_id,
    })


def derive_level_sender(masked_pub: dict, level: int, previous_key: bytes | None, prior_key_id: str | None):
    outer_raw, outer_ss, inner_raw, inner_ss = encapsulate_fused(masked_pub)
    if previous_key is None:
        outer_nonce = inner_nonce = b''
        stored_outer, stored_inner = outer_raw, inner_raw
    else:
        outer_nonce, stored_outer = wrap_kem_ciphertext(previous_key, level, b'outer-mlkem-768', outer_raw)
        inner_nonce, stored_inner = wrap_kem_ciphertext(previous_key, level, b'inner-mlkem-1024', inner_raw)
    transcript = tower_transcript(level, masked_pub, stored_outer, stored_inner, prior_key_id)
    efss = derive_ef_gated_session(inner_ss, masked_pub['ef_fusion_commitment_sha256'], transcript)
    key = derive_aes256_key(outer_ss, inner_ss, efss, transcript, CONTEXT)
    return {
        'outer_nonce': outer_nonce,
        'inner_nonce': inner_nonce,
        'stored_outer': stored_outer,
        'stored_inner': stored_inner,
        'transcript': transcript,
        'key': key,
        'raw_outer': outer_raw,
        'raw_inner': inner_raw,
    }


def _private_public(priv: dict) -> dict:
    return priv['public_identity']


def derive_level_receiver(priv: dict, capsule_level: dict, level: int, previous_key: bytes | None, prior_key_id: str | None):
    masked_pub = capsule_level['masked_public_identity']
    stored_outer = b64d(capsule_level['outer_ct_b64'])
    stored_inner = b64d(capsule_level['inner_ct_b64'])

    if level == 1:
        raw_outer, raw_inner = stored_outer, stored_inner
        link_verified = True
    else:
        if previous_key is None:
            raise ValueError(f'Level {level} requires the previous level key')
        restored = transform_public(masked_pub, previous_key, level, -1)
        link_verified = restored == _private_public(priv)
        if not link_verified:
            raise ValueError(f'Level {level} EF-share link did not restore the recipient identity')
        raw_outer = unwrap_kem_ciphertext(
            previous_key, level, b'outer-mlkem-768', b64d(capsule_level['outer_nonce_b64']), stored_outer
        )
        raw_inner = unwrap_kem_ciphertext(
            previous_key, level, b'inner-mlkem-1024', b64d(capsule_level['inner_nonce_b64']), stored_inner
        )

    transcript = tower_transcript(level, masked_pub, stored_outer, stored_inner, prior_key_id)
    if b64e(transcript) != capsule_level['transcript_b64']:
        raise ValueError(f'Level {level} transcript mismatch')
    outer_ss, inner_ss, report, _fusion_secret = decapsulate_fused(priv, raw_outer, raw_inner)
    efss = derive_ef_gated_session(inner_ss, priv['public_identity']['ef_fusion_commitment_sha256'], transcript)
    key = derive_aes256_key(outer_ss, inner_ss, efss, transcript, CONTEXT)
    return key, report, link_verified


def keygen(keydir: Path, depth: int, seed0: int) -> dict:
    if depth < 2:
        raise ValueError('depth must be >= 2')
    keydir = Path(keydir)
    public_dir = keydir / 'public'
    private_dir = keydir / 'private'
    public_dir.mkdir(parents=True, exist_ok=True)
    private_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for i in range(1, depth + 1):
        pub_path = public_dir / f'L{i:02d}_public.json'
        priv_path = private_dir / f'L{i:02d}_private.json'
        rep = generate_identity(pub_path, priv_path, seed=seed0 + i - 1)
        rows.append({
            'level': i,
            'seed': seed0 + i - 1,
            'public_file': pub_path.name,
            'private_file': priv_path.name,
            'public_identity_sha256': rep['public_identity_sha256'],
        })
    manifest = {
        'version': VERSION,
        'format': 'ET-0.10-TOWER-KEYSET-1',
        'depth': depth,
        'seed0': seed0,
        'levels': rows,
        'warning': 'Research keyset only. Private files are unencrypted test material.',
    }
    (keydir / 'tower_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    return manifest


def _load_manifest(keydir: Path) -> dict:
    m = json.loads((Path(keydir) / 'tower_manifest.json').read_text(encoding='utf-8'))
    if m.get('format') != 'ET-0.10-TOWER-KEYSET-1':
        raise ValueError('not an ET 0.10 tower keyset')
    return m


def encrypt_file(keydir: Path, input_path: Path, capsule_path: Path, *, return_debug: bool = False):
    keydir = Path(keydir)
    manifest = _load_manifest(keydir)
    depth = manifest['depth']
    data = Path(input_path).read_bytes()
    levels = []
    previous_key = None
    prior_key_id = None
    debug_keys = []
    for row in manifest['levels']:
        level = row['level']
        pub = load_public(keydir / 'public' / row['public_file'])
        masked_pub = copy.deepcopy(pub) if level == 1 else transform_public(pub, previous_key, level, +1)
        d = derive_level_sender(masked_pub, level, previous_key, prior_key_id)
        levels.append({
            'level': level,
            'masked_public_identity': masked_pub,
            'outer_nonce_b64': b64e(d['outer_nonce']),
            'inner_nonce_b64': b64e(d['inner_nonce']),
            'outer_ct_b64': b64e(d['stored_outer']),
            'inner_ct_b64': b64e(d['stored_inner']),
            'transcript_b64': b64e(d['transcript']),
            'prior_key_id': prior_key_id,
        })
        previous_key = d['key']
        prior_key_id = derive_key_id(previous_key)
        debug_keys.append(d['key'])

    payload_nonce = os.urandom(12)
    aad_obj = {
        'domain': PAYLOAD_AAD_DOMAIN,
        'depth': depth,
        'filename': Path(input_path).name,
        'plaintext_bytes': len(data),
        'final_level_public_sha256': levels[-1]['masked_public_identity']['public_identity_sha256'],
    }
    payload_aad = canonical(aad_obj)
    payload_ct = AESGCM(previous_key).encrypt(payload_nonce, data, payload_aad)
    capsule = {
        'version': VERSION,
        'format': FORMAT,
        'warning': 'Research runtime capsule. Not production cryptography.',
        'depth': depth,
        'filename': Path(input_path).name,
        'plaintext_bytes': len(data),
        'levels': levels,
        'payload': {
            'nonce_b64': b64e(payload_nonce),
            'ciphertext_b64': b64e(payload_ct),
            'aad': aad_obj,
        },
    }
    Path(capsule_path).write_text(json.dumps(capsule, indent=2) + '\n', encoding='utf-8')
    return (capsule, debug_keys) if return_debug else capsule


def decrypt_file(keydir: Path, capsule_path: Path, output_path: Path, *, return_debug: bool = False):
    keydir = Path(keydir)
    manifest = _load_manifest(keydir)
    capsule = json.loads(Path(capsule_path).read_text(encoding='utf-8'))
    if capsule.get('format') != FORMAT:
        raise ValueError('not an ET 0.10 recursive capsule')
    if capsule['depth'] != manifest['depth']:
        raise ValueError('capsule depth does not match keyset')

    previous_key = None
    prior_key_id = None
    recovered_keys = []
    reports = []
    for row, cap_level in zip(manifest['levels'], capsule['levels']):
        level = row['level']
        priv = load_private(keydir / 'private' / row['private_file'])
        key, rep, link_verified = derive_level_receiver(priv, cap_level, level, previous_key, prior_key_id)
        recovered_keys.append(key)
        reports.append({
            'level': level,
            'recursive_link_verified': link_verified,
            'key_id': derive_key_id(key),
            'ef_positions': rep['positions'],
            'ef_edges': rep['edges'],
            'ef_equations_verified': rep['equations_verified'],
        })
        previous_key = key
        prior_key_id = derive_key_id(key)

    payload = capsule['payload']
    aad = canonical(payload['aad'])
    plaintext = AESGCM(previous_key).decrypt(b64d(payload['nonce_b64']), b64d(payload['ciphertext_b64']), aad)
    Path(output_path).write_bytes(plaintext)
    result = {
        'version': VERSION,
        'depth': capsule['depth'],
        'recovered_bytes': len(plaintext),
        'levels': reports,
        'all_levels_full_relation': all(r['ef_positions'] == 81 and r['ef_edges'] == 216 and r['ef_equations_verified'] == 432 for r in reports),
        'all_recursive_links_verified': all(r['recursive_link_verified'] for r in reports),
        'output_sha256': hashlib.sha256(plaintext).hexdigest(),
    }
    return (result, recovered_keys) if return_debug else result


def demo(depth: int, input_path: Path, workdir: Path, seed0: int) -> dict:
    start = time.perf_counter()
    lineage = source_gate()
    workdir = Path(workdir)
    if workdir.exists():
        shutil.rmtree(workdir)
    workdir.mkdir(parents=True)
    keydir = workdir / 'tower_keys'
    capsule_path = workdir / 'message.et10.json'
    recovered_path = workdir / 'RECOVERED_MESSAGE.txt'

    manifest = keygen(keydir, depth, seed0)
    capsule, sender_keys = encrypt_file(keydir, input_path, capsule_path, return_debug=True)

    # A deployment-reality control that ET 0.7 did not include: the receiver has the
    # original later-level private identities. The new ciphertext link must still make
    # direct Level-2 key recovery fail before Level 1 is recovered.
    direct_l2_key_match = None
    wrong_l1_unwrap_rejected = None
    if depth >= 2:
        row = manifest['levels'][1]
        priv2 = load_private(keydir / 'private' / row['private_file'])
        cap2 = capsule['levels'][1]
        stored_outer = b64d(cap2['outer_ct_b64'])
        stored_inner = b64d(cap2['inner_ct_b64'])
        tr2 = b64d(cap2['transcript_b64'])
        try:
            oss, iss, _rep, _fs = decapsulate_fused(priv2, stored_outer, stored_inner)
            efss = derive_ef_gated_session(iss, priv2['public_identity']['ef_fusion_commitment_sha256'], tr2)
            guessed = derive_aes256_key(oss, iss, efss, tr2, CONTEXT)
            direct_l2_key_match = guessed == sender_keys[1]
        except Exception:
            direct_l2_key_match = False

        bad = bytearray(sender_keys[0]); bad[0] ^= 1
        try:
            unwrap_kem_ciphertext(bytes(bad), 2, b'outer-mlkem-768', b64d(cap2['outer_nonce_b64']), stored_outer)
            wrong_l1_unwrap_rejected = False
        except InvalidTag:
            wrong_l1_unwrap_rejected = True

    dec_result, receiver_keys = decrypt_file(keydir, capsule_path, recovered_path, return_debug=True)
    source_bytes = Path(input_path).read_bytes()
    recovered_bytes = recovered_path.read_bytes()

    wrong_final_payload_rejected = False
    bad_final = bytearray(receiver_keys[-1]); bad_final[-1] ^= 1
    try:
        payload = capsule['payload']
        AESGCM(bytes(bad_final)).decrypt(b64d(payload['nonce_b64']), b64d(payload['ciphertext_b64']), canonical(payload['aad']))
    except InvalidTag:
        wrong_final_payload_rejected = True

    result = {
        'version': VERSION,
        'mode': 'testable-recursive-runtime',
        'warning': 'Research integration demo only. This is a working recursive runtime, not a proof of tetrational complexity or production security.',
        'purpose': 'Make the recursive tower testable as an actual sender/receiver file round-trip and repair the deployment sequencing gap by authenticating each later-level ML-KEM ciphertext under the previous level final key, while retaining EF-share masking.',
        'parameters': {
            'depth': depth,
            'geometry': '4D n=3',
            'positions_per_level': 81,
            'edges_per_level': 216,
            'equations_per_level': 432,
            'dim': 64,
            'real_mlkem_per_level': ['ML-KEM-768', 'ML-KEM-1024'],
            'recursive_link': 'previous 256-bit final key -> EF share mask + authenticated wrapping of next-level KEM ciphertexts',
        },
        'source_lineage': lineage,
        'roundtrip': {
            'input_file': str(Path(input_path).resolve()),
            'capsule_file': str(capsule_path.resolve()),
            'recovered_file': str(recovered_path.resolve()),
            'input_sha256': hashlib.sha256(source_bytes).hexdigest(),
            'recovered_sha256': hashlib.sha256(recovered_bytes).hexdigest(),
            'exact_file_roundtrip': source_bytes == recovered_bytes,
        },
        'level_reports': dec_result['levels'],
        'controls': {
            'original_level2_private_identity_without_level1_key_recovers_true_level2_key': direct_l2_key_match,
            'one_bit_wrong_level1_key_rejected_by_level2_ciphertext_link': wrong_l1_unwrap_rejected,
            'wrong_final_key_rejects_payload': wrong_final_payload_rejected,
        },
        'known_0_8_limitation_retained': 'If an external oracle supplies both raw ML-KEM shared secrets for a level, the current B.23.1 final combiner can still be reproduced without an independent EF secret contribution. ET 0.9 repairs recursive deployment sequencing; it does not yet solve the EF-native third-leg problem.',
        'elapsed_seconds': time.perf_counter() - start,
    }
    result['suite_pass'] = all([
        result['roundtrip']['exact_file_roundtrip'],
        dec_result['all_levels_full_relation'],
        dec_result['all_recursive_links_verified'],
        direct_l2_key_match is False if depth >= 2 else True,
        wrong_l1_unwrap_rejected is True if depth >= 2 else True,
        wrong_final_payload_rejected,
    ])
    (workdir / 'ET_0_10_0_DEMO_RESULT.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    return result



PENTA_FORMAT = 'ET-0.10-PENTATION-STREAM-1'
PENTA_PUBLIC_KEYS_FORMAT = 'ET-0.10-PENTA-PUBLIC-KEYS-1'
PENTA_PRIVATE_KEYS_FORMAT = 'ET-0.10-PENTA-PRIVATE-KEYS-1'
PENTA_HEADER_TYPE = 'header'
PENTA_LEVEL_TYPE = 'level'
PENTA_PAYLOAD_TYPE = 'payload'


def _tetration_capped(base: int, height: int, cap: int) -> int | None:
    if base < 2 or height < 1:
        raise ValueError('base must be >= 2 and height >= 1')
    value = base
    if value > cap:
        return None
    for _ in range(2, height + 1):
        # Stop as soon as the exact value leaves the engineering cap.
        if value > 64 and base >= 2:
            return None
        value = pow(base, value)
        if value > cap:
            return None
    return value


def pentation_depth(base: int, height: int, cap: int = 1_000_000_000) -> int | None:
    """Return a ↑↑↑ height while the exact result remains <= cap."""
    if base < 2 or height < 1:
        raise ValueError('base must be >= 2 and height >= 1')
    value = base
    if value > cap:
        return None
    for _ in range(2, height + 1):
        value = _tetration_capped(base, value, cap)
        if value is None:
            return None
    return value


def pentation_plan(base: int, height: int, cap: int = 1_000_000_000) -> dict:
    depth = pentation_depth(base, height, cap)
    return {
        'notation': f'{base} ↑↑↑ {height}',
        'base': base,
        'height': height,
        'exact_depth': depth,
        'exact_within_cap': depth is not None,
        'cap': cap,
        'interpretation': (
            'The pentation value is used as a requested recursive tower depth. '
            'This is a pentation-depth engineering target, not a claim that the cryptographic construction has pentational asymptotic complexity.'
        ),
    }


def _build_public_from_seed_and_pks(seed: int, outer_pk: bytes, inner_pk: bytes):
    ef_pub, ef_witness, ef_report, fusion_secret = efrel.generate(seed)
    public_obj = {
        'format': efid.PUBLIC_FORMAT,
        'version': efid.VERSION,
        'outer_kem': 'ML-KEM-768',
        'fused_inner_kem': 'ML-KEM-1024',
        'ef_relation': 'EF-v0.11-full-face-centre',
        'fusion_mode': 'EF-direct-three-leg-combiner',
        'ef_public': ef_pub,
        'ef_fusion_commitment_sha256': ef_report['fusion_commitment_sha256'],
        'outer_public_pem_b64': b64e(outer_pk),
        'inner_public_pem_b64': b64e(inner_pk),
    }
    public_obj['public_identity_sha256'] = public_fingerprint(public_obj)
    return public_obj, ef_witness, ef_report, fusion_secret


def _public_from_private_pem(sk_pem: bytes) -> bytes:
    cp = subprocess.run(
        [openssl_executable(), 'pkey', '-pubout', '-outform', 'PEM'],
        input=sk_pem,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if cp.returncode:
        raise RuntimeError(cp.stderr.decode('utf-8', 'replace').strip() or 'OpenSSL public-key derivation failed')
    return cp.stdout


def penta_keygen_stream(public_keys_path: Path, private_keys_path: Path, *, depth: int, seed0: int, progress_every: int = 64) -> dict:
    if depth < 2:
        raise ValueError('depth must be >= 2')
    public_keys_path = Path(public_keys_path)
    private_keys_path = Path(private_keys_path)
    start = time.perf_counter()
    with public_keys_path.open('w', encoding='utf-8') as pubfh, private_keys_path.open('w', encoding='utf-8') as privfh:
        pubfh.write(json.dumps({
            'type': PENTA_HEADER_TYPE,
            'format': PENTA_PUBLIC_KEYS_FORMAT,
            'version': VERSION,
            'depth': depth,
            'seed0': seed0,
            'warning': 'Research compact public stream. Seeds are deterministic test controls and are not deployment-safe public key material.',
        }, separators=(',', ':')) + '\n')
        privfh.write(json.dumps({
            'type': PENTA_HEADER_TYPE,
            'format': PENTA_PRIVATE_KEYS_FORMAT,
            'version': VERSION,
            'depth': depth,
            'seed0': seed0,
            'warning': 'Research compact private stream. Contains raw ML-KEM private keys. Protect as secret test material.',
        }, separators=(',', ':')) + '\n')
        for level in range(1, depth + 1):
            seed = seed0 + level - 1
            outer_pk, outer_sk = keygen_bytes('ML-KEM-768')
            inner_pk, inner_sk = keygen_bytes('ML-KEM-1024')
            pub, _witness, rep, _fusion_secret = _build_public_from_seed_and_pks(seed, outer_pk, inner_pk)
            pubfh.write(json.dumps({
                'type': PENTA_LEVEL_TYPE,
                'level': level,
                'seed': seed,
                'outer_public_pem_b64': b64e(outer_pk),
                'inner_public_pem_b64': b64e(inner_pk),
                'public_identity_sha256': pub['public_identity_sha256'],
                'ef_fusion_commitment_sha256': rep['fusion_commitment_sha256'],
            }, separators=(',', ':')) + '\n')
            privfh.write(json.dumps({
                'type': PENTA_LEVEL_TYPE,
                'level': level,
                'seed': seed,
                'outer_private_pem_b64': b64e(outer_sk),
                'inner_private_pem_b64': b64e(inner_sk),
                'public_identity_sha256': pub['public_identity_sha256'],
            }, separators=(',', ':')) + '\n')
            if progress_every and (level % progress_every == 0 or level == depth):
                print(f'[keygen] level {level}/{depth}', file=sys.stderr, flush=True)
    return {
        'depth': depth,
        'public_keys_path': str(public_keys_path.resolve()),
        'private_keys_path': str(private_keys_path.resolve()),
        'public_keys_bytes': public_keys_path.stat().st_size,
        'private_keys_bytes': private_keys_path.stat().st_size,
        'seconds': time.perf_counter() - start,
    }


def _read_stream_header(fh, expected_format: str) -> dict:
    line = fh.readline()
    if not line:
        raise ValueError('empty stream')
    h = json.loads(line)
    if h.get('type') != PENTA_HEADER_TYPE or h.get('format') != expected_format:
        raise ValueError(f'wrong stream format; expected {expected_format}')
    return h


def penta_encrypt_stream(public_keys_path: Path, input_path: Path, capsule_path: Path, *, progress_every: int = 64) -> dict:
    public_keys_path = Path(public_keys_path)
    capsule_path = Path(capsule_path)
    data = Path(input_path).read_bytes()
    previous_key = None
    prior_key_id = None
    start = time.perf_counter()
    reconstructed_hash_checks = 0
    with public_keys_path.open('r', encoding='utf-8') as keyfh, capsule_path.open('w', encoding='utf-8') as out:
        kh = _read_stream_header(keyfh, PENTA_PUBLIC_KEYS_FORMAT)
        depth = int(kh['depth'])
        seed0 = int(kh['seed0'])
        out.write(json.dumps({
            'type': PENTA_HEADER_TYPE,
            'format': PENTA_FORMAT,
            'version': VERSION,
            'depth': depth,
            'seed0': seed0,
            'filename': Path(input_path).name,
            'plaintext_bytes': len(data),
            'warning': 'Research streaming capsule. Not production cryptography.',
        }, separators=(',', ':')) + '\n')
        level_count = 0
        for line in keyfh:
            row = json.loads(line)
            if row.get('type') != PENTA_LEVEL_TYPE:
                raise ValueError('unexpected public-key stream record')
            level = int(row['level'])
            if level != level_count + 1:
                raise ValueError('non-sequential public-key stream')
            seed = int(row['seed'])
            if seed != seed0 + level - 1:
                raise ValueError('public-key seed sequence mismatch')
            pub, _w, _r, _fs = _build_public_from_seed_and_pks(seed, b64d(row['outer_public_pem_b64']), b64d(row['inner_public_pem_b64']))
            if pub['public_identity_sha256'] != row['public_identity_sha256']:
                raise ValueError(f'Level {level} compact public reconstruction mismatch')
            reconstructed_hash_checks += 1
            masked_pub = copy.deepcopy(pub) if level == 1 else transform_public(pub, previous_key, level, +1)
            d = derive_level_sender(masked_pub, level, previous_key, prior_key_id)
            out.write(json.dumps({
                'type': PENTA_LEVEL_TYPE,
                'level': level,
                'masked_public_identity_sha256': masked_pub['public_identity_sha256'],
                'ef_fusion_commitment_sha256': masked_pub['ef_fusion_commitment_sha256'],
                'outer_nonce_b64': b64e(d['outer_nonce']),
                'inner_nonce_b64': b64e(d['inner_nonce']),
                'outer_ct_b64': b64e(d['stored_outer']),
                'inner_ct_b64': b64e(d['stored_inner']),
                'transcript_b64': b64e(d['transcript']),
                'prior_key_id': prior_key_id,
            }, separators=(',', ':')) + '\n')
            previous_key = d['key']
            prior_key_id = derive_key_id(previous_key)
            level_count += 1
            if progress_every and (level % progress_every == 0 or level == depth):
                print(f'[sender] level {level}/{depth}', file=sys.stderr, flush=True)
        if level_count != depth:
            raise ValueError('public key stream depth mismatch')
        payload_nonce = os.urandom(12)
        aad_obj = {
            'domain': PAYLOAD_AAD_DOMAIN,
            'depth': depth,
            'filename': Path(input_path).name,
            'plaintext_bytes': len(data),
            'final_key_id': prior_key_id,
        }
        payload_ct = AESGCM(previous_key).encrypt(payload_nonce, data, canonical(aad_obj))
        out.write(json.dumps({
            'type': PENTA_PAYLOAD_TYPE,
            'nonce_b64': b64e(payload_nonce),
            'ciphertext_b64': b64e(payload_ct),
            'aad': aad_obj,
        }, separators=(',', ':')) + '\n')
    return {
        'depth': depth,
        'capsule_path': str(capsule_path.resolve()),
        'capsule_bytes': capsule_path.stat().st_size,
        'sender_seconds': time.perf_counter() - start,
        'final_key_id': prior_key_id,
        'compact_public_reconstruction_checks': reconstructed_hash_checks,
    }


def _compact_receiver_level(base_pub: dict, ef_witness: dict, outer_sk: bytes, inner_sk: bytes, rec: dict, previous_key: bytes | None, prior_key_id: str | None):
    level = int(rec['level'])
    masked_pub = copy.deepcopy(base_pub) if level == 1 else transform_public(base_pub, previous_key, level, +1)
    if masked_pub['public_identity_sha256'] != rec['masked_public_identity_sha256']:
        raise ValueError(f'Level {level} reconstructed masked public identity hash mismatch')
    stored_outer = b64d(rec['outer_ct_b64'])
    stored_inner = b64d(rec['inner_ct_b64'])
    if level == 1:
        raw_outer, raw_inner = stored_outer, stored_inner
    else:
        if previous_key is None:
            raise ValueError(f'Level {level} requires previous key')
        raw_outer = unwrap_kem_ciphertext(previous_key, level, b'outer-mlkem-768', b64d(rec['outer_nonce_b64']), stored_outer)
        raw_inner = unwrap_kem_ciphertext(previous_key, level, b'inner-mlkem-1024', b64d(rec['inner_nonce_b64']), stored_inner)
    transcript = tower_transcript(level, masked_pub, stored_outer, stored_inner, prior_key_id)
    if b64e(transcript) != rec['transcript_b64']:
        raise ValueError(f'Level {level} transcript mismatch')
    report, _fusion_secret = efrel.verify_and_derive(base_pub['ef_public'], ef_witness)
    if report['fusion_commitment_sha256'] != base_pub['ef_fusion_commitment_sha256']:
        raise ValueError(f'Level {level} EF fusion commitment mismatch')
    outer_ss = decapsulate_bytes(outer_sk, raw_outer, 'ML-KEM-768')
    inner_ss = decapsulate_bytes(inner_sk, raw_inner, 'ML-KEM-1024')
    efss = derive_ef_gated_session(inner_ss, base_pub['ef_fusion_commitment_sha256'], transcript)
    key = derive_aes256_key(outer_ss, inner_ss, efss, transcript, CONTEXT)
    return key, report


def penta_decrypt_stream(private_keys_path: Path, capsule_path: Path, output_path: Path, *, progress_every: int = 64) -> dict:
    private_keys_path = Path(private_keys_path)
    capsule_path = Path(capsule_path)
    previous_key = None
    prior_key_id = None
    start = time.perf_counter()
    level_count = 0
    all_full_relation = True
    public_hash_checks = 0
    with private_keys_path.open('r', encoding='utf-8') as keyfh, capsule_path.open('r', encoding='utf-8') as capfh:
        kh = _read_stream_header(keyfh, PENTA_PRIVATE_KEYS_FORMAT)
        ch = _read_stream_header(capfh, PENTA_FORMAT)
        depth = int(ch['depth'])
        seed0 = int(ch['seed0'])
        if int(kh['depth']) != depth or int(kh['seed0']) != seed0:
            raise ValueError('private key stream does not match capsule')
        payload_record = None
        for capline in capfh:
            rec = json.loads(capline)
            if rec.get('type') == PENTA_PAYLOAD_TYPE:
                payload_record = rec
                break
            if rec.get('type') != PENTA_LEVEL_TYPE:
                raise ValueError('unexpected capsule record')
            keyline = keyfh.readline()
            if not keyline:
                raise ValueError('private key stream ended early')
            krow = json.loads(keyline)
            level = int(rec['level'])
            if int(krow.get('level', -1)) != level or level != level_count + 1:
                raise ValueError('private key/capsule level mismatch')
            seed = int(krow['seed'])
            if seed != seed0 + level - 1:
                raise ValueError('private-key seed sequence mismatch')
            outer_sk = b64d(krow['outer_private_pem_b64'])
            inner_sk = b64d(krow['inner_private_pem_b64'])
            outer_pk = _public_from_private_pem(outer_sk)
            inner_pk = _public_from_private_pem(inner_sk)
            base_pub, witness, _r0, _fs0 = _build_public_from_seed_and_pks(seed, outer_pk, inner_pk)
            if base_pub['public_identity_sha256'] != krow['public_identity_sha256']:
                raise ValueError(f'Level {level} private compact reconstruction mismatch')
            public_hash_checks += 1
            key, rep = _compact_receiver_level(base_pub, witness, outer_sk, inner_sk, rec, previous_key, prior_key_id)
            all_full_relation = all_full_relation and rep['positions'] == 81 and rep['edges'] == 216 and rep['equations_verified'] == 432
            previous_key = key
            prior_key_id = derive_key_id(key)
            level_count += 1
            if progress_every and (level % progress_every == 0 or level == depth):
                print(f'[receiver] level {level}/{depth}', file=sys.stderr, flush=True)
        if payload_record is None:
            raise ValueError('capsule missing payload record')
        if level_count != depth:
            raise ValueError('capsule depth mismatch')
        if keyfh.readline():
            raise ValueError('private key stream contains extra level records')
    plaintext = AESGCM(previous_key).decrypt(
        b64d(payload_record['nonce_b64']),
        b64d(payload_record['ciphertext_b64']),
        canonical(payload_record['aad']),
    )
    Path(output_path).write_bytes(plaintext)
    return {
        'depth': level_count,
        'receiver_seconds': time.perf_counter() - start,
        'all_levels_full_relation': all_full_relation,
        'final_key_id': prior_key_id,
        'compact_private_reconstruction_checks': public_hash_checks,
        'output_sha256': hashlib.sha256(plaintext).hexdigest(),
        'recovered_bytes': len(plaintext),
    }


def penta_demo(*, base: int, height: int, materialize_depth: int | None, full_target: bool, input_path: Path, workdir: Path, seed0: int, progress_every: int, cap: int = 1_000_000_000) -> dict:
    lineage = source_gate()
    plan = pentation_plan(base, height, cap)
    exact_target = plan['exact_depth']
    if full_target:
        if exact_target is None:
            raise ValueError('requested pentation target exceeds the configured exact-depth cap')
        depth = int(exact_target)
    else:
        if materialize_depth is None:
            materialize_depth = 64
        depth = int(materialize_depth)
        if exact_target is not None and depth > exact_target:
            raise ValueError('materialize-depth cannot exceed the pentation target')
    if depth < 2:
        raise ValueError('materialized depth must be >= 2')

    workdir = Path(workdir)
    if workdir.exists():
        shutil.rmtree(workdir)
    workdir.mkdir(parents=True)
    public_keys_path = workdir / 'PENTA_PUBLIC_KEYS.ndjson'
    private_keys_path = workdir / 'PENTA_PRIVATE_KEYS.ndjson'
    capsule_path = workdir / 'message.et10.penta.ndjson'
    recovered_path = workdir / 'RECOVERED_MESSAGE.txt'
    source_bytes = Path(input_path).read_bytes()

    start = time.perf_counter()
    kg = penta_keygen_stream(public_keys_path, private_keys_path, depth=depth, seed0=seed0, progress_every=progress_every)
    enc = penta_encrypt_stream(public_keys_path, input_path, capsule_path, progress_every=progress_every)
    dec = penta_decrypt_stream(private_keys_path, capsule_path, recovered_path, progress_every=progress_every)
    elapsed = time.perf_counter() - start
    recovered = recovered_path.read_bytes()
    total_storage = kg['public_keys_bytes'] + kg['private_keys_bytes'] + enc['capsule_bytes']
    projected = None
    if exact_target is not None:
        ratio = exact_target / depth
        projected = {
            'target_depth': exact_target,
            'linear_seconds_at_observed_rate': elapsed * ratio,
            'linear_hours_at_observed_rate': elapsed * ratio / 3600.0,
            'linear_total_storage_bytes_at_observed_rate': int(total_storage * ratio),
            'linear_public_key_stream_bytes': int(kg['public_keys_bytes'] * ratio),
            'linear_private_key_stream_bytes': int(kg['private_keys_bytes'] * ratio),
            'linear_capsule_bytes': int(enc['capsule_bytes'] * ratio),
            'note': 'Linear engineering extrapolation only. It is not a cryptographic hardness or asymptotic complexity estimate.',
        }
    result = {
        'version': VERSION,
        'mode': 'pentation-depth-compact-streaming-runtime',
        'warning': 'Research integration/stress harness only. Pentation supplies the requested recursion depth; this is not a pentational-complexity claim.',
        'pentation': plan,
        'materialized_depth': depth,
        'full_pentation_target_materialized': bool(exact_target is not None and depth == exact_target),
        'fraction_of_target_materialized': (depth / exact_target) if exact_target else None,
        'parameters': {
            'geometry': '4D n=3',
            'positions_per_level': 81,
            'edges_per_level': 216,
            'equations_per_level': 432,
            'dim': 64,
            'real_mlkem_per_level': ['ML-KEM-768', 'ML-KEM-1024'],
            'recursive_link': 'previous 256-bit final key -> EF share mask + authenticated wrapping of next-level ML-KEM ciphertexts',
            'capsule_format': PENTA_FORMAT,
            'key_storage': 'compact NDJSON streams: deterministic research EF seed + ML-KEM public/private PEM material; full EF JSON identities are reconstructed per level and never stored',
        },
        'source_lineage': lineage,
        'keygen': kg,
        'sender': enc,
        'receiver': dec,
        'roundtrip': {
            'input_sha256': hashlib.sha256(source_bytes).hexdigest(),
            'recovered_sha256': hashlib.sha256(recovered).hexdigest(),
            'exact_file_roundtrip': source_bytes == recovered,
        },
        'observed': {
            'elapsed_seconds': elapsed,
            'seconds_per_materialized_level_full_roundtrip': elapsed / depth,
            'total_stream_storage_bytes': total_storage,
            'bytes_per_materialized_level_total': total_storage / depth,
        },
        'projected_full_target': projected,
        'known_limitation': 'The ET 0.8.1 dual-KEM-compromise finding remains open: both raw ML-KEM shared secrets still reproduce the current B.23.1 final combiner without an independently secret EF third leg.',
        'research_key_warning': 'Compact seed-based reconstruction is specifically a local stress-test optimisation. The deterministic EF seeds must not be treated as public deployment material because they regenerate the EF witness.',
    }
    result['suite_pass'] = all([
        result['roundtrip']['exact_file_roundtrip'],
        dec['all_levels_full_relation'],
        enc['final_key_id'] == dec['final_key_id'],
        enc['compact_public_reconstruction_checks'] == depth,
        dec['compact_private_reconstruction_checks'] == depth,
    ])
    (workdir / 'ET_0_10_0_PENTA_RESULT.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    return result

def main():
    ap = argparse.ArgumentParser(description='Entropic Tetration ET 0.10.0-alpha research runtime')
    sub = ap.add_subparsers(dest='cmd', required=True)

    p = sub.add_parser('keygen', help='generate a multi-level research keyset')
    p.add_argument('--depth', type=int, default=4)
    p.add_argument('--seed0', type=int, default=2026090501)
    p.add_argument('--keydir', type=Path, default=HERE / 'ET_0_10_0_KEYS')

    p = sub.add_parser('encrypt', help='encrypt a file into an ET 0.10 recursive capsule')
    p.add_argument('--keydir', type=Path, required=True)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--out', type=Path, default=HERE / 'message.et10.json')

    p = sub.add_parser('decrypt', help='decrypt an ET 0.10 recursive capsule')
    p.add_argument('--keydir', type=Path, required=True)
    p.add_argument('--capsule', type=Path, required=True)
    p.add_argument('--out', type=Path, default=HERE / 'RECOVERED_MESSAGE.bin')

    p = sub.add_parser('demo', help='one-command full keygen -> encrypt -> sequential decrypt round-trip')
    p.add_argument('--depth', type=int, default=4)
    p.add_argument('--seed0', type=int, default=2026090501)
    p.add_argument('--input', type=Path, default=HERE / 'TEST_MESSAGE.txt')
    p.add_argument('--workdir', type=Path, default=HERE / 'ET_0_10_0_DEMO_OUTPUT')

    p = sub.add_parser('penta-plan', help='show the pentation-derived recursion target')
    p.add_argument('--base', type=int, default=2)
    p.add_argument('--height', type=int, default=3)
    p.add_argument('--cap', type=int, default=1_000_000_000)

    p = sub.add_parser('penta-demo', help='stream a real EF/ML-KEM tower toward a pentation-derived depth')
    p.add_argument('--base', type=int, default=2)
    p.add_argument('--height', type=int, default=3)
    p.add_argument('--materialize-depth', type=int, default=64)
    p.add_argument('--full-target', action='store_true', help='materialize the full exact pentation target (2 ↑↑↑ 3 = 65,536 with defaults)')
    p.add_argument('--seed0', type=int, default=2026091001)
    p.add_argument('--input', type=Path, default=HERE / 'TEST_MESSAGE.txt')
    p.add_argument('--workdir', type=Path, default=HERE / 'ET_0_10_0_PENTA_OUTPUT')
    p.add_argument('--progress-every', type=int, default=16)
    p.add_argument('--cap', type=int, default=1_000_000_000)

    a = ap.parse_args()
    if a.cmd == 'keygen':
        print(json.dumps(keygen(a.keydir, a.depth, a.seed0), indent=2))
    elif a.cmd == 'encrypt':
        source_gate()
        c = encrypt_file(a.keydir, a.input, a.out)
        print(json.dumps({'written': str(a.out), 'depth': c['depth'], 'plaintext_bytes': c['plaintext_bytes']}, indent=2))
    elif a.cmd == 'decrypt':
        source_gate()
        print(json.dumps(decrypt_file(a.keydir, a.capsule, a.out), indent=2))
        print('WROTE', a.out)
    elif a.cmd == 'demo':
        r = demo(a.depth, a.input, a.workdir, a.seed0)
        print(json.dumps(r, indent=2))
        print('DEMO OUTPUT', a.workdir)
    elif a.cmd == 'penta-plan':
        print(json.dumps(pentation_plan(a.base, a.height, a.cap), indent=2, ensure_ascii=False))
    elif a.cmd == 'penta-demo':
        r = penta_demo(
            base=a.base,
            height=a.height,
            materialize_depth=a.materialize_depth,
            full_target=a.full_target,
            input_path=a.input,
            workdir=a.workdir,
            seed0=a.seed0,
            progress_every=a.progress_every,
            cap=a.cap,
        )
        print(json.dumps(r, indent=2, ensure_ascii=False))
        print('PENTA OUTPUT', a.workdir)


if __name__ == '__main__':
    main()
