# Entropic Tetration ET 0.13.0-alpha

Research prototype only. Not production cryptography and not a security proof.

## The change

ET 0.13 stops treating a hyperoperation value as a demand to physically generate that many complete Entropic Fusion and ML-KEM identities.

Instead, one file operation performs one full cryptographic root establishment:

- Entropic Fusion Beta 1.1.1 / B.23.1
- 4D n=3, 81 positions, 216 adjacencies, 432 materialised equations, DIM 64
- ML-KEM-768
- ML-KEM-1024
- the existing B.23.1 combined 256-bit root key

That secret root key then enters a virtual recursive state engine. Every virtual transition is actually executed in memory, in sequence, but no per-transition EF identity, ML-KEM keypair, JSON object or file is created.

The final 256-bit virtual state protects the payload with AES-256-GCM.

## Tetration mode

For `2^^4`, the planner evaluates the hyperoperation value as 65,536 virtual transitions.

Each transition updates a public modular accumulator

`t[n+1] = 2^t[n] mod p`

for a fixed public 64-bit prime `p`, and mixes that accumulator, the transition number and the fixed operation context into a sequential HMAC-SHA256 secret-state transition.

The next secret state depends on the previous secret state, so all 65,536 transitions are genuinely executed.

## Pentation mode

For `2^^^3`, the planner again gives 65,536 virtual transitions.

The experimental pentation kernel keeps the tetration accumulator and adds a second nested modular exponentiation accumulator before each secret-state transition.

This is deliberately described as a finite modular analogue / pentation-shaped recurrence. It is not a theorem that the cryptographic work factor grows pentationally.

## Measured ET 0.13 reference run

The packaged self-test ran both complete 65,536-transition sender/receiver paths.

On this environment the tetration kernel ran around 100,000 virtual transitions/second and the pentation kernel around 45,000-50,000 transitions/second. The exact figures are recorded in `ET_0_13_0_SUITE_RESULT.json` and will vary by machine.

Both 65,536-transition encryption/decryption round-trips passed exactly. The root EF relation verified, wrong private password was rejected, and payload tampering was rejected.

This is orders of magnitude faster than physically materialising 65,536 complete EF + dual-ML-KEM levels because only the root public-key establishment is physical.

## What this does NOT claim

- It does not prove tetrational or pentational security complexity.
- It does not establish extra security bits over the standard cryptographic core.
- It does not solve the ET 0.8 dual-KEM-compromise issue.
- The modular hyperoperation recurrences are experimental research kernels, not standard cryptographic primitives.
- Extremely large targets such as `3^^3^^3` remain symbolic unless a defensible jump-ahead mathematical construction is found. ET 0.13 does not pretend to execute that impossible number of transitions.

## Windows GUI

The Windows application now makes the distinction explicit:

- Standard: one full root, optional direct virtual-step count
- Tetration: hyperoperation-derived virtual transitions
- Pentation: hyperoperation-derived virtual transitions

The GUI includes live virtual-step progress, ETA, Cancel, Benchmark and Technical Details.

Build on Windows with:

`BUILD_ET_0_13_0_WINDOWS.bat`
