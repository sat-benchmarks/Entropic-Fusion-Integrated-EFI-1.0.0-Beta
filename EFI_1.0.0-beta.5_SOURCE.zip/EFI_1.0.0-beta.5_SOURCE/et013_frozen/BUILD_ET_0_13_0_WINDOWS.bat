@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo   Entropic Tetration ET 0.13.0-alpha - Virtual Recursion
echo ============================================================
echo.
echo One full EF 1.1.1 + dual ML-KEM root, then fast in-memory
echo sequential virtual recursion, then AES-256-GCM.
echo.
echo Target:
echo   1. One-file portable EntropicTetration.exe
echo   2. Self-contained Windows installer
echo   3. No end-user Python or separate OpenSSL installation
echo.

python validate_et_0_13_0_source.py
if errorlevel 1 goto :fail
python -c "import cryptography" >nul 2>nul
if errorlevel 1 python -m pip install --upgrade cryptography
if errorlevel 1 goto :fail
python -c "import PyInstaller" >nul 2>nul
if errorlevel 1 python -m pip install --upgrade pyinstaller
if errorlevel 1 goto :fail
python prepare_et_0_13_0_pyinstaller.py
if errorlevel 1 goto :fail
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if not exist release mkdir release
python -m PyInstaller --noconfirm --clean EntropicTetration_ET_0_13_0.spec
if errorlevel 1 goto :fail
python validate_et_0_13_0_frozen.py
if errorlevel 1 goto :fail
set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
 echo Inno Setup 6 was not found.
 goto :fail
)
"%ISCC%" EntropicTetration_ET_0_13_0.iss
if errorlevel 1 goto :fail
python package_et_0_13_0_windows_release.py
if errorlevel 1 goto :fail
echo.
echo ============================================================
echo   ET 0.13.0 WINDOWS VIRTUAL-RECURSION GATE PASSED
echo ============================================================
echo Portable: dist\EntropicTetration.exe
echo Installer: release\EntropicTetration_ET_0_13_0_Setup.exe
echo.
echo Send back ET_0_13_0_*_RESULT.json files.
pause
exit /b 0
:fail
echo.
echo ET 0.13.0 WINDOWS BUILD OR GATE FAILED
echo Send back any ET_0_13_0_*_RESULT.json files that were created.
pause
exit /b 1
