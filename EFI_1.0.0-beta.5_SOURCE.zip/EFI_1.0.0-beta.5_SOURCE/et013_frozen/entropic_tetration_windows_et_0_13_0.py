#!/usr/bin/env python3
from __future__ import annotations

import importlib
import json
import queue
import sys
import threading
import time
from pathlib import Path

import entropic_tetration_et_0_13_0 as core

VERSION = 'Entropic Tetration ET 0.13.0-alpha'
REFERENCE_TET_STEPS_PER_SECOND = 250_000.0
REFERENCE_PEN_STEPS_PER_SECOND = 70_000.0
REFERENCE_STD_STEPS_PER_SECOND = 400_000.0


def import_probe():
    names = [
        'entropic_tetration_et_0_13_0',
        'entropic_bound_fusion_v0_11B_23_1',
        'entropic_fusion_relation_v0_11B_23_1',
        'entropic_fusion_hybrid_combiner_v0_11B_23_1',
        'entropic_fusion_public_identity_v0_11B_23_1',
        'entropic_fusion_mlkem_runtime_v0_11B_23_1',
        'entropic_openssl_runtime_v0_11B_23_1',
        'beta1_1_1_rebuild_kit.entropic_bound_fusion_v0_11B_23_1',
        'beta1_1_1_rebuild_kit.entropic_fusion_relation_v0_11B_23_1',
        'beta1_1_1_rebuild_kit.entropic_fusion_public_identity_v0_11B_23_1',
        'beta1_1_1_rebuild_kit.entropic_fusion_mlkem_runtime_v0_11B_23_1',
    ]
    for name in names:
        importlib.import_module(name)
    print(json.dumps({'version': VERSION, 'import_probe': True, 'modules': names}, indent=2))
    return 0


def virtual_probe():
    t = core.virtual_plan('tetration', 2, 4)
    p = core.virtual_plan('pentation', 2, 3)
    assert t['steps'] == 65536
    assert p['steps'] == 65536
    bt = core.benchmark(steps=65536, mode='tetration')
    bp = core.benchmark(steps=65536, mode='pentation')
    out = {
        'version': VERSION,
        'virtual_probe': True,
        'tetration_plan': t,
        'pentation_plan': p,
        'tetration_benchmark': bt['benchmark'],
        'pentation_benchmark': bp['benchmark'],
    }
    print(json.dumps(out, indent=2))
    return 0


def cli_passthrough():
    if len(sys.argv) <= 1:
        return None
    if sys.argv[1] == 'import-probe':
        return import_probe()
    if sys.argv[1] == 'virtual-probe':
        return virtual_probe()
    return core.main(sys.argv[1:])


def _safe_details(obj):
    banned = ('password', 'private', 'secret', 'witness', 'seed', 'ciphertext_b64', 'outer_ct_b64', 'inner_ct_b64')
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            lk = str(k).lower()
            out[k] = '[redacted]' if any(x in lk for x in banned) else _safe_details(v)
        return out
    if isinstance(obj, list):
        return [_safe_details(x) for x in obj]
    return obj


def launch_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title(VERSION)
    root.geometry('920x700')
    root.minsize(780, 590)

    q = queue.Queue()
    cancel_event = threading.Event()
    busy = {'value': False, 'started': 0.0, 'step': 0, 'total': 0, 'pulse': False}
    last_details = {'value': {}}

    mode = tk.StringVar(value='Tetration')
    standard_steps = tk.StringVar(value='0')
    hyper_base = tk.StringVar(value='2')
    hyper_height = tk.StringVar(value='4')
    password = tk.StringVar()
    confirm = tk.StringVar()
    plan_text = tk.StringVar(value='')
    status = tk.StringVar(value='Ready')
    timing = tk.StringVar(value='')
    technical = tk.BooleanVar(value=False)

    main = ttk.Frame(root, padding=14)
    main.pack(fill='both', expand=True)

    bottom = ttk.Frame(main)
    bottom.pack(side='bottom', fill='x', pady=(8,0))
    buttons = ttk.Frame(bottom)
    buttons.pack(side='bottom', fill='x')
    techrow = ttk.Frame(bottom)
    techrow.pack(side='bottom', fill='x', pady=(0,4))

    ttk.Label(main, text=VERSION, font=('Segoe UI', 17, 'bold')).pack(anchor='w')
    ttk.Label(main, text='One full EF 1.1.1 + ML-KEM-768 + ML-KEM-1024 root, then fast in-memory virtual recursion, then AES-256-GCM.').pack(anchor='w', pady=(2,10))

    depthbox = ttk.LabelFrame(main, text='Virtual recursion', padding=10)
    depthbox.pack(fill='x')
    radio = ttk.Frame(depthbox)
    radio.grid(row=0, column=0, columnspan=8, sticky='w')
    for name in ('Standard','Tetration','Pentation'):
        ttk.Radiobutton(radio, text=name, variable=mode, value=name).pack(side='left', padx=(0,18))

    ttk.Label(depthbox, text='Standard steps').grid(row=1,column=0,sticky='w',pady=(10,0))
    std_entry = ttk.Entry(depthbox, textvariable=standard_steps, width=10)
    std_entry.grid(row=1,column=1,sticky='w',padx=(8,20),pady=(10,0))
    ttk.Label(depthbox, text='Base').grid(row=1,column=2,sticky='w',pady=(10,0))
    base_entry = ttk.Entry(depthbox, textvariable=hyper_base, width=8)
    base_entry.grid(row=1,column=3,sticky='w',padx=(8,20),pady=(10,0))
    ttk.Label(depthbox, text='Height').grid(row=1,column=4,sticky='w',pady=(10,0))
    height_entry = ttk.Entry(depthbox, textvariable=hyper_height, width=8)
    height_entry.grid(row=1,column=5,sticky='w',padx=(8,0),pady=(10,0))
    ttk.Label(depthbox, textvariable=plan_text, font=('Segoe UI',10,'bold')).grid(row=2,column=0,columnspan=8,sticky='w',pady=(10,0))
    ttk.Label(depthbox, text='All virtual transitions are actually executed sequentially in memory. No per-step EF/KEM objects or files are created.').grid(row=3,column=0,columnspan=8,sticky='w',pady=(4,0))

    pwbox = ttk.LabelFrame(main, text='Root private identity', padding=10)
    pwbox.pack(fill='x', pady=(10,0))
    ttk.Label(pwbox,text='Password').grid(row=0,column=0,sticky='w')
    ttk.Entry(pwbox,textvariable=password,show='*').grid(row=0,column=1,sticky='ew',padx=(8,20))
    ttk.Label(pwbox,text='Confirm for key generation').grid(row=0,column=2,sticky='w')
    ttk.Entry(pwbox,textvariable=confirm,show='*').grid(row=0,column=3,sticky='ew',padx=(8,0))
    pwbox.columnconfigure(1,weight=1); pwbox.columnconfigure(3,weight=1)

    statbox = ttk.LabelFrame(main, text='Operation status', padding=10)
    statbox.pack(fill='x',pady=(10,0))
    top = ttk.Frame(statbox); top.pack(fill='x')
    ttk.Label(top,textvariable=status,font=('Segoe UI',11,'bold')).pack(side='left')
    badge = tk.Label(top,text='READY',padx=12,pady=4,bg='#6b7280',fg='white')
    badge.pack(side='right')
    progressbar = ttk.Progressbar(statbox,orient='horizontal',mode='determinate',maximum=100)
    progressbar.pack(fill='x',pady=(8,4))
    ttk.Label(statbox,textvariable=timing).pack(anchor='w')

    summary = tk.Text(main,height=7,wrap='word',state='disabled',font=('Segoe UI',10))
    summary.pack(fill='both',expand=True,pady=(10,6))

    ttk.Checkbutton(techrow,text='Technical details',variable=technical).pack(side='left')
    detailframe = ttk.Frame(main)
    detail = tk.Text(detailframe,height=10,wrap='none',state='disabled',font=('Consolas',9))
    sy = ttk.Scrollbar(detailframe,orient='vertical',command=detail.yview)
    sx = ttk.Scrollbar(detailframe,orient='horizontal',command=detail.xview)
    detail.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
    detail.grid(row=0,column=0,sticky='nsew'); sy.grid(row=0,column=1,sticky='ns'); sx.grid(row=1,column=0,sticky='ew')
    detailframe.rowconfigure(0,weight=1); detailframe.columnconfigure(0,weight=1)

    def set_summary(lines):
        summary.configure(state='normal'); summary.delete('1.0','end')
        summary.insert('end','\n'.join(lines if isinstance(lines,list) else [lines])+'\n')
        summary.configure(state='disabled')

    set_summary([
        'Virtual recursion engine ready.',
        'Tetration 2^^4 and Pentation 2^^^3 both evaluate to 65,536 sequential virtual transitions.',
        'Unlike the old physical tower, only one full EF + dual-ML-KEM root establishment is created.',
    ])

    def refresh_details(*_):
        if technical.get():
            detailframe.pack(side='bottom',fill='both',expand=False,pady=(4,6),before=bottom)
            detail.configure(state='normal'); detail.delete('1.0','end')
            detail.insert('end',json.dumps(_safe_details(last_details['value']),indent=2)); detail.configure(state='disabled')
        else:
            detailframe.pack_forget()
    technical.trace_add('write',refresh_details)

    def fmt_seconds(sec):
        if sec < 1: return f'{sec*1000:.0f} ms'
        if sec < 60: return f'{sec:.1f} s'
        m, s = divmod(sec,60)
        if m < 60: return f'{int(m)}m {s:.0f}s'
        h, m = divmod(m,60); return f'{int(h)}h {int(m)}m'

    def current_plan(show_error=False):
        try:
            m = mode.get().lower()
            b = int(hyper_base.get() or '2')
            h = int(hyper_height.get() or '1')
            ss = int(standard_steps.get() or '0')
            p = core.virtual_plan(m,b,h,ss)
            if m == 'standard':
                std_entry.configure(state='normal'); base_entry.configure(state='disabled'); height_entry.configure(state='disabled')
                rate = REFERENCE_STD_STEPS_PER_SECOND
            else:
                std_entry.configure(state='disabled'); base_entry.configure(state='normal'); height_entry.configure(state='normal')
                rate = REFERENCE_TET_STEPS_PER_SECOND if m == 'tetration' else REFERENCE_PEN_STEPS_PER_SECOND
            if p['steps'] is None:
                plan_text.set(p['description'] + ' (symbolic only)')
            else:
                estimate = p['steps']/rate if rate else 0
                plan_text.set(f"{p['description']}   •   virtual-kernel estimate ~{fmt_seconds(estimate)}")
            return p
        except Exception as e:
            plan_text.set(str(e))
            if show_error: messagebox.showerror('Virtual recursion',str(e))
            return None

    last_mode = {'value':mode.get()}
    def mode_changed(*_):
        m = mode.get()
        if m != last_mode['value']:
            if m == 'Tetration': hyper_base.set('2'); hyper_height.set('4')
            elif m == 'Pentation': hyper_base.set('2'); hyper_height.set('3')
            last_mode['value']=m
        current_plan()
    mode.trace_add('write',mode_changed)
    for var in (standard_steps,hyper_base,hyper_height): var.trace_add('write',lambda *_: current_plan())
    current_plan()

    action_buttons=[]
    def set_controls(enabled):
        st='normal' if enabled else 'disabled'
        for b in action_buttons: b.configure(state=st)
        if enabled: current_plan()
        else:
            std_entry.configure(state='disabled'); base_entry.configure(state='disabled'); height_entry.configure(state='disabled')

    def begin(label):
        cancel_event.clear(); busy.update(value=True,started=time.perf_counter(),step=0,total=0)
        status.set(label); timing.set('Starting…'); progressbar['value']=0
        badge.configure(text='WORKING',bg='#2563eb'); cancel_button.configure(state='normal'); set_controls(False)

    def finish(ok=True):
        busy['value']=False; cancel_button.configure(state='disabled'); set_controls(True)
        badge.configure(text='PASSED' if ok else 'FAILED',bg='#15803d' if ok else '#b91c1c')

    def progress(kind,step,total):
        if cancel_event.is_set(): raise core.OperationCancelled('cancelled by user')
        q.put(('progress',{'kind':kind,'step':int(step),'total':int(total)}))

    def worker(label,fn):
        begin(label)
        def run():
            try:
                r=fn()
                q.put(('cancelled',{'label':label}) if cancel_event.is_set() else ('done',{'label':label,'result':r}))
            except core.OperationCancelled:
                q.put(('cancelled',{'label':label}))
            except Exception as e:
                q.put(('error',{'label':label,'error':f'{type(e).__name__}: {e}'}))
        threading.Thread(target=run,daemon=True).start()

    def require_password(confirm_needed=False):
        pw=password.get()
        if len(pw)<10:
            messagebox.showerror('Password','Password must be at least 10 characters.'); return None
        if confirm_needed and pw!=confirm.get():
            messagebox.showerror('Password','Password confirmation does not match.'); return None
        return pw

    def do_keygen():
        pw=require_password(True)
        if pw is None:return
        pub=filedialog.asksaveasfilename(title='Save ET 0.13 public root',initialfile='ET ROOT PUBLIC.et13pub.json',defaultextension='.et13pub.json')
        if not pub:return
        priv=filedialog.asksaveasfilename(title='Save protected ET 0.13 private root',initialfile='ET ROOT PRIVATE.et13priv.json',defaultextension='.et13priv.json')
        if not priv:return
        worker('Generating one full EF + dual-ML-KEM root…',lambda:core.generate_identity(Path(pub),Path(priv),password=pw))

    def do_encrypt():
        p=current_plan(True)
        if not p or not p['exact_within_cap']:
            messagebox.showerror('Virtual recursion','This setting is symbolic only in ET 0.13.');return
        pub=filedialog.askopenfilename(title='Select ET 0.13 public root',filetypes=[('ET 0.13 public root','*.et13pub.json'),('JSON','*.json'),('All files','*.*')])
        if not pub:return
        inp=filedialog.askopenfilename(title='Select file to encrypt')
        if not inp:return
        out=filedialog.asksaveasfilename(title='Save encrypted file',initialfile=Path(inp).name+'.et13',defaultextension='.et13')
        if not out:return
        worker(f"Encrypting with {p['description']}…",lambda:core.encrypt_file(Path(pub),Path(inp),Path(out),mode=p['mode'],base_value=int(p.get('base') or 2),height=int(p.get('height') or 1),standard_steps=int(p.get('steps') or 0) if p['mode']=='standard' else 0,progress=progress,cancel=cancel_event.is_set))

    def do_decrypt():
        pw=require_password(False)
        if pw is None:return
        priv=filedialog.askopenfilename(title='Select ET 0.13 protected private root',filetypes=[('ET 0.13 private root','*.et13priv.json'),('JSON','*.json'),('All files','*.*')])
        if not priv:return
        cap=filedialog.askopenfilename(title='Select ET 0.13 encrypted file',filetypes=[('Entropic Tetration ET 0.13','*.et13'),('All files','*.*')])
        if not cap:return
        try: meta=core.capsule_metadata(Path(cap))
        except Exception as e: messagebox.showerror('Capsule',f'{type(e).__name__}: {e}');return
        out=filedialog.asksaveasfilename(title='Save recovered file',initialfile=meta['filename'],defaultextension=Path(meta['filename']).suffix)
        if not out:return
        worker(f"Decrypting {meta['notation']} ({meta['steps']:,} virtual transitions)…",lambda:core.decrypt_file(Path(priv),pw,Path(cap),Path(out),progress=progress,cancel=cancel_event.is_set))

    def do_selftest():
        worker('Running ET 0.13 virtual self-test…',lambda:core.self_test(Path.cwd()/'ET_0_13_0_GUI_SELFTEST'))

    def do_benchmark():
        p=current_plan(True)
        if not p or not p['exact_within_cap']:return
        worker(f"Benchmarking {p['mode']} virtual kernel…",lambda:core.benchmark(steps=int(p['steps']),mode=p['mode']))

    for text,cmd in [('Generate Root Keys',do_keygen),('Encrypt File',do_encrypt),('Decrypt File',do_decrypt),('Self-Test',do_selftest),('Benchmark',do_benchmark)]:
        b=ttk.Button(buttons,text=text,command=cmd,width=18); b.pack(side='left',padx=(0,7),pady=(2,2)); action_buttons.append(b)

    def request_cancel():
        if busy['value']:
            cancel_event.set(); status.set('Cancelling…'); timing.set('Cancellation requested.'); badge.configure(text='CANCELLING',bg='#b45309'); cancel_button.configure(state='disabled')
    cancel_button=ttk.Button(buttons,text='Cancel',command=request_cancel,width=12,state='disabled'); cancel_button.pack(side='right',padx=(8,0))

    def summarize(label,r):
        lines=[f'{label}: PASSED']
        if 'virtual_steps' in r:
            lines += [f"Virtual transitions: {r['virtual_steps']:,}", f"Mode: {r.get('notation',r.get('mode',''))}"]
        vm=r.get('virtual_metrics') or r.get('benchmark')
        if vm:
            lines += [f"Virtual kernel: {vm.get('steps_per_second',0):,.0f} transitions/second", f"Virtual kernel time: {vm.get('seconds',0):.3f} s"]
        if r.get('root_relation_verified') is True: lines.append('Entropic Fusion root relation: PASSED')
        if r.get('recovered_bytes') is not None: lines.append(f"Recovered bytes: {r['recovered_bytes']:,}")
        if r.get('suite_pass') is True: lines.append('Full self-test suite: PASSED')
        return lines

    def pump():
        try:
            while True:
                kind,payload=q.get_nowait()
                if kind=='progress':
                    step,total=payload['step'],payload['total']; busy['step']=step;busy['total']=total
                    progressbar['maximum']=max(1,total);progressbar['value']=step
                    elapsed=max(.001,time.perf_counter()-busy['started']); eta=(elapsed/step)*(total-step) if step else 0
                    status.set(f"Virtual recursion: {step:,} / {total:,}"); timing.set(f"Elapsed {fmt_seconds(elapsed)}   ETA {fmt_seconds(eta)}")
                elif kind=='done':
                    r=payload['result']; last_details['value']=r; elapsed=time.perf_counter()-busy['started']
                    status.set('Complete'); timing.set(f'Completed in {fmt_seconds(elapsed)}'); progressbar['value']=progressbar['maximum']
                    set_summary(summarize(payload['label'],r)); finish(True); refresh_details(); messagebox.showinfo('Entropic Tetration','Operation completed successfully.')
                elif kind=='cancelled':
                    last_details['value']={'cancelled':True,'completed_steps':busy['step'],'requested_steps':busy['total']}
                    status.set('Cancelled');timing.set('Operation cancelled.');set_summary([f"{payload['label']}: CANCELLED",f"Completed virtual transitions: {busy['step']:,}"])
                    busy['value']=False;cancel_button.configure(state='disabled');badge.configure(text='CANCELLED',bg='#b45309');set_controls(True);refresh_details()
                elif kind=='error':
                    last_details['value']={'error':payload['error']};status.set('Failed');timing.set('');set_summary([f"{payload['label']}: FAILED",payload['error']]);finish(False);refresh_details();messagebox.showerror('Entropic Tetration',payload['error'])
        except queue.Empty:
            pass
        if busy['value']:
            busy['pulse']=not busy['pulse'];badge.configure(bg='#2563eb' if busy['pulse'] else '#60a5fa')
            if not busy['step']: timing.set(f"Elapsed {fmt_seconds(time.perf_counter()-busy['started'])}")
        root.after(200,pump)

    def on_close():
        if busy['value']:
            if messagebox.askyesno('Operation in progress','Cancel the current operation and close?'):
                cancel_event.set();root.destroy()
        else: root.destroy()
    root.protocol('WM_DELETE_WINDOW',on_close)
    pump();root.mainloop()


if __name__ == '__main__':
    rc=cli_passthrough()
    if rc is None: launch_gui()
    else: raise SystemExit(rc)
