# Entropic Tetration changelog

## ET 0.13.0-alpha
- Replaced hyperoperation-as-physical-level-count for normal Tetration/Pentation mode with a fast virtual recursive state engine.
- One full EF 1.1.1 + ML-KEM-768 + ML-KEM-1024 root establishment per operation.
- All virtual transitions execute sequentially in memory without per-step KEM keypairs or EF identities.
- Added tetration modular recurrence bound into the HMAC-SHA256 secret-state chain.
- Added experimental nested modular recurrence for Pentation mode.
- Verified 2^^4 = 65,536 virtual transitions end-to-end.
- Verified 2^^^3 = 65,536 virtual transitions end-to-end.
- Added Benchmark button and virtual-step progress/ETA/Cancel.
- Retained AES-256-GCM payload protection.
- Explicitly does not claim tetrational/pentational security hardness.
- ET 0.8 dual-KEM-compromise finding remains open.
