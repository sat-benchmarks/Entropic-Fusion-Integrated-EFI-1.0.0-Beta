#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, json, subprocess, sys, tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
KIT=HERE/'beta1_1_1_rebuild_kit'
CORE_HASHES={
'entropic_bound_fusion_v0_11B_23_1.py':'8fdc7e7c8c8b1d45a12d09a86d799c642eec12170eaf0c221a0acc07473e81b9',
'entropic_fusion_relation_v0_11B_23_1.py':'2ca99b6b23bcfbaf527fec957f7dd8c041a3f26a6b201f539b7e7150910c1838',
'entropic_fusion_hybrid_combiner_v0_11B_23_1.py':'d78f38177866c8a2821c61774cc1362cf515bfeaddd37e6de62f9b95a98e8f5d',
'entropic_fusion_public_identity_v0_11B_23_1.py':'e87399245ba047679c8eca388cc65f66fee2b17581ab1c633ec43b561143ed64',
'entropic_fusion_mlkem_runtime_v0_11B_23_1.py':'4807d984ad15230c40e0f5f8ac57d1f56ed0910824d86e63bd98b587b5b76091',
}

def h(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(args): return subprocess.run(args,cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)

def main():
    tests={};bad=[]
    for p in list(HERE.glob('*.py'))+list(KIT.glob('*.py')):
        try: ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
        except Exception as e: bad.append(f'{p.name}: {e}')
    tests['all_python_sources_parse']=not bad
    observed={n:h(KIT/n) for n in CORE_HASHES}
    tests['beta111_core_hashes_exact']=all(observed[n]==CORE_HASHES[n] for n in CORE_HASHES)
    probe=run([sys.executable,'entropic_tetration_windows_et_0_13_0.py','virtual-probe'])
    tests['virtual_probe_passed']=probe.returncode==0
    try:
        pobj=json.loads(probe.stdout)
        tests['tetration_65536_verified']=pobj['tetration_plan']['steps']==65536
        tests['pentation_65536_verified']=pobj['pentation_plan']['steps']==65536
        tests['tetration_virtual_speed_over_1000_per_second']=pobj['tetration_benchmark']['steps_per_second']>1000
        tests['pentation_virtual_speed_over_1000_per_second']=pobj['pentation_benchmark']['steps_per_second']>1000
    except Exception:
        tests['tetration_65536_verified']=tests['pentation_65536_verified']=False
        tests['tetration_virtual_speed_over_1000_per_second']=tests['pentation_virtual_speed_over_1000_per_second']=False
    with tempfile.TemporaryDirectory(prefix='et013_source_') as td:
        cp=run([sys.executable,'entropic_tetration_et_0_13_0.py','self-test','--workdir',str(Path(td)/'work')])
        tests['source_selftest_returncode_zero']=cp.returncode==0
        result_path=Path(td)/'work'/'ET_0_13_0_SELFTEST_RESULT.json'
        if result_path.exists():
            r=json.loads(result_path.read_text())
            tests['source_selftest_suite_pass']=r.get('suite_pass') is True
            tests['source_tetration_roundtrip']=r.get('tests',{}).get('tetration_roundtrip_exact') is True
            tests['source_pentation_roundtrip']=r.get('tests',{}).get('pentation_roundtrip_exact') is True
        else:
            tests['source_selftest_suite_pass']=tests['source_tetration_roundtrip']=tests['source_pentation_roundtrip']=False
    result={'version':'ET 0.13.0-alpha','scope':'virtual recursion source gate','tests':tests,'core_hashes':observed,'virtual_probe_stdout':probe.stdout[-12000:],'parse_errors':bad,'all_tests_passed':all(tests.values())}
    (HERE/'ET_0_13_0_SOURCE_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    raise SystemExit(0 if result['all_tests_passed'] else 1)

if __name__=='__main__': main()
