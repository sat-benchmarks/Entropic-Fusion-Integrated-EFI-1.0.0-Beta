#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, subprocess, tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent

def h(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run_hidden(cmd,**kwargs):
    startup=None; flags=0
    if os.name=='nt':
        startup=subprocess.STARTUPINFO(); startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW; flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    return subprocess.run(cmd,startupinfo=startup,creationflags=flags,**kwargs)

def main():
    exe=HERE/'dist'/'EntropicTetration.exe'; tests={'frozen_exe_exists':exe.exists()}; observed={}
    if exe.exists():
        observed['exe_sha256']=h(exe)
        with tempfile.TemporaryDirectory(prefix='et013_frozen_') as td:
            td=Path(td); env=dict(os.environ); env.pop('ENTROPIC_OPENSSL',None)
            probe=run_hidden([str(exe),'import-probe'],cwd=td,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            tests['frozen_beta111_import_closure']=probe.returncode==0; observed['import_probe_stdout_tail']=probe.stdout[-4000:]; observed['import_probe_stderr_tail']=probe.stderr[-4000:]
            vp=run_hidden([str(exe),'virtual-probe'],cwd=td,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            tests['frozen_virtual_probe']=vp.returncode==0; observed['virtual_probe_stdout_tail']=vp.stdout[-8000:]; observed['virtual_probe_stderr_tail']=vp.stderr[-4000:]
            work=td/'work'
            cp=run_hidden([str(exe),'self-test','--workdir',str(work)],cwd=td,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            tests['frozen_selftest_returncode_zero']=cp.returncode==0; observed['selftest_stdout_tail']=cp.stdout[-8000:]; observed['selftest_stderr_tail']=cp.stderr[-4000:]
            rp=work/'ET_0_13_0_SELFTEST_RESULT.json'
            if rp.exists():
                r=json.loads(rp.read_text())
                tests['frozen_selftest_suite_pass']=r.get('suite_pass') is True
                tests['frozen_tetration_roundtrip']=r.get('tests',{}).get('tetration_roundtrip_exact') is True
                tests['frozen_pentation_roundtrip']=r.get('tests',{}).get('pentation_roundtrip_exact') is True
                tests['frozen_used_bundled_runtime']=bool(r.get('runtime_lineage',{}).get('frozen'))
                observed['openssl']=r.get('runtime_lineage',{}).get('openssl')
                observed['openssl_executable']=r.get('runtime_lineage',{}).get('openssl_executable')
            else:
                tests['frozen_selftest_suite_pass']=tests['frozen_tetration_roundtrip']=tests['frozen_pentation_roundtrip']=tests['frozen_used_bundled_runtime']=False
    result={'version':'ET 0.13.0-alpha','scope':'Frozen Windows virtual-recursion gate','tests':tests,'observed':observed,'all_tests_passed':all(tests.values())}
    (HERE/'ET_0_13_0_FROZEN_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2)); raise SystemExit(0 if result['all_tests_passed'] else 1)
if __name__=='__main__': main()
