#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import ast, json, sys

HERE = Path(__file__).resolve().parent
KIT = HERE / 'beta1_1_1_rebuild_kit'
sys.path.insert(0, str(KIT))
VERSION = 'ET 0.13.0-alpha'


def collect_openssl():
    from entropic_openssl_runtime_v0_11B_23_1 import openssl_executable
    exe = Path(openssl_executable()).resolve()
    if not exe.exists():
        raise FileNotFoundError(exe)
    binaries=[(str(exe),'openssl')]
    for p in exe.parent.glob('*.dll'):
        binaries.append((str(p),'openssl'))
    for folder in (exe.parent.parent/'lib'/'ossl-modules', exe.parent/'ossl-modules', exe.parent.parent/'lib64'/'ossl-modules'):
        if folder.is_dir():
            for p in folder.glob('*'):
                if p.is_file(): binaries.append((str(p),'openssl/ossl-modules'))
    return exe,binaries


def kit_module_names():
    stems=sorted(p.stem for p in KIT.glob('*.py') if p.name!='__init__.py')
    return stems+[f'beta1_1_1_rebuild_kit.{n}' for n in stems]


def source_import_closure():
    stems={p.stem for p in KIT.glob('*.py') if p.name!='__init__.py'}
    found=set()
    for p in KIT.glob('*.py'):
        tree=ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):
                for alias in node.names:
                    head=alias.name.split('.',1)[0]
                    if head in stems: found.add(head)
            elif isinstance(node,ast.ImportFrom) and node.module:
                head=node.module.split('.',1)[0]
                if head in stems: found.add(head)
    return sorted(found)


def main():
    exe,binaries=collect_openssl()
    hidden=kit_module_names()
    closure=source_import_closure()
    missing=sorted(set(closure)-set(hidden))
    if missing: raise RuntimeError('PyInstaller hidden-import closure incomplete: '+', '.join(missing))
    spec="""# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas=[]
binaries={binaries!r}
hiddenimports={hidden!r}
for pkg in ('cryptography',):
    try:
        d,b,h=collect_all(pkg); datas+=d; binaries+=b; hiddenimports+=h
    except Exception:
        pass

a=Analysis(
    ['entropic_tetration_windows_et_0_13_0.py'],
    pathex=[{here!r},{kit!r}],
    binaries=binaries,datas=datas,hiddenimports=hiddenimports,
    hookspath=[],hooksconfig={{}},runtime_hooks=[],excludes=[],noarchive=False,optimize=0,
)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,a.binaries,a.datas,[],name='EntropicTetration',debug=False,bootloader_ignore_signals=False,strip=False,upx=False,console=False,disable_windowed_traceback=True)
""".format(binaries=binaries,hidden=hidden,here=str(HERE),kit=str(KIT))
    (HERE/'EntropicTetration_ET_0_13_0.spec').write_text(spec,encoding='utf-8')
    audit={'version':VERSION,'openssl':str(exe),'kit_python_modules':len(list(KIT.glob('*.py'))),'hidden_import_entries':len(hidden),'direct_kit_import_closure':closure,'missing_from_hidden_imports':missing,'spec_written':True}
    (HERE/'ET_0_13_0_PYINSTALLER_PREP_RESULT.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps(audit,indent=2))

if __name__=='__main__': main()
