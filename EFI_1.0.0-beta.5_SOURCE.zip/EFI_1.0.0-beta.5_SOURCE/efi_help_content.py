from __future__ import annotations

HELP_SECTIONS = [
    (
        "quick-start",
        "Quick Start",
        "The shortest route from a fresh install to a verified encrypted round trip.",
        """ENTROPIC FUSION INTEGRATED - QUICK START

WHY EFI EXISTS - HNDL IN ONE SENTENCE
HNDL means Harvest Now, Decrypt Later: an attacker can copy encrypted material today and keep it, hoping future quantum computers or other advances will make today's public-key protection breakable later.

WHAT ENTROPIC FUSION MEANS
ENTROPIC FUSION = ENTROPIC NOTATION + ML-KEM-768 + ML-KEM-1024

Entropic Fusion is the project's coupled root construction. The two NIST-standardised post-quantum ML-KEM sessions and the Entropic relation are deliberately bound into one legitimate root-recovery dependency. They are not presented as detachable outer and inner encryption layers.

On the official private path, the Entropic witness must verify to derive the fusion secret that releases both wrapped root ML-KEM private keys. The root combiner then binds the ML-KEM-768 shared secret, the ML-KEM-1024 shared secret, the EF-gated contribution, transcript and context into one 256-bit root key.

AES-256-GCM is not the thing being "fused" in the name Entropic Fusion. It is the established conventional authenticated-encryption layer used later to protect file and control data. EFI then builds the wider application stack on the fused root with Tetration/Pentation, Entropic Chain, metadata-private streaming and optional deniable storage.

IMPORTANT: HNDL resistance in the current system is anchored to the NIST-standardised ML-KEM components. The novel Entropic constructions remain experimental and are not claimed to have an independently proven post-quantum security level.

1. Create an EFI identity
Open Identity. Choose where to save the public and private identity files, enter a strong password twice, then click Create EFI Identity.

The public identity is the file you share with someone who needs to encrypt to you. The private identity stays with you and is protected by the password you chose.

2. Choose the Entropic Engine settings
On Encrypt you can choose Standard, Tetration or Pentation. The normal demonstration settings are:
• Tetration: Base 2, Height 4, giving 2^^4 = 65,536 finite virtual transitions.
• Pentation: Base 2, Height 3, giving 2^^^3 = 65,536 finite virtual transitions.
• Entropic Chain: 20 cycles, which gives 100 sequential stages because each cycle contains five mathematical families.

3. Encrypt a file
Open Encrypt, choose the recipient public identity and choose the source file. EFI suggests a random name such as EFI-a1b2c3d4e5f60718.efi so the Windows filename does not reveal the original document name.

Click Encrypt File. EFI 1.0.0-beta.5 streams the source in bounded chunks instead of loading a multi-gigabyte file into memory. The progress bar shows the content phase, followed by finalisation of the Entropic control layers.

4. Decrypt a file
Open Decrypt, choose the matching private identity, the .efi capsule and a destination folder. Enter the password and click Decrypt File.

The original filename is not available to the GUI until the protected control information has been opened successfully. EFI then restores the original filename in the selected folder. Existing files are not silently overwritten.

5. Check the installation
Open Self-Test and run the integrated test. It checks the bundled ET and Beta source lines, ML-KEM/OpenSSL availability, GUI features, metadata privacy and a real encrypt/decrypt round trip.

6. Use the Vault only when required
The mounted Entropic Vault is a separate storage workflow. Launch it from Vault. WinFsp is included in the normal Windows installer, so the target computer does not need to download it separately.

A standalone .efi file does not require a mounted vault.""",
    ),
    (
        "overview",
        "What This Application Does",
        "A map of the integrated application and what each subsystem is responsible for.",
        """Entropic Fusion Integrated combines the previously separate Entropic Fusion, Entropic Tetration, Entropic Chain and Beta 1.1.1 Vault work into one Windows application. Its long-term confidentiality motivation is Harvest Now, Decrypt Later (HNDL): protect key establishment today with NIST-standardised post-quantum ML-KEM rather than rely on classical public-key exchange that may become vulnerable later.

EFI FILE WORKFLOW
Identity, Encrypt, Decrypt and Inspect operate the standalone .efi file format. EFI 1.0.0-beta.5 retains the metadata-private streaming envelope outside the existing EFI 0.5 integrated protocol.

ENTROPIC ENGINE
The Entropic Engine exposes ET 0.13 Standard, Tetration and Pentation planning. It can calculate the finite transition count, execute the sequential virtual kernel, show live progress, cancel a demo and benchmark the kernel on the current computer.

ENTROPIC CHAIN
The inner EFI workflow can add the sequential Entropic Chain after the root layer. One cycle contains five mathematical families. Twenty cycles gives the normal EC100 profile of 100 stages.

STREAMING FILE LAYER
The actual user file is encrypted in authenticated 2 MiB chunks using a fresh 256-bit data key. That data key, the real filename, the exact length and the stream parameters are placed inside a small secret control record. The control record is then protected by the full integrated EFI inner protocol.

METADATA-PRIVATE CONTROL LAYER
The complete inner EFI control capsule is compressed, padded to a fixed 4 MiB control region and encrypted with a fresh ML-KEM-1024 derived outer control key. This keeps the mode, chain profile, filename and inner capsule structure off the public surface.

ENTROPIC VAULT
The Vault tab launches the validated Beta 1.1.1 mounted-storage desktop. It uses a separate EntropicFusionHost.exe process and WinFsp. It is related to the same project but is not required for normal standalone file encryption.

SELF-TEST AND ACTIVITY
Self-Test performs repeatable implementation checks. Activity records human-readable session events. Passwords, private keys and plaintext file contents are not intentionally written to the Activity view.

RESEARCH STATUS
This is experimental research software. A successful round trip proves that the implementation completed the intended route. It does not prove a formal security level for the novel Entropic layers.""",
    ),
    (
        "fusion-model",
        "What Entropic Fusion Means",
        "Entropic Notation + ML-KEM-768 + ML-KEM-1024, mutually bound in one root recovery path.",
        """ENTROPIC FUSION = ENTROPIC NOTATION + ML-KEM-768 + ML-KEM-1024

THE DEFINING FUSION
Entropic Fusion is the project's coupled root construction. It binds the experimental Entropic Notation relation directly to two NIST-standardised post-quantum key-establishment sessions: ML-KEM-768 and ML-KEM-1024.

WHY FUSION, NOT LAYERS
The design goal was specifically to avoid a simple sequence such as "break the Entropic layer, then break the KEM layer" or the reverse. In the official private recovery path, the components form one dependency graph rather than independent outer and inner encryption wrappers.

The Entropic witness must verify first. Verification derives the fusion secret. That fusion secret releases both wrapped root KEM private keys. Only then can the two KEM ciphertexts be decapsulated. The final root combiner binds both KEM shared secrets, the EF-gated session contribution, the authenticated ciphertext transcript and application context into one 256-bit root key.

This is what "fused" means in EFI: the legitimate root path depends on the Entropic relation and both root KEM sessions together. It is not merely three algorithms listed beside one another.

ENTROPIC NOTATION / ENTROPIC RELATION
In the current frozen root, the notation is represented by a 4D n=3 arrangement with 81 positions, 81 pieces, 8 faces per piece and 192 proper orientations per piece. A candidate adjacency transcript determines which face and centre equations materialise. The complete private witness must cover the geometry one-to-one and satisfy both equation channels across every true adjacency before the fusion secret is released.

DUAL ML-KEM
The fused root uses ML-KEM-768 and ML-KEM-1024. ML-KEM-1024 is the highest-security parameter set in ML-KEM; ML-KEM-768 provides a second independently encapsulated post-quantum contribution. Both are NIST-standardised key-encapsulation mechanisms, not bulk file ciphers.

AES-256-GCM COMES AFTER THE FUSION
AES-256-GCM is the established conventional authenticated-encryption primitive used for protected data, stream records and control records. It is an essential EFI component, but it is not what the name Entropic Fusion refers to.

THE WIDER EFI STACK
Entropic Fusion
+ Tetration/Pentation
+ Entropic Chain
+ AES-256-GCM
+ metadata-private streaming
+ optional deniable storage
= EFI

RESEARCH LIMIT
The current B.23.1 root has a recorded limitation. The EF-gated session contribution is derived from the ML-KEM-1024 shared secret plus public commitment/transcript material. If an external oracle supplies both raw B.23.1 KEM shared secrets, that contribution can presently be recomputed without an independently secret third Entropic value.

Accordingly, EFI demonstrates a fused Entropic-witness-gated ML-KEM recovery path, but it is not yet a formal proof that every attacker must independently break Entropic Notation and both ML-KEM instances simultaneously under every attack model. Strengthening that independent Entropic secret contribution is the next root research target.

CORRECT SHORT DESCRIPTION
Entropic Fusion mutually binds Entropic Notation with dual NIST-standardised post-quantum key establishment using ML-KEM-768 and ML-KEM-1024. EFI then builds Tetration/Pentation, Entropic Chain, conventional AES-256-GCM data protection, metadata privacy and optional deniable storage on that fused root.""",
    ),
    (
        "hndl",
        "Harvest Now, Decrypt Later (HNDL)",
        "Why EFI uses post-quantum key establishment now, before cryptographically relevant quantum computers exist.",
        """HNDL IN ONE SENTENCE
Harvest Now, Decrypt Later means an attacker collects encrypted material today and stores it, betting that future quantum computers or other cryptanalytic advances will make today's public-key protection breakable later.

WHY IT MATTERS
The attack does not require the adversary to decrypt anything today. Collection alone may be useful when the protected material has a long confidentiality lifetime: archives, intellectual property, legal records, research, credentials, infrastructure data or anything expected to remain sensitive for years.

THE PUBLIC-KEY PROBLEM
Many conventional encrypted systems protect a randomly generated symmetric data key through a public-key mechanism. If that public-key mechanism is vulnerable to a future quantum attack, an adversary who retained the ciphertext may later recover the data key and then decrypt the stored content.

WHAT EFI DOES
EFI does not use classical RSA or elliptic-curve key establishment for its root. Entropic Fusion establishes two independent NIST-standardised post-quantum sessions, ML-KEM-768 and ML-KEM-1024, and binds them into the Entropic root recovery path. EFI also uses ML-KEM-1024 for the independent guard leg and the outer metadata-private control envelope.

The actual file content is protected with AES-256-GCM, an established conventional authenticated-encryption primitive. The post-quantum part protects key establishment; AES-256-GCM protects the bulk data.

WHY ENTROPIC FUSION WAS DEVELOPED
The research question was not merely "can post-quantum ML-KEM be added to a conventional file cipher?" Hybrid and post-quantum constructions already exist. The EFI research question was whether Entropic Notation could be bound directly to post-quantum key establishment so the legitimate root is coupled rather than a stack of detachable stages.

That is why the defining formula is:

ENTROPIC NOTATION + ML-KEM-768 + ML-KEM-1024 = ENTROPIC FUSION

and the wider application is:

ENTROPIC FUSION + TETRATION/PENTATION + ENTROPIC CHAIN + AES-256-GCM + METADATA-PRIVATE STREAMING = EFI

IMPORTANT: Do not describe EFI as "HNDL-proof". The defensible claim is that EFI is designed for HNDL-resistant key establishment through NIST-standardised ML-KEM. The experimental Entropic components remain research constructions, and B.23.1 has a documented raw-KEM-secret oracle limitation.""",
    ),
    (
        "identity",
        "EFI Identities",
        "Public identity, private identity, passwords and what can be shared.",
        """An EFI recipient identity is a pair of files.

PUBLIC IDENTITY
The public identity contains the material a sender needs to encrypt to that recipient. It is intended to be shareable. The sender does not need the recipient password or private identity.

PRIVATE IDENTITY
The private identity contains the corresponding private material in password-protected form. Keep it private. Anyone who obtains both the private identity and its password may be able to open capsules encrypted to that identity.

PASSWORD
Use a long password or passphrase that is not reused elsewhere. The password protects the private identity at rest. Losing the password can make old capsules unrecoverable even if the private identity file still exists.

BACKUPS
Back up the private identity independently from the working computer. The public identity alone cannot decrypt existing capsules. If long-term recovery matters, keep at least one independent copy of the private identity and an appropriate independent method of retaining the password.

DO NOT SEND THE PRIVATE IDENTITY WITH A CAPSULE
To receive an encrypted file, give the sender the public identity only. Keep the private identity and password on the receiving side.

RECIPIENT FINGERPRINTS
Older EFI formats exposed a stable recipient fingerprint in readable metadata. EFI 1.0.0-beta.5 does not place that fingerprint on the public outside of a new streaming envelope. Identity binding still exists internally where the protocol requires it.""",
    ),
    (
        "encrypt",
        "Encrypting Files",
        "What each field means and what happens after you click Encrypt File.",
        """RECIPIENT PUBLIC IDENTITY
Choose the public identity belonging to the person or system that should be able to decrypt the file.

INPUT FILE
Choose the file to protect. EFI 1.0.0-beta.5 processes the source in bounded 2 MiB chunks. It does not pass a multi-gigabyte source file into the old whole-file EFI 0.5 payload routine.

EFI CAPSULE NAME
EFI suggests a random opaque .efi filename. This is deliberate. The Windows filename exists outside the cryptography, so naming the capsule after the original file would immediately reveal information.

ENTROPIC ENGINE MODE
Standard, Tetration and Pentation select the ET 0.13 finite virtual-recursion plan used by the inner EFI root layer. The selected plan is part of the encrypted control capsule and is not readable from the public outside of the new format.

EC CYCLES
Each cycle contains the five Entropic Chain families. The normal setting is 20 cycles, producing 100 stages. More cycles increase legitimate sequential work and increase the size of the encrypted control capsule. The outer control region is fixed in size so that this does not directly reveal the cycle count.

WHAT HAPPENS INTERNALLY
1. EFI records the real filename and exact source size in a secret stream-control record.
2. EFI generates a fresh 256-bit data key, stream identifier and nonce prefix.
3. The source is encrypted in authenticated 2 MiB AES-256-GCM chunks.
4. After the real file ends, zero-filled plaintext chunks continue until the selected coarse size class is reached. Encryption makes those zero chunks look like the rest of the ciphertext.
5. A SHA-256 digest of the real source is recorded in the secret control record for end-to-end recovery checking.
6. The complete secret control record is encrypted as the small payload of the existing EFI 0.5 integrated protocol. The ET root, guard leg and Entropic Chain therefore protect the data key rather than forcing the huge source file through the legacy in-memory payload path.
7. That inner control capsule is compressed, placed in a fixed 4 MiB control block and encrypted with a fresh outer ML-KEM-1024 plus HKDF-SHA256 and AES-256-GCM control layer.
8. The fixed control block is written at the start of the .efi file, followed by the authenticated streaming data records.

CANCELLATION
Encrypt has a Cancel button. Cancellation is cooperative. EFI finishes the current bounded operation, removes the incomplete output capsule and stops.

OUTPUT SAFETY
EFI refuses to overwrite an existing capsule. If the source file changes while it is being processed, the operation fails instead of silently creating a capsule from inconsistent data.""",
    ),
    (
        "decrypt",
        "Decrypting Files",
        "How the protected control is opened and how the large-file stream is recovered.",
        """PRIVATE IDENTITY
Choose the private identity corresponding to the public identity used during encryption.

EFI CAPSULE
EFI 1.0.0-beta.5 recognises EFIPRIV3 streaming envelopes. It also retains compatibility with the protected EFI 0.8.x EFIPRIV1 and EFIPRIV2 envelopes and with legacy EFI 0.5 JSON capsules.

DESTINATION FOLDER
Choose a folder, not a final filename. In EFIPRIV3 the original filename is inside the protected control record and is intentionally unavailable before successful private processing.

DECRYPTION ORDER FOR EFIPRIV3
1. EFI reads only the fixed public outer structure and the fixed encrypted control block.
2. The private guard key decapsulates the fresh outer ML-KEM-1024 ciphertext.
3. HKDF-SHA256 derives the outer control key.
4. AES-256-GCM authenticates and opens the fixed 4 MiB control region.
5. The compressed inner EFI control capsule is recovered.
6. The normal EFI inner protocol recovers the protected stream-control payload through the root, guard and Entropic Chain route.
7. EFI now learns the original filename, exact byte length, stream key and internal stream parameters.
8. The large data section is decrypted one authenticated 2 MiB record at a time.
9. Only the real number of source bytes is written. Authenticated zero padding after the real end is discarded.
10. The recovered SHA-256 is compared with the protected digest before the operation is reported complete.

NAME COLLISIONS
EFI does not silently replace an existing recovered file. If the original name already exists, a non-conflicting recovered filename is selected.

CANCELLATION
Decrypt has a Cancel button. If cancellation occurs after an output file has been opened, the incomplete recovered file is removed.

LEGACY RAW ET FILES
A raw ET 0.13 .et13 capsule is not the integrated EFIPRIV3 format. It can expose descriptive metadata. Recover it with the matching ET workflow, then re-encrypt the plaintext through integrated EFI if metadata privacy is required.""",
    ),
    (
        "deniable",
        "Deniable Containers and Duress",
        "How EFIPRIV4 decoy, hidden and deliberate duress paths work, and what they cannot guarantee.",
        """EFIPRIV4 OVERVIEW

EFI 1.0.0-beta.5 adds an optional deniable container format named EFIPRIV4. It is separate from the ordinary EFIPRIV3 Encrypt/Decrypt workflow. Open the Deniable tab to create or open one.

IMPORTANT: THE DURESS PASSPHRASE IS THE HIDDEN-PROFILE SELF-DESTRUCT CREDENTIAL. Entering the configured duress passphrase is a deliberate action. EFI opens the ordinary decoy profile normally and, at the same time, replaces the live hidden-slot recovery material in that current container copy. It does NOT destroy the decoy. It does NOT wipe the whole EFI file. Ordinary wrong passwords and typing mistakes do NOT trigger destruction.

Every EFIPRIV4 file contains exactly two equal opaque slots. Slot 0 is the ordinary or decoy profile. Slot 1 always exists. When no hidden profile is configured, slot 1 is random cover. When a hidden profile is configured, the second slot contains a complete separately protected EFIPRIV3 capsule.

WHY THE SECOND SLOT ALWAYS EXISTS

Plausible deniability fails if the file gets a new section only when hidden data exists. An examiner could simply count sections. EFIPRIV4 therefore reserves the second slot in every file of this format. A cover-only file, an active-hidden file and a post-duress file all retain the same two-slot public geometry for the same reserve size.

WHAT THE OUTSIDE CAN SEE

Public inspection can identify EFIPRIV4, the version, total file length, two-slot geometry and reserve capacity. It cannot read a hidden-present flag because there is none. It cannot recover the original filenames, exact source sizes, recipient fingerprints, Entropic mode, chain profile or profile credentials from the public framing.

The fact that a file is EFIPRIV4 does reveal that it is a dual-profile-capable EFI container. That is analogous to knowing a storage format supports hidden volumes: capability is visible, use is not proven by the format bytes.

CREATING A DUAL-PROFILE FILE

Choose the recipient public identity and a Decoy file. A hidden file is optional. If you choose a hidden file, enter and confirm a hidden profile passphrase of at least 12 characters. You may also enter and confirm a separate duress passphrase.

The Entropic Engine mode and EC cycle settings are shared with the normal Encrypt/Engine controls. EFI creates a complete EFIPRIV3 capsule for the decoy and, when supplied, another complete EFIPRIV3 capsule for the hidden file. The two inner capsules therefore retain the normal EFI metadata-private streaming architecture.

HOW THE OUTER SLOTS ARE MASKED

Each active slot gets a fresh ML-KEM-1024 encapsulation to the recipient guard public key. HKDF-SHA256 derives separate wrapper keys. The complete inner slot is masked with AES-256-CTR and authenticated with HMAC-SHA256.

For slot 1, the wrapper derivation additionally includes an Argon2id value from the hidden profile passphrase. Current parameters are 65,536 KiB memory, time cost 3, parallelism 1 and 32-byte output. The private EFI identity alone therefore does not provide a direct hidden-slot validation key. A hidden passphrase candidate is required as well.

The outer masking layer is not a replacement for EFIPRIV3 encryption. It hides the recognisable EFIPRIV3 framing so an active hidden slot has the same random-looking public shape as cover.

OPENING THE DECOY

Choose the private identity, EFIPRIV4 file and destination folder. Enter the private-identity password. Leave Profile credential blank and click Open Profile. EFI authenticates the ordinary slot, extracts its inner EFIPRIV3 capsule and recovers the decoy through the normal EFI private path.

OPENING THE HIDDEN PROFILE

Enter the same private-identity password plus the hidden Profile credential. EFI derives the hidden slot wrapper keys, authenticates the slot and then opens the contained EFIPRIV3 capsule. An incorrect hidden credential fails generically.

WRONG CREDENTIALS ARE NOT A WIPE TRIGGER

EFI deliberately does not destroy anything merely because a password is wrong. A typo, random guess or incorrect hidden profile credential must fail without modifying the container. The source and frozen regression suites explicitly test that the file hash remains unchanged after a wrong profile attempt.

THE DELIBERATE DURESS / SELF-DESTRUCT CREDENTIAL

IMPORTANT: USE THIS PASSPHRASE ONLY WHEN YOU INTEND TO DESTROY HIDDEN-PROFILE RECOVERY FROM THE CURRENT CONTAINER COPY. It returns the decoy as a normal successful open while silently destroying the live recovery material for the hidden slot.

A duress passphrase is a valid action credential, not a failed password. The decoy slot contains a fixed 128-byte field. When no duress password is configured the field is random. When configured it contains an authenticated action marker protected by a key derived from the duress passphrase. The field itself is inside the encrypted decoy slot.

When a correct duress credential is entered, EFI replaces the live hidden slot's ML-KEM ciphertext, profile salt, CTR IV and HMAC with fresh random bytes. It then opens the decoy profile. The normal GUI success message is the same ordinary profile-open result; it does not announce a special duress event.

WHY EFI DOES NOT OVERWRITE THE WHOLE HIDDEN PAYLOAD

The hidden payload may be gigabytes or terabytes. Its wrapper key depends on the hidden slot's ML-KEM recovery material and passphrase contribution. Replacing the small live recovery material makes that current slot unrecoverable without spending minutes or hours rewriting the enormous masked payload.

The old masked payload remains physically present and continues to look like opaque reserve data. This is cryptographic erasure of live recovery material, not a promise of physical sanitisation.

CURRENT CONTAINER COPY ONLY

The duress action can modify only the file copy EFI is given. It cannot reach an earlier copy stored elsewhere. Backups, cloud version history, filesystem snapshots, copied containers, SSD remanence, pagefiles and journals may preserve previous bytes. A person who copied the container before the duress action may still have a recoverable historical copy.

For that reason the precise documented claim is: the configured duress credential replaces the active hidden-slot recovery material in the current container copy.

STORAGE COST

Deniability needs reserve space. Both slots have equal payload capacity. The slot payload is rounded in 2 MiB increments and currently has a 10 MiB minimum. A cover-only file pays the same second-slot reserve cost because omitting the reserve would leak hidden-state information.

Reserve per slot is a public-capacity choice. Leave it blank to use the minimum required by the decoy profile only, or enter a larger MiB value. A larger reserve may be created even with no hidden file. Hidden content is never allowed to silently enlarge the public geometry; if the hidden profile will not fit, creation fails and asks you to choose a larger reserve.

For very large profiles, expect the deniable file to approach roughly twice the selected slot capacity. That is not cryptographic overhead in the ordinary sense; it is reserved plausible-deniability capacity.

EXTERNAL EVIDENCE

EFIPRIV4 is not an anonymity or anti-forensics system. Windows recent-file history, temporary files, thumbnails, cloud logs, endpoint monitoring, screenshots, network timing or another person who already knows about the hidden data can provide evidence outside the container.

The format makes a narrower claim: its public bytes do not state whether the fixed second slot is random cover, an active hidden profile or a previously destroyed hidden profile.

BACKUPS AND TESTING

Do not test a duress credential on the only copy of valuable hidden data. Use a disposable test container first. If you need recoverability, maintain backups according to your own threat model. Remember that a backup which preserves recoverability also weakens the practical effect of a self-destruct action against someone who can obtain that backup.

RESEARCH STATUS

The EFIPRIV4 wrapper uses ML-KEM-1024, HKDF-SHA256, Argon2id, AES-256-CTR and HMAC-SHA256. The inner profile remains the experimental EFI stack. The deniable wrapper does not solve the separate B.23.1 research limitation and does not add a claimed security-bit total.""",
    ),
    (
        "metadata-privacy",
        "Metadata Privacy",
        "What EFIPRIV3 hides, what remains observable and what the claim does not cover.",
        """WHY THIS LAYER EXISTS
Earlier integrated capsules were encrypted payloads inside readable JSON structures. An observer could learn the original filename, exact plaintext length, recipient fingerprint, selected Entropic mode, transition count, chain profile and substantial public protocol structure without possessing the private identity.

EFIPRIV3 changes the external format while preserving the existing inner protocol.

HIDDEN IN A NEW EFIPRIV3 CAPSULE
• original filename and extension;
• exact original plaintext byte count;
• stable inner recipient fingerprint;
• Standard, Tetration or Pentation selection;
• hyperoperation notation and transition count;
• Entropic Chain cycle count, stage count and schedule;
• inner root and guard records;
• inner algorithm-suite strings and JSON field names;
• the stream data key, stream identifier and nonce prefix;
• the complete inner EFI control capsule.

VISIBLE BY DESIGN
An observer can still see that the object is an EFIPRIV3 file if they know the format. The eight-byte EFIPRIV3 marker, format version, a KEM ciphertext field and the total filesystem length are public. Knowledge of the implementation can therefore identify the cryptographic family being used even though algorithm names are not printed as readable strings in the capsule.

SIZE PRIVACY
The exact source length is hidden inside the protected control record. The visible total file size maps only to a graduated size class. This is deliberate size obfuscation, not perfect traffic-flow confidentiality.

FILESYSTEM NAME
The outer Windows filename is not encrypted by the file format. EFI suggests a random name to avoid leaking the original. A user can defeat that privacy by manually renaming the capsule to something revealing.

TIMESTAMPS AND TRANSPORT METADATA
Windows timestamps, cloud-service metadata, network timing, sender and receiver account information and endpoint logs are outside the EFI file-format boundary. EFIPRIV3 does not claim to hide them.

RECIPIENT ANONYMITY
The stable recipient fingerprint is no longer present as readable outer metadata. This reduces direct linkability in the file itself. It is not a formal anonymity system and does not claim to defeat every form of correlation or traffic analysis.

LEGACY FILES
Metadata already present in an old file cannot be retroactively hidden. The migration path is decrypt, then re-encrypt with EFIPRIV3.""",
    ),
    (
        "large-files",
        "Large Files, Streaming and Padding",
        "Why a 2 GB source no longer turns into a 4 GB capsule and why encrypted empty space is useful.",
        """THE OLD PROBLEM
EFI 0.8 wrapped the whole legacy inner capsule and therefore inherited a 512 MiB practical ceiling. It also used aggressive power-of-two padding. A file near a power-of-two boundary could have been pushed into a much larger class.

EFI 0.9.1 STREAMS THE USER FILE
The user file is no longer loaded as one giant plaintext object. It is read in 2 MiB chunks and each chunk is independently authenticated with AES-256-GCM. The working set stays bounded by chunk-sized buffers plus cryptographic and protocol overhead.

THE FIXED CONTROL REGION
A 4 MiB protected control region carries the compressed inner EFI control capsule. The inner capsule protects the random stream data key and the hidden metadata. This fixed region is included in the size-class calculation.

GRADUATED SIZE CLASSES
EFI chooses the next class for the total protected plaintext, including the fixed 4 MiB control region:
• up to 8 MiB: 8 MiB total protected class;
• above 8 MiB through 64 MiB: next 8 MiB step;
• above 64 MiB through 512 MiB: next 32 MiB step;
• above 512 MiB through 4 GiB: next 128 MiB step;
• above 4 GiB: next 256 MiB step.

This keeps small files deliberately coarse while preventing a large file from being rounded all the way to the next power of two.

EXAMPLE: ABOUT 2.14 MiB
The 4 MiB control region plus a roughly 2.14 MiB source still fits inside the 8 MiB minimum class. The visible capsule remains roughly 8 MiB plus small fixed cryptographic record overhead.

EXAMPLE: A TRUE 2 GiB SOURCE
A true 2 GiB source plus the 4 MiB control region crosses the 2 GiB boundary, so the next 128 MiB step is 2.125 GiB. The capsule is therefore about 2.125 GiB plus small KEM, nonce and per-chunk authentication overhead. It does not become 4 GiB.

EXAMPLE: 2,000,000,000 BYTES
A decimal 2 GB source is about 1.86 GiB. After adding the fixed control region it rounds to the next 128 MiB step, about 1.875 GiB protected payload, again plus small record overhead.

WHY ZERO PADDING IS ENCRYPTED
Padding plaintext is deliberately all zeros. There is no security benefit in spending CPU time generating megabytes of random filler before encryption. AES-GCM transforms the zeros into random-looking authenticated ciphertext just like real data. On decryption, EFI writes only the protected real byte count and discards the padding.

PADDING DOES NOT MAKE THE CIPHER STRONGER
Padding is a metadata-privacy feature. It makes the exact source length less precise to an observer. It does not add cryptographic key strength.

FILESYSTEM LIMITS STILL APPLY
The EFI format itself no longer has the old 512 MiB envelope ceiling. The destination drive still has to support a file of the resulting size. NTFS and exFAT are appropriate for multi-gigabyte files. FAT32 has its own single-file limit near 4 GiB.""",
    ),
    (
        "engine",
        "Entropic Engine",
        "Standard, Tetration, Pentation, live planning, Demo, Benchmark and Cancel.",
        """The Entropic Engine tab is the control panel for ET 0.13.

STANDARD
Standard executes a direct finite number of virtual transitions. It is useful for short tests and for separating the virtual kernel from hyperoperation planning.

TETRATION
Tetration uses b^^h notation. With Base 2 and Height 4, the current finite planner resolves the demonstration to 65,536 sequential virtual transitions.

PENTATION
Pentation uses b^^^h notation. With Base 2 and Height 3, the current finite planner also resolves to 65,536 virtual transitions.

FINITE EXPERIMENTAL RECURRENCES
The application does not attempt to materialise astronomically large ordinary integers. ET 0.13 uses bounded finite modular recurrences and an HMAC-linked state. The displayed plan is the actual finite work the implementation will execute.

RUN ENGINE DEMO
Run Engine Demo executes the selected virtual kernel without encrypting a user file. It exposes progress and timing so the sequential work is visible.

BENCHMARK
Benchmark measures the current machine. It is a performance measurement, not a cryptographic hardness proof.

CANCEL
Cancel requests that the demo stop. Cancellation is cooperative, so a current small internal operation may finish before the worker exits.

ENCRYPT SHARES THE SAME MODE SETTINGS
The Encrypt tab uses the same Standard, Tetration and Pentation concepts. The chosen values are protected inside the EFIPRIV3 control capsule rather than printed on the outside.""",
    ),
    (
        "chain",
        "Entropic Chain / EC100",
        "The five families, the normal 100-stage profile and what the number does not mean.",
        """The Entropic Chain is the sequential stage layer used by the integrated EFI inner workflow.

ONE CYCLE CONTAINS FIVE FAMILIES
1. subset-sum;
2. XOR relation;
3. modular-sum relation;
4. ternary-vector relation;
5. permutation assignment.

TWENTY CYCLES = 100 STAGES
The normal GUI setting is 20 cycles. Each cycle contains all five families in the defined order, so the normal integrated chain has 100 sequential stages.

SEQUENTIAL DEPENDENCY
The legitimate route advances through the chain in order. The terminal token contributes to the inner EFI final-key derivation.

CONTROL CAPSULE SIZE
More cycles increase the inner control capsule size. EFI 0.9.1 compresses that capsule and places it in a fixed 4 MiB encrypted control region. The current backend permits up to 256 cycles, and the streaming release gate checks that the maximum profile remains within the fixed protected control capacity.

WHAT EC100 DOES NOT MEAN
One hundred stages does not mean one hundred security bits. A measured route time is not a lower bound for every possible solver. The research goal is reproducible construction and explicit shortcut testing, not numerology.""",
    ),
    (
        "vault",
        "Entropic Vault and WinFsp",
        "Mounted encrypted storage, the isolated host and offline WinFsp packaging.",
        """The Entropic Vault is the mounted-storage branch inherited from the validated Beta 1.1.1 desktop line.

OPEN FULL VAULT MANAGER
The Vault tab launches the full Beta 1.1.1 vault desktop rather than a reduced imitation. It retains the existing create, mount, dismount, storage-health and compact/rekey workflow.

ISOLATED HOST
Mounted vault operations use a separate EntropicFusionHost.exe. Keeping the mount host separate preserves the validated process boundary used by the Beta 1.1.1 Windows vault workflow.

WINFSP
WinFsp supplies the Windows filesystem interface required for mounted vault drives. It is not required merely to encrypt or decrypt a standalone .efi file, but it is required for mounted vaults.

OFFLINE INSTALLATION
The normal EFI Windows installer carries the exact validated WinFsp 2.1.25156 MSI. A clean target computer does not need to download WinFsp from the internet. The application also embeds the MSI for the Install / Repair WinFsp action.

ADMINISTRATOR PROMPT
Installing a filesystem driver requires Windows elevation. A UAC prompt during WinFsp installation or repair is expected.

KEEP THE HOST EXE
Do not remove EntropicFusionHost.exe from an installed copy. Standalone EFI files may still work, but the mounted vault workflow can fail without the host.""",
    ),
    (
        "file-formats",
        "File Types and Compatibility",
        "EFIPRIV3, older private envelopes, legacy JSON, ET capsules and identity files.",
        """EFIPRIV3 .EFI - CURRENT FORMAT
Binary metadata-private streaming envelope introduced by EFI 0.9.1. It contains a fixed encrypted control region followed by authenticated streaming data records. It is the format produced by the integrated Encrypt tab.

EFIPRIV2 .EFI - EFI 0.8.1
Metadata-private binary envelope with an 8 MiB minimum power-of-two body class. It protected metadata but used the older whole-file wrapper and 512 MiB ceiling. EFI 1.0.0-beta.5 can still decrypt it.

EFIPRIV1 .EFI - EFI 0.8.0
First metadata-private binary envelope. It used 1 MiB linear buckets and the older whole-file processing route. EFI 1.0.0-beta.5 can still decrypt it.

LEGACY EFI 0.5 JSON CAPSULE
Readable JSON outer structure. The payload is encrypted, but descriptive and protocol metadata are visible. EFI 1.0.0-beta.5 retains decryption compatibility and labels it legacy/exposed in Inspect.

RAW ET 0.13 .ET13
A separate Entropic Tetration capsule format. It predates the integrated metadata-private envelope and may expose filename, size and hyperoperation metadata. It is not emitted by the integrated Encrypt tab.

EFI PUBLIC IDENTITY
Shareable recipient encryption material.

EFI PRIVATE IDENTITY
Password-protected recipient private material. Do not share it.

VAULT IDENTITIES
The Beta 1.1.1 mounted-vault subsystem has its own identity workflow. Those files are not interchangeable with the integrated standalone EFI identity pair.

WINDOWS APPLICATION FILES
EntropicFusionIntegrated.exe is the main desktop application. EntropicFusionHost.exe is the isolated vault host. The normal Setup executable installs both and carries WinFsp.""",
    ),
    (
        "inspect-selftest",
        "Inspect, Self-Test and Activity",
        "What diagnostics can reveal and what they deliberately cannot reveal.",
        """INSPECT
For EFIPRIV3, Inspect reports only public outer facts such as the protected-container type, total visible size and coarse protected size class. It cannot display the original filename, exact source size, recipient, engine mode or chain profile without private processing.

For EFIPRIV1 and EFIPRIV2, Inspect identifies the file as an older protected envelope. For legacy EFI JSON and raw ET capsules it warns that readable metadata is exposed.

SELF-TEST
The integrated source and frozen gates check:
• exact frozen EFI 0.5, ET 0.13, Beta 1.1.1 and EC source lineage where required;
• ML-KEM/OpenSSL availability;
• Standard, Tetration and Pentation GUI controls;
• the Beta vault-manager launcher and isolated host;
• metadata-private EFIPRIV3 output;
• exact streaming encrypt/decrypt recovery;
• zero forbidden metadata strings in the outside of test capsules;
• identical public size for the same payload encrypted under Standard, Tetration and Pentation;
• graduated large-file size estimates, including the 2 GiB case;
• the Windows freeze, WinFsp bundle and installer path when the build is run on Windows.

A passing self-test means those implementation checks passed. It is not a proof that the novel cryptographic construction has a formal security level.

ACTIVITY
Activity is an operational session view. It is useful for seeing what the GUI did, but it is not intended as a formal forensic audit log.""",
    ),
    (
        "troubleshooting",
        "Troubleshooting",
        "Common symptoms, likely causes and what to check first.",
        """THE APP STARTS BUT VAULT MOUNTING DOES NOT WORK
Check Vault for WinFsp status. Use Install / Repair Bundled WinFsp if necessary and confirm EntropicFusionHost.exe remains installed beside the main application.

DECRYPTION SAYS THE IDENTITY DOES NOT MATCH
The file was encrypted to a different EFI public identity. Select the private identity paired with the public identity used by the sender.

DECRYPTION FAILS AFTER ENTERING THE PASSWORD
Check the password and private identity first. Authenticated decryption also fails if the capsule has been modified, truncated or combined with records from another capsule.

I CANNOT SEE THE ORIGINAL FILENAME IN INSPECT
That is expected for EFIPRIV3. The filename is protected metadata and appears only after successful private decryption.

AN OLD FILE SHOWS LOTS OF JSON
It is probably a legacy EFI 0.5 capsule or a raw ET capsule. Inspect identifies the format. Recover the plaintext and re-encrypt through EFI 1.0.0-beta.5 to migrate it.

THE ENCRYPTED FILE IS LARGER THAN THE SOURCE
That is expected. EFI carries a fixed protected control region, authenticated record tags and deliberate encrypted padding. The graduated bucket policy is designed to hide exact length without doubling every large file.

A 2 GIB FILE IS ABOUT 2.125 GIB AFTER ENCRYPTION
That is expected for a true 2 GiB source because the fixed control region pushes the total protected plaintext into the next 128 MiB class. It should not jump to 4 GiB under EFIPRIV3.

A MULTI-GIGABYTE FILE FAILS ON A USB STICK
Check the filesystem. FAT32 cannot store a single file above roughly 4 GiB. Use NTFS or exFAT where appropriate.

ENCRYPT OR DECRYPT LOOKS STUCK
Watch the progress bar and phase label. Large file content is processed in 2 MiB records, while the Entropic control finalisation can add a few seconds after the content progress reaches 100 per cent.

CANCEL WAS NOT INSTANT
Cancellation is cooperative. A current cryptographic operation or chunk finishes before the worker notices the request. Partial outputs are removed.

WINDOWS SMARTSCREEN OR UAC APPEARS
Development builds may not have commercial signing reputation. UAC is expected when installing the WinFsp driver. Verify the build against its recorded hashes.

THE GUI DOES NOT FIT OR A CONTROL SEEMS TO BE MISSING
Long-form tabs now have their own vertical scrollbar. Use the scrollbar or mouse wheel to reach controls below the visible area. Nothing on Create, Open, Encrypt, Decrypt, Identity, Engine or Inspect should be inaccessible because of window height.

RESIZING THE WINDOW
EFI is explicitly resizable. Drag any normal Windows edge or corner, or use the visible resize grip at the bottom-right of the application. The Deniable Create/Open panels also stack vertically when the window becomes narrow.

THE GUI DOES NOT FIT ON A SECOND MONITOR
The application sizes itself from the active Windows work area and the long-form tabs remain scrollable. If Windows DPI scaling changes while EFI is open, close it and reopen on the intended monitor.""",
    ),
    (
        "backup-recovery",
        "Backups and Recovery",
        "What must survive if encrypted files are meant to remain recoverable after a computer failure.",
        """For standalone EFI capsules, the essential recovery set is the encrypted .efi file, the matching private identity and the password.

PUBLIC IDENTITY ALONE IS NOT A BACKUP
It allows new encryption to you. It does not decrypt old capsules.

KEEP AN INDEPENDENT COPY OF THE PRIVATE IDENTITY
One disk is not a backup. Keep at least one separate copy under your control if long-term recovery matters.

DO NOT STORE THE ONLY PASSWORD COPY WITH THE ONLY PRIVATE-IDENTITY COPY
Losing both together destroys recovery. Having both stolen together can destroy confidentiality.

CAPSULE BACKUPS
An .efi file is self-contained ciphertext. Back it up like any other important file, but remember that cloud providers, backup tools and filesystems can still expose external metadata such as filenames you choose, timestamps and account information.

VAULT BACKUPS ARE SEPARATE
Mounted Entropic Vault containers have their own storage-health and backup workflow. Backing up an EFI private identity does not automatically back up mounted vault contents.""",
    ),
    (
        "architecture",
        "Technical Architecture",
        "An engineering view of EFIPRIV3 and the existing inner protocol.",
        """EFIPRIV3 PUBLIC OUTER STRUCTURE
The file begins with a small fixed binary header, one fresh ML-KEM-1024 ciphertext, one control nonce and one fixed-size authenticated control ciphertext. The remainder consists of fixed-size authenticated streaming data records.

OUTER CONTROL PROTECTION
Recipient mechanism: fresh ML-KEM-1024 encapsulation to the EFI guard public key.
KDF: HKDF-SHA256 with the KEM ciphertext and header committed into the derivation.
AEAD: AES-256-GCM.
Control plaintext size: fixed 4 MiB.
Control content: compressed complete EFI inner control capsule plus encrypted zero padding.

SECRET STREAM CONTROL
The EFI inner payload contains:
• original filename;
• exact plaintext byte count;
• SHA-256 of the real source;
• fresh 256-bit stream data key;
• stream nonce prefix;
• random stream identifier;
• chunk size and protected size-class values.

INNER EFI 0.5 CONTROL CAPSULE
The existing integrated protocol protects that small stream-control payload.
Guard leg: ML-KEM-1024 derives the chain secret.
Root leg: frozen ET 0.13 protects an independent root-binding secret over the Beta 1.1.1 foundation.
Entropic Chain: sequential route produces the terminal token.
Final inner key: depends on the chain secret, terminal token, root-binding secret and committed public core.
Inner payload AEAD: AES-256-GCM.

STREAM DATA LAYER
Data key: fresh random 256-bit key stored only inside the protected stream control.
AEAD: AES-256-GCM per 2 MiB record.
Nonce: random four-byte prefix plus 64-bit record index.
Associated data binds the stream identifier, record index and protected size class.
Reordering, truncation, cross-file record splicing and bit modification are therefore detected by authenticated decryption.

WHY THE LARGE FILE DOES NOT PASS THROUGH EFI 0.5 AS ONE PAYLOAD
EFI 0.5 was designed around a bounded in-memory payload and a readable JSON capsule. EFIPRIV3 keeps its validated control logic but uses it to protect a random stream key. This preserves the Entropic root/chain dependency while allowing the user file itself to be processed in bounded records.

PADDING
Zero plaintext records are encrypted after the real file ends until the graduated size class is full. The exact length remains only inside the protected stream control. Random filler is unnecessary because authenticated encryption already makes encrypted zeros appear random.

LEGACY COMPATIBILITY
EFIPRIV1 and EFIPRIV2 remain decryptable through read-only compatibility code. Legacy EFI 0.5 JSON remains recoverable. New encryption emits EFIPRIV3 only.

VAULT ARCHITECTURE
Mounted storage remains the Beta 1.1.1 desktop and isolated host architecture with WinFsp integration.""",
    ),
    (
        "release-history",
        "Why the File Format Changed",
        "The progression from readable capsules to streaming metadata-private files.",
        """EFI 0.5
The integrated protocol was hardened for parsing, commitments and repeatable reference vectors, but the capsule itself was readable JSON. Payload confidentiality and metadata confidentiality were different questions.

EFI 0.8.0 - EFIPRIV1
Introduced the first binary metadata-private wrapper. It encrypted the complete EFI 0.5 capsule and used 1 MiB padding buckets. Metadata was no longer plainly readable, but the design still processed the entire source through the old bounded payload path.

EFI 0.8.1 - EFIPRIV2
Made padding more aggressive with an 8 MiB minimum and power-of-two size classes. This substantially reduced size precision for small files but could create excessive expansion near power-of-two boundaries. The whole-file 512 MiB envelope ceiling also remained.

EFI 0.9.1 - EFIPRIV3
Separates the huge file from the small Entropic control capsule. The full inner EFI protocol now protects a random stream key and hidden metadata, while the actual source is encrypted in bounded authenticated records. Padding moves to graduated size classes so a multi-gigabyte file is not automatically doubled to the next power of two.

This evolution is deliberately recorded because metadata behaviour is part of the file-format design, not a cosmetic GUI detail.""",
    ),
    (
        "research-status",
        "Research Status and Limits",
        "What the implementation demonstrates and what it deliberately does not claim.",
        """Entropic Fusion Integrated is a research prototype.

A WORKING ROUND TRIP IS NOT A SECURITY PROOF
Successful encryption and decryption demonstrate that the implementation executes the intended route and that the authenticated formats interoperate. They do not prove that every intended hard problem must be solved by an adversary.

TRANSITION COUNTS ARE NOT SECURITY BITS
A 65,536-transition ET plan, 100 EC stages or any other work count is an implementation property. There is no automatic conversion to a claimed bit-security level.

LARGE SEARCH SPACES ARE NOT ENOUGH
A construction can have a huge nominal search space and still admit a shortcut. The project therefore uses malformed-input tests, dependency-separation tests, negative controls and solver work rather than relying on astronomical numbers alone.

STANDARD COMPONENTS DO NOT PROVE THE NOVEL WHOLE
ML-KEM, HKDF-SHA256 and AES-GCM are standard components. The novel Entropic Fusion, ET and EC constructions remain experimental and require independent analysis.

METADATA PRIVACY HAS A NARROW CLAIM
EFIPRIV3 is intended to prevent the old readable capsule metadata from being available at rest and to reduce exact size leakage through coarse padding. It does not hide Windows timestamps, network timing, endpoint compromise, cloud-account metadata or every possible traffic-analysis signal.

STREAMING CHANGES ENGINEERING, NOT A CLAIMED HARDNESS LEVEL
Moving the user file to authenticated chunked encryption solves memory and large-file packaging problems. It does not, by itself, make the underlying cryptographic assumptions harder.

B.23.1 ROOT-COMBINER RESEARCH
The earlier dual-ML-KEM raw-secret-oracle finding remains a separate research item in the frozen root lineage. EFIPRIV3 is a packaging, metadata-privacy and streaming improvement. It does not silently reclassify that earlier finding as solved.

READ RESULTS LITERALLY
Treat result files as records of what was built, what was executed, what failed closed and what remains unproven.""",
    ),
    (
        "glossary",
        "Glossary",
        "Terms used throughout the GUI, help centre and result files.",
        """AEAD
Authenticated Encryption with Associated Data. Encryption that also detects unauthorised modification of protected data and committed context.

AES-256-GCM
The authenticated symmetric cipher used for EFI inner payloads, the EFIPRIV3 control region and streaming data records.

CAPSULE
An encrypted EFI file containing the structures the recipient needs to recover protected content.

CONTROL REGION
The fixed 4 MiB plaintext-sized EFIPRIV3 region that holds the compressed inner EFI control capsule before outer AES-GCM protection.

DATA CHUNK
A 2 MiB plaintext record of real source data or zero padding, encrypted and authenticated independently in EFIPRIV3.

EC / ENTROPIC CHAIN
The sequential five-family stage construction. EC100 is the normal 20-cycle, 100-stage profile.

EFI
Entropic Fusion Integrated, the combined standalone file workflow and application line.

EFIPRIV1
EFI 0.8.0 metadata-private whole-file envelope.

EFIPRIV2
EFI 0.8.1 metadata-private whole-file envelope with power-of-two padding.

EFIPRIV3
EFI 0.9.1 metadata-private streaming envelope with graduated padding.

ENTROPIC ENGINE
The GUI control surface for ET 0.13 Standard, Tetration and Pentation finite virtual transitions.

GRADUATED SIZE CLASS
The coarse padded protected size selected in 8 MiB, 32 MiB, 128 MiB or 256 MiB steps depending on the total protected size range.

HKDF-SHA256
The standard KDF used to derive the EFIPRIV3 outer control key from the fresh ML-KEM shared secret and committed context.

INNER CONTROL CAPSULE
The complete EFI 0.5 JSON capsule whose small payload is the secret stream-control record. It is compressed and encrypted inside the EFIPRIV3 fixed control region.

KEM
Key Encapsulation Mechanism. A public-key mechanism used to establish shared secret material.

ML-KEM
The standard lattice-based KEM used by the current guard and outer control layers.

PENTATION
The ET 0.13 higher hyperoperation mode. The implementation uses a bounded finite recurrence rather than literal storage of an astronomically large integer.

PRIVATE IDENTITY
Password-protected recipient secret material required for decryption.

PUBLIC IDENTITY
Shareable recipient material used by a sender to encrypt a capsule.

STREAM CONTROL
The protected small record containing the original filename, exact size, digest, stream key and stream parameters.

TETRATION
The ET 0.13 tetration mode, displayed with notation such as 2^^4.

EFIPRIV4
EFI 1.0.0-beta.5 dual-profile-capable container with two equal opaque slots. The second slot is always present as cover or a hidden profile.

HIDDEN PROFILE
A complete EFIPRIV3 capsule stored in the second EFIPRIV4 slot and additionally gated by a profile passphrase.

DURESS CREDENTIAL
A deliberately configured action passphrase that returns the decoy while replacing live hidden-slot recovery material in the current container copy. It is not triggered by ordinary wrong passwords.

OPAQUE RESERVE
The fixed second EFIPRIV4 slot. Its existence and capacity are public, but its state as cover, hidden content or post-duress destroyed recovery material is not encoded in public framing.

WINFSP
The Windows filesystem framework required by the mounted Entropic Vault feature.

ZERO PADDING
Authenticated all-zero plaintext written after the real source until the chosen size class is full. Encryption makes it random-looking on disk; its purpose is size privacy, not extra key strength.""",
    ),
]

HELP_BY_KEY = {key: (title, subtitle, body) for key, title, subtitle, body in HELP_SECTIONS}
