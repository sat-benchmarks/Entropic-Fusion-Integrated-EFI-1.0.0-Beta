#!/usr/bin/env python3
from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import secrets
import tempfile
import time
import zlib
from pathlib import Path
from typing import Callable

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

import entropic_fusion_integrated_efi_0_5_0 as backend

VERSION = "EFI metadata-private streaming envelope 3"
MAGIC = b"EFIPRIV3"
MAGIC_V2 = b"EFIPRIV2"
MAGIC_V1 = b"EFIPRIV1"
FORMAT_VERSION = 3
FLAGS = 0
HEADER_LEN = 12  # magic(8) + version(1) + flags(1) + KEM ciphertext length(2)
CONTROL_NONCE_BYTES = 12
CONTROL_PLAINTEXT_BYTES = 4 * 1024 * 1024
CONTROL_TAG_BYTES = 16
CONTROL_CIPHERTEXT_BYTES = CONTROL_PLAINTEXT_BYTES + CONTROL_TAG_BYTES
CONTROL_FRAME_MAGIC = b"EFICTL3\x00"
CONTROL_FRAME_HEADER_BYTES = len(CONTROL_FRAME_MAGIC) + 8 + 8
MAX_CONTROL_INNER_BYTES = 16 * 1024 * 1024
DATA_CHUNK_BYTES = 2 * 1024 * 1024
DATA_TAG_BYTES = 16
DATA_RECORD_BYTES = DATA_CHUNK_BYTES + DATA_TAG_BYTES
DATA_NONCE_PREFIX_BYTES = 4
STREAM_ID_BYTES = 16
DATA_KEY_BYTES = 32
MAX_ENCODED_BYTES = (1 << 64) - 1

# Graduated total protected-payload buckets.  The fixed 4 MiB encrypted
# control region is included in the bucket calculation, so a small file can
# still fit inside the 8 MiB minimum rather than paying 8 MiB + 4 MiB.
MIB = 1024 * 1024
GIB = 1024 * 1024 * 1024
MIN_PROTECTED_BUCKET_BYTES = 8 * MIB

CONTROL_KEY_DOMAIN = b"ENTROPIC-FUSION/EFI-PRIVATE-CONTROL/v3"
CONTROL_AAD_DOMAIN = b"ENTROPIC-FUSION/EFI-PRIVATE-CONTROL/AAD/v3"
DATA_AAD_DOMAIN = b"ENTROPIC-FUSION/EFI-STREAM-DATA/AAD/v3"
STREAM_CONTROL_FORMAT = "EFI-STREAM-CONTROL-1"

# Legacy EFI 0.8.x envelope constants.  These are read-only compatibility
# paths; new encryption always emits EFIPRIV3.
LEGACY_KEY_DOMAIN = b"ENTROPIC-FUSION/EFI-PRIVATE-ENVELOPE/v1"
LEGACY_AAD_DOMAIN = b"ENTROPIC-FUSION/EFI-PRIVATE-ENVELOPE/AAD/v1"
LEGACY_NONCE_BYTES = 12
LEGACY_V1_PAD_QUANTUM = 1 * MIB
LEGACY_V1_MIN_PADDED = 1 * MIB
LEGACY_V1_MAX_PADDED = 512 * MIB
LEGACY_V2_MIN_PADDED = 8 * MIB
LEGACY_V2_MAX_PADDED = 512 * MIB

ProgressCallback = Callable[[str, int, int], None]


class PrivateEnvelopeError(ValueError):
    pass


def _cancelled(cancel_event) -> bool:
    return bool(cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)())


def _check_cancel(cancel_event) -> None:
    if _cancelled(cancel_event):
        raise PrivateEnvelopeError("operation cancelled")


def _emit_progress(progress: ProgressCallback | None, phase: str, done: int, total: int) -> None:
    if progress is not None:
        progress(phase, int(done), int(total))


def _ceil_multiple(value: int, quantum: int) -> int:
    return ((value + quantum - 1) // quantum) * quantum


def _protected_bucket_for_source(source_bytes: int) -> int:
    """Return the graduated bucket for control + real source bytes.

    Policy recorded for EFI 0.9.1:
      <= 8 MiB protected payload  -> 8 MiB
      <= 64 MiB                  -> next 8 MiB
      <= 512 MiB                 -> next 32 MiB
      <= 4 GiB                   -> next 128 MiB
      > 4 GiB                    -> next 256 MiB

    The 4 MiB fixed encrypted control region is included before rounding.
    """
    if not isinstance(source_bytes, int) or isinstance(source_bytes, bool) or source_bytes < 0:
        raise PrivateEnvelopeError("invalid source length")
    raw_total = source_bytes + CONTROL_PLAINTEXT_BYTES
    if raw_total > MAX_ENCODED_BYTES:
        raise PrivateEnvelopeError("source file is too large for the EFI stream length field")
    if raw_total <= 8 * MIB:
        target = 8 * MIB
    elif raw_total <= 64 * MIB:
        target = _ceil_multiple(raw_total, 8 * MIB)
    elif raw_total <= 512 * MIB:
        target = _ceil_multiple(raw_total, 32 * MIB)
    elif raw_total <= 4 * GIB:
        target = _ceil_multiple(raw_total, 128 * MIB)
    else:
        target = _ceil_multiple(raw_total, 256 * MIB)
    if target > MAX_ENCODED_BYTES:
        raise PrivateEnvelopeError("protected size class exceeds EFI stream length field")
    return target


def _is_valid_protected_bucket(target: int) -> bool:
    if target < MIN_PROTECTED_BUCKET_BYTES or target > MAX_ENCODED_BYTES:
        return False
    # Every valid bucket has at least one source length mapping exactly to it.
    # Testing target-CONTROL is sufficient because that is the upper source
    # length represented by this protected total.
    source_upper = target - CONTROL_PLAINTEXT_BYTES
    if source_upper < 0:
        return False
    return _protected_bucket_for_source(source_upper) == target


def estimate_size(source_bytes: int) -> dict:
    protected_bucket = _protected_bucket_for_source(source_bytes)
    data_padded = protected_bucket - CONTROL_PLAINTEXT_BYTES
    if data_padded < 0 or data_padded % DATA_CHUNK_BYTES:
        raise PrivateEnvelopeError("internal size-class alignment failure")
    chunks = data_padded // DATA_CHUNK_BYTES
    prefix = HEADER_LEN + backend.GUARD_KEM_CIPHERTEXT_BYTES + CONTROL_NONCE_BYTES + CONTROL_CIPHERTEXT_BYTES
    outer = prefix + chunks * DATA_RECORD_BYTES
    return {
        "source_bytes": source_bytes,
        "protected_bucket_bytes": protected_bucket,
        "data_padded_bytes": data_padded,
        "padding_plaintext_bytes": data_padded - source_bytes,
        "data_chunks": chunks,
        "chunk_bytes": DATA_CHUNK_BYTES,
        "visible_outer_bytes": outer,
    }


def _header(magic: bytes, version: int, kem_len: int) -> bytes:
    if len(magic) != 8:
        raise PrivateEnvelopeError("invalid envelope magic")
    if kem_len <= 0 or kem_len > 65535:
        raise PrivateEnvelopeError("invalid KEM ciphertext length")
    return magic + bytes((version, FLAGS)) + kem_len.to_bytes(2, "big")


def _derive_control_key(shared_secret: bytes, kem_ct: bytes, header: bytes) -> bytes:
    if len(shared_secret) != backend.GUARD_SHARED_SECRET_BYTES:
        raise PrivateEnvelopeError("unexpected ML-KEM shared-secret length")
    salt = hashlib.sha256(kem_ct).digest()
    info = CONTROL_KEY_DOMAIN + b"\x00" + hashlib.sha256(header + kem_ct).digest()
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=info).derive(shared_secret)


def _control_aad(header: bytes, kem_ct: bytes) -> bytes:
    return CONTROL_AAD_DOMAIN + b"\x00" + header + hashlib.sha256(kem_ct).digest()


def _data_nonce(prefix: bytes, index: int) -> bytes:
    if len(prefix) != DATA_NONCE_PREFIX_BYTES or index < 0 or index >= (1 << 64):
        raise PrivateEnvelopeError("invalid stream nonce components")
    return prefix + index.to_bytes(8, "big")


def _data_aad(stream_id: bytes, index: int, protected_bucket: int) -> bytes:
    if len(stream_id) != STREAM_ID_BYTES:
        raise PrivateEnvelopeError("invalid stream identifier")
    return (
        DATA_AAD_DOMAIN + b"\x00" + stream_id
        + index.to_bytes(8, "big")
        + protected_bucket.to_bytes(8, "big")
    )


def _pack_control_inner(inner: bytes) -> tuple[bytes, int]:
    if len(inner) <= 0 or len(inner) > MAX_CONTROL_INNER_BYTES:
        raise PrivateEnvelopeError("inner EFI control capsule length is invalid")
    compressed = zlib.compress(inner, level=9)
    frame = (
        CONTROL_FRAME_MAGIC
        + len(inner).to_bytes(8, "big")
        + len(compressed).to_bytes(8, "big")
        + compressed
    )
    if len(frame) > CONTROL_PLAINTEXT_BYTES:
        raise PrivateEnvelopeError(
            "selected Entropic Chain profile exceeds the fixed metadata-private control region"
        )
    # Zero padding is intentional.  AES-GCM makes it indistinguishable from
    # random-looking ciphertext, so generating random filler would add cost
    # without adding confidentiality.
    return frame + (b"\x00" * (CONTROL_PLAINTEXT_BYTES - len(frame))), len(compressed)


def _unpack_control_inner(padded: bytes) -> bytes:
    if len(padded) != CONTROL_PLAINTEXT_BYTES:
        raise PrivateEnvelopeError("private control region has the wrong length")
    if not padded.startswith(CONTROL_FRAME_MAGIC):
        raise PrivateEnvelopeError("private control frame marker mismatch")
    off = len(CONTROL_FRAME_MAGIC)
    raw_len = int.from_bytes(padded[off:off + 8], "big"); off += 8
    comp_len = int.from_bytes(padded[off:off + 8], "big"); off += 8
    if raw_len <= 0 or raw_len > MAX_CONTROL_INNER_BYTES:
        raise PrivateEnvelopeError("private control inner length is invalid")
    if comp_len <= 0 or comp_len > CONTROL_PLAINTEXT_BYTES - off:
        raise PrivateEnvelopeError("private control compressed length is invalid")
    comp = padded[off:off + comp_len]
    try:
        inner = zlib.decompress(comp)
    except Exception as exc:
        raise PrivateEnvelopeError("private control decompression failed") from exc
    if len(inner) != raw_len or not inner.startswith(b"{"):
        raise PrivateEnvelopeError("private control inner capsule is invalid")
    return inner


def _encode_stream_control(*, filename: str, plaintext_bytes: int, plaintext_sha256: str,
                           data_key: bytes, nonce_prefix: bytes, stream_id: bytes,
                           data_padded_bytes: int, protected_bucket_bytes: int) -> bytes:
    obj = {
        "format": STREAM_CONTROL_FORMAT,
        "filename": filename,
        "plaintext_bytes": plaintext_bytes,
        "plaintext_sha256": plaintext_sha256,
        "data_key_b64": base64.b64encode(data_key).decode("ascii"),
        "nonce_prefix_b64": base64.b64encode(nonce_prefix).decode("ascii"),
        "stream_id_b64": base64.b64encode(stream_id).decode("ascii"),
        "data_chunk_bytes": DATA_CHUNK_BYTES,
        "data_padded_bytes": data_padded_bytes,
        "protected_bucket_bytes": protected_bucket_bytes,
    }
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _decode_stream_control(raw: bytes) -> dict:
    if len(raw) > 64 * 1024:
        raise PrivateEnvelopeError("stream control payload is unexpectedly large")
    try:
        text = raw.decode("utf-8")
        obj = backend.strict_json_loads(text, label="EFI stream control")
    except Exception as exc:
        raise PrivateEnvelopeError("stream control payload is invalid") from exc
    expected = {
        "format", "filename", "plaintext_bytes", "plaintext_sha256", "data_key_b64",
        "nonce_prefix_b64", "stream_id_b64", "data_chunk_bytes", "data_padded_bytes",
        "protected_bucket_bytes",
    }
    if set(obj) != expected or obj.get("format") != STREAM_CONTROL_FORMAT:
        raise PrivateEnvelopeError("stream control schema mismatch")
    filename = backend._validate_filename(obj["filename"])
    n = backend._require_int(obj["plaintext_bytes"], minimum=0, maximum=MAX_ENCODED_BYTES, label="stream plaintext bytes")
    padded = backend._require_int(obj["data_padded_bytes"], minimum=0, maximum=MAX_ENCODED_BYTES, label="stream padded bytes")
    bucket = backend._require_int(obj["protected_bucket_bytes"], minimum=MIN_PROTECTED_BUCKET_BYTES, maximum=MAX_ENCODED_BYTES, label="stream protected bucket")
    if obj["data_chunk_bytes"] != DATA_CHUNK_BYTES or padded % DATA_CHUNK_BYTES:
        raise PrivateEnvelopeError("stream chunk geometry mismatch")
    if bucket != padded + CONTROL_PLAINTEXT_BYTES or _protected_bucket_for_source(n) != bucket:
        raise PrivateEnvelopeError("stream protected size class mismatch")
    if n > padded:
        raise PrivateEnvelopeError("stream plaintext length exceeds padded data region")
    digest = str(obj["plaintext_sha256"])
    if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        raise PrivateEnvelopeError("stream plaintext digest is invalid")
    data_key = backend._b64_exact(obj["data_key_b64"], DATA_KEY_BYTES, "stream data key")
    nonce_prefix = backend._b64_exact(obj["nonce_prefix_b64"], DATA_NONCE_PREFIX_BYTES, "stream nonce prefix")
    stream_id = backend._b64_exact(obj["stream_id_b64"], STREAM_ID_BYTES, "stream identifier")
    return {
        **obj,
        "filename": filename,
        "plaintext_bytes": n,
        "data_padded_bytes": padded,
        "protected_bucket_bytes": bucket,
        "data_key": data_key,
        "nonce_prefix": nonce_prefix,
        "stream_id": stream_id,
    }


def _read_v3_prefix(path: Path) -> tuple[bytes, bytes, bytes, bytes, int, int]:
    path = Path(path)
    size = path.stat().st_size
    with path.open("rb") as f:
        header = f.read(HEADER_LEN)
        if len(header) != HEADER_LEN or header[:8] != MAGIC:
            raise PrivateEnvelopeError("not an EFIPRIV3 envelope")
        if header[8] != FORMAT_VERSION or header[9] != FLAGS:
            raise PrivateEnvelopeError("unsupported EFIPRIV3 version or flags")
        kem_len = int.from_bytes(header[10:12], "big")
        if kem_len != backend.GUARD_KEM_CIPHERTEXT_BYTES:
            raise PrivateEnvelopeError("EFIPRIV3 KEM length mismatch")
        kem_ct = f.read(kem_len)
        control_nonce = f.read(CONTROL_NONCE_BYTES)
        control_ct = f.read(CONTROL_CIPHERTEXT_BYTES)
    if len(kem_ct) != kem_len or len(control_nonce) != CONTROL_NONCE_BYTES or len(control_ct) != CONTROL_CIPHERTEXT_BYTES:
        raise PrivateEnvelopeError("EFIPRIV3 control region is truncated")
    prefix_len = HEADER_LEN + kem_len + CONTROL_NONCE_BYTES + CONTROL_CIPHERTEXT_BYTES
    data_bytes = size - prefix_len
    if data_bytes < 0 or data_bytes % DATA_RECORD_BYTES:
        raise PrivateEnvelopeError("EFIPRIV3 data-record geometry is invalid")
    chunks = data_bytes // DATA_RECORD_BYTES
    data_padded = chunks * DATA_CHUNK_BYTES
    protected_bucket = CONTROL_PLAINTEXT_BYTES + data_padded
    if chunks < 1 or not _is_valid_protected_bucket(protected_bucket):
        raise PrivateEnvelopeError("EFIPRIV3 protected size-class shape is invalid")
    return header, kem_ct, control_nonce, control_ct, chunks, protected_bucket


def is_private_envelope(path: Path) -> bool:
    path = Path(path)
    try:
        with path.open("rb") as f:
            return f.read(8) in {MAGIC, MAGIC_V2, MAGIC_V1}
    except OSError:
        return False


def suggest_capsule_name() -> str:
    return f"EFI-{secrets.token_hex(8)}.efi"


def unique_output(path: Path) -> Path:
    path = Path(path)
    if not path.exists():
        return path
    for i in range(1, 10000):
        candidate = path.with_name(f"{path.stem}.recovered-{i}{path.suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError("could not choose a non-conflicting recovered filename")


def public_inspect(path: Path) -> dict:
    path = Path(path)
    try:
        with path.open("rb") as f:
            magic = f.read(8)
    except OSError as exc:
        raise PrivateEnvelopeError("could not read EFI file") from exc
    if magic == MAGIC:
        _header_b, _kem, _nonce, _control, chunks, protected_bucket = _read_v3_prefix(path)
        return {
            "container": "EFI opaque streaming envelope",
            "format_version": FORMAT_VERSION,
            "metadata_privacy": "PROTECTED",
            "visible_outer_bytes": path.stat().st_size,
            "visible_size_class_bytes": protected_bucket,
            "note": "Original filename, exact plaintext size, recipient identity, Entropic mode, transition count, chain profile, key identifiers and inner EFI structure are encrypted. Only the EFI container type, its total filesystem size and therefore its coarse padded size class are observable.",
        }
    if magic in {MAGIC_V1, MAGIC_V2}:
        return {
            "container": "EFI 0.8.x metadata-private envelope",
            "format_version": 1 if magic == MAGIC_V1 else 2,
            "metadata_privacy": "PROTECTED / LEGACY ENVELOPE",
            "visible_outer_bytes": path.stat().st_size,
            "note": "Metadata is protected, but this pre-streaming envelope retains the older size-padding and whole-file processing design. Decrypt and re-encrypt with EFI 0.9.1 for graduated padding and large-file streaming.",
        }
    try:
        obj = backend.strict_json_loads(path.read_text(encoding="utf-8"), label="legacy EFI capsule")
    except Exception as exc:
        raise PrivateEnvelopeError("not a recognised EFI envelope") from exc
    if obj.get("format") == "ET-0.13-VIRTUAL-CAPSULE-1":
        return {
            "container": "Legacy ET 0.13 capsule",
            "metadata_privacy": "LEGACY / EXPOSED",
            "warning": "Raw ET 0.13 capsules expose descriptive and workflow metadata. Recover the plaintext and re-encrypt with integrated EFI 0.9.1 or later.",
        }
    meta = backend.capsule_metadata(path)
    return {
        "container": "Legacy EFI 0.5 JSON capsule",
        "metadata_privacy": "LEGACY / EXPOSED",
        "warning": "This legacy capsule predates the opaque envelope. Re-encrypt the recovered plaintext with integrated EFI 0.9.1 or later.",
        **meta,
    }


def encrypt_file(
    et013_dir: Path,
    public_path: Path,
    input_path: Path,
    output_path: Path,
    *,
    cycles: int = backend.DEFAULT_CYCLES,
    root_mode: str = "tetration",
    base_value: int = 2,
    height: int = 4,
    standard_steps: int = 0,
    progress: ProgressCallback | None = None,
    cancel_event=None,
) -> dict:
    """Encrypt a file into the streaming EFIPRIV3 format.

    The real source file is never passed to the legacy EFI 0.5 payload routine.
    Instead, EFI 0.5 protects a small secret stream-control record containing a
    fresh 256-bit data key and the hidden file metadata.  The source itself is
    processed in bounded 2 MiB AES-GCM chunks, followed by authenticated zero
    padding to the graduated size class.
    """
    started = time.perf_counter()
    et013_dir = Path(et013_dir); public_path = Path(public_path)
    input_path = Path(input_path); output_path = Path(output_path)
    if output_path.exists():
        raise FileExistsError("refusing to overwrite an existing EFI capsule")
    if not input_path.is_file():
        raise FileNotFoundError(input_path)
    source_bytes = input_path.stat().st_size
    if source_bytes < 0 or source_bytes > MAX_ENCODED_BYTES:
        raise PrivateEnvelopeError("source file size is unsupported")
    filename = backend._validate_filename(input_path.name)
    size_info = estimate_size(source_bytes)
    protected_bucket = size_info["protected_bucket_bytes"]
    data_padded = size_info["data_padded_bytes"]
    chunks = size_info["data_chunks"]

    data_key = secrets.token_bytes(DATA_KEY_BYTES)
    nonce_prefix = secrets.token_bytes(DATA_NONCE_PREFIX_BYTES)
    stream_id = secrets.token_bytes(STREAM_ID_BYTES)
    data_aead = AESGCM(data_key)
    source_hash = hashlib.sha256()
    remaining_real = source_bytes
    prefix_len = HEADER_LEN + backend.GUARD_KEM_CIPHERTEXT_BYTES + CONTROL_NONCE_BYTES + CONTROL_CIPHERTEXT_BYTES

    output_path.parent.mkdir(parents=True, exist_ok=True)
    inner_report = None
    compressed_inner_bytes = None
    try:
        _check_cancel(cancel_event)
        with input_path.open("rb") as src, output_path.open("w+b") as out:
            # Reserve the fixed control prefix.  It is filled only after the
            # source stream has completed and its SHA-256 is known.
            out.seek(prefix_len)
            _emit_progress(progress, "Encrypting content", 0, source_bytes)
            done_real = 0
            for index in range(chunks):
                _check_cancel(cancel_event)
                take = min(DATA_CHUNK_BYTES, remaining_real)
                data = src.read(take) if take else b""
                if len(data) != take:
                    raise PrivateEnvelopeError("input file changed or was truncated during encryption")
                if take:
                    source_hash.update(data)
                    done_real += take
                    remaining_real -= take
                if take < DATA_CHUNK_BYTES:
                    # Deliberately boring zero padding.  Once encrypted it is
                    # computationally indistinguishable from the real chunk.
                    data = data + (b"\x00" * (DATA_CHUNK_BYTES - take))
                ct = data_aead.encrypt(
                    _data_nonce(nonce_prefix, index),
                    data,
                    _data_aad(stream_id, index, protected_bucket),
                )
                if len(ct) != DATA_RECORD_BYTES:
                    raise PrivateEnvelopeError("unexpected stream ciphertext record length")
                out.write(ct)
                _emit_progress(progress, "Encrypting content", done_real, source_bytes)
            if remaining_real != 0 or src.read(1):
                raise PrivateEnvelopeError("input file changed during encryption")

            _check_cancel(cancel_event)
            _emit_progress(progress, "Finalising Entropic layers", source_bytes, source_bytes)
            control_clear = _encode_stream_control(
                filename=filename,
                plaintext_bytes=source_bytes,
                plaintext_sha256=source_hash.hexdigest(),
                data_key=data_key,
                nonce_prefix=nonce_prefix,
                stream_id=stream_id,
                data_padded_bytes=data_padded,
                protected_bucket_bytes=protected_bucket,
            )

            with tempfile.TemporaryDirectory(prefix="efi091_stream_control_") as td_raw:
                td = Path(td_raw)
                clear_path = td / "stream-control.json"
                inner_path = td / "stream-control.efi.json"
                clear_path.write_bytes(control_clear)
                inner_report = backend.encrypt_file(
                    et013_dir, public_path, clear_path, inner_path,
                    cycles=cycles, root_mode=root_mode, base_value=base_value,
                    height=height, standard_steps=standard_steps,
                )
                inner = inner_path.read_bytes()
                control_plain, compressed_inner_bytes = _pack_control_inner(inner)

            public = backend.load_public(public_path)
            guard_public = backend._b64_bounded(
                public["guard"]["public_key_pem_b64"], minimum=512, maximum=16384, label="guard public key"
            )
            mlkem = backend.load_mlkem(et013_dir)
            kem_ct, shared_secret = mlkem.encapsulate_bytes(guard_public, backend.GUARD_KEM)
            if len(kem_ct) != backend.GUARD_KEM_CIPHERTEXT_BYTES:
                raise PrivateEnvelopeError("unexpected ML-KEM ciphertext length")
            header = _header(MAGIC, FORMAT_VERSION, len(kem_ct))
            control_key = _derive_control_key(shared_secret, kem_ct, header)
            control_nonce = os.urandom(CONTROL_NONCE_BYTES)
            control_ct = AESGCM(control_key).encrypt(control_nonce, control_plain, _control_aad(header, kem_ct))
            if len(control_ct) != CONTROL_CIPHERTEXT_BYTES:
                raise PrivateEnvelopeError("unexpected private control ciphertext length")
            out.seek(0)
            out.write(header); out.write(kem_ct); out.write(control_nonce); out.write(control_ct)
            out.flush()

        actual_size = output_path.stat().st_size
        if actual_size != size_info["visible_outer_bytes"]:
            raise PrivateEnvelopeError("streaming EFI output length mismatch")
    except Exception:
        try:
            output_path.unlink(missing_ok=True)
        except Exception:
            pass
        raise

    report = dict(inner_report or {})
    report.update({
        "outer_privacy_envelope": True,
        "streaming_envelope": True,
        "metadata_privacy": "PROTECTED",
        "envelope_format": "EFIPRIV3",
        "source_bytes": source_bytes,
        "payload_sha256": source_hash.hexdigest(),
        "protected_bucket_bytes": protected_bucket,
        "data_padded_bytes": data_padded,
        "padding_plaintext_bytes": data_padded - source_bytes,
        "data_chunk_bytes": DATA_CHUNK_BYTES,
        "data_chunks": chunks,
        "fixed_control_plaintext_bytes": CONTROL_PLAINTEXT_BYTES,
        "compressed_inner_control_bytes": compressed_inner_bytes,
        "capsule_bytes": output_path.stat().st_size,
        "outer_seconds": time.perf_counter() - started,
        "large_file_policy": "bounded-memory streaming; no 512 MiB EFI 0.8 envelope ceiling",
    })
    return report


def _unwrap_v3_control(et013_dir: Path, private_path: Path, password: str, input_path: Path,
                       inner_path: Path) -> tuple[dict, dict]:
    header, kem_ct, control_nonce, control_ct, chunks, protected_bucket = _read_v3_prefix(input_path)
    inner_private = backend.open_private(private_path, password)
    guard_private = backend._b64_bounded(
        inner_private["guard_private_key_pem_b64"], minimum=512, maximum=16384, label="guard private key"
    )
    mlkem = backend.load_mlkem(Path(et013_dir))
    shared_secret = mlkem.decapsulate_bytes(guard_private, kem_ct, backend.GUARD_KEM)
    key = _derive_control_key(shared_secret, kem_ct, header)
    control_plain = AESGCM(key).decrypt(control_nonce, control_ct, _control_aad(header, kem_ct))
    inner = _unpack_control_inner(control_plain)
    inner_path.write_bytes(inner)
    return {
        "metadata_privacy": "PROTECTED",
        "envelope_format": "EFIPRIV3",
        "protected_bucket_bytes": protected_bucket,
        "data_chunks": chunks,
    }, inner_private


def _decrypt_v3(
    et013_dir: Path,
    private_path: Path,
    password: str,
    input_path: Path,
    destination_dir: Path,
    *,
    explicit_output: Path | None = None,
    progress: ProgressCallback | None = None,
    cancel_event=None,
) -> dict:
    started = time.perf_counter()
    target: Path | None = None
    with tempfile.TemporaryDirectory(prefix="efi091_stream_unwrap_") as td_raw:
        td = Path(td_raw)
        inner_path = td / "stream-control.efi.json"
        control_clear_path = td / "stream-control.clear.json"
        privacy, _ = _unwrap_v3_control(et013_dir, private_path, password, input_path, inner_path)
        _check_cancel(cancel_event)
        _emit_progress(progress, "Opening Entropic control", 0, 1)
        backend.decrypt_file(et013_dir, private_path, password, inner_path, control_clear_path)
        control = _decode_stream_control(control_clear_path.read_bytes())
        _emit_progress(progress, "Opening Entropic control", 1, 1)

        observed = _read_v3_prefix(input_path)
        chunks = observed[4]; protected_bucket = observed[5]
        if control["protected_bucket_bytes"] != protected_bucket:
            raise PrivateEnvelopeError("stream control does not match outer size class")
        if control["data_padded_bytes"] != chunks * DATA_CHUNK_BYTES:
            raise PrivateEnvelopeError("stream control does not match outer chunk count")

        destination_dir = Path(destination_dir)
        destination_dir.mkdir(parents=True, exist_ok=True)
        target = Path(explicit_output) if explicit_output is not None else unique_output(destination_dir / control["filename"])
        if target.exists():
            raise FileExistsError("refusing to overwrite an existing recovered file")

        prefix_len = HEADER_LEN + backend.GUARD_KEM_CIPHERTEXT_BYTES + CONTROL_NONCE_BYTES + CONTROL_CIPHERTEXT_BYTES
        remaining_real = control["plaintext_bytes"]
        hasher = hashlib.sha256()
        aead = AESGCM(control["data_key"])
        try:
            with Path(input_path).open("rb") as src, target.open("wb") as out:
                src.seek(prefix_len)
                _emit_progress(progress, "Decrypting content", 0, control["plaintext_bytes"])
                done_real = 0
                for index in range(chunks):
                    _check_cancel(cancel_event)
                    record = src.read(DATA_RECORD_BYTES)
                    if len(record) != DATA_RECORD_BYTES:
                        raise PrivateEnvelopeError("stream ciphertext is truncated")
                    plain = aead.decrypt(
                        _data_nonce(control["nonce_prefix"], index),
                        record,
                        _data_aad(control["stream_id"], index, protected_bucket),
                    )
                    if len(plain) != DATA_CHUNK_BYTES:
                        raise PrivateEnvelopeError("stream plaintext chunk length mismatch")
                    take = min(DATA_CHUNK_BYTES, remaining_real)
                    if take:
                        real = plain[:take]
                        out.write(real); hasher.update(real)
                        remaining_real -= take; done_real += take
                    _emit_progress(progress, "Decrypting content", done_real, control["plaintext_bytes"])
                if remaining_real != 0 or src.read(1):
                    raise PrivateEnvelopeError("stream ciphertext length mismatch")
            if hasher.hexdigest() != control["plaintext_sha256"]:
                raise PrivateEnvelopeError("recovered plaintext digest mismatch")
        except Exception:
            try:
                target.unlink(missing_ok=True)
            except Exception:
                pass
            raise

    return {
        **privacy,
        "filename": control["filename"],
        "output_path": str(target),
        "recovered_bytes": control["plaintext_bytes"],
        "payload_sha256": control["plaintext_sha256"],
        "data_chunk_bytes": DATA_CHUNK_BYTES,
        "data_chunks": chunks,
        "total_private_workflow_seconds": time.perf_counter() - started,
    }


# ----------------------- legacy 0.8.x compatibility -----------------------

def _legacy_header(magic: bytes, version: int, kem_len: int) -> bytes:
    return _header(magic, version, kem_len)


def _legacy_derive_key(shared_secret: bytes, kem_ct: bytes, header: bytes) -> bytes:
    if len(shared_secret) != backend.GUARD_SHARED_SECRET_BYTES:
        raise PrivateEnvelopeError("unexpected legacy ML-KEM shared-secret length")
    salt = hashlib.sha256(kem_ct).digest()
    info = LEGACY_KEY_DOMAIN + b"\x00" + hashlib.sha256(header + kem_ct).digest()
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=info).derive(shared_secret)


def _legacy_aad(header: bytes, kem_ct: bytes) -> bytes:
    return LEGACY_AAD_DOMAIN + b"\x00" + header + hashlib.sha256(kem_ct).digest()


def _legacy_load_outer(path: Path) -> tuple[bytes, bytes, bytes, bytes, int]:
    raw = Path(path).read_bytes()
    if len(raw) < HEADER_LEN + LEGACY_NONCE_BYTES + 16:
        raise PrivateEnvelopeError("legacy private EFI envelope is truncated")
    magic = raw[:8]
    if magic not in {MAGIC_V1, MAGIC_V2}:
        raise PrivateEnvelopeError("not a legacy EFI 0.8.x private envelope")
    expected_version = 1 if magic == MAGIC_V1 else 2
    if raw[8] != expected_version or raw[9] != FLAGS:
        raise PrivateEnvelopeError("unsupported legacy EFI envelope version")
    kem_len = int.from_bytes(raw[10:12], "big")
    if kem_len != backend.GUARD_KEM_CIPHERTEXT_BYTES:
        raise PrivateEnvelopeError("legacy EFI envelope KEM length mismatch")
    off = HEADER_LEN
    kem_ct = raw[off:off + kem_len]; off += kem_len
    nonce = raw[off:off + LEGACY_NONCE_BYTES]; off += LEGACY_NONCE_BYTES
    ciphertext = raw[off:]
    if len(kem_ct) != kem_len or len(nonce) != LEGACY_NONCE_BYTES or len(ciphertext) < 16:
        raise PrivateEnvelopeError("legacy EFI envelope is truncated")
    return raw[:HEADER_LEN], kem_ct, nonce, ciphertext, expected_version


def _legacy_validate_padded(padded: bytes, version: int) -> None:
    n = len(padded)
    if version == 1:
        if n < LEGACY_V1_MIN_PADDED or n > LEGACY_V1_MAX_PADDED or n % LEGACY_V1_PAD_QUANTUM:
            raise PrivateEnvelopeError("legacy EFIPRIV1 padding shape is invalid")
    elif version == 2:
        if n < LEGACY_V2_MIN_PADDED or n > LEGACY_V2_MAX_PADDED or (n & (n - 1)):
            raise PrivateEnvelopeError("legacy EFIPRIV2 size-class shape is invalid")
    else:
        raise PrivateEnvelopeError("unsupported legacy private-envelope version")


def _legacy_unpack_inner(padded: bytes) -> bytes:
    if len(padded) < 8:
        raise PrivateEnvelopeError("legacy private envelope payload is truncated")
    inner_len = int.from_bytes(padded[:8], "big")
    if inner_len <= 0 or inner_len > len(padded) - 8:
        raise PrivateEnvelopeError("legacy private envelope inner length is invalid")
    inner = padded[8:8 + inner_len]
    if not inner.startswith(b"{"):
        raise PrivateEnvelopeError("legacy private envelope inner capsule is invalid")
    return inner


def _legacy_unwrap_to_inner(et013_dir: Path, private_path: Path, password: str,
                            input_path: Path, inner_path: Path) -> dict:
    header, kem_ct, nonce, ciphertext, version = _legacy_load_outer(input_path)
    inner_private = backend.open_private(private_path, password)
    guard_private = backend._b64_bounded(
        inner_private["guard_private_key_pem_b64"], minimum=512, maximum=16384, label="guard private key"
    )
    mlkem = backend.load_mlkem(Path(et013_dir))
    shared_secret = mlkem.decapsulate_bytes(guard_private, kem_ct, backend.GUARD_KEM)
    key = _legacy_derive_key(shared_secret, kem_ct, header)
    padded = AESGCM(key).decrypt(nonce, ciphertext, _legacy_aad(header, kem_ct))
    _legacy_validate_padded(padded, version)
    inner = _legacy_unpack_inner(padded)
    inner_path.write_bytes(inner)
    return {
        "metadata_privacy": "PROTECTED / LEGACY ENVELOPE",
        "envelope_format": f"EFIPRIV{version}",
        "padded_inner_bytes": len(padded),
        "inner_capsule_bytes": len(inner),
    }


def decrypt_file(
    et013_dir: Path,
    private_path: Path,
    password: str,
    input_path: Path,
    destination_dir: Path,
    *,
    explicit_output: Path | None = None,
    progress: ProgressCallback | None = None,
    cancel_event=None,
) -> dict:
    started = time.perf_counter()
    input_path = Path(input_path); private_path = Path(private_path); destination_dir = Path(destination_dir)
    destination_dir.mkdir(parents=True, exist_ok=True)
    with input_path.open("rb") as f:
        magic = f.read(8)

    if magic == MAGIC:
        return _decrypt_v3(
            Path(et013_dir), private_path, password, input_path, destination_dir,
            explicit_output=explicit_output, progress=progress, cancel_event=cancel_event,
        )

    if magic in {MAGIC_V1, MAGIC_V2}:
        with tempfile.TemporaryDirectory(prefix="efi091_legacy_unwrap_") as td_raw:
            td = Path(td_raw); inner_path = td / "inner.efi.json"
            privacy = _legacy_unwrap_to_inner(Path(et013_dir), private_path, password, input_path, inner_path)
            meta = backend.capsule_metadata(inner_path)
            target = Path(explicit_output) if explicit_output is not None else unique_output(destination_dir / meta["filename"])
            if target.exists():
                raise FileExistsError("refusing to overwrite an existing recovered file")
            dec = backend.decrypt_file(Path(et013_dir), private_path, password, inner_path, target)
        out = dict(dec); out.update(privacy); out.update({
            "filename": meta["filename"], "output_path": str(target),
            "total_private_workflow_seconds": time.perf_counter() - started,
        })
        return out

    # Legacy raw EFI 0.5 JSON compatibility.  Raw ET 0.13 capsules are
    # intentionally inspectable as legacy/exposed but are not EFI integrated
    # capsules and therefore are not decrypted by this path.
    meta = backend.capsule_metadata(input_path)
    target = Path(explicit_output) if explicit_output is not None else unique_output(destination_dir / meta["filename"])
    if target.exists():
        raise FileExistsError("refusing to overwrite an existing recovered file")
    dec = backend.decrypt_file(Path(et013_dir), private_path, password, input_path, target)
    out = dict(dec); out.update({
        "metadata_privacy": "LEGACY / EXPOSED", "legacy_capsule": True,
        "filename": meta["filename"], "output_path": str(target),
        "total_private_workflow_seconds": time.perf_counter() - started,
    })
    return out


def privacy_regression_probe(et013_dir: Path) -> dict:
    password = "EFI090-Privacy-Probe-Password"
    secret_name = "Quarterly-Acquisition-Plan-FINAL.docx"
    # Large enough to exercise multiple streaming records while remaining
    # small enough for routine source/frozen validation.
    payload = (b"metadata-private streaming EFI probe\n" + bytes(range(256))) * 1900
    with tempfile.TemporaryDirectory(prefix="efi091_privacy_probe_") as td_raw:
        td = Path(td_raw)
        pub = td / "recipient.public.json"; prv = td / "recipient.private.json"; src = td / secret_name
        src.write_bytes(payload)
        backend.generate_identity(Path(et013_dir), pub, prv, password)
        public_obj = backend.load_public(pub)
        fp = str(public_obj.get("public_fingerprint") or public_obj.get("fingerprint") or "")

        caps = []; reports = []
        modes = [
            ("standard", 2, 4, 8),
            ("tetration", 2, 4, 0),
            ("pentation", 2, 3, 0),
        ]
        for i, (mode, base_value, height, standard_steps) in enumerate(modes):
            cap = td / f"opaque-{i}.efi"
            rep = encrypt_file(
                Path(et013_dir), pub, src, cap, cycles=1, root_mode=mode,
                base_value=base_value, height=height, standard_steps=standard_steps,
            )
            caps.append(cap); reports.append(rep)

        raws = [p.read_bytes() for p in caps]
        sizes = [len(r) for r in raws]
        public_meta = public_inspect(caps[1])
        outdir = td / "recovered"
        dec = decrypt_file(Path(et013_dir), prv, password, caps[1], outdir)
        recovered = Path(dec["output_path"])
        exact = recovered.read_bytes() == payload

        forbidden_text = [
            secret_name, ".docx", "plaintext_bytes", "recipient_fingerprint", "public_fingerprint",
            "root_hyperoperation", "chain_schedule", "tetration", "pentation", "2^^4", "2^^^3",
            "65536", "final_key_id", "EFI-0.5-ALGORITHM-SUITE-1", "ML-KEM-768", "ML-KEM-1024",
            "AES-256-GCM", "ET-0.13-VIRTUAL-CAPSULE-1", STREAM_CONTROL_FORMAT,
        ]
        if fp:
            forbidden_text.append(fp)
        leaks = sorted({tok for tok in forbidden_text if any(tok.encode("utf-8") in raw for raw in raws)})
        bodies = [raw[HEADER_LEN:] for raw in raws]

        estimates = {
            "2_14_mib": estimate_size(int(2.14 * MIB)),
            "20_mib": estimate_size(20 * MIB),
            "100_mib": estimate_size(100 * MIB),
            "500_mib": estimate_size(500 * MIB),
            "2_gib_exact": estimate_size(2 * GIB),
            "2_gib_plus_one": estimate_size(2 * GIB + 1),
        }

    pass_state = (
        exact and not leaks and len(set(sizes)) == 1 and len(set(bodies)) == len(bodies)
        and all(r.get("streaming_envelope") is True for r in reports)
        and estimates["2_gib_exact"]["protected_bucket_bytes"] == int(2.125 * GIB)
        and estimates["2_gib_exact"]["protected_bucket_bytes"] < 4 * GIB
    )
    return {
        "version": VERSION,
        "status": "PASS" if pass_state else "FAIL",
        "exact_roundtrip": exact,
        "outer_binary": all(raw.startswith(MAGIC) for raw in raws),
        "streaming_envelope": all(r.get("streaming_envelope") is True for r in reports),
        "forbidden_metadata_tokens_found": leaks,
        "original_filename_not_visible": all(secret_name.encode("utf-8") not in raw for raw in raws),
        "public_inspect_reports_protected": public_meta.get("metadata_privacy") == "PROTECTED",
        "graduated_size_policy": True,
        "cross_mode_outer_sizes_identical": len(set(sizes)) == 1,
        "cross_mode_cipher_bodies_distinct": len(set(bodies)) == len(bodies),
        "zero_padding_encrypted": True,
        "bounded_chunk_bytes": DATA_CHUNK_BYTES,
        "fixed_control_plaintext_bytes": CONTROL_PLAINTEXT_BYTES,
        "modes_tested": [m[0] for m in modes],
        "recovered_filename": dec.get("filename"),
        "recovered_bytes": dec.get("recovered_bytes"),
        "outer_capsule_bytes": sizes[0],
        "size_estimates": estimates,
        "two_gib_not_four_gib": estimates["2_gib_exact"]["protected_bucket_bytes"] < 4 * GIB,
    }


def control_capacity_regression_probe(et013_dir: Path) -> dict:
    """Exercise the maximum current EC cycle count against the fixed control block.

    This does not process a large user file. It verifies that the largest
    control profile currently accepted by the frozen EFI 0.5 backend can be
    compressed into the EFIPRIV3 fixed 4 MiB private control region.
    """
    password = "EFI090-Control-Capacity-Probe"
    with tempfile.TemporaryDirectory(prefix="efi091_control_capacity_") as td_raw:
        td = Path(td_raw)
        pub = td / "recipient.public.json"
        prv = td / "recipient.private.json"
        clear = td / "stream-control.json"
        inner = td / "stream-control.efi.json"
        clear.write_bytes(_encode_stream_control(
            filename="capacity-probe.bin",
            plaintext_bytes=1,
            plaintext_sha256=hashlib.sha256(b"x").hexdigest(),
            data_key=b"K" * DATA_KEY_BYTES,
            nonce_prefix=b"N" * DATA_NONCE_PREFIX_BYTES,
            stream_id=b"S" * STREAM_ID_BYTES,
            data_padded_bytes=6 * MIB,
            protected_bucket_bytes=8 * MIB,
        ))
        backend.generate_identity(Path(et013_dir), pub, prv, password)
        report = backend.encrypt_file(
            Path(et013_dir), pub, clear, inner,
            cycles=backend.MAX_CYCLES,
            root_mode="standard",
            base_value=2,
            height=4,
            standard_steps=8,
        )
        raw = inner.read_bytes()
        packed, compressed_len = _pack_control_inner(raw)
    return {
        "status": "PASS" if len(packed) == CONTROL_PLAINTEXT_BYTES else "FAIL",
        "cycles": backend.MAX_CYCLES,
        "inner_capsule_bytes": len(raw),
        "compressed_inner_bytes": compressed_len,
        "fixed_control_plaintext_bytes": CONTROL_PLAINTEXT_BYTES,
        "remaining_control_bytes": CONTROL_PLAINTEXT_BYTES - CONTROL_FRAME_HEADER_BYTES - compressed_len,
        "stages": report.get("stages"),
    }
