#!/usr/bin/env python3
from __future__ import annotations

import argparse, base64, getpass, hashlib, importlib, json, os, re, secrets, sys, tempfile, time
from pathlib import Path

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

import efi_chain_core as chain

VERSION = "Entropic Fusion Integrated EFI 0.5.0-alpha"
PROTOCOL = "EFI 0.5 canonical integrated protocol over frozen ET 0.13 root binding plus independent ML-KEM-1024-derived EC100 chain secret"
CAPSULE_FORMAT = "EFI-0.5-INTEGRATED-CAPSULE-1"
PUBLIC_FORMAT = "EFI-0.5-PUBLIC-IDENTITY-1"
PRIVATE_VAULT_FORMAT = "EFI-0.5-PRIVATE-VAULT-1"
PRIVATE_INNER_FORMAT = "EFI-0.5-PRIVATE-INNER-1"
PAYLOAD_DOMAIN = "ENTROPIC-FUSION/EFI-0.5/PAYLOAD/v1"
FINAL_CONTEXT_DOMAIN = "ENTROPIC-FUSION/EFI-0.5/FINAL-CONTEXT/v1"
GUARD_AAD_DOMAIN = "ENTROPIC-FUSION/EFI-0.5/GUARD-KEM/v1"
GUARD_KDF_DOMAIN = b"ENTROPIC-FUSION/EFI-0.5/GUARD-CHAIN-SECRET/v1"
FINAL_KEY_DOMAIN = b"ENTROPIC-FUSION/EFI-0.5/FINAL-KEY/v1"
PRIVATE_AAD_DOMAIN = b"ENTROPIC-FUSION/EFI-0.5/PRIVATE/v1"
ROOT_ENGINE_VERSION = "Entropic Tetration ET 0.13.0-alpha"
ROOT_CAPSULE_FORMAT = "ET-0.13-VIRTUAL-CAPSULE-1"
ROOT_PROTOCOL = "ET-0.13 virtual recursive state experiment over one full Beta 1.1.1 root establishment"
GUARD_KEM = "ML-KEM-1024"
DEFAULT_CYCLES = 20
MAX_CYCLES = 256
MAX_PUBLIC_IDENTITY_BYTES = 8 * 1024 * 1024
MAX_PRIVATE_VAULT_BYTES = 16 * 1024 * 1024
MAX_CAPSULE_BYTES = 1024 * 1024 * 1024
MAX_PLAINTEXT_BYTES = 512 * 1024 * 1024
MAX_FILENAME_UTF8_BYTES = 255
SCRYPT_N = 2**15
SCRYPT_R = 8
SCRYPT_P = 1
SCRYPT_SALT_BYTES = 16
AEAD_NONCE_BYTES = 12
GCM_TAG_BYTES = 16
GUARD_KEM_CIPHERTEXT_BYTES = 1568
GUARD_SHARED_SECRET_BYTES = 32
ROOT_BINDING_BYTES = 32
HEX64_RE = re.compile(r"^[0-9a-f]{64}$")
HEX32_RE = re.compile(r"^[0-9a-f]{32}$")

ALGORITHM_SUITE = {
    "suite": "EFI-0.5-ALGORITHM-SUITE-1",
    "canonical_encoding": "UTF-8 JSON; object keys sorted lexicographically; separators=(',',':'); ensure_ascii=false",
    "hash": "SHA-256",
    "guard_kem": GUARD_KEM,
    "guard_kem_ciphertext_bytes": GUARD_KEM_CIPHERTEXT_BYTES,
    "guard_kdf": "HKDF-SHA256",
    "root_engine": ROOT_ENGINE_VERSION,
    "root_capsule_format": ROOT_CAPSULE_FORMAT,
    "root_protocol": ROOT_PROTOCOL,
    "chain_core_version": chain.VERSION,
    "chain_gate": "Argon2id",
    "chain_transition_kdf": "HKDF-SHA256",
    "chain_transition_aead": "AES-256-GCM",
    "final_kdf": "HKDF-SHA256",
    "payload_aead": "AES-256-GCM",
    "private_vault_kdf": "scrypt",
    "private_vault_scrypt": {"n": SCRYPT_N, "r": SCRYPT_R, "p": SCRYPT_P, "salt_bytes": SCRYPT_SALT_BYTES},
    "private_vault_aead": "AES-256-GCM",
    "aead_nonce_bytes": AEAD_NONCE_BYTES,
    "domains": {
        "payload": PAYLOAD_DOMAIN,
        "final_context": FINAL_CONTEXT_DOMAIN,
        "guard_aad": GUARD_AAD_DOMAIN,
        "guard_kdf": GUARD_KDF_DOMAIN.decode("ascii"),
        "final_key": FINAL_KEY_DOMAIN.decode("ascii"),
        "private_aad": PRIVATE_AAD_DOMAIN.decode("ascii"),
    },
}


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")

def _reject_constant(value: str):
    raise ValueError(f"non-finite JSON number is not permitted: {value}")

def strict_json_loads(text: str, *, label: str = "JSON"):
    if text.startswith("\ufeff"):
        raise ValueError(f"{label} must not contain a UTF-8 BOM")
    def no_duplicates(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ValueError(f"{label} contains duplicate key: {key}")
            out[key] = value
        return out
    try:
        return json.loads(text, object_pairs_hook=no_duplicates, parse_constant=_reject_constant)
    except UnicodeError as exc:
        raise ValueError(f"{label} is not valid UTF-8 JSON") from exc

def _read_json(path: Path, *, max_bytes: int, label: str) -> dict:
    path = Path(path)
    size = path.stat().st_size
    if size <= 0 or size > max_bytes:
        raise ValueError(f"{label} size outside permitted range")
    raw = path.read_bytes()
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise ValueError(f"{label} is not UTF-8") from exc
    obj = strict_json_loads(text, label=label)
    if not isinstance(obj, dict):
        raise ValueError(f"{label} top level must be an object")
    return obj

def _require_exact_keys(obj: dict, expected, label: str) -> None:
    if not isinstance(obj, dict):
        raise ValueError(f"{label} must be an object")
    expected = set(expected)
    actual = set(obj)
    missing = sorted(expected - actual)
    unknown = sorted(actual - expected)
    if missing or unknown:
        raise ValueError(f"{label} field set mismatch; missing={missing}, unknown={unknown}")

def _require_int(value, *, minimum: int, maximum: int, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise ValueError(f"{label} outside permitted integer range")
    return value

def _require_hex(text, *, pattern, label: str) -> str:
    if not isinstance(text, str) or pattern.fullmatch(text) is None:
        raise ValueError(f"{label} malformed")
    return text

def _require_fingerprint(text, label: str = "fingerprint") -> str:
    return _require_hex(text, pattern=HEX64_RE, label=label)

def b64e(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")

def b64d(text: str) -> bytes:
    if not isinstance(text, str):
        raise ValueError("base64 field must be a string")
    try:
        return base64.b64decode(text.encode("ascii"), validate=True)
    except (UnicodeEncodeError, ValueError) as exc:
        raise ValueError("invalid canonical base64") from exc

def _b64_exact(text: str, length: int, label: str) -> bytes:
    raw = b64d(text)
    if len(raw) != length:
        raise ValueError(f"{label} length mismatch")
    if b64e(raw) != text:
        raise ValueError(f"{label} is not canonical base64")
    return raw

def _b64_bounded(text: str, *, minimum: int, maximum: int, label: str) -> bytes:
    raw = b64d(text)
    if not minimum <= len(raw) <= maximum:
        raise ValueError(f"{label} length outside permitted range")
    if b64e(raw) != text:
        raise ValueError(f"{label} is not canonical base64")
    return raw

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def _validate_algorithms(value) -> None:
    if value != ALGORITHM_SUITE:
        raise ValueError("EFI 0.5 algorithm suite mismatch")

def _validate_filename(name: str) -> str:
    if not isinstance(name, str) or name in ("", ".", ".."):
        raise ValueError("filename malformed")
    if Path(name).name != name or "/" in name or "\\" in name or "\x00" in name:
        raise ValueError("filename must be a basename only")
    if len(name.encode("utf-8")) > MAX_FILENAME_UTF8_BYTES:
        raise ValueError("filename exceeds UTF-8 byte limit")
    return name

def _fingerprint(obj_without_fp: dict) -> str:
    return sha256_hex(canonical(obj_without_fp))

def _derive_password_key(password: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    if not isinstance(password, str) or len(password) < 10:
        raise ValueError("password must be at least 10 characters")
    if (n, r, p) != (SCRYPT_N, SCRYPT_R, SCRYPT_P) or len(salt) != SCRYPT_SALT_BYTES:
        raise ValueError("EFI 0.5 private-vault KDF parameters are not canonical")
    return Scrypt(salt=salt, length=32, n=n, r=r, p=p).derive(password.encode("utf-8"))

def _private_aad(public_fp: str) -> bytes:
    _require_fingerprint(public_fp, "public fingerprint")
    return PRIVATE_AAD_DOMAIN + b"\x00" + bytes.fromhex(public_fp)

def load_root_engine(et013_dir: Path):
    directory = Path(et013_dir).resolve()
    source = directory / "entropic_tetration_et_0_13_0.py"
    if not source.is_file():
        raise FileNotFoundError(f"ET 0.13 source not found in {directory}")
    for p in (directory, directory / "beta1_1_1_rebuild_kit"):
        if str(p) not in sys.path:
            sys.path.insert(0, str(p))
    module = importlib.import_module("entropic_tetration_et_0_13_0")
    if getattr(module, "VERSION", None) != ROOT_ENGINE_VERSION:
        raise ValueError("root engine version mismatch")
    return module

def load_mlkem(et013_dir: Path):
    load_root_engine(et013_dir)
    module = importlib.import_module("entropic_fusion_mlkem_runtime_v0_11B_23_1")
    module.check_available()
    return module


def generate_identity(et013_dir: Path, public_path: Path, private_path: Path, password: str, seed: int | None = None) -> dict:
    engine = load_root_engine(et013_dir)
    mlkem = load_mlkem(et013_dir)
    started = time.perf_counter()
    with tempfile.TemporaryDirectory(prefix="efi050_identity_") as td:
        td = Path(td)
        root_pub_path, root_priv_path = td / "root.public.json", td / "root.private.json"
        root_report = engine.generate_identity(root_pub_path, root_priv_path, password=password, deterministic_seed=seed)
        root_public = strict_json_loads(root_pub_path.read_text(encoding="utf-8"), label="ET 0.13 public identity")
        root_private_vault = strict_json_loads(root_priv_path.read_text(encoding="utf-8"), label="ET 0.13 private vault")
    guard_pk, guard_sk = mlkem.keygen_bytes(GUARD_KEM)
    _validate_pem(guard_pk, label="guard public key", private=False)
    _validate_pem(guard_sk, label="guard private key", private=True)
    public_obj = {
        "format": PUBLIC_FORMAT,
        "version": VERSION,
        "algorithms": ALGORITHM_SUITE,
        "root_engine": ROOT_ENGINE_VERSION,
        "root_public_identity": root_public,
        "guard": {"kem": GUARD_KEM, "public_key_pem_b64": b64e(guard_pk)},
        "security_note": "EFI 0.5 fixes one canonical algorithm suite and capsule interpretation around the EFI 0.4 independent root-binding and guard-derived chain-secret dependency graph.",
    }
    public_obj["public_fingerprint"] = _fingerprint(public_obj)
    Path(public_path).parent.mkdir(parents=True, exist_ok=True)
    Path(public_path).write_text(json.dumps(public_obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    inner = {
        "format": PRIVATE_INNER_FORMAT,
        "version": VERSION,
        "algorithms": ALGORITHM_SUITE,
        "public_fingerprint": public_obj["public_fingerprint"],
        "root_private_vault": root_private_vault,
        "guard_private_key_pem_b64": b64e(guard_sk),
    }
    salt, nonce = os.urandom(SCRYPT_SALT_BYTES), os.urandom(AEAD_NONCE_BYTES)
    key = _derive_password_key(password, salt, SCRYPT_N, SCRYPT_R, SCRYPT_P)
    ct = AESGCM(key).encrypt(nonce, canonical(inner), _private_aad(public_obj["public_fingerprint"]))
    vault = {
        "format": PRIVATE_VAULT_FORMAT,
        "version": VERSION,
        "algorithms": ALGORITHM_SUITE,
        "public_fingerprint": public_obj["public_fingerprint"],
        "kdf": {"name": "scrypt", "n": SCRYPT_N, "r": SCRYPT_R, "p": SCRYPT_P, "salt_b64": b64e(salt)},
        "aead": "AES-256-GCM",
        "nonce_b64": b64e(nonce),
        "ciphertext_b64": b64e(ct),
    }
    Path(private_path).parent.mkdir(parents=True, exist_ok=True)
    Path(private_path).write_text(json.dumps(vault, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    try:
        os.chmod(private_path, 0o600)
    except OSError:
        pass
    return {
        "version": VERSION,
        "public_fingerprint": public_obj["public_fingerprint"],
        "root_identity": root_report,
        "guard_kem": GUARD_KEM,
        "algorithm_suite": ALGORITHM_SUITE["suite"],
        "seconds": time.perf_counter() - started,
    }


def _validate_pem(raw: bytes, *, label: str, private: bool) -> None:
    """Validate generic PKCS#8/SPKI PEM while accepting LF or Windows CRLF.

    OpenSSL emits platform-native line endings on some Windows builds.  EFI's
    protocol is defined over the decoded key bytes, not a single host newline
    convention, so both standard LF and CRLF PEM framing are accepted.  Other
    whitespace ambiguity remains rejected.
    """
    if not isinstance(raw, (bytes, bytearray)) or not 512 <= len(raw) <= 16384:
        raise ValueError(f"{label} length outside permitted range")
    try:
        text = bytes(raw).decode("ascii")
    except UnicodeDecodeError as exc:
        raise ValueError(f"{label} must be ASCII PEM") from exc
    if "\x00" in text:
        raise ValueError(f"{label} PEM contains NUL")
    begin = "-----BEGIN PRIVATE KEY-----" if private else "-----BEGIN PUBLIC KEY-----"
    end = "-----END PRIVATE KEY-----" if private else "-----END PUBLIC KEY-----"
    lines = text.splitlines()
    if len(lines) < 3 or lines[0] != begin or lines[-1] != end:
        raise ValueError(f"{label} PEM framing mismatch")
    body_lines = lines[1:-1]
    if any((not line) or line != line.strip() for line in body_lines):
        raise ValueError(f"{label} PEM body whitespace mismatch")
    try:
        base64.b64decode("".join(body_lines), validate=True)
    except Exception as exc:
        raise ValueError(f"{label} PEM body is not strict base64") from exc


def load_public(path: Path) -> dict:
    obj = _read_json(path, max_bytes=MAX_PUBLIC_IDENTITY_BYTES, label="EFI 0.5 public identity")
    _require_exact_keys(obj, {"format","version","algorithms","root_engine","root_public_identity","guard","security_note","public_fingerprint"}, "public identity")
    if obj["format"] != PUBLIC_FORMAT or obj["version"] != VERSION:
        raise ValueError("not an EFI 0.5 public identity")
    _validate_algorithms(obj["algorithms"])
    if obj["root_engine"] != ROOT_ENGINE_VERSION or not isinstance(obj["root_public_identity"], dict):
        raise ValueError("EFI root engine/public identity mismatch")
    claimed = _require_fingerprint(obj["public_fingerprint"], "public fingerprint")
    tmp = dict(obj)
    tmp.pop("public_fingerprint")
    if claimed != _fingerprint(tmp):
        raise ValueError("EFI public fingerprint mismatch")
    guard = obj["guard"]
    _require_exact_keys(guard, {"kem","public_key_pem_b64"}, "guard public identity")
    if guard["kem"] != GUARD_KEM:
        raise ValueError("EFI guard KEM mismatch")
    guard_pk = _b64_bounded(guard["public_key_pem_b64"], minimum=512, maximum=16384, label="guard public key")
    _validate_pem(guard_pk, label="guard public key", private=False)
    if not isinstance(obj["security_note"], str) or len(obj["security_note"]) > 1024:
        raise ValueError("security note malformed")
    return obj


def open_private(path: Path, password: str) -> dict:
    vault = _read_json(path, max_bytes=MAX_PRIVATE_VAULT_BYTES, label="EFI 0.5 private vault")
    _require_exact_keys(vault, {"format","version","algorithms","public_fingerprint","kdf","aead","nonce_b64","ciphertext_b64"}, "private vault")
    if vault["format"] != PRIVATE_VAULT_FORMAT or vault["version"] != VERSION:
        raise ValueError("not an EFI 0.5 private vault")
    _validate_algorithms(vault["algorithms"])
    _require_fingerprint(vault["public_fingerprint"], "private-vault public fingerprint")
    if vault["aead"] != "AES-256-GCM":
        raise ValueError("private-vault AEAD mismatch")
    k = vault["kdf"]
    _require_exact_keys(k, {"name","n","r","p","salt_b64"}, "private-vault KDF")
    if k["name"] != "scrypt" or (k["n"], k["r"], k["p"]) != (SCRYPT_N, SCRYPT_R, SCRYPT_P):
        raise ValueError("private-vault KDF suite mismatch")
    salt = _b64_exact(k["salt_b64"], SCRYPT_SALT_BYTES, "private-vault salt")
    nonce = _b64_exact(vault["nonce_b64"], AEAD_NONCE_BYTES, "private-vault nonce")
    ciphertext = _b64_bounded(vault["ciphertext_b64"], minimum=GCM_TAG_BYTES + 2, maximum=MAX_PRIVATE_VAULT_BYTES, label="private-vault ciphertext")
    key = _derive_password_key(password, salt, k["n"], k["r"], k["p"])
    raw = AESGCM(key).decrypt(nonce, ciphertext, _private_aad(vault["public_fingerprint"]))
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise ValueError("private-vault inner is not UTF-8") from exc
    inner = strict_json_loads(text, label="EFI 0.5 private inner")
    _require_exact_keys(inner, {"format","version","algorithms","public_fingerprint","root_private_vault","guard_private_key_pem_b64"}, "private inner")
    if inner["format"] != PRIVATE_INNER_FORMAT or inner["version"] != VERSION or inner["public_fingerprint"] != vault["public_fingerprint"]:
        raise ValueError("EFI private-vault inner mismatch")
    _validate_algorithms(inner["algorithms"])
    if not isinstance(inner["root_private_vault"], dict):
        raise ValueError("root private vault malformed")
    guard_sk = _b64_bounded(inner["guard_private_key_pem_b64"], minimum=512, maximum=16384, label="guard private key")
    _validate_pem(guard_sk, label="guard private key", private=True)
    return inner


def _root_protect_binding(engine, root_public_obj: dict, root_binding_secret: bytes, temp_dir: Path, *, root_mode: str, base_value: int, height: int, standard_steps: int):
    pub = temp_dir / "root.public.json"; secret_file = temp_dir / "root_binding.bin"; cap = temp_dir / "root_capsule.json"
    pub.write_text(json.dumps(root_public_obj, indent=2)+"\n", encoding="utf-8")
    secret_file.write_bytes(root_binding_secret)
    report = engine.encrypt_file(pub, secret_file, cap, mode=root_mode, base_value=base_value, height=height, standard_steps=standard_steps)
    return json.loads(cap.read_text(encoding="utf-8")), report


def _root_recover_binding(engine, root_private_vault: dict, password: str, root_capsule: dict, temp_dir: Path):
    priv = temp_dir / "root.private.json"; cap = temp_dir / "root_capsule.json"; out = temp_dir / "root_binding.bin"
    priv.write_text(json.dumps(root_private_vault, indent=2)+"\n", encoding="utf-8")
    cap.write_text(json.dumps(root_capsule, indent=2)+"\n", encoding="utf-8")
    report = engine.decrypt_file(priv, password, cap, out)
    root_binding_secret = out.read_bytes()
    if len(root_binding_secret) != 32: raise ValueError("root did not recover a 256-bit binding secret")
    return root_binding_secret, report


def _guard_aad(public_fp: str, kem_ct: bytes) -> dict:
    _require_fingerprint(public_fp, "guard recipient fingerprint")
    if len(kem_ct) != GUARD_KEM_CIPHERTEXT_BYTES:
        raise ValueError("guard KEM ciphertext length mismatch")
    return {"domain": GUARD_AAD_DOMAIN, "recipient_fingerprint": public_fp, "kem": GUARD_KEM, "kem_ciphertext_sha256": sha256_hex(kem_ct)}


def _guard_chain_secret(guard_ss: bytes, aad: dict) -> bytes:
    if len(guard_ss) != GUARD_SHARED_SECRET_BYTES:
        raise ValueError("guard KEM shared secret length mismatch")
    _require_exact_keys(aad, {"domain","recipient_fingerprint","kem","kem_ciphertext_sha256"}, "guard AAD")
    if aad["domain"] != GUARD_AAD_DOMAIN or aad["kem"] != GUARD_KEM:
        raise ValueError("guard AAD suite mismatch")
    _require_fingerprint(aad["recipient_fingerprint"], "guard AAD recipient fingerprint")
    _require_fingerprint(aad["kem_ciphertext_sha256"], "guard AAD ciphertext hash")
    salt = hashlib.sha256(canonical(aad)).digest()
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=GUARD_KDF_DOMAIN + b"\x00" + canonical(aad)).derive(guard_ss)


def _guard_encapsulate(mlkem, guard_public_pem: bytes, public_fp: str):
    _validate_pem(guard_public_pem, label="guard public key", private=False)
    kem_ct, guard_ss = mlkem.encapsulate_bytes(guard_public_pem, GUARD_KEM)
    if len(kem_ct) != GUARD_KEM_CIPHERTEXT_BYTES or len(guard_ss) != GUARD_SHARED_SECRET_BYTES:
        raise ValueError("guard KEM output length mismatch")
    aad = _guard_aad(public_fp, kem_ct)
    chain_secret = _guard_chain_secret(guard_ss, aad)
    block = {"kem": GUARD_KEM, "kem_ciphertext_b64": b64e(kem_ct), "aad": aad}
    return block, guard_ss, chain_secret


def _guard_decapsulate(mlkem, guard_private_pem: bytes, block: dict, public_fp: str):
    _validate_pem(guard_private_pem, label="guard private key", private=True)
    _require_exact_keys(block, {"kem","kem_ciphertext_b64","aad"}, "guard layer")
    if block["kem"] != GUARD_KEM:
        raise ValueError("guard KEM mismatch")
    kem_ct = _b64_exact(block["kem_ciphertext_b64"], GUARD_KEM_CIPHERTEXT_BYTES, "guard KEM ciphertext")
    expected = _guard_aad(public_fp, kem_ct)
    if block["aad"] != expected:
        raise ValueError("guard AAD mismatch")
    guard_ss = mlkem.decapsulate_bytes(guard_private_pem, kem_ct, GUARD_KEM)
    return _guard_chain_secret(guard_ss, expected)


def _core_from_capsule(capsule: dict) -> dict:
    return {k: capsule[k] for k in ("format","version","protocol","algorithms","root_engine","recipient_fingerprint","root_layer","guard_layer","chain")}


def _core_commitment(core: dict) -> bytes:
    _require_exact_keys(core, {"format","version","protocol","algorithms","root_engine","recipient_fingerprint","root_layer","guard_layer","chain"}, "committed core")
    return hashlib.sha256(canonical({"domain": FINAL_CONTEXT_DOMAIN, "core": core})).digest()


def _final_key(chain_secret: bytes, terminal: bytes, root_binding_secret: bytes, context: bytes) -> bytes:
    if len(chain_secret) != 32 or len(terminal) != 32 or len(root_binding_secret) != ROOT_BINDING_BYTES or len(context) != 32:
        raise ValueError("EFI 0.5 final-key inputs must each be 256 bits")
    chain_leg = chain.final_key(chain_secret, terminal, context)
    if len(chain_leg) != 32:
        raise ValueError("chain final leg length mismatch")
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=hashlib.sha256(context).digest(),
        info=FINAL_KEY_DOMAIN + b"\x00" + context,
    ).derive(chain_leg + root_binding_secret)


def _validate_root_layer(r: dict) -> dict:
    _require_exact_keys(r, {"format","version","protocol","public_fingerprint","root","virtual","payload"}, "root layer")
    if r["format"] != ROOT_CAPSULE_FORMAT or r["version"] != ROOT_ENGINE_VERSION or r["protocol"] != ROOT_PROTOCOL:
        raise ValueError("root capsule metadata mismatch")
    _require_fingerprint(r["public_fingerprint"], "root public fingerprint")

    rr = r["root"]
    _require_exact_keys(rr, {"level","masked_public_identity","outer_nonce_b64","inner_nonce_b64","outer_ct_b64","inner_ct_b64","transcript_b64","prior_key_id"}, "root record")
    if rr["level"] != 1 or not isinstance(rr["masked_public_identity"], dict) or rr["prior_key_id"] is not None:
        raise ValueError("root record level/identity mismatch")
    if rr["outer_nonce_b64"] != "" or rr["inner_nonce_b64"] != "":
        raise ValueError("root record nonce markers are not canonical")
    _b64_bounded(rr["outer_ct_b64"], minimum=512, maximum=8192, label="root outer ciphertext")
    _b64_bounded(rr["inner_ct_b64"], minimum=512, maximum=8192, label="root inner ciphertext")
    _b64_bounded(rr["transcript_b64"], minimum=32, maximum=65536, label="root transcript")

    rv = r["virtual"]
    if not isinstance(rv, dict) or rv.get("mode") not in {"standard","tetration","pentation"}:
        raise ValueError("root virtual mode malformed")
    mode = rv["mode"]
    if mode == "standard":
        _require_exact_keys(rv, {"mode","notation","steps","exact_within_cap","description"}, "root virtual plan")
        steps = _require_int(rv["steps"], minimum=0, maximum=10_000_000, label="root virtual steps")
        if rv["notation"] != str(steps):
            raise ValueError("standard root notation mismatch")
    else:
        _require_exact_keys(rv, {"mode","notation","base","height","steps","exact_within_cap","description"}, "root virtual plan")
        base_value = _require_int(rv["base"], minimum=2, maximum=2**31-1, label="root hyperoperation base")
        height = _require_int(rv["height"], minimum=1, maximum=64, label="root hyperoperation height")
        _require_int(rv["steps"], minimum=0, maximum=10_000_000, label="root virtual steps")
        expected_notation = f"{base_value}^^{height}" if mode == "tetration" else f"{base_value}^^^{height}"
        if rv["notation"] != expected_notation:
            raise ValueError("root hyperoperation notation mismatch")
    if rv["exact_within_cap"] is not True or not isinstance(rv["description"], str) or len(rv["description"]) > 512:
        raise ValueError("root virtual plan must be exact and bounded")

    rp = r["payload"]
    _require_exact_keys(rp, {"nonce_b64","ciphertext_b64","aad"}, "root payload")
    _b64_exact(rp["nonce_b64"], AEAD_NONCE_BYTES, "root payload nonce")
    _b64_exact(rp["ciphertext_b64"], ROOT_BINDING_BYTES + GCM_TAG_BYTES, "root payload ciphertext")
    ra = rp["aad"]
    _require_exact_keys(ra, {"domain","public_fingerprint","filename","plaintext_bytes","mode","notation","steps","base","height","virtual_context_sha256","final_key_id"}, "root payload AAD")
    if ra["domain"] != "ENTROPIC-TETRATION/ET-0.13/PAYLOAD/v1" or ra["public_fingerprint"] != r["public_fingerprint"]:
        raise ValueError("root payload AAD domain/fingerprint mismatch")
    if ra["filename"] != "root_binding.bin" or ra["plaintext_bytes"] != ROOT_BINDING_BYTES:
        raise ValueError("root payload binding-secret metadata mismatch")
    if (ra["mode"], ra["notation"], ra["steps"]) != (rv["mode"], rv["notation"], rv["steps"]):
        raise ValueError("root payload/virtual plan mismatch")
    if mode == "standard":
        if ra["base"] is not None or ra["height"] is not None:
            raise ValueError("standard root payload base/height must be null")
    else:
        if ra["base"] != rv["base"] or ra["height"] != rv["height"]:
            raise ValueError("root payload hyperoperation parameters mismatch")
    _require_fingerprint(ra["virtual_context_sha256"], "root virtual context hash")
    if not isinstance(ra["final_key_id"], str) or re.fullmatch(r"[0-9a-f]{24}", ra["final_key_id"]) is None:
        raise ValueError("root final-key identifier malformed")
    return rv


def _validate_chain_layer(c: dict) -> tuple[list[str], int]:
    _require_exact_keys(c, {"version","warning","layout","chain_id_hex","profile","chain_schedule","first_node","transitions"}, "chain layer")
    if c["version"] != chain.VERSION or c["warning"] != chain.WARNING or c["layout"] != "sequential encrypted transition envelopes":
        raise ValueError("chain metadata mismatch")
    _require_hex(c["chain_id_hex"], pattern=HEX32_RE, label="chain id")
    schedule = c["chain_schedule"]
    if not isinstance(schedule, list) or not schedule or any(not isinstance(item, str) for item in schedule):
        raise ValueError("chain schedule malformed")
    if len(schedule) % len(chain.FAMILIES):
        raise ValueError("chain schedule length is not a whole family cycle")
    cycles = len(schedule) // len(chain.FAMILIES)
    _require_int(cycles, minimum=1, maximum=MAX_CYCLES, label="chain cycles")
    if schedule != chain.chain_schedule(cycles):
        raise ValueError("non-canonical chain schedule")
    if c["profile"] != chain.public_profile(chain.Profile(), schedule):
        raise ValueError("chain profile mismatch")

    first = c["first_node"]
    _require_exact_keys(first, {"node_version","index","type","problem","salt_b64"}, "chain first node")
    if first["node_version"] != 1 or first["index"] != 1 or first["type"] != schedule[0]:
        raise ValueError("chain first-node metadata mismatch")
    _b64_exact(first["salt_b64"], 16, "chain first-node salt")
    problem = first["problem"]
    _require_exact_keys(problem, {"weights","target","selected_count"}, "subset-sum first-node problem")
    profile = chain.Profile()
    if problem["selected_count"] != profile.subset_selected or not isinstance(problem["weights"], list) or len(problem["weights"]) != profile.subset_items:
        raise ValueError("subset-sum first-node problem shape mismatch")
    if any(isinstance(v, bool) or not isinstance(v, int) or v <= 0 or v >= (1 << profile.subset_weight_bits) for v in problem["weights"]):
        raise ValueError("subset-sum weight outside permitted range")
    if isinstance(problem["target"], bool) or not isinstance(problem["target"], int) or problem["target"] <= 0:
        raise ValueError("subset-sum target malformed")

    transitions = c["transitions"]
    if not isinstance(transitions, dict) or set(transitions) != {str(i) for i in range(1, len(schedule) + 1)}:
        raise ValueError("transition index set mismatch")
    for i in range(1, len(schedule) + 1):
        envelope = transitions[str(i)]
        _require_exact_keys(envelope, {"nonce_b64","ciphertext_b64"}, f"chain transition {i}")
        _b64_exact(envelope["nonce_b64"], AEAD_NONCE_BYTES, f"chain transition {i} nonce")
        _b64_bounded(envelope["ciphertext_b64"], minimum=GCM_TAG_BYTES + 2, maximum=1024 * 1024, label=f"chain transition {i} ciphertext")
    return schedule, cycles


def _validate_capsule_structure(capsule: dict) -> None:
    _require_exact_keys(capsule, {"format","version","protocol","algorithms","root_engine","recipient_fingerprint","root_layer","guard_layer","chain","payload"}, "EFI capsule")
    if capsule["format"] != CAPSULE_FORMAT:
        raise ValueError("not an EFI 0.5 integrated capsule")
    if capsule["version"] != VERSION or capsule["protocol"] != PROTOCOL:
        raise ValueError("EFI version/protocol marker mismatch")
    _validate_algorithms(capsule["algorithms"])
    if capsule["root_engine"] != ROOT_ENGINE_VERSION:
        raise ValueError("root engine marker mismatch")
    recipient_fp = _require_fingerprint(capsule["recipient_fingerprint"], "recipient fingerprint")

    rv = _validate_root_layer(capsule["root_layer"])

    g = capsule["guard_layer"]
    _require_exact_keys(g, {"kem","kem_ciphertext_b64","aad"}, "guard layer")
    if g["kem"] != GUARD_KEM:
        raise ValueError("guard KEM mismatch")
    kem_ct = _b64_exact(g["kem_ciphertext_b64"], GUARD_KEM_CIPHERTEXT_BYTES, "guard KEM ciphertext")
    expected_guard_aad = _guard_aad(recipient_fp, kem_ct)
    _require_exact_keys(g["aad"], {"domain","recipient_fingerprint","kem","kem_ciphertext_sha256"}, "guard AAD")
    if g["aad"] != expected_guard_aad:
        raise ValueError("guard public binding mismatch")

    c = capsule["chain"]
    schedule, cycles = _validate_chain_layer(c)

    payload = capsule["payload"]
    _require_exact_keys(payload, {"nonce_b64","ciphertext_b64","aad"}, "payload")
    _b64_exact(payload["nonce_b64"], AEAD_NONCE_BYTES, "payload nonce")
    aad = payload["aad"]
    _require_exact_keys(aad, {"domain","filename","plaintext_bytes","cycles","stages","chain_id_hex","recipient_fingerprint","root_hyperoperation","guard_kem","core_commitment_sha256"}, "payload AAD")
    if aad["domain"] != PAYLOAD_DOMAIN:
        raise ValueError("payload domain mismatch")
    _validate_filename(aad["filename"])
    plaintext_bytes = _require_int(aad["plaintext_bytes"], minimum=0, maximum=MAX_PLAINTEXT_BYTES, label="payload plaintext bytes")
    if aad["cycles"] != cycles or aad["stages"] != len(schedule):
        raise ValueError("payload chain count mismatch")
    if aad["chain_id_hex"] != c["chain_id_hex"] or aad["recipient_fingerprint"] != recipient_fp:
        raise ValueError("payload chain/recipient binding mismatch")
    _require_exact_keys(aad["root_hyperoperation"], {"mode","notation","steps"}, "payload root hyperoperation")
    expected_root = {"mode": rv["mode"], "notation": rv["notation"], "steps": rv["steps"]}
    if aad["root_hyperoperation"] != expected_root:
        raise ValueError("payload/root mode mismatch")
    if aad["guard_kem"] != GUARD_KEM:
        raise ValueError("payload guard KEM mismatch")
    context = _core_commitment(_core_from_capsule(capsule))
    _require_fingerprint(aad["core_commitment_sha256"], "core commitment")
    if aad["core_commitment_sha256"] != context.hex():
        raise ValueError("core commitment mismatch")
    _b64_exact(payload["ciphertext_b64"], plaintext_bytes + GCM_TAG_BYTES, "payload ciphertext")


def encrypt_file(et013_dir: Path, public_path: Path, input_path: Path, output_path: Path, *, cycles: int = DEFAULT_CYCLES, root_mode: str = "tetration", base_value: int = 2, height: int = 4, standard_steps: int = 0) -> dict:
    cycles = _require_int(cycles, minimum=1, maximum=MAX_CYCLES, label="chain cycles")
    if root_mode not in {"standard","tetration","pentation"}:
        raise ValueError("root mode must be standard, tetration, or pentation")
    input_path = Path(input_path)
    if not input_path.is_file():
        raise FileNotFoundError(input_path)
    plaintext_bytes = input_path.stat().st_size
    _require_int(plaintext_bytes, minimum=0, maximum=MAX_PLAINTEXT_BYTES, label="plaintext bytes")
    filename = _validate_filename(input_path.name)

    engine = load_root_engine(et013_dir)
    mlkem = load_mlkem(et013_dir)
    public = load_public(public_path)
    started = time.perf_counter()
    schedule = chain.chain_schedule(cycles)
    profile = chain.Profile()
    guard_public = _b64_bounded(public["guard"]["public_key_pem_b64"], minimum=512, maximum=16384, label="guard public key")
    guard_block, _guard_ss, chain_secret = _guard_encapsulate(mlkem, guard_public, public["public_fingerprint"])
    root_binding_secret = secrets.token_bytes(ROOT_BINDING_BYTES)
    with tempfile.TemporaryDirectory(prefix="efi050_root_") as tdn:
        root_layer, root_encrypt = _root_protect_binding(
            engine, public["root_public_identity"], root_binding_secret, Path(tdn),
            root_mode=root_mode, base_value=base_value, height=height, standard_steps=standard_steps,
        )
    chain_capsule, terminal, chain_build = chain.build_chain(chain_secret, profile, schedule)
    core = {
        "format": CAPSULE_FORMAT,
        "version": VERSION,
        "protocol": PROTOCOL,
        "algorithms": ALGORITHM_SUITE,
        "root_engine": ROOT_ENGINE_VERSION,
        "recipient_fingerprint": public["public_fingerprint"],
        "root_layer": root_layer,
        "guard_layer": guard_block,
        "chain": chain_capsule,
    }
    context = _core_commitment(core)
    key = _final_key(chain_secret, terminal, root_binding_secret, context)
    plaintext = input_path.read_bytes()
    if len(plaintext) != plaintext_bytes:
        raise ValueError("input file changed during encryption")
    nonce = os.urandom(AEAD_NONCE_BYTES)
    rv = root_layer["virtual"]
    aad = {
        "domain": PAYLOAD_DOMAIN,
        "filename": filename,
        "plaintext_bytes": plaintext_bytes,
        "cycles": cycles,
        "stages": len(schedule),
        "chain_id_hex": chain_capsule["chain_id_hex"],
        "recipient_fingerprint": public["public_fingerprint"],
        "root_hyperoperation": {"mode": rv["mode"], "notation": rv["notation"], "steps": rv["steps"]},
        "guard_kem": GUARD_KEM,
        "core_commitment_sha256": context.hex(),
    }
    payload_ct = AESGCM(key).encrypt(nonce, plaintext, canonical(aad))
    capsule = dict(core)
    capsule["payload"] = {"nonce_b64": b64e(nonce), "ciphertext_b64": b64e(payload_ct), "aad": aad}
    _validate_capsule_structure(capsule)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(capsule, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return {
        "version": VERSION,
        "algorithm_suite": ALGORITHM_SUITE["suite"],
        "root_mode": rv["mode"],
        "root_notation": rv["notation"],
        "root_virtual_steps": rv["steps"],
        "cycles": cycles,
        "stages": len(schedule),
        "root_encrypt": root_encrypt,
        "chain_build": chain_build,
        "terminal_sha256": sha256_hex(terminal),
        "payload_sha256": sha256_hex(plaintext),
        "core_commitment_sha256": context.hex(),
        "capsule_bytes": output_path.stat().st_size,
        "total_seconds": time.perf_counter() - started,
        "dependency_design": "guard KEM derives chain_secret; frozen root protects independent root_binding_secret; final payload key requires chain_secret + terminal + root_binding_secret",
    }


def decrypt_file(et013_dir: Path, private_path: Path, password: str, input_path: Path, output_path: Path) -> dict:
    started = time.perf_counter()
    capsule = _read_json(input_path, max_bytes=MAX_CAPSULE_BYTES, label="EFI 0.5 capsule")
    _validate_capsule_structure(capsule)
    inner = open_private(private_path, password)
    if capsule["recipient_fingerprint"] != inner["public_fingerprint"]:
        raise ValueError("capsule/private identity mismatch")

    engine = load_root_engine(et013_dir)
    mlkem = load_mlkem(et013_dir)
    with tempfile.TemporaryDirectory(prefix="efi050_root_") as tdn:
        root_binding_secret, root_report = _root_recover_binding(
            engine, inner["root_private_vault"], password, capsule["root_layer"], Path(tdn)
        )
    guard_private = _b64_bounded(inner["guard_private_key_pem_b64"], minimum=512, maximum=16384, label="guard private key")
    chain_secret = _guard_decapsulate(mlkem, guard_private, capsule["guard_layer"], inner["public_fingerprint"])
    terminal, chain_report = chain.legitimate_traverse(capsule["chain"], chain_secret, chain.Profile())
    context = _core_commitment(_core_from_capsule(capsule))
    key = _final_key(chain_secret, terminal, root_binding_secret, context)
    payload = capsule["payload"]
    plaintext = AESGCM(key).decrypt(
        _b64_exact(payload["nonce_b64"], AEAD_NONCE_BYTES, "payload nonce"),
        b64d(payload["ciphertext_b64"]),
        canonical(payload["aad"]),
    )
    if len(plaintext) != payload["aad"]["plaintext_bytes"]:
        raise ValueError("plaintext length mismatch")
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(plaintext)
    return {
        "version": VERSION,
        "algorithm_suite": ALGORITHM_SUITE["suite"],
        "root_report": root_report,
        "chain_report": chain_report,
        "root_mode": capsule["root_layer"]["virtual"]["mode"],
        "root_virtual_steps": capsule["root_layer"]["virtual"]["steps"],
        "recovered_bytes": len(plaintext),
        "payload_sha256": sha256_hex(plaintext),
        "core_commitment_sha256": context.hex(),
        "total_seconds": time.perf_counter() - started,
    }


def capsule_metadata(path: Path) -> dict:
    c = _read_json(path, max_bytes=MAX_CAPSULE_BYTES, label="EFI 0.5 capsule")
    _validate_capsule_structure(c)
    aad = c["payload"]["aad"]
    return {
        "version": VERSION,
        "algorithm_suite": ALGORITHM_SUITE["suite"],
        "root_hyperoperation": aad["root_hyperoperation"],
        "guard_kem": GUARD_KEM,
        "filename": aad["filename"],
        "plaintext_bytes": aad["plaintext_bytes"],
        "cycles": aad["cycles"],
        "stages": aad["stages"],
        "core_commitment_sha256": aad["core_commitment_sha256"],
    }


def _password_from_file(path: Path|None) -> str:
    return getpass.getpass("Password: ") if path is None else Path(path).read_text(encoding="utf-8").rstrip("\r\n")

def main(argv=None):
    p=argparse.ArgumentParser(description=VERSION); p.add_argument("--et013-dir",type=Path,required=True); s=p.add_subparsers(dest="cmd",required=True)
    q=s.add_parser("identity"); q.add_argument("--public",type=Path,required=True); q.add_argument("--private",type=Path,required=True); q.add_argument("--password-file",type=Path); q.add_argument("--seed",type=int)
    q=s.add_parser("encrypt"); q.add_argument("--public",type=Path,required=True); q.add_argument("--input",type=Path,required=True); q.add_argument("--output",type=Path,required=True); q.add_argument("--cycles",type=int,default=DEFAULT_CYCLES); q.add_argument("--root-mode",choices=("standard","tetration","pentation"),default="tetration"); q.add_argument("--base",type=int,default=2); q.add_argument("--height",type=int,default=4); q.add_argument("--standard-steps",type=int,default=0)
    q=s.add_parser("decrypt"); q.add_argument("--private",type=Path,required=True); q.add_argument("--password-file",type=Path); q.add_argument("--input",type=Path,required=True); q.add_argument("--output",type=Path,required=True)
    q=s.add_parser("inspect"); q.add_argument("--input",type=Path,required=True)
    a=p.parse_args(argv)
    if a.cmd=="identity": r=generate_identity(a.et013_dir,a.public,a.private,_password_from_file(a.password_file),a.seed)
    elif a.cmd=="encrypt": r=encrypt_file(a.et013_dir,a.public,a.input,a.output,cycles=a.cycles,root_mode=a.root_mode,base_value=a.base,height=a.height,standard_steps=a.standard_steps)
    elif a.cmd=="decrypt": r=decrypt_file(a.et013_dir,a.private,_password_from_file(a.password_file),a.input,a.output)
    else: r=capsule_metadata(a.input)
    print(json.dumps(r,indent=2)); return 0

if __name__=="__main__": raise SystemExit(main())
