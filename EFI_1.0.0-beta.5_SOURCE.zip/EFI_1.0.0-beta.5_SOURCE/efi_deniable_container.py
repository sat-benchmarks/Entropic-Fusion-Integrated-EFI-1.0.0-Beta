#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import tempfile
import time
from pathlib import Path
from typing import Callable

from argon2.low_level import Type, hash_secret_raw
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

import entropic_fusion_integrated_efi_0_5_0 as backend
import efi_private_envelope as privacy

VERSION = "EFI deniable dual-profile wrapper 1"
MAGIC = b"EFIPRIV4"
FORMAT_VERSION = 4
FLAGS = 0
HEADER_LEN = 20  # magic(8), version(1), flags(1), KEM length(2), slot payload bytes(8)
SLOT_COUNT = 2
SLOT_FRAME_MAGIC = b"EFISLOT1"
SLOT_FRAME_BYTES = 256
DURESS_RECORD_BYTES = 128
DURESS_SALT_BYTES = 16
DURESS_NONCE_BYTES = 12
DURESS_PLAINTEXT_BYTES = DURESS_RECORD_BYTES - DURESS_SALT_BYTES - DURESS_NONCE_BYTES - 16
DURESS_MAGIC = b"EFI-DURESS-ACTION-1\x00"
SLOT_SALT_BYTES = 16
SLOT_IV_BYTES = 16
SLOT_MAC_BYTES = 32
SLOT_QUANTUM_BYTES = 2 * 1024 * 1024
MIN_SLOT_PAYLOAD_BYTES = 10 * 1024 * 1024
MAX_SLOT_PAYLOAD_BYTES = (1 << 63) - 1

PROFILE_ARGON_MEMORY_KIB = 64 * 1024
PROFILE_ARGON_TIME_COST = 3
PROFILE_ARGON_PARALLELISM = 1
PROFILE_ARGON_HASH_BYTES = 32
MIN_PROFILE_PASSPHRASE = 12

SLOT_KEY_DOMAIN = b"ENTROPIC-FUSION/EFI-DENIABLE-SLOT/v1"
SLOT_MAC_DOMAIN = b"ENTROPIC-FUSION/EFI-DENIABLE-SLOT/MAC/v1"
DURESS_KEY_DOMAIN = b"ENTROPIC-FUSION/EFI-DURESS/v1"

ProgressCallback = Callable[[str, int, int], None]


class DeniableContainerError(ValueError):
    pass


def _cancelled(cancel_event) -> bool:
    return bool(cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)())


def _check_cancel(cancel_event) -> None:
    if _cancelled(cancel_event):
        raise DeniableContainerError("operation cancelled")


def _emit(progress: ProgressCallback | None, phase: str, done: int, total: int) -> None:
    if progress is not None:
        progress(phase, int(done), int(total))


def _ceil_multiple(value: int, quantum: int) -> int:
    return ((value + quantum - 1) // quantum) * quantum


def _header(kem_len: int, slot_payload_bytes: int) -> bytes:
    if kem_len <= 0 or kem_len > 65535:
        raise DeniableContainerError("invalid KEM ciphertext length")
    if slot_payload_bytes < MIN_SLOT_PAYLOAD_BYTES or slot_payload_bytes % SLOT_QUANTUM_BYTES:
        raise DeniableContainerError("invalid deniable slot capacity")
    return MAGIC + bytes((FORMAT_VERSION, FLAGS)) + kem_len.to_bytes(2, "big") + slot_payload_bytes.to_bytes(8, "big")


def _parse_header(raw: bytes) -> tuple[int, int]:
    if len(raw) != HEADER_LEN or raw[:8] != MAGIC:
        raise DeniableContainerError("not an EFIPRIV4 deniable container")
    if raw[8] != FORMAT_VERSION or raw[9] != FLAGS:
        raise DeniableContainerError("unsupported EFIPRIV4 version or flags")
    kem_len = int.from_bytes(raw[10:12], "big")
    slot_payload = int.from_bytes(raw[12:20], "big")
    if kem_len != backend.GUARD_KEM_CIPHERTEXT_BYTES:
        raise DeniableContainerError("EFIPRIV4 KEM length mismatch")
    if slot_payload < MIN_SLOT_PAYLOAD_BYTES or slot_payload % SLOT_QUANTUM_BYTES:
        raise DeniableContainerError("EFIPRIV4 slot geometry mismatch")
    return kem_len, slot_payload


def _slot_total_bytes(kem_len: int, slot_payload_bytes: int) -> int:
    return kem_len + SLOT_SALT_BYTES + SLOT_IV_BYTES + slot_payload_bytes + SLOT_MAC_BYTES


def _slot_offset(index: int, kem_len: int, slot_payload_bytes: int) -> int:
    if index not in (0, 1):
        raise DeniableContainerError("invalid deniable slot index")
    return HEADER_LEN + index * _slot_total_bytes(kem_len, slot_payload_bytes)


def _slot_payload_for_inners(*inner_sizes: int) -> int:
    required = SLOT_FRAME_BYTES + max(int(x) for x in inner_sizes)
    if required > MAX_SLOT_PAYLOAD_BYTES:
        raise DeniableContainerError("inner EFI capsule is too large for deniable slot")
    return max(MIN_SLOT_PAYLOAD_BYTES, _ceil_multiple(required, SLOT_QUANTUM_BYTES))


def minimum_slot_payload_for_source(source_bytes: int) -> int:
    """Return the minimum EFIPRIV4 slot payload needed for one source file.

    This is deterministic from the EFIPRIV3 size policy and can be used to
    choose reserve capacity before creating a hidden profile.
    """
    inner_est = privacy.estimate_size(int(source_bytes))["visible_outer_bytes"]
    return _slot_payload_for_inners(inner_est)


def normalize_reserve_bytes(reserve_bytes: int | None, *, decoy_source_bytes: int) -> int:
    minimum = minimum_slot_payload_for_source(decoy_source_bytes)
    if reserve_bytes is None:
        return minimum
    if not isinstance(reserve_bytes, int) or isinstance(reserve_bytes, bool) or reserve_bytes <= 0:
        raise DeniableContainerError("reserve capacity must be a positive byte count")
    rounded = max(MIN_SLOT_PAYLOAD_BYTES, _ceil_multiple(reserve_bytes, SLOT_QUANTUM_BYTES))
    if rounded < minimum:
        raise DeniableContainerError("selected reserve capacity is too small for the decoy profile")
    if rounded > MAX_SLOT_PAYLOAD_BYTES:
        raise DeniableContainerError("selected reserve capacity is too large")
    return rounded


def estimate_size_from_inner(inner_bytes: int, hidden_inner_bytes: int | None = None) -> dict:
    hidden = inner_bytes if hidden_inner_bytes is None else hidden_inner_bytes
    slot_payload = _slot_payload_for_inners(inner_bytes, hidden)
    kem_len = backend.GUARD_KEM_CIPHERTEXT_BYTES
    slot_total = _slot_total_bytes(kem_len, slot_payload)
    return {
        "slot_payload_bytes": slot_payload,
        "slot_total_bytes": slot_total,
        "reserve_selected_explicitly": reserve_bytes is not None,
        "reserve_policy": "public slot capacity is chosen from decoy minimum or explicit reserve; hidden content never silently enlarges it",
        "visible_outer_bytes": HEADER_LEN + SLOT_COUNT * slot_total,
        "slots": SLOT_COUNT,
        "reserve_policy": "two equal opaque slots; second is random cover when unused",
    }


def _profile_component(passphrase: str, salt: bytes) -> bytes:
    if len(salt) != SLOT_SALT_BYTES:
        raise DeniableContainerError("invalid profile salt")
    if not isinstance(passphrase, str) or len(passphrase) < MIN_PROFILE_PASSPHRASE:
        raise DeniableContainerError(f"hidden/duress passphrase must be at least {MIN_PROFILE_PASSPHRASE} characters")
    return hash_secret_raw(
        secret=passphrase.encode("utf-8"),
        salt=salt,
        time_cost=PROFILE_ARGON_TIME_COST,
        memory_cost=PROFILE_ARGON_MEMORY_KIB,
        parallelism=PROFILE_ARGON_PARALLELISM,
        hash_len=PROFILE_ARGON_HASH_BYTES,
        type=Type.ID,
    )


def _derive_slot_keys(shared_secret: bytes, kem_ct: bytes, header: bytes, index: int,
                      salt: bytes, profile_component: bytes | None) -> tuple[bytes, bytes]:
    if len(shared_secret) != backend.GUARD_SHARED_SECRET_BYTES:
        raise DeniableContainerError("unexpected ML-KEM shared-secret length")
    extra = profile_component if profile_component is not None else b"\x00" * PROFILE_ARGON_HASH_BYTES
    ikm = shared_secret + extra
    info = SLOT_KEY_DOMAIN + bytes((index,)) + hashlib.sha256(header + kem_ct + salt).digest()
    material = HKDF(
        algorithm=hashes.SHA256(),
        length=64,
        salt=hashlib.sha256(kem_ct + salt).digest(),
        info=info,
    ).derive(ikm)
    return material[:32], material[32:]


def _slot_mac(mac_key: bytes, header: bytes, index: int, kem_ct: bytes, salt: bytes, iv: bytes,
              ciphertext_path: Path | None = None, ciphertext_bytes: bytes | None = None) -> bytes:
    hm = hmac.new(mac_key, digestmod=hashlib.sha256)
    hm.update(SLOT_MAC_DOMAIN + b"\x00" + header + bytes((index,)) + kem_ct + salt + iv)
    if ciphertext_bytes is not None:
        hm.update(ciphertext_bytes)
    elif ciphertext_path is not None:
        with Path(ciphertext_path).open("rb") as f:
            while True:
                chunk = f.read(4 * 1024 * 1024)
                if not chunk:
                    break
                hm.update(chunk)
    else:
        raise DeniableContainerError("slot MAC requires ciphertext")
    return hm.digest()


def _duress_record(passphrase: str | None) -> bytes:
    if not passphrase:
        return secrets.token_bytes(DURESS_RECORD_BYTES)
    if len(passphrase) < MIN_PROFILE_PASSPHRASE:
        raise DeniableContainerError(f"duress passphrase must be at least {MIN_PROFILE_PASSPHRASE} characters")
    salt = secrets.token_bytes(DURESS_SALT_BYTES)
    nonce = secrets.token_bytes(DURESS_NONCE_BYTES)
    raw = hash_secret_raw(
        secret=passphrase.encode("utf-8"), salt=salt,
        time_cost=PROFILE_ARGON_TIME_COST, memory_cost=PROFILE_ARGON_MEMORY_KIB,
        parallelism=PROFILE_ARGON_PARALLELISM, hash_len=32, type=Type.ID,
    )
    key = HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=DURESS_KEY_DOMAIN).derive(raw)
    filler = secrets.token_bytes(DURESS_PLAINTEXT_BYTES - len(DURESS_MAGIC))
    ct = AESGCM(key).encrypt(nonce, DURESS_MAGIC + filler, DURESS_KEY_DOMAIN)
    if len(ct) != DURESS_RECORD_BYTES - DURESS_SALT_BYTES - DURESS_NONCE_BYTES:
        raise DeniableContainerError("internal duress record length failure")
    return salt + nonce + ct


def _duress_matches(record: bytes, passphrase: str) -> bool:
    if len(record) != DURESS_RECORD_BYTES or not passphrase or len(passphrase) < MIN_PROFILE_PASSPHRASE:
        return False
    salt = record[:DURESS_SALT_BYTES]
    nonce = record[DURESS_SALT_BYTES:DURESS_SALT_BYTES + DURESS_NONCE_BYTES]
    ct = record[DURESS_SALT_BYTES + DURESS_NONCE_BYTES:]
    try:
        raw = hash_secret_raw(
            secret=passphrase.encode("utf-8"), salt=salt,
            time_cost=PROFILE_ARGON_TIME_COST, memory_cost=PROFILE_ARGON_MEMORY_KIB,
            parallelism=PROFILE_ARGON_PARALLELISM, hash_len=32, type=Type.ID,
        )
        key = HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=DURESS_KEY_DOMAIN).derive(raw)
        plain = AESGCM(key).decrypt(nonce, ct, DURESS_KEY_DOMAIN)
        return plain.startswith(DURESS_MAGIC) and len(plain) == DURESS_PLAINTEXT_BYTES
    except Exception:
        return False


def _make_slot_plain(inner_path: Path, slot_payload_bytes: int, duress_record: bytes) -> Path:
    inner_path = Path(inner_path)
    inner_len = inner_path.stat().st_size
    if len(duress_record) != DURESS_RECORD_BYTES:
        raise DeniableContainerError("invalid duress record")
    if SLOT_FRAME_BYTES + inner_len > slot_payload_bytes:
        raise DeniableContainerError("inner EFI capsule exceeds deniable slot capacity")
    fd, tmp_name = tempfile.mkstemp(prefix="efi_slot_plain_", suffix=".bin")
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        with tmp.open("wb") as out, inner_path.open("rb") as src:
            frame = bytearray(SLOT_FRAME_BYTES)
            frame[:len(SLOT_FRAME_MAGIC)] = SLOT_FRAME_MAGIC
            frame[8:16] = inner_len.to_bytes(8, "big")
            frame[16:16 + DURESS_RECORD_BYTES] = duress_record
            frame[16 + DURESS_RECORD_BYTES:] = secrets.token_bytes(SLOT_FRAME_BYTES - 16 - DURESS_RECORD_BYTES)
            out.write(frame)
            while True:
                chunk = src.read(4 * 1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
            remaining = slot_payload_bytes - SLOT_FRAME_BYTES - inner_len
            zero = b"\x00" * min(4 * 1024 * 1024, max(1, remaining))
            while remaining:
                take = min(remaining, len(zero))
                out.write(zero[:take])
                remaining -= take
        return tmp
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def _encrypt_slot_to_file(*, header: bytes, index: int, slot_plain: Path, public_path: Path,
                          et013_dir: Path, out, hidden_passphrase: str | None,
                          progress: ProgressCallback | None, cancel_event) -> dict:
    public = backend.load_public(public_path)
    guard_public = backend._b64_bounded(
        public["guard"]["public_key_pem_b64"], minimum=512, maximum=16384, label="guard public key"
    )
    mlkem = backend.load_mlkem(et013_dir)
    kem_ct, shared_secret = mlkem.encapsulate_bytes(guard_public, backend.GUARD_KEM)
    salt = secrets.token_bytes(SLOT_SALT_BYTES)
    component = _profile_component(hidden_passphrase, salt) if hidden_passphrase is not None else None
    enc_key, mac_key = _derive_slot_keys(shared_secret, kem_ct, header, index, salt, component)
    iv = secrets.token_bytes(SLOT_IV_BYTES)
    encryptor = Cipher(algorithms.AES(enc_key), modes.CTR(iv)).encryptor()
    hm = hmac.new(mac_key, digestmod=hashlib.sha256)
    hm.update(SLOT_MAC_DOMAIN + b"\x00" + header + bytes((index,)) + kem_ct + salt + iv)
    out.write(kem_ct); out.write(salt); out.write(iv)
    total = Path(slot_plain).stat().st_size
    done = 0
    with Path(slot_plain).open("rb") as src:
        while True:
            _check_cancel(cancel_event)
            chunk = src.read(4 * 1024 * 1024)
            if not chunk:
                break
            ct = encryptor.update(chunk)
            out.write(ct); hm.update(ct); done += len(chunk)
            _emit(progress, "Writing deniable slots", done, total)
    tail = encryptor.finalize()
    if tail:
        out.write(tail); hm.update(tail)
    out.write(hm.digest())
    return {"kem_ct_bytes": len(kem_ct), "slot_payload_bytes": total}


def _write_random_slot(out, slot_total_bytes: int, *, progress: ProgressCallback | None, cancel_event) -> None:
    remaining = slot_total_bytes
    done = 0
    while remaining:
        _check_cancel(cancel_event)
        take = min(4 * 1024 * 1024, remaining)
        out.write(os.urandom(take))
        remaining -= take; done += take
        _emit(progress, "Writing opaque reserve", done, slot_total_bytes)


def create_container(
    et013_dir: Path,
    public_path: Path,
    decoy_path: Path,
    output_path: Path,
    *,
    hidden_path: Path | None = None,
    hidden_passphrase: str | None = None,
    duress_passphrase: str | None = None,
    reserve_bytes: int | None = None,
    cycles: int = backend.DEFAULT_CYCLES,
    root_mode: str = "tetration",
    base_value: int = 2,
    height: int = 4,
    standard_steps: int = 0,
    progress: ProgressCallback | None = None,
    cancel_event=None,
) -> dict:
    """Create an EFIPRIV4 two-slot container.

    Slot 0 always contains a complete EFIPRIV3 decoy capsule. Slot 1 is either
    a passphrase-gated EFIPRIV3 hidden capsule or random cover occupying the
    exact same public geometry. A configured duress record is stored only
    inside slot 0's encrypted plaintext frame and is random-looking when not
    configured.
    """
    started = time.perf_counter()
    et013_dir = Path(et013_dir); public_path = Path(public_path); decoy_path = Path(decoy_path); output_path = Path(output_path)
    hidden_path = Path(hidden_path) if hidden_path else None
    if output_path.exists():
        raise FileExistsError("refusing to overwrite an existing deniable container")
    if not decoy_path.is_file():
        raise FileNotFoundError(decoy_path)
    if hidden_path is not None and not hidden_path.is_file():
        raise FileNotFoundError(hidden_path)
    if hidden_path is not None:
        if not hidden_passphrase or len(hidden_passphrase) < MIN_PROFILE_PASSPHRASE:
            raise DeniableContainerError(f"hidden profile requires a passphrase of at least {MIN_PROFILE_PASSPHRASE} characters")
    elif hidden_passphrase:
        raise DeniableContainerError("hidden passphrase was supplied without a hidden file")
    if duress_passphrase and len(duress_passphrase) < MIN_PROFILE_PASSPHRASE:
        raise DeniableContainerError(f"duress passphrase must be at least {MIN_PROFILE_PASSPHRASE} characters")
    if hidden_passphrase and duress_passphrase and hmac.compare_digest(hidden_passphrase, duress_passphrase):
        raise DeniableContainerError("hidden and duress passphrases must be different")

    slot_payload = normalize_reserve_bytes(reserve_bytes, decoy_source_bytes=decoy_path.stat().st_size)
    if hidden_path is not None:
        hidden_min = minimum_slot_payload_for_source(hidden_path.stat().st_size)
        if hidden_min > slot_payload:
            raise DeniableContainerError(
                f"hidden profile needs at least {hidden_min // (1024*1024)} MiB per slot; "
                "choose a larger reserve capacity. EFI will not silently enlarge a deniable container based on hidden content."
            )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="efi010_dual_build_") as td_raw:
        td = Path(td_raw)
        decoy_inner = td / "decoy.efi"
        hidden_inner = td / "hidden.efi"
        _emit(progress, "Building decoy EFI profile", 0, 1)
        decoy_report = privacy.encrypt_file(
            et013_dir, public_path, decoy_path, decoy_inner,
            cycles=cycles, root_mode=root_mode, base_value=base_value,
            height=height, standard_steps=standard_steps, cancel_event=cancel_event,
        )
        _emit(progress, "Building decoy EFI profile", 1, 1)
        hidden_report = None
        if hidden_path is not None:
            _emit(progress, "Building hidden EFI profile", 0, 1)
            hidden_report = privacy.encrypt_file(
                et013_dir, public_path, hidden_path, hidden_inner,
                cycles=cycles, root_mode=root_mode, base_value=base_value,
                height=height, standard_steps=standard_steps, cancel_event=cancel_event,
            )
            _emit(progress, "Building hidden EFI profile", 1, 1)

        # slot_payload was selected before hidden encryption. Hidden content is
        # never allowed to silently enlarge public geometry. The user may pick
        # a larger reserve even for a cover-only container.
        if SLOT_FRAME_BYTES + decoy_inner.stat().st_size > slot_payload:
            raise DeniableContainerError("decoy inner capsule exceeded preflight reserve estimate")
        if hidden_path is not None and SLOT_FRAME_BYTES + hidden_inner.stat().st_size > slot_payload:
            raise DeniableContainerError("hidden inner capsule exceeded selected reserve capacity")
        header = _header(backend.GUARD_KEM_CIPHERTEXT_BYTES, slot_payload)
        slot_total = _slot_total_bytes(backend.GUARD_KEM_CIPHERTEXT_BYTES, slot_payload)
        decoy_plain = _make_slot_plain(decoy_inner, slot_payload, _duress_record(duress_passphrase))
        hidden_plain = None
        if hidden_path is not None:
            hidden_plain = _make_slot_plain(hidden_inner, slot_payload, secrets.token_bytes(DURESS_RECORD_BYTES))
        try:
            with output_path.open("wb") as out:
                out.write(header)
                _encrypt_slot_to_file(
                    header=header, index=0, slot_plain=decoy_plain, public_path=public_path,
                    et013_dir=et013_dir, out=out, hidden_passphrase=None,
                    progress=progress, cancel_event=cancel_event,
                )
                if hidden_plain is not None:
                    _encrypt_slot_to_file(
                        header=header, index=1, slot_plain=hidden_plain, public_path=public_path,
                        et013_dir=et013_dir, out=out, hidden_passphrase=hidden_passphrase,
                        progress=progress, cancel_event=cancel_event,
                    )
                else:
                    _write_random_slot(out, slot_total, progress=progress, cancel_event=cancel_event)
                out.flush()
            expected = HEADER_LEN + 2 * slot_total
            if output_path.stat().st_size != expected:
                raise DeniableContainerError("deniable container size mismatch")
        except Exception:
            output_path.unlink(missing_ok=True)
            raise
        finally:
            decoy_plain.unlink(missing_ok=True)
            if hidden_plain is not None:
                hidden_plain.unlink(missing_ok=True)

    return {
        "version": VERSION,
        "envelope_format": "EFIPRIV4",
        "metadata_privacy": "PROTECTED",
        "plausible_deniability": "two equal opaque slots; hidden presence is not encoded in public framing",
        "hidden_profile_configured": hidden_path is not None,
        "duress_profile_configured": bool(duress_passphrase),
        "slot_payload_bytes": slot_payload,
        "slot_total_bytes": slot_total,
        "reserve_selected_explicitly": reserve_bytes is not None,
        "reserve_policy": "public slot capacity is chosen from decoy minimum or explicit reserve; hidden content never silently enlarges it",
        "capsule_bytes": output_path.stat().st_size,
        "decoy_source_bytes": decoy_path.stat().st_size,
        "hidden_source_bytes": hidden_path.stat().st_size if hidden_path is not None else None,
        "inner_decoy_capsule_bytes": decoy_report.get("capsule_bytes"),
        "inner_hidden_capsule_bytes": hidden_report.get("capsule_bytes") if hidden_report else None,
        "outer_seconds": time.perf_counter() - started,
        "duress_scope": "current container copy only; backups, snapshots, journals and prior copies are outside the erasure guarantee",
    }


def _read_geometry(path: Path) -> tuple[bytes, int, int]:
    path = Path(path)
    size = path.stat().st_size
    with path.open("rb") as f:
        header = f.read(HEADER_LEN)
    kem_len, slot_payload = _parse_header(header)
    slot_total = _slot_total_bytes(kem_len, slot_payload)
    if size != HEADER_LEN + 2 * slot_total:
        raise DeniableContainerError("EFIPRIV4 file geometry is invalid")
    return header, kem_len, slot_payload


def public_inspect(path: Path) -> dict:
    header, kem_len, slot_payload = _read_geometry(Path(path))
    slot_total = _slot_total_bytes(kem_len, slot_payload)
    return {
        "container": "EFI opaque dual-profile-capable envelope",
        "format_version": FORMAT_VERSION,
        "metadata_privacy": "PROTECTED",
        "visible_outer_bytes": Path(path).stat().st_size,
        "visible_slot_payload_bytes": slot_payload,
        "visible_slot_count": SLOT_COUNT,
        "plausible_deniability": "The second fixed slot is always present. Public bytes do not state whether it contains random cover, an active hidden profile, or a previously destroyed hidden profile.",
        "note": "EFIPRIV4 reveals that the container supports a fixed opaque reserve. It does not encode hidden-profile existence, original filenames, exact source lengths, recipient fingerprints, Entropic mode or chain profile in readable form.",
    }


def is_deniable_container(path: Path) -> bool:
    try:
        with Path(path).open("rb") as f:
            return f.read(8) == MAGIC
    except OSError:
        return False


def _load_private_guard(et013_dir: Path, private_path: Path, identity_password: str):
    private_obj = backend.open_private(private_path, identity_password)
    guard_private = backend._b64_bounded(
        private_obj["guard_private_key_pem_b64"], minimum=512, maximum=16384, label="guard private key"
    )
    return private_obj, guard_private, backend.load_mlkem(et013_dir)


def _read_slot_parts(path: Path, index: int) -> tuple[bytes, bytes, bytes, bytes, bytes, int, bytes]:
    header, kem_len, slot_payload = _read_geometry(path)
    offset = _slot_offset(index, kem_len, slot_payload)
    with Path(path).open("rb") as f:
        f.seek(offset)
        kem_ct = f.read(kem_len)
        salt = f.read(SLOT_SALT_BYTES)
        iv = f.read(SLOT_IV_BYTES)
        ciphertext = f.read(slot_payload)
        mac = f.read(SLOT_MAC_BYTES)
    if len(kem_ct) != kem_len or len(salt) != SLOT_SALT_BYTES or len(iv) != SLOT_IV_BYTES or len(ciphertext) != slot_payload or len(mac) != SLOT_MAC_BYTES:
        raise DeniableContainerError("deniable slot is truncated")
    return header, kem_ct, salt, iv, ciphertext, slot_payload, mac


def _unwrap_slot_to_inner(et013_dir: Path, private_path: Path, identity_password: str,
                          input_path: Path, index: int, inner_path: Path,
                          profile_passphrase: str | None) -> tuple[bytes, dict]:
    header, kem_ct, salt, iv, ciphertext, slot_payload, mac = _read_slot_parts(input_path, index)
    _private, guard_private, mlkem = _load_private_guard(et013_dir, private_path, identity_password)
    shared_secret = mlkem.decapsulate_bytes(guard_private, kem_ct, backend.GUARD_KEM)
    component = None
    if index == 1:
        if not profile_passphrase or len(profile_passphrase) < MIN_PROFILE_PASSPHRASE:
            raise DeniableContainerError("profile credential did not open a valid hidden profile")
        component = _profile_component(profile_passphrase, salt)
    enc_key, mac_key = _derive_slot_keys(shared_secret, kem_ct, header, index, salt, component)
    expected = _slot_mac(mac_key, header, index, kem_ct, salt, iv, ciphertext_bytes=ciphertext)
    if not hmac.compare_digest(expected, mac):
        raise DeniableContainerError("profile credential did not open a valid hidden profile" if index == 1 else "decoy slot authentication failed")
    decryptor = Cipher(algorithms.AES(enc_key), modes.CTR(iv)).decryptor()
    plain = decryptor.update(ciphertext) + decryptor.finalize()
    if len(plain) != slot_payload or plain[:8] != SLOT_FRAME_MAGIC:
        raise DeniableContainerError("deniable slot frame is invalid")
    inner_len = int.from_bytes(plain[8:16], "big")
    if inner_len <= 0 or SLOT_FRAME_BYTES + inner_len > slot_payload:
        raise DeniableContainerError("deniable slot inner length is invalid")
    duress_record = plain[16:16 + DURESS_RECORD_BYTES]
    inner = plain[SLOT_FRAME_BYTES:SLOT_FRAME_BYTES + inner_len]
    if not inner.startswith(privacy.MAGIC):
        raise DeniableContainerError("deniable slot does not contain an EFIPRIV3 profile")
    inner_path.write_bytes(inner)
    return duress_record, {"slot_payload_bytes": slot_payload, "inner_capsule_bytes": inner_len}


def _destroy_hidden_slot_key_material(path: Path) -> dict:
    """Cryptographically erase the live hidden slot without rewriting its payload.

    The KEM ciphertext, profile salt, CTR IV and MAC are replaced. The masked
    hidden payload is left in place. Without the original KEM ciphertext and
    salt the wrapper key cannot be reconstructed from this container copy.
    Historical copies, filesystem snapshots, SSD remanence and cloud versions
    are explicitly outside this guarantee.
    """
    header, kem_len, slot_payload = _read_geometry(path)
    offset = _slot_offset(1, kem_len, slot_payload)
    mac_offset = offset + kem_len + SLOT_SALT_BYTES + SLOT_IV_BYTES + slot_payload
    with Path(path).open("r+b") as f:
        f.seek(offset)
        f.write(os.urandom(kem_len + SLOT_SALT_BYTES + SLOT_IV_BYTES))
        f.seek(mac_offset)
        f.write(os.urandom(SLOT_MAC_BYTES))
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:
            pass
    return {
        "hidden_recovery_material_replaced": True,
        "bytes_replaced": kem_len + SLOT_SALT_BYTES + SLOT_IV_BYTES + SLOT_MAC_BYTES,
        "payload_ciphertext_rewritten": False,
    }


def open_container(
    et013_dir: Path,
    private_path: Path,
    identity_password: str,
    input_path: Path,
    destination_dir: Path,
    *,
    profile_passphrase: str | None = None,
    explicit_output: Path | None = None,
    progress: ProgressCallback | None = None,
    cancel_event=None,
) -> dict:
    """Open decoy, hidden, or duress path.

    Blank profile_passphrase opens the decoy. A nonblank passphrase is first
    checked against the fixed duress record inside the authenticated decoy
    slot. If it matches, the hidden slot's live recovery material is replaced
    and the decoy is opened. Otherwise the same passphrase is attempted as the
    hidden-slot credential. Wrong credentials fail generically and never erase.
    """
    started = time.perf_counter()
    et013_dir = Path(et013_dir); private_path = Path(private_path); input_path = Path(input_path); destination_dir = Path(destination_dir)
    _check_cancel(cancel_event)
    with tempfile.TemporaryDirectory(prefix="efi010_dual_open_") as td_raw:
        td = Path(td_raw)
        decoy_inner = td / "decoy-inner.efi"
        duress_record, decoy_slot_meta = _unwrap_slot_to_inner(
            et013_dir, private_path, identity_password, input_path, 0, decoy_inner, None
        )
        selected = "decoy"
        inner_path = decoy_inner
        erasure = None
        if profile_passphrase:
            if _duress_matches(duress_record, profile_passphrase):
                erasure = _destroy_hidden_slot_key_material(input_path)
                selected = "decoy"
                inner_path = decoy_inner
            else:
                hidden_inner = td / "hidden-inner.efi"
                try:
                    _unwrap_slot_to_inner(
                        et013_dir, private_path, identity_password, input_path, 1,
                        hidden_inner, profile_passphrase,
                    )
                except Exception as exc:
                    raise DeniableContainerError("profile credential did not open a valid profile") from exc
                selected = "hidden"
                inner_path = hidden_inner

        _emit(progress, "Opening selected EFI profile", 0, 1)
        result = privacy.decrypt_file(
            et013_dir, private_path, identity_password, inner_path, destination_dir,
            explicit_output=explicit_output, cancel_event=cancel_event,
        )
        _emit(progress, "Opening selected EFI profile", 1, 1)

    out = dict(result)
    out.update({
        "deniable_container": True,
        "envelope_format": "EFIPRIV4",
        "selected_profile": selected,
        "metadata_privacy": "PROTECTED",
        "plausible_deniability": "second slot existence is invariant",
        "total_private_workflow_seconds": time.perf_counter() - started,
    })
    if erasure is not None:
        # Intentionally not worded as a user-facing alert. The GUI may suppress
        # these fields entirely on the duress path. They remain available to the
        # regression harness and API callers for verification.
        out["duress_action_performed"] = True
        out["duress_erasure"] = erasure
    else:
        out["duress_action_performed"] = False
    return out


def deniable_regression_probe(et013_dir: Path) -> dict:
    identity_password = "EFI010-Identity-Password"
    hidden_passphrase = "Hidden-Profile-Password-010"
    duress_passphrase = "Duress-Profile-Password-010"
    decoy_name = "Holiday-Recipes.txt"
    hidden_name = "Acquisition-Strategy-SECRET.docx"
    decoy_payload = (b"harmless decoy material\n" + bytes(range(64))) * 2500
    hidden_payload = (b"hidden profile material\n" + bytes(range(128))) * 42000
    with tempfile.TemporaryDirectory(prefix="efi010_deniable_probe_") as td_raw:
        td = Path(td_raw)
        pub = td / "recipient.public.json"; prv = td / "recipient.private.json"
        decoy = td / decoy_name; hidden = td / hidden_name
        decoy.write_bytes(decoy_payload); hidden.write_bytes(hidden_payload)
        backend.generate_identity(Path(et013_dir), pub, prv, identity_password)

        cap = td / "EFI-probe.efi"
        reserve = max(minimum_slot_payload_for_source(len(decoy_payload)), minimum_slot_payload_for_source(len(hidden_payload)))
        report = create_container(
            Path(et013_dir), pub, decoy, cap, hidden_path=hidden,
            hidden_passphrase=hidden_passphrase, duress_passphrase=duress_passphrase, reserve_bytes=reserve,
            cycles=1, root_mode="standard", base_value=2, height=4, standard_steps=4,
        )
        public_before = public_inspect(cap)
        raw_head = cap.read_bytes()[:1024 * 1024]
        forbidden = [decoy_name, hidden_name, ".docx", "hidden_profile_configured", "duress_profile_configured", "EFI-DURESS-ACTION-1"]
        leaks = [x for x in forbidden if x.encode("utf-8") in raw_head]

        out_decoy = td / "out-decoy"; out_hidden = td / "out-hidden"
        dec = open_container(Path(et013_dir), prv, identity_password, cap, out_decoy)
        hid = open_container(Path(et013_dir), prv, identity_password, cap, out_hidden, profile_passphrase=hidden_passphrase)
        decoy_exact = Path(dec["output_path"]).read_bytes() == decoy_payload
        hidden_exact = Path(hid["output_path"]).read_bytes() == hidden_payload

        cap_duress = td / "EFI-duress-copy.efi"
        cap_duress.write_bytes(cap.read_bytes())
        hidden_offset_before = _slot_offset(1, backend.GUARD_KEM_CIPHERTEXT_BYTES, public_before["visible_slot_payload_bytes"])
        with cap_duress.open("rb") as f:
            f.seek(hidden_offset_before); key_material_before = f.read(backend.GUARD_KEM_CIPHERTEXT_BYTES + SLOT_SALT_BYTES + SLOT_IV_BYTES)
        out_duress = td / "out-duress"
        dur = open_container(Path(et013_dir), prv, identity_password, cap_duress, out_duress, profile_passphrase=duress_passphrase)
        duress_decoy_exact = Path(dur["output_path"]).read_bytes() == decoy_payload
        with cap_duress.open("rb") as f:
            f.seek(hidden_offset_before); key_material_after = f.read(len(key_material_before))
        public_after = public_inspect(cap_duress)
        hidden_fails_after = False
        try:
            open_container(Path(et013_dir), prv, identity_password, cap_duress, td / "after-hidden", profile_passphrase=hidden_passphrase)
        except Exception:
            hidden_fails_after = True

        wrong_non_destructive = td / "EFI-wrong-copy.efi"
        wrong_non_destructive.write_bytes(cap.read_bytes())
        wrong_hash_before = hashlib.sha256(wrong_non_destructive.read_bytes()).hexdigest()
        wrong_failed = False
        try:
            open_container(Path(et013_dir), prv, identity_password, wrong_non_destructive, td / "wrong-out", profile_passphrase="Wrong-Profile-Password-010")
        except Exception:
            wrong_failed = True
        wrong_hash_after = hashlib.sha256(wrong_non_destructive.read_bytes()).hexdigest()

        cover = td / "EFI-cover-only.efi"
        cover_report = create_container(
            Path(et013_dir), pub, decoy, cover, reserve_bytes=reserve,
            cycles=1, root_mode="standard", base_value=2, height=4, standard_steps=4,
        )
        cover_public = public_inspect(cover)

        hidden_growth_refused = False
        try:
            create_container(
                Path(et013_dir), pub, decoy, td / "should-refuse.efi", hidden_path=hidden,
                hidden_passphrase=hidden_passphrase, reserve_bytes=minimum_slot_payload_for_source(len(decoy_payload)),
                cycles=1, root_mode="standard", base_value=2, height=4, standard_steps=4,
            )
        except DeniableContainerError as exc:
            hidden_growth_refused = "will not silently enlarge" in str(exc) or "larger reserve capacity" in str(exc)

    pass_state = all([
        decoy_exact, hidden_exact, duress_decoy_exact, hidden_fails_after,
        dur.get("duress_action_performed") is True,
        key_material_before != key_material_after,
        public_before == public_after,
        not leaks, wrong_failed, wrong_hash_before == wrong_hash_after,
        public_before["visible_slot_count"] == 2,
        cover_public["visible_slot_count"] == 2,
        report["capsule_bytes"] == cover_report["capsule_bytes"], hidden_growth_refused,
    ])
    return {
        "version": VERSION,
        "status": "PASS" if pass_state else "FAIL",
        "decoy_roundtrip_exact": decoy_exact,
        "hidden_roundtrip_exact": hidden_exact,
        "duress_returns_decoy_exact": duress_decoy_exact,
        "duress_hidden_recovery_fails_after": hidden_fails_after,
        "duress_key_material_changed": key_material_before != key_material_after,
        "duress_preserves_public_geometry": public_before == public_after,
        "wrong_profile_fails": wrong_failed,
        "wrong_profile_non_destructive": wrong_hash_before == wrong_hash_after,
        "forbidden_public_tokens_found": leaks,
        "fixed_two_slots": public_before["visible_slot_count"] == 2,
        "cover_only_same_public_size": report["capsule_bytes"] == cover_report["capsule_bytes"],
        "hidden_content_cannot_silently_enlarge_public_geometry": hidden_growth_refused,
        "slot_payload_bytes": public_before["visible_slot_payload_bytes"],
        "capsule_bytes": report["capsule_bytes"],
        "argon2id": {
            "memory_kib": PROFILE_ARGON_MEMORY_KIB,
            "time_cost": PROFILE_ARGON_TIME_COST,
            "parallelism": PROFILE_ARGON_PARALLELISM,
        },
        "duress_scope": report["duress_scope"],
    }
